## 1. 基本用法

头文件：

```C++
#include <iterator>
#include <iostream>
```

构造：

```C++
std::ostream_iterator<int> out(std::cout);          // 不带分隔符
std::ostream_iterator<int> out2(std::cout, ", ");   // 带分隔符
```

典型：配合算法输出容器

```C++
#include <vector>
#include <algorithm>
#include <iterator>
#include <iostream>

int main() {
    std::vector<int> v{1,2,3,4};

    std::copy(v.begin(), v.end(),
              std::ostream_iterator<int>(std::cout, " "));
    // 输出：1 2 3 4
}
```

`std::ostream_iterator` 每写一个元素后会再写一次 delimiter（如果给了）。[en.cppreference.com+2Cplusplus.com+2](https://en.cppreference.com/w/cpp/iterator/ostream_iterator.html?utm_source=chatgpt.com)

---

## 2. 它是 Output Iterator：能做什么、不能做什么？

它是**单趟输出迭代器（single-pass LegacyOutputIterator）**。[en.cppreference.com+1](https://en.cppreference.com/w/cpp/iterator/ostream_iterator.html?utm_source=chatgpt.com)

**支持的操作：**

- `*out = value;` —— 把 value 写到流里
    
- `out = value;` —— 也行（解引用与否都触发写入）
    
- `++out; out++;` —— 允许写，但**纯 no-op**（不改变状态）
    

**不支持：**

- 读取：`*out` 得不到“元素”，它只是“写入口”
    
- 多趟：你不能在写完一遍后指望“回头重新遍历输出序列”
    

---

## 3. 底层原理：为啥“++ 是空操作”？

它的实现是个很巧的“作弊式迭代器”：

- 内部保存：
    
    - 一个 `ostream* os;`
        
    - 一个可选分隔符 `const charT* delim;`
        
- `operator*()` **返回它自己**
    
- `operator++()` **也返回它自己，不动任何状态**
    
- 真正的写入发生在 `operator=` 里：  
    `*out = x` → 调用 `(*os) << x;` 再输出 `delim`（如果有）[en.cppreference.com+2Stack Overflow+2](https://en.cppreference.com/w/cpp/iterator/ostream_iterator.html?utm_source=chatgpt.com)
    

所以你看到的典型输出模式：

`*out++ = x;`

其实等价于：

1. `out.operator*().operator=(x)` 触发输出
    
2. `out.operator++(int)` 空操作
    

这就是为什么它可以当“算法输出端口”。[en.cppreference.com+1](https://en.cppreference.com/w/cpp/iterator/ostream_iterator.html?utm_source=chatgpt.com)

---

## 4. 输出自定义类型

只要你的类型支持 `operator<<`，就能用 `ostream_iterator`。

```C++
struct Node { int id; };

std::ostream& operator<<(std::ostream& os, const Node& n) {
    return os << "Node(" << n.id << ")";
}

int main() {
    std::vector<Node> v{{1},{2},{3}};
    std::copy(v.begin(), v.end(),
              std::ostream_iterator<Node>(std::cout, "\n"));
}//第一个参数是输入到那里去
```

---

## 5. 常见应用场景

### 5.1 快速打印容器

```C++
std::copy(v.begin(), v.end(),
          std::ostream_iterator<int>(std::cout, ", "));
```

### 5.2 作为算法的输出端

比如把变换结果直接输出：

```C++
std::transform(v.begin(), v.end(),
               std::ostream_iterator<int>(std::cout, " "),
               [](int x){ return x*x; });
```

---

## 6. 容易踩的坑

1. **分隔符会在最后一个元素后也输出**  
    输入 `1 2 3` + delim `", "` → 输出 `1, 2, 3,`  
    如果你需要“最后不带分隔符”，要手动处理（比如先输出第一个，后面加 delim）。
    
2. **类型不匹配**  
    `ostream_iterator<T>` 会用 `operator<<` 输出 T。  
    如果 `T` 和容器元素类型不同，有时能隐式转换（比如 int→float），有时不行。[DevTut](https://devtut.github.io/cpp/cpp-streams.html?utm_source=chatgpt.com)
    
3. **别指望它能读取或回退**  
    它是 Output Iterator，`*out` 不是“元素引用”，只是写接口。
    

---

## 7. 和其它“特殊迭代器”的对比

- `std::ostream_iterator<T>`：按 `operator<<` 格式化输出（文本化）[en.cppreference.com+1](https://en.cppreference.com/w/cpp/iterator/ostream_iterator.html?utm_source=chatgpt.com)
    
- `std::ostreambuf_iterator<char>`：直接写原始字符到 streambuf，**更底层更快**，但不做格式化。
    
- `std::back_insert_iterator` / `back_inserter`：输出到容器尾部（不是到流）。[en.cppreference.com+1](https://en.cppreference.com/w/cpp/iterator/back_inserter.html?utm_source=chatgpt.com)
    

---

一句话记：  
`ostream_iterator` 把“输出流”伪装成一个输出迭代器，算法对它做的 `*it = x` 实际就是 `os << x`（再加分隔符），`++it` 只是走流程不做事。