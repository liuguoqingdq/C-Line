## 0. log4cpp 是什么，先有个最小认知

log4cpp 是仿照 log4j 设计的 C++ 日志库，核心组件就是 **Category（日志器）/ Appender（输出目标）/ Layout（输出格式）/ Priority（等级）**。[Log4cpp+1](https://log4cpp.sourceforge.net/?utm_source=chatgpt.com)  
你用它本质是在配置一条“日志管线”：

**Category → Appender → Layout**

---

## 1. 安装与集成

### 1.1 Linux（最省事）

多数发行版直接有包：

```bash
sudo apt-get install liblog4cpp5-dev   # Ubuntu/Debian
# 或
sudo yum install log4cpp-devel        # CentOS/RHEL（包名可能略不同）
```

编译时链接：

`g++ main.cpp -llog4cpp -o app`

### 1.2 源码/Conan（跨平台/固定版本）

Conan 中心仓库有现成 recipe（当前常见版本 1.1.x）。[conan.io](https://conan.io/center/recipes/log4cpp?utm_source=chatgpt.com)  
你用 Conan 就按它的标准流程装，然后 CMake `target_link_libraries(... log4cpp::log4cpp)`。

---

## 2. 方式 A：纯代码手动配置（最快跑起来）

适合：demo、小项目、本地实验。

```C++
#include <log4cpp/Category.hh>
#include <log4cpp/OstreamAppender.hh>
#include <log4cpp/FileAppender.hh>
#include <log4cpp/PatternLayout.hh>
#include <log4cpp/Priority.hh>
#include <iostream>

int main() {
    using namespace log4cpp;

    // 1) Layout：日志长什么样
    auto* layout1 = new PatternLayout();
    layout1->setConversionPattern("%d [%p] %c: %m%n"); 
    // %d时间 %p级别 %c类别名 %m消息 %n换行（PatternLayout 是最常用格式）:contentReference[oaicite:2]{index=2}

    auto* layout2 = new PatternLayout();
    layout2->setConversionPattern("%d [%p] %c (%f:%l): %m%n"); // 带文件/行号

    // 2) Appender：输出到哪
    auto* console = new OstreamAppender("console", &std::cout);
    console->setLayout(layout1);

    auto* file = new FileAppender("file", "app.log");
    file->setLayout(layout2);

    // 3) Category：绑定 appender + 设置级别
    Category& root = Category::getRoot();
    root.addAppender(console);
    root.addAppender(file);
    root.setPriority(Priority::INFO); // INFO及以上才输出

    // 4) 打日志
    root.debug("debug won't show");
    root.info("hello log4cpp");
    root.warn("warning");
    root.error("error happened");

    Category::shutdown(); // 推荐做收尾
}

```

**你需要记住的就两句：**

- **先配置（layout/appender/category），再 `Category::getInstance()` 打日志。**
    
- `setPriority()` 控制过滤等级。
    

---

## 3. 方式 B：配置文件驱动（工程里更推荐）

log4cpp 支持 log4j 风格 `.properties`，用 `PropertyConfigurator::configure()` 一行加载。[ROS Documentation+2Log4cpp+2](https://docs.ros.org/lunar/api/log4cpp/html/classlog4cpp_1_1PropertyConfigurator.html?utm_source=chatgpt.com)

### 3.1 写一个 `log4cpp.properties`

```C++
# 根Category：DEBUG级别，挂 console 和 roll 两个 appender
log4cpp.rootCategory=DEBUG, console, roll

# ---------- console appender ----------
log4cpp.appender.console=ConsoleAppender
log4cpp.appender.console.layout=PatternLayout
log4cpp.appender.console.layout.ConversionPattern=%d [%p] %c: %m%n

# ---------- rolling file appender ----------
log4cpp.appender.roll=RollingFileAppender
log4cpp.appender.roll.fileName=app.log
log4cpp.appender.roll.maxFileSize=10MB
log4cpp.appender.roll.maxBackupIndex=5
log4cpp.appender.roll.layout=PatternLayout
log4cpp.appender.roll.layout.ConversionPattern=%d [%p] %c (%f:%l): %m%n

# ---------- 子模块Category ----------
log4cpp.category.net=INFO
log4cpp.category.db=DEBUG

```

说明：

- `rootCategory=级别, appender1, appender2...` 的语法是官方支持的 log4j 风格。[ROS Documentation+2Log4cpp+2](https://docs.ros.org/lunar/api/log4cpp/html/classlog4cpp_1_1PropertyConfigurator.html?utm_source=chatgpt.com)
    
- RollingFileAppender 用 `maxFileSize/maxBackupIndex` 控制滚动。[PIRATLA ADITYA](https://piratlaaditya.wordpress.com/activities/logging-in-c-using-log4cpp/?utm_source=chatgpt.com)
    

### 3.2 代码里加载并使用

```C++
#include <log4cpp/PropertyConfigurator.hh>
#include <log4cpp/Category.hh>

int main() {
    log4cpp::PropertyConfigurator::configure("log4cpp.properties"); // 一行加载配置 :contentReference[oaicite:6]{index=6}

    auto& net = log4cpp::Category::getInstance("net");
    auto& db  = log4cpp::Category::getInstance("db");

    net.info("network ready");
    net.debug("this won't show because net=INFO");

    db.debug("sql executed"); // db=DEBUG 会显示

    log4cpp::Category::shutdown();
}

```

**配置文件模式的核心好处：**  
线上只改 properties 就能调日志级别/输出位置/格式，不必重新编译。

---

## 4. 常用功能怎么用

### 4.1 多 Category（按模块打日志）

```C++
auto& root = log4cpp::Category::getRoot();
auto& auth = log4cpp::Category::getInstance("auth");
auto& net  = log4cpp::Category::getInstance("net");

auth.info("login ok");
net.warn("packet loss");
```
Category 名字形成树（如 `a.b.c`），默认会继承父 Category 的 appender（additivity 语义）。[Alibaba Cloud+1](https://topic.alibabacloud.com/a/example-of-log4cpp-properties-configuration_8_8_31654572.html?utm_source=chatgpt.com)

## `Category::getRoot()`

- **返回根日志器（root category）**，是整个日志树的顶层单例。
    
- 你通常在这里：
    
    - 绑定全局 `Appender`（控制台/文件/滚动文件…）
        
    - 设置全局默认 `Priority`（INFO/WARN/DEBUG…）
        
- **所有其他 Category 默认都会继承 root 的 appender 和级别**（除非你关掉 additivity）。
    

直观理解：

> `root` = 全局默认日志出口和默认规则的“总开关”。

例子：

```C++
auto& root = log4cpp::Category::getRoot();
root.setPriority(log4cpp::Priority::INFO);
root.addAppender(consoleAppender);
root.addAppender(fileAppender);

```

---

## `Category::getInstance("name")`

- **按名字获取/创建一个子日志器**。
    
- 如果这个名字的 Category 之前没创建过，会**自动创建并挂到日志树里**；创建过就返回同一个实例（单例式复用）。
    
- 名字可以有层级，比如 `"net"`、`"db"`、`"net.p2p"`：
    
    - `"net.p2p"` 的父节点是 `"net"`，再往上是 `root`。
        
- 它继承父 Category（最终到 root）的配置：
    
    - 默认继承 appender
        
    - 默认继承级别/过滤规则  
        你也可以对它单独 `setPriority()` 或 `addAppender()`。
        

直观理解：

> `getInstance("xxx")` = 拿一个“模块专属 logger”。

例子：

```C++
auto& net = log4cpp::Category::getInstance("net");
auto& db  = log4cpp::Category::getInstance("db");

net.info("network ready");
db.debug("sql executed");
```

---

## 关键区别一句话

- **`getRoot()`：拿“全局根 logger”，设置默认出口/默认级别。**
    
- **`getInstance(name)`：拿“某个模块的 logger”，用来按模块打日志并可单独配置。**
---

### 4.2 只让某个模块写到独立文件

在 properties 里给子 Category 专门绑 appender：

```properties
log4cpp.category.auth=DEBUG, authFile
log4cpp.additivity.auth=false

log4cpp.appender.authFile=FileAppender
log4cpp.appender.authFile.fileName=auth.log
log4cpp.appender.authFile.layout=PatternLayout
log4cpp.appender.authFile.layout.ConversionPattern=%d [%p] %c: %m%n
```

- `additivity=false` 表示子 Category 不再继承 root 的 appender，只输出自己的。[Cnblogs](https://www.cnblogs.com/diegodu/p/6100804.html?utm_source=chatgpt.com)
    

---

### 4.3 使用 printf 风格接口（可选）

log4cpp 有 `info/debug` 的流式接口，也支持 `printf` 风格（部分版本/封装里常用）[Alibaba Cloud+1](https://topic.alibabacloud.com/a/example-of-log4cpp-properties-configuration_8_8_31654572.html?utm_source=chatgpt.com)：

`root.info("value=%d, name=%s", x, name.c_str());`

---

## 5. 最佳实践（避免你踩坑）

1. **统一入口**：写一个全局初始化函数  
    程序启动就 `configure()`，结束 `shutdown()`。[Log4cpp+1](https://log4cpp.sourceforge.net/api/classlog4cpp_1_1PropertyConfigurator.html?utm_source=chatgpt.com)
    
2. **线上默认 INFO 或 WARN**  
    DEBUG 量大时会拖慢 IO（写磁盘/控制台本来就慢）。[Zhihu](https://zhuanlan.zhihu.com/p/549927891?utm_source=chatgpt.com)
    
3. **不要重复 configure / 重复 addAppender**  
    否则一条日志会打印多次（典型坑）。[Alibaba Cloud](https://topic.alibabacloud.com/a/example-of-log4cpp-properties-configuration_8_8_31654572.html?utm_source=chatgpt.com)
    
4. **文件路径要想清楚**  
    `app.log` 的相对路径是“进程启动目录”，别以为是源码目录。
    
5. **多线程没问题，但要控制日志量**  
    log4cpp 是线程安全的，但吞吐取决于 IO，别在热路径刷 debug。[Log4cpp+1](https://log4cpp.sourceforge.net/?utm_source=chatgpt.com)
    

---

## 6. 你照着做的最短 checklist

1. `#include <sstream>` 不对，log4cpp 需要 `#include <log4cpp/...>`
    
2. 写 `log4cpp.properties`
    
3. `PropertyConfigurator::configure("log4cpp.properties");`
    
4. `Category::getInstance("xxx").info("msg");`
    
5. 结束时 `Category::shutdown();`