*`前言回顾`* ：
内存池的几个类型：
```C++
// -------------------------------------------------------------
// 内部数据结构：Chunk + Node
// -------------------------------------------------------------
struct Chunk;
// Node 表示池中的一个“槽位”：包含一个 T 的存储空间 + 元信息
struct Node {
Node* next_free; // 空闲链表指针
Chunk* owner; // 指向所属 Chunk
// 真正放 T 对象的地方：只提供原始字节，不自动构造/析构
alignas(T) unsigned char storage[sizeof(T)];//用alignas对齐
};
// 一个 Chunk 是一块大内存，里面包含若干 Node
struct Chunk {
Chunk* next_chunk; // 所有 Chunk 组成链表（主要为了调试 / 统计）
std::size_t capacity; // 该 Chunk 拆成多少个 Node
std::size_t live; // 当前有多少 Node “在用”（被 allocate 出去）
// Node 实际上紧跟在 Chunk 之后顺序排布，我们用指针指向开头
Node* nodes;
};

// --- 静态成员：per T 的全局 free list 和 chunk list（非线程安全） --
static Node* s_free_list; // 所有空闲 Node 构成的链表
static Chunk* s_chunks; // 所有 Chunk 构成的链表（可选）
```
![[Pasted image 20251130203057.png]]
整体内存逻辑布局如图所示
##### `也就是说，物理上，这些node属于chunk，但是逻辑上又有一条链把他们这些空闲的node串在一起，同时chunk又有一条链`

分配单个的策略：
```C++
static pointer allocate_one() {
if (!s_free_list) {
// 池子空了，向 OS 申请一个新的 Chunk
add_chunk();
}
// 从 free list 头取一个 Node
Node* node = s_free_list;
s_free_list = node->next_free;
// 更新所属 Chunk 的 live 计数
++node->owner->live;
// 把 Node 的 storage 视作 T* 返回
return reinterpret_cast<pointer>(node->storage);
/*
### 为啥不能 `static_cast<T*>(node->storage)`？

因为 **`static_cast` 不允许在无关指针类型之间随便转**。

规则大致是（简化版）：

- 可以 static_cast：
    
    - `T*` → `void*`
        
    - `void*` → `T*`
        
    - 指向**同一继承体系**里基类/派生类的指针（有一定限制）
        
- 不能 static_cast：
    
    - `unsigned char*` ↔ `int*`
        
    - `unsigned char*` ↔ `MyStruct*`
        
    - **也就是：两个毫无继承关系的对象指针之间不能用 static_cast 直接转**
*/
```
首先如果池子空了会调用add_chunk函数：
```C++
// -------------------------------------------------------------

// 新建一个 4KB Chunk，拆成若干 Node，全部挂入 free_list

// -------------------------------------------------------------

static void add_chunk() {
std::size_t bytes = CHUNK_SIZE;//4096B
// 1. 向 OS 申请一块原始内存
unsigned char* raw = static_cast<unsigned char*>(::operator new(bytes));
// 2. 在这块内存头部“原地构造”一个 Chunk 头

Chunk* chunk = new (raw) Chunk;

chunk->next_chunk = s_chunks;

chunk->capacity = 0;

chunk->live = 0;

chunk->nodes = nullptr;
s_chunks = chunk;

// 3. 剩余空间用来放 Node 数组
std::size_t space = bytes - sizeof(Chunk);
void* ptr = raw + sizeof(Chunk);

// 让 Node 对齐到 alignof(Node)
void* aligned = std::align(alignof(Node), sizeof(Node), ptr, space);
if (!aligned || space < sizeof(Node)) {
// 对齐失败或空间太小，直接抛异常
throw std::bad_alloc();

}

unsigned char* node_mem = static_cast<unsigned char*>(aligned);
std::size_t node_count = space / sizeof(Node);

chunk->capacity = node_count;
chunk->nodes = reinterpret_cast<Node*>(node_mem);

std::cout << "[ChunkPoolAllocator] new Chunk @ " << chunk
<< ", nodes = " << node_count << "\n";

// 4. 在这块区域里“原地构造”一个个 Node，并全部挂到 free_list
for (std::size_t i = 0; i < node_count; ++i) {
unsigned char* p = node_mem + i * sizeof(Node);
Node* node = new (p) Node;
node->owner = chunk;
node->next_free = s_free_list;
s_free_list = node;

}
}
};
```
指针指向一段内存空间的起始地址，而指针的类型决定偏移量或者说，观察视角的单位。
```lua
提示词：
根据上述代码完成一个html网页用来展示内存池内存分配的过程
1.用这两句代码申请一块大小为CHUNK——SIZE大小的堆空间：
std::size_t bytes = CHUNK_SIZE;//4096B
// 1. 向 OS 申请一块原始内存
unsigned char* raw = static_cast<unsigned char*>(::operator new(bytes));

2.接着用下述代码在这块内存中构造一个chunk，并初始化：
Chunk* chunk = new (raw) Chunk;

chunk->next_chunk = s_chunks;

chunk->capacity = 0;

chunk->live = 0;

chunk->nodes = nullptr;
s_chunks = chunk;
3.用下述代码来对齐剩余空间：
std::size_t space = bytes - sizeof(Chunk);
void* ptr = raw + sizeof(Chunk);

// 让 Node 对齐到 alignof(Node)
void* aligned = std::align(alignof(Node), sizeof(Node), ptr, space);
if (!aligned || space < sizeof(Node)) {
// 对齐失败或空间太小，直接抛异常
throw std::bad_alloc();

}
4.用下述代码创造一个指针，把它移动到对齐后的内存起始地址，并且计算能划分多少个node
unsigned char* node_mem = static_cast<unsigned char*>(aligned);
std::size_t node_count = space / sizeof(Node);

chunk->capacity = node_count;
chunk->nodes = reinterpret_cast<Node*>(node_mem);

std::cout << "[ChunkPoolAllocator] new Chunk @ " << chunk
<< ", nodes = " << node_count << "\n";

5.用下述代码在这块区域里“原地构造”一个个 Node，并全部挂到 free_list：
for (std::size_t i = 0; i < node_count; ++i) {
unsigned char* p = node_mem + i * sizeof(Node);
Node* node = new (p) Node;
node->owner = chunk;
node->next_free = s_free_list;
s_free_list = node;

}
```
