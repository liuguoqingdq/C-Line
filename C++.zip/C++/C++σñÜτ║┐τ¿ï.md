# 目录

1. 多线程的目标与风险
    
2. `std::thread` 基础：创建/参数/生命周期
    
3. 数据竞争与 C++ 内存模型（happens-before）
    
4. 互斥与 RAII 锁体系
    
5. 条件变量与生产者-消费者
    
6. 原子与内存序（从易到难）
    
7. 高层异步：future / promise / async / packaged_task
    
8. C++20/23 并发新工具：jthread / stop_token / latch / barrier / semaphore
    
9. 常见并发模式：线程池、任务队列、读写优化、无锁思路
    
10. 性能与正确性调优：锁粒度、惊群、伪共享、死锁排查
    
11. 并发设计清单（你写工程时照着检查）
    

---

# 1. 多线程的目标与风险
[[C++多线程的目标与风险]]

### 1.1 为什么要多线程

- 提升吞吐（多核并行）
    
- 降低延迟（IO 与计算重叠）
    
- 解耦任务（生产者/消费者、流水线）
    

### 1.2 多线程的核心风险

- **数据竞争 data race（UB）**
    
- **死锁 deadlock**
    
- **活锁/饥饿 livelock/starvation**
    
- **性能崩坏：锁竞争、惊群、伪共享**
    

并发的第一原则：

> **只有“共享可变状态”才需要同步。**  
> 不共享 / 不可变 / thread-local / 消息传递 → 能免锁就免锁。

---

# 2. `std::thread` 基础
[[C++thread基础]]
## 2.1 创建线程

```C++
#include <thread>

void worker(int id) {
    // ...
}

int main() {
    std::thread t(worker, 1);
    t.join();
}
```

- 构造 `std::thread` 就启动线程。
    
- 线程对象**可移动不可复制**。
    

## 2.2 参数传递规则（非常重要）

默认是**值拷贝**：

```C++
void f(std::vector<int> v); // 复制一份

std::vector<int> big;
std::thread t(f, big);      // big 被拷贝到子线程
```

要传引用必须 `std::ref`：

```C++
void g(std::vector<int>& v);

std::vector<int> v;
std::thread t(g, std::ref(v));  // 传引用
```

## 2.3 `join()` vs `detach()`

- `join()`：主线程等待子线程结束（推荐默认）
    
- `detach()`：子线程后台跑，主线程不再管理
    

```C++
std::thread t(worker);
t.detach();
```

**硬规则：**

> `std::thread` 析构时如果仍 joinable → `std::terminate()`。  
> 所以你必须 join 或 detach。

## 2.4 线程 ID 与硬件并行度

```C++
auto id = std::this_thread::get_id();
unsigned n = std::thread::hardware_concurrency(); // 可能为 0
```

---

# 3. 数据竞争与 C++ 内存模型
[[C++数据竞争与内存模型]]
## 3.1 data race 定义

> 两个线程**同时访问同一对象**，且至少一个是写，且**没有同步**  
> → data race → **未定义行为 UB**。

UB 不是“偶尔错”，是“编译器可随便优化到你崩”。

## 3.2 happens-before（你要掌握的最小集合）

同步原语建立可见性顺序：

- `mutex.unlock()` = **release**
    
- `mutex.lock()` = **acquire**
    

所以：

> A 线程 unlock 前的写，  
> 对 B 线程 lock 后的读可见。

条件变量、原子（acquire/release）也建立 happens-before。  
**没有 happens-before 就没有跨线程一致性保证。**

---

# 4. 互斥与 RAII 锁体系

## 4.1 `std::mutex`：最基本互斥

```C++
std::mutex m;
int x = 0;

void inc() {
    std::lock_guard<std::mutex> lk(m);
    ++x;
}
```

### 为什么必须 RAII？

- 异常/早返回也能解锁
    
- 避免手写 lock/unlock 漏掉
    

## 4.2 三种主力锁封装

### `lock_guard`（最轻量）

- 进入作用域就锁，离开就解
    
- 无 try/timed/提前 unlock
    
- **默认优先使用**
    
[[C++lock_guard]]
`std::lock_guard lk(m);`

### `unique_lock`（可控）

- defer / try / timed / 提前 unlock / move
    
- 条件变量必须用它
    
[[C++unique_lock]]
```C++
std::unique_lock lk(m);
lk.unlock();
// ...
lk.lock();
```

### `scoped_lock`（多锁无死锁 C++17）

```C++
std::scoped_lock lk(m1, m2, m3);
```

## 4.3 读写锁 `shared_mutex`

读多写少时提升并发度：
[[C++ shared_mutex]]
```C++
std::shared_mutex sm;

void reader() {
    std::shared_lock lk(sm);
    // read
}

void writer() {
    std::unique_lock lk(sm);
    // write
}
```

注意写者饥饿风险：读锁要短。

---

# 5. 条件变量（线程协作）

## 5.1 标准正确模板：生产者-消费者

```C++
std::mutex m;
std::condition_variable cv;
std::queue<int> q;

void producer(int v) {
    {
        std::lock_guard lk(m);
        q.push(v);
    }           // 锁内更新共享状态
    cv.notify_one(); // 锁外唤醒更高效
}

int consumer() {
    std::unique_lock lk(m);
    cv.wait(lk, [&]{ return !q.empty(); }); // 必须谓词！
    int v = q.front(); q.pop();
    return v;
}
```
[[C++condition_variable]]
[[C++生产者消费者模型]]
**金科玉律：**

1. 锁内改状态
    
2. 锁外 notify
    
3. wait 必须谓词/while（防虚假唤醒与丢失唤醒）
    

## 5.2 `notify_one` vs `notify_all`

- `notify_one`：只唤醒一个线程（优先）
    
- `notify_all`：全唤醒 → 惊群效应（必要时用）
    

---

# 6. 原子与内存序

## 6.1 什么时候用 atomic？

- 单变量计数/标志位
    
- 无锁结构组件
    

多变量不变式 → 用 mutex。

## 6.2 最常用内存序

### relaxed（只保证原子性）

```C++
cnt.fetch_add(1, std::memory_order_relaxed);
```

用于统计/计数，不建立跨线程顺序。

### acquire/release（发布-订阅）

```C++
// writer:
flag.store(true, std::memory_order_release);

// reader:
if (flag.load(std::memory_order_acquire)) {
    // 能看到 writer 之前的写
}
```

### seq_cst（最强最慢）

不确定时用，但别滥用热路径。

---

# 7. 高层异步抽象

多线程不一定要你手写线程。高层抽象更安全。

## 7.1 `std::future` / `std::async`

```C++
auto fut = std::async(std::launch::async, []{
    return heavy();
});
int r = fut.get(); // 阻塞等待结果
```

`launch::async` 强制新线程；不加可能延迟执行。

## 7.2 `promise` / `future`

线程之间传结果：

```C++
std::promise<int> p;
std::future<int> f = p.get_future();

std::thread t([pp = std::move(p)]() mutable {
    pp.set_value(42);
});

int v = f.get();
t.join();
```

## 7.3 `packaged_task`

把可调用对象包装成异步任务：

```C++
std::packaged_task<int()> task([]{ return work(); });
auto fut = task.get_future();
std::thread t(std::move(task));
int r = fut.get();
t.join();
```

---

# 8. C++20/23 并发新工具

## 8.1 `std::jthread`（自动 join + 可停止）

C++20 推荐代替 `std::thread`：
[[C++20-23的并发新工具]]
```C++
std::jthread jt([](std::stop_token st){
    while(!st.stop_requested()) {
        // ...
    }
}); // 析构自动 join
```

无需担心忘 join 导致 terminate。

## 8.2 `stop_token` 协作式停止

比共享 atomic flag 更正规。

## 8.3 `latch`（一次性倒计时门闩）

例如等待 N 个线程准备完成：

```C++
std::latch ready(n);

for (...) {
    std::jthread([&]{
        init();
        ready.count_down();
        ready.wait(); // 所有人准备好再继续
        run();
    });
}
```

## 8.4 `barrier`（可循环的同步栅栏）

每一轮都等所有线程到达：

```C++
std::barrier sync(n);

std::jthread([&]{
    while (rounds--) {
        do_phase1();
        sync.arrive_and_wait();
        do_phase2();
        sync.arrive_and_wait();
    }
});
```

## 8.5 `counting_semaphore`（信号量）

控制并发数量（比如连接/资源池）：

```C++
std::counting_semaphore<10> sem(10);

void task() {
    sem.acquire();
    // use resource
    sem.release();
}
```

---

# 9. 典型并发模式（工程必备）

## 9.1 线程池（核心模板）
[[C++ 线程池]]
固定 N 工作者 + 任务队列 + cv：

```C++
class ThreadPool {
    std::vector<std::jthread> workers;
    std::queue<std::function<void()>> tasks;
    std::mutex m;
    std::condition_variable cv;
    bool stop = false;

public:
    ThreadPool(size_t n) {
        for(size_t i=0;i<n;i++){
            workers.emplace_back([this](std::stop_token st){
                while(true){
                    std::function<void()> task;
                    {
                        std::unique_lock lk(m);
                        cv.wait(lk, [&]{ return stop || !tasks.empty(); });
                        if (stop && tasks.empty()) return;
                        task = std::move(tasks.front());
                        tasks.pop();
                    }
                    task();
                }
            });
        }
    }

    void submit(std::function<void()> f){
        {
            std::lock_guard lk(m);
            tasks.push(std::move(f));
        }
        cv.notify_one();
    }

    ~ThreadPool(){
        {
            std::lock_guard lk(m);
            stop = true;
        }
        cv.notify_all();
        // jthread 自动 join
    }
};
```

## 9.2 读多写少优化：共享锁 + 快照

读锁内只复制，锁外重活。

## 9.3 无锁思路（入门）

- 先用原子做“队列长度/状态”
    
- 数据结构仍可锁保护（混合策略）
    
- 真无锁结构难度大，慢慢来
    

---

# 10. 性能与正确性调优
[[C++多线程性能与正确性调优]]
## 10.1 锁粒度

- 粗锁简单，但吞吐低
    
- 细锁提高并发，但复杂、死锁风险更高  
    **先粗后细**是正确路线。
    

## 10.2 临界区要短

锁内只做共享状态更新：

- 禁止 IO / sleep / 大计算
    

## 10.3 惊群效应

`notify_all` / 广播式唤醒会导致大量线程争锁又睡回去。  
能 one 就 one。

## 10.4 伪共享（false sharing）

多个线程写同一 cache line 会抖动性能。  
解决：

- 结构体 padding / `alignas(64)`
    
- 分桶计数
    

## 10.5 死锁排查四原则

1. 固定锁顺序
    
2. 多锁用 `scoped_lock/std::lock`
    
3. 少持锁等待外部事件
    
4. 尽量减少嵌套锁
    

---

# 11. 并发设计检查清单（写工程时照着扫一遍）

1. **共享可变状态在哪里？**
    
2. 每个共享状态**由哪把锁/原子保护？**
    
3. 是否存在**嵌套锁 / 交叉锁顺序？**
    
4. 临界区内是否有**慢操作？**
    
5. `wait` 是否 **带谓词循环？**
    
6. `notify_one/all` 是否合理？
    
7. shared_ptr 是否形成**环？（weak_ptr 断开）**
    
8. 读多写少是否可用**shared_mutex/快照化？**
    
9. 是否有伪共享热点？
    
10. 是否能用 **jthread + stop_token** 简化生命周期？