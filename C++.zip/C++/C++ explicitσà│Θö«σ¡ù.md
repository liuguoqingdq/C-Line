## 1. `explicit` 修饰构造函数：禁止隐式构造

### 1.1 经典问题：单参数构造函数会变成“隐式转换”

```C++
struct A {
    A(int x) { }   // 没写 explicit
};

void f(A a) {}

int main() {
    A a1 = 3;   // ✅ 允许：3 被隐式转换成 A
    f(3);       // ✅ 允许：参数处发生隐式构造
}
```

这里 `A(int)` 既是构造函数，又被当成 “int -> A” 的隐式转换通道。

### 1.2 加上 `explicit` 后

```C++
struct A {
    explicit A(int x) { }
};

void f(A a) {}

int main() {
    // A a1 = 3;   // ❌ 编译错误：禁止隐式转换（拷贝初始化）
    A a2(3);       // ✅ 直接初始化 ok
    A a3{3};       // ✅ 直接列表初始化 ok

    // f(3);       // ❌ 编译错误
    f(A(3));       // ✅ 必须显式构造
}
```

**关键区别：**

- `A a = 3;` 这种叫**拷贝初始化（copy initialization）**，会用到隐式转换 → 被 `explicit` 禁掉。
    
- `A a(3);` / `A a{3};` 叫**直接初始化（direct initialization）** → 允许。
    

> 记忆：  
> **explicit 禁拷贝初始化，不禁直接初始化。**

---

## 2. `explicit` 修饰转换运算符（C++11 起）

### 2.1 不写 `explicit` 的风险

```C++
struct BoolLike {
    operator bool() const { return true; }  // 隐式转 bool
};

int main() {
    BoolLike x;
    int a = x + 1;  // ✅ 可以：x -> bool -> int，可能不是你想要的
}
```

### 2.2 写上 `explicit` 后

```C++
struct BoolLike {
    explicit operator bool() const { return true; }
};

int main() {
    BoolLike x;
    // int a = x + 1;  // ❌ 不允许隐式转 bool

    if (x) { }              // ✅ 允许（上下文转换）
    bool b = static_cast<bool>(x);  // ✅ 显式转换
}
```

**注意：**  
`explicit operator bool()` 仍允许在 `if/while/for/?:/!` 这种**布尔语境**里使用（叫 _contextual conversion to bool_），但禁止别的隐式链式转换。

---

## 3. 更现代的形式：`explicit(bool)`（C++20）

你可以让构造函数“**有条件 explicit**”：

```C++
template<class T>
struct Vec {
    explicit(!std::is_integral_v<T>)
    Vec(T n) { /*...*/ }
};
```

- 当 `T` 不是整数时，构造函数是 explicit（禁隐式）
    
- 当 `T` 是整数时，不 explicit（允许隐式）
    

这种常见于模板库里做“更精细的转换控制”。

---

## 4. 什么时候该用 `explicit`？

### 4.1 **几乎所有单参数构造函数都建议 explicit**

尤其是可能产生歧义/危险转换的类型：

```C++
struct Seconds {
    explicit Seconds(double s) : s(s) {}
    double s;
};
```

避免这种错误：

`void sleep(Seconds s);  sleep(5);   // 你真是想 5 秒吗？还是 5 毫秒/5 帧？`

### 4.2 例外：你**确实希望**它像“自然转换”

比如 `std::string` 的 `const char*` 构造不是 explicit，因为你常常写：

`std::string s = "hi";`

若写成 explicit，会让日常代码变得很啰嗦。

---

## 5. 一个小表总结

| 场景                           | 没 explicit | 有 explicit      |
| ---------------------------- | ---------- | --------------- |
| `A a = 3;`                   | ✅ 允许隐式构造   | ❌ 禁止            |
| `A a(3);`                    | ✅          | ✅               |
| `A a{3};`                    | ✅          | ✅               |
| `f(3)`（形参是 A）                | ✅          | ❌ 必须写 `f(A(3))` |
| `operator bool()` 用在算术/赋值    | ✅          | ❌               |
| `operator bool()` 用在 `if(x)` | ✅          | ✅               |
