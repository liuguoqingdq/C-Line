它的作用很简单：**定义“当智能指针销毁时，应该如何释放它所持有的资源”。**

虽然默认的删除器只是调用 `delete ptr;`，但在处理**非内存资源**（如文件句柄、Socket、互斥锁）或**第三方 C 语言库**（如 `malloc`/`free`，OpenSSL 对象）时，自定义删除器是必须的。

---

### 1. 两大智能指针的删除器区别

这是面试和实战中的关键点：

|**特性**|**std::unique_ptr**|**std::shared_ptr**|
|---|---|---|
|**定义位置**|**在模板类型中**<br><br>  <br><br>`unique_ptr<T, DeleterType>`|**在构造函数中**<br><br>  <br><br>`shared_ptr<T>(ptr, deleter)`|
|**类型绑定**|删除器类型是对象类型的一部分|删除器类型被**擦除**（Type Erasure）|
|**对象大小**|极小（若使用 Lambda/Functor，通常等于裸指针大小）|较大（通常是裸指针的 2 倍，删除器存放在控制块中）|
|**性能**|静态绑定，编译器可内联优化，极快|动态绑定（通过虚函数或函数指针调用），稍慢|

---

### 2. 实战代码示例

我为你编写了一个涵盖三种常见场景的完整示例。

C++

```C++
#include <iostream>
#include <memory>
#include <cstdio>  // for FILE*, fclose
#include <functional>

// 一个模拟的资源类
class MyResource {
public:
    void say() { std::cout << "Using resource...\n"; }
    ~MyResource() { std::cout << "MyResource Destructor (Default)\n"; }
};

// ==========================================
// 场景 1: 使用仿函数 (Functor)
// 优点：无状态的仿函数不会增加 unique_ptr 的大小 (EBO 优化)
// ==========================================
struct MyDeleter {
    void operator()(MyResource* ptr) const {
        std::cout << "[Custom Deleter] Closing resource via Functor...\n";
        delete ptr;
    }
};

// ==========================================
// 场景 2: 传统的 C 语言函数
// ==========================================
void free_legacy_resource(int* p) {
    std::cout << "[Legacy C] Freeing int pointer...\n";
    free(p);
}

int main() {
    // ---------------------------------------------------------
    // 1. std::unique_ptr 自定义删除器
    // ---------------------------------------------------------
    std::cout << "=== 1. unique_ptr with Functor ===\n";
    {
        // 类型中必须包含删除器的类型
        std::unique_ptr<MyResource, MyDeleter> p1(new MyResource());
        p1->say();
        
        // 验证大小：无状态的 deleter 不会增加 unique_ptr 的大小
        static_assert(sizeof(p1) == sizeof(void*), "Size should be equal to raw pointer");
    } // p1 离开作用域，调用 MyDeleter

    std::cout << "\n=== 2. unique_ptr with Lambda ===\n";
    {
        // 这种写法需要 decltype，稍微繁琐，但在现代 C++ 中很常见
        auto lambda_del = [](MyResource* ptr) {
            std::cout << "[Lambda Deleter] Zapping resource...\n";
            delete ptr;
        };

        // 注意：lambda 的类型必须写在模板参数里
        std::unique_ptr<MyResource, decltype(lambda_del)> p2(new MyResource(), lambda_del);
    }

    // ---------------------------------------------------------
    // 3. std::shared_ptr 自定义删除器
    // ---------------------------------------------------------
    std::cout << "\n=== 3. shared_ptr (最灵活) ===\n";
    {
        // shared_ptr 不需要把删除器类型写在模板里！
        // 它可以轻松接纳任何可调用对象
        std::shared_ptr<MyResource> sp(new MyResource(), [](MyResource* p) {
            std::cout << "[Shared Deleter] Cleaning up...\n";
            delete p;
        });
        
        // 这里的类型依然是 shared_ptr<MyResource>，没有变脏
    }

    // ---------------------------------------------------------
    // 4. 实战：管理 C 语言资源 (FILE*)
    // ---------------------------------------------------------
    std::cout << "\n=== 4. 实战：自动关闭文件 (RAII) ===\n";
    {
        // 打开文件，并指定 fclose 为删除器
        // 这样即使发生异常，文件也会自动关闭
        std::unique_ptr<FILE, decltype(&std::fclose)> filePtr(
            std::fopen("test_deleter.txt", "w"), 
            &std::fclose
        );

        if (filePtr) {
            std::fputs("Hello Deleter!", filePtr.get());
            std::cout << "File written.\n";
        }
    } // 自动调用 fclose(filePtr)

    return 0;
}
```

### 3. 深度解析：为什么 unique_ptr 的设计这么麻烦？

你可能会问：_为什么 `unique_ptr` 需要把删除器类型写在 `< >` 里，而 `shared_ptr` 不用？_

这是为了**性能**和**零开销原则 (Zero Overhead Principle)**。

#### `unique_ptr` 的逻辑 (EBO 优化)

如果你写 `std::unique_ptr<T, MyDeleter>`，而 `MyDeleter` 是一个空的结构体（没有成员变量，只有函数调用），C++ 编译器会利用 **空基类优化 (Empty Base Optimization, EBO)**。

- 结果：`sizeof(unique_ptr)` **严格等于** `sizeof(void*)`。
    
- 它就像裸指针一样小，一样快，但是具备了 RAII 功能。
    

#### `shared_ptr` 的逻辑 (类型擦除)

`shared_ptr` 内部已经有一个指向堆内存的“控制块”（Control Block，存放引用计数）。

- 当你传入一个删除器时，这个删除器被拷贝到了“控制块”里。
    
- `shared_ptr` 通过虚函数或者函数指针间接调用删除器。
    
- 代价：稍微多一点的内存占用和一次间接调用的开销，换取了极大的灵活性（不同删除器的 `shared_ptr` 可以互相赋值）。
    

### 4. 什么时候必须用自定义删除器？

1. **C 语言 API 交互**：
    
    - `FILE*` -> `fclose`
        
    - `SDL_Surface*` -> `SDL_FreeSurface`
        
    - `SSL*` -> `SSL_free`
        
2. **对象池 (Object Pool)**：
    
    - 删除器不执行 `delete`，而是把对象“归还”给对象池队列。
        
3. **共享内存 / Mmap**：
    
    - 需要调用系统特定的 `unmap` 函数而不是 `delete`。