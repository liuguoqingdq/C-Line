## 1. `propagate_on_container_move_assignment`

> “当容器做 **移动赋值**（`a = std::move(b);`）时，  
> allocator 要不要也从 `b` 移到 `a` 上？”

设：

```C++
std::vector<int, ChunkPoolAllocator<int>> a, b;
```

- 如果 `propagate_on_container_move_assignment == std::true_type`：
    
    容器在做 `a = std::move(b);` 时，会**连同 allocator 一起 move 过去**，就像：
    
    `a.alloc_ = std::move(b.alloc_); a.ptr_   = b.ptr_; b.ptr_   = nullptr;`
    
    也就是说，“哪块内存是哪个 allocator 分配的，之后还是由同一个 allocator 回收”，  
    能保证 **真正 O(1)、noexcept 的快移动**。
    
- 如果是 `std::false_type`（默认情况）：
    
    - move assignment 时 **allocator 不变**，`a` 继续用自己的 allocator；
        
    - 容器为了不出现“用 A 分配，用 B 回收”的情况，必须做**元素级别的移动 / 重新分配**；
        
    - 这样 `a = std::move(b)` 可能变成 O(n) 且会抛异常。
        

你这里设成 `true`，就是告诉容器：

> “我这个 allocator 是可以安全地跟着容器一起移动的，你放心把 allocator 也 move 过去，做最快的 move assignment。”

---

## 2. `propagate_on_container_swap`

> “当容器做 **swap**（`a.swap(b); std::swap(a,b);`）时，  
> allocator 要不要也一起 swap？”

- `true`：交换容器时，**连 allocator 也一起交换**：
    
    ```C++
    std::swap(a.alloc_, b.alloc_);
	std::swap(a.ptr_,   b.ptr_);
    ```
    
    这样“谁分配的内存，最后还是谁回收”，  
    容器可以放心地 O(1) 交换内部指针。
    
- `false`（默认）：  
    容器 swap 时**不换 allocator**，只换数据指针：
    
    - 如果两个 allocator 类型相同且 compare equal，也许还能常数 swap；
        
    - 如果 allocator 不相等，很多标准容器要么做慢版 swap（元素级别），要么行为受限（实现要做很多判断）。
        

你设成 `true`，意思是：

> “两个容器 swap 的时候，可以把 allocator 一起换了，  
> 不用担心哪块内存最后谁负责回收。”

---

## 3. `is_always_equal`

> “**同类型的 allocator 对象是不是可以看成永远‘等价’**？”

- `std::true_type`：表示
    
    > “**只要 allocator 类型一样，就当它们永远是 equal**，随便换、随便拷，没关系。”
    
    对容器的意义：
    
    - 不用费劲比较 `a.get_allocator() == b.get_allocator()`；
        
    - 即使两个 allocator 对象是不同实例，也可以假设它们可以互相回收对方的内存；
        
    - 很多地方可以直接走“快路径”，例如 move / swap 可以大胆偷指针。
        
- `std::false_type`：表示这个 allocator **可能有重要状态**（比如从哪个内存池、哪个 NUMA 节点、哪个堆区分配），不同实例不能乱用彼此的内存，需要更小心地对待 move/swap/copy。
    

你这里设成 `true`，其实是在宣称：

> “`ChunkPoolAllocator<T>` 是一个完全‘无状态’或者‘状态无关’的 allocator，  
> 所有这个类型的实例都是等价的，可以互相回收对方分配的内存。”

结合前两个：

```C++
using propagate_on_container_move_assignment = std::true_type;
using propagate_on_container_swap            = std::true_type;
using is_always_equal                        = std::true_type;
```

总体意思就是向标准容器发出一个强信号：

> “我这个 allocator：
> 
> - 可以在 **move 赋值** 时一起移动；
>     
> - 可以在 **swap** 时一起交换；
>     
> - 同类型实例之间是 **完全等价** 的，不用担心‘谁分配谁回收’的问题。
>     
> 
> 所以你大胆用最快的 move / swap 实现就行，不用搞慢路径。”

这也是写这类“全局静态内存池 allocator”的典型配置：  
内部真正的“状态”其实都在 `static` 池子里，allocator 对象本身是“空壳”，所以设成全 `true` 最省事。