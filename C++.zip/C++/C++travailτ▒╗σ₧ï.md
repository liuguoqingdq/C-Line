## 1. trivial / trivially copyable 类型：为什么能直接 memcpy？

### 1.1 概念：什么算 trivial / trivially copyable？

标准里有一堆分类，你可以先只记两个：

- **Trivially destructible**：析构函数是“平凡的”（trivial），编译器不需要做任何事；
    
- **Trivially copyable**：可以通过**按字节拷贝**（bitwise copy）来完成拷贝，不会破坏语义。
    

C++ 标准库提供对应的 type traits：

```C++
std::is_trivially_copyable<T>::value 
std::is_trivially_destructible<T>::value
```
典型 trivially copyable 的例子：

- 内置标量：`int`, `double`, `char`, `bool`, 指针 `T*`；
    
- 只包含这些成员且没有自定义构造/析构/拷贝的简单 struct，例如：
    
    `struct Vec3 {     float x, y, z; }; // 没有自定义构造/析构/拷贝/赋值，通常是 trivially copyable`
    

这类类型的特点：  
**对象的“状态”就是那一片原始内存的比特位，按字节搬过去就等效于拷贝/移动。**

---

### 1.2 为什么可以用 `memcpy` / `memmove` 优化搬移？

假设你有：

`struct P { int x; double y; }; std::vector<P> v; // ...`

当 `v` 扩容时，需要把旧内存里的元素搬到新内存：

- 如果 `P` 是 `trivially_copyable`，那么
    
    `std::memmove(new_mem, old_mem, sizeof(P) * size);`
    
    就等价于对每个元素做拷贝构造 + 析构，而且**更快**（一次大块内存搬运，CPU cache 友好，库实现可以用 SIMD/汇编优化）。
    
- 对 `int` / `double` / `指针` 等更是如此：  
    它们根本没什么“构造逻辑”，只要那几字节的数据过去就行。
    

标准库实现通常会做这种优化：

`if (std::is_trivially_copyable<T>::value) {     // 用 memmove/memcpy 搬 } else {     // 对每个元素调用 T 的拷贝/移动构造 }`

**关键点：**

> 对 trivially copyable 类型，  
> “拷贝构造/析构”可以视为 no-op + 按字节拷贝，  
> 所以 vector 可以放心用 `memmove` 来搬家，速度非常高。

---

## 2. 非 trivial 类型（如 `std::string`）：为什么必须调用构造/析构/移动？

### 2.1 `std::string` 里面藏了一堆资源

一个 `std::string` 一般内部是类似这样的结构（简化）：

```C++
class string {
    char*  data_;
    size_t size_;
    size_t capacity_;
    // 还有 SSO、小 buffer 优化等实现细节
};

```

它的真正字符数据是在 **堆上** 的 buffer 里，`data_` 只是个指向这块内存的指针。  
而且：

- 构造函数可能会分配内存、拷贝初始字符串；
    
- 析构函数负责释放这块内存；
    
- 拷贝构造函数，需要**深拷贝**（新分一块 buffer，拷贝内容），  
    不能简单把指针按字节拷过去。
    

所以如果你对 `std::string` 做 `memcpy`：

```C++
std::string s1 = "hello";
std::string s2;

std::memcpy(&s2, &s1, sizeof(std::string));  // 野路子

```

结果就是：

- `s1` 和 `s2` 持有**同一个** `data_` 指针；
    
- 析构时两个 string 都要 `delete[] data_` 一次 → 双重释放，未定义行为。
    

因此，标准明确规定：  
**`std::string` 不是 trivially copyable / trivially destructible**。

---

### 2.2 vector 遇到非 trivial 类型必须这么做

`std::vector<std::string>` 扩容时，必须“老老实实”：

```C++
for each old element:
     new (new_mem + i) std::string(std::move_or_copy(old_mem[i]));     
	 old_mem[i].~std::string();
```

也就是说，对每个 string：

1. 调构造函数（拷贝构造 or 移动构造）；
    
2. 调析构函数销毁旧对象。
    

**绝不能 `memcpy` 整段内存过去**，否则就会出现一大堆指针重复释放 / 内部状态错乱的问题。

---

## 3. 移动语义 vs 拷贝语义：为什么“是否支持高效 move”很关键？

### 3.1 扩容 / 插入时的成本差异

当 `vector<T>` 需要搬动元素时，每个元素的成本 roughly 是：

- 拷贝：调用 `T(const T&)`
    
    - 对 `std::string` 来说，会**新分配一块堆内存 + 拷贝内容**；
        
- 移动：调用 `T(T&&)`
    
    - 对 string 来说，通常只是**偷对方的指针 + 把源置空**，不再分配/拷贝字符数据。
        

举个类比：

- 拷贝 string：像是重新买一套房，把对方家所有家具再搬一遍；
    
- 移动 string：像是直接把房产证过户给你，对方搬出空房，家具留给你。
    

所以对于 `std::vector<std::string>`：

- 如果元素类型只有拷贝构造，没有移动构造：
    
    - 扩容 / 插入 时，一批 string 会被深拷贝一次，分配很多内存，拷贝很多字符，代价大；
        
- 如果提供了移动构造（C++11 的 string 就有）：
    
    - 同样的操作主要是 pointer 级的移动 + 很少的内存分配，代价小很多。
        

**复杂度：都是 O(n)**（毕竟要处理 n 个元素），  
**但常数因子差别巨大**——一个是“搬整套家具”，一个是“换房产证”。

---

### 3.2 这也是为什么现代 C++“推销”移动语义

你可以这样理解现代 C++ 的演化逻辑：

1. C++98 时代：只有拷贝语义 `T(const T&)`
    
    - `std::vector` 扩容时只能深拷贝所有元素；
        
    - 对复杂类型（string, vector, 自定义资源类）代价很高。
        
2. C++11 加入 **右值引用 + 移动构造/移动赋值 + `std::move`**
    
    - 容器在扩容 / 插入 / 删除时，可以优先尝试调用 **移动构造**；
        
    - 若类型支持“轻量 move”，整体操作就轻量很多。
        

例如 `std::vector<T>::push_back(const T&)` 的插入过程大致是：

- 空间足够：
    
    - 调用拷贝构造 / 移动构造在尾部构造一个新元素；
        
- 空间不够（要扩容）：
    
    1. 分配更大的内存；
        
    2. 遍历旧元素：
        
        - 如果 `T` 是 `move_constructible`，则 `new (new_mem+i) T(std::move(old_mem[i]));`
            
        - 否则使用拷贝构造；
            
    3. 析构旧元素，释放旧内存。
        

**也就是说**：

> 只要你的类型实现了高效的移动构造 / 移动赋值，  
> `std::vector<T>` 在各种操作（特别是扩容）中就能自然而然地利用起来。

---

### 3.3 再对比一下 trivial 类型 vs 复杂类型

#### 对 trivial 类型（`int`, `double`, 简单 struct）

- 拷贝/移动 = 按字节复制，编译器/库可以直接 `memmove`;
    
- vector 扩容时可以一口气搬整个数组；
    
- 性能非常好，CPU cache 命中高，分支预测简单；
    

你在 `std::vector<int>` 上做疯了的 `push_back` 和 `insert`，  
性能往往比你自己手写 `new[]` / `malloc` 管得还好。

#### 对复杂类型（`std::string`, `std::vector` 作为元素, 自己的 RAII 类）

- 拷贝构造要重新申请资源并拷贝内容，代价大；
    
- 移动构造只需要“偷资源” + 清空源对象，不再分配/拷贝底层数据，代价小。
    
- vector 无法用 `memmove` 搬动，只能一个一个调用构造/析构。
    

如果这种类型没有写移动构造（或者被 `const` 卡死移动不起效果）：

- 容器操作大量触发深拷贝，性能急剧下降；
    
- 所以现代 C++ 把“写好移动构造/移动赋值”视为一个类设计的基本素养。


给个例子：
## 例子代码：有移动构造时，`vector` 会优先用 move

```C++
#include <iostream>
#include <vector>
#include <algorithm>

struct Big {
    static int copy_ctor_cnt;
    static int move_ctor_cnt;

    int size;
    int* data;

    Big(int n = 1000000) : size(n), data(new int[n]) {
        // 模拟“很重”的对象：分配大量内存
    }

    ~Big() {
        delete[] data;
    }

    // 拷贝构造：深拷贝
    Big(const Big& other) : size(other.size), data(new int[other.size]) {
        std::copy(other.data, other.data + other.size, data);
        ++copy_ctor_cnt;
        std::cout << "Big copy ctor\n";
    }

    // 移动构造：偷资源（只搬指针，不再分配/拷贝数据）
    Big(Big&& other) noexcept : size(other.size), data(other.data) {
        other.size = 0;
        other.data = nullptr;
        ++move_ctor_cnt;
        std::cout << "Big move ctor\n";
    }

    // 拷贝赋值（简单版本）
    Big& operator=(const Big& other) {
        if (this != &other) {
            delete[] data;
            size = other.size;
            data = new int[size];
            std::copy(other.data, other.data + other.size, data);
        }
        return *this;
    }

    // 移动赋值
    Big& operator=(Big&& other) noexcept {
        if (this != &other) {
            delete[] data;
            size = other.size;
            data = other.data;
            other.size = 0;
            other.data = nullptr;
        }
        return *this;
    }
};

int Big::copy_ctor_cnt = 0;
int Big::move_ctor_cnt = 0;

int main() {
    {
        std::vector<Big> v;
        v.reserve(1);        // 先预留 1 个容量，方便我们控制第一次扩容

        std::cout << "=== 第一次 emplace_back，构造第一个元素 ===\n";
        v.emplace_back();   // 直接在 vector 内部构造一个 Big

        std::cout << "=== 第二次 push_back，会触发扩容并搬家 ===\n";
        v.push_back(Big{}); // 这里一般会触发扩容，把第一个元素从旧内存搬到新内存

        std::cout << "=== 统计结果 ===\n";
        std::cout << "copy ctor count = " << Big::copy_ctor_cnt << "\n";
        std::cout << "move ctor count = " << Big::move_ctor_cnt << "\n";
    }

    return 0;
}

```

### 预期现象（在支持 C++11 的实现里）：

- 程序输出若干行：
    
    - 第一次 `emplace_back()`：只会调用一次 `Big(int)`（构造函数），不涉及拷贝/移动；
        
    - 第二次 `push_back(Big{})`：
        
        - `Big{}` 这个临时对象本身会调用一次构造；
            
        - **扩容时，`vector` 要把第一个元素从旧内存搬到新内存**：
            
            - 如果有 `Big(Big&&)`，STL 会优先调用它 → 你会看到“Big move ctor”；
                
            - `Big::move_ctor_cnt` 会是 1；
                
            - `Big::copy_ctor_cnt` 常常是 0（具体输出行数因实现略有不同，但趋势就是“移多拷少”）。
                

---

## 自己做个对比实验：注释掉移动构造

你可以在同一个类上做个简单实验：

1. **先保留移动构造**（现在的代码），编译运行，看看：
    
    `Big move ctor copy ctor count = 0 move ctor count = 1   // 类似这样的结果`
    
2. 然后把移动构造这段**注释掉**：
    
    `// Big(Big&& other) noexcept = delete;`
    
    或者干脆删掉整个移动构造函数（类只剩拷贝构造）。
    
    再编译运行同样的 `main`，你会发现：
    
    - 扩容时容器就只能调用 `Big(const Big&)`；
        
    - 这时 `copy_ctor_cnt` 增加，`move_ctor_cnt` 保持为 0；
        
    - 日志里只会看到 “Big copy ctor”。
        

这就非常直观地验证了：

> **C++11 以后，如果类提供了移动构造，`std::vector` 在扩容 / 插入时会优先用 `move` 来搬元素；  
> 如果没有移动构造，它只能退回 `copy`。**