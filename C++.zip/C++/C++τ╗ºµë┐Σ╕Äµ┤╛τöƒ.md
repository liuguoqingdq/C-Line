## 1. 基本概念：继承 vs 派生

- **继承（inheritance）**：子类从父类获得成员与接口，实现“代码复用 + is-a 关系”。
    
- **派生（derivation）**：从一个基类派生出新类，得到**派生类**。
    

一句话：

> **派生类继承基类的成员，并可以扩展/重写行为。**

---

## 2. 继承语法与访问控制

### 2.1 语法

```C++
class Base {
public:
    void f();
protected:
    int x;
private:
    int y;
};

class Derived : public Base {  // public 继承
public:
    void g();
};
```

### 2.2 三种继承方式（影响“基类成员在派生类中的可见性”）

|继承方式|Base 的 public 在 Derived 中|Base 的 protected 在 Derived 中|Base 的 private|
|---|---|---|---|
|`public`|public|protected|不可直接访问|
|`protected`|protected|protected|不可直接访问|
|`private`|private|private|不可直接访问|

> private 成员永远不能被派生类直接访问，只能通过 Base 的 public/protected 接口间接访问。

### 2.3 is-a vs has-a

- `public` 继承表达 **is-a**：Derived 是一种 Base
    
- `private/protected` 继承更像“**实现复用**”，外部不把 Derived 当 Base 用
    

---

## 3. 构造/析构顺序（非常常考）

### 3.1 调用顺序

**构造：先 Base 后 Derived**  
**析构：先 Derived 后 Base**

```C++
struct Base {
    Base(){ std::cout<<"Base()\n"; }
    ~Base(){ std::cout<<"~Base()\n"; }
};

struct Derived : Base {
    Derived(){ std::cout<<"Derived()\n"; }
    ~Derived(){ std::cout<<"~Derived()\n"; }
};
```

输出：

`Base() Derived() ~Derived() ~Base()`

### 3.2 派生类构造时初始化基类

```C++
class Base {
public:
    Base(int a): x(a) {}
protected:
    int x;
};

class Derived : public Base {
public:
    Derived(int a, int b) : Base(a), y(b) {}
private:
    int y;
};
```

> Base 没有默认构造时，Derived 必须在初始化列表里显式调用 Base 构造。

---

## 4. 成员覆盖、隐藏与重载

### 4.1 覆盖（override，虚函数重写）

要求：

1. 基类函数是 `virtual`
    
2. 派生类函数签名一致（返回类型/参数/const/ref 限定一致）
    
3. 通过基类指针/引用调用时产生动态多态
    

```C++
struct Base {
    virtual void show() { std::cout<<"Base\n"; }
    virtual ~Base() = default; // 多态基类必须虚析构
};

struct Derived : Base {
    void show() override { std::cout<<"Derived\n"; }
};
```

### 4.2 隐藏（name hiding）

**只要派生类出现同名函数，基类所有同名重载都会被隐藏**：

```C++
struct Base {
    void f(int) {}
    void f(double) {}
};

struct Derived : Base {
    void f(int) {}   // hides Base::f(double) too
};
```

解决：把基类重载引入作用域

`struct Derived: Base {     using Base::f;     void f(int) {} };`

---

## 5. 多态（Polymorphism）

### 5.1 静态多态 vs 动态多态

- **静态多态**：编译期决定（模板、函数重载）
    
- **动态多态**：运行期决定（virtual + 基类指针/引用）
    

### 5.2 动态绑定示例

```C++
Base* p = new Derived();
p->show();  // Derived::show()
delete p;
```

### 5.3 为什么“多态基类必须虚析构”

否则：

```C++
Base* p = new Derived();
delete p;  // 只调用 Base 析构 -> Derived 资源泄漏/UB
```

---

## 6. 指针/引用转换与对象切片

### 6.1 向上转型（upcast）

Derived → Base **安全、自动**

```C++
Derived d;
Base* pb = &d;
Base& rb = d;
```

### 6.2 向下转型（downcast）

Base → Derived **不安全，需要 RTTI**

```C++
Base* pb = new Derived();

Derived* pd = dynamic_cast<Derived*>(pb);
if(pd) pd->show();
```

### 6.3 对象切片（slicing）

按值赋值会丢掉派生部分：

```C++
Derived d;
Base b = d;   // slicing: b 只保留 Base 子对象
b.show();     // Base::show
```

避免：用指针/引用传递多态对象。

---

## 7. 多重继承与菱形继承

### 7.1 多重继承

```C++
struct A { void fa(); };
struct B { void fb(); };
struct C : public A, public B {};
```

访问：

```C++
C c;
c.fa(); c.fb();
```

### 7.2 菱形继承问题

```C++
struct A { int x; };
struct B : A {};
struct C : A {};
struct D : B, C {}; // D 里有两份 A
```

导致歧义：

`D d; // d.x;  // ambiguous`

### 7.3 虚继承解决

```C++
struct A { int x; };
struct B : virtual A {};
struct C : virtual A {};
struct D : B, C {};  // 只有一份 A
```

**虚继承的代价**：对象模型更复杂，访问虚基类成员需间接寻址；但能解决菱形二义性。

---

## 8. 继承中的特殊成员函数规则

1. **基类析构非虚 → 派生类也不虚**
    
2. **基类有虚函数**：
    
    - 派生类可重写
        
    - 若不重写，继承基类版本
        
3. 构造/拷贝/移动：
    
    - 派生类默认生成的特殊成员函数会调用基类对应函数
        
    - 基类不可拷贝/移动时，派生类相应操作也会被删除（=delete）
        

---

## 9. 现代 C++ 建议（工程最佳实践）

1. **只在需要多态时才用继承**  
    复用代码更多用组合（has-a）。
    
2. 多态基类：
    
    - 至少一个虚函数
        
    - **虚析构**
        
3. 重写虚函数务必加 `override`  
    防止签名不一致导致“没重写成功”。
    
4. 不想再被派生就用 `final`
    

```C++
struct Base final {};
```

5. 谨慎多重继承，除非：
    
    - 纯接口（类似 Java interface）
        
    - mixin 小功能块
        

---

## 10. 一个完整的小例子串起来

```C++
#include <iostream>
using namespace std;

struct Animal {
    Animal(string n): name(n) {}
    virtual void speak() const { cout << name << " makes sound\n"; }
    virtual ~Animal() = default;//纯虚析构
protected:
    string name;
};

struct Dog : Animal {
    Dog(string n): Animal(n) {}
    void speak() const override { cout << name << " barks\n"; }
};

struct Cat : Animal {
    Cat(string n): Animal(n) {}
    void speak() const override { cout << name << " meows\n"; }
};

int main() {
    Animal* a1 = new Dog("Buddy");
    Animal* a2 = new Cat("Kitty");

    a1->speak(); // Buddy barks
    a2->speak(); // Kitty meows

    delete a1;
    delete a2;
}
```

##### 多态与虚函数部分详见[[C++虚函数与菱形继承]]