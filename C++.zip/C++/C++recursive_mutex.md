## 1. `recursive_mutex` 是什么？

> `std::recursive_mutex` 是一种 **可重入互斥锁**：  
> 同一个线程可以对同一把锁 **重复 lock 多次而不会死锁**。

对比普通 `std::mutex`：

- `std::mutex`：同线程二次 `lock()` 会**自死锁**（block forever）。
    
- `std::recursive_mutex`：同线程二次 `lock()` 会**成功**，内部计数 +1。
    

---

## 2. 语义规则（必须记牢）

`recursive_mutex` 内部维护两样东西：

1. **owner thread id**：当前持有锁的线程是谁
    
2. **recursion count**：同一 owner 重入了几次
    

行为是：

- `lock()`：
    
    - 若锁空闲 → 当前线程成为 owner，count=1
        
    - 若锁已被当前线程持有 → count++
        
    - 若锁被别的线程持有 → 阻塞等待
        
- `unlock()`：
    
    - count--
        
    - 若 count==0 → 释放 owner，其他线程可获取
        

**重要结论**：

> lock 几次，就必须 unlock 几次，否则锁永远不释放。

---

## 3. 最小例子：递归函数必须重入

```C++
std::recursive_mutex rm;

int dfs(int n){
    std::lock_guard<std::recursive_mutex> lk(rm);
    if(n == 0) return 0;
    return 1 + dfs(n-1);  // 同线程再次加锁
}
```

如果这里换成 `std::mutex`：

```C++
std::mutex m;
std::lock_guard<std::mutex> lk(m);
dfs(n-1); // ❌ 同线程第二次 lock，直接死锁
```

这就是 `recursive_mutex` 最典型的动机——**递归路径上锁边界不好拆**。

---

## 4. 实现直觉（不是死记 API）

你可以把它理解为“**带计数的普通 mutex**”。

伪实现：

```C++
class recursive_mutex {
    mutex inner;
    thread_id owner = none;
    int count = 0;

    void lock() {
        if (owner == this_thread_id()) {
            ++count;
            return;
        }
        inner.lock();
        owner = this_thread_id();
        count = 1;
    }

    void unlock() {
        if (owner != this_thread_id()) abort(); // 未定义行为
        --count;
        if (count == 0) {
            owner = none;
            inner.unlock();
        }
    }
};
```

所以它比 `mutex` 有额外开销：要检查 owner、维护 count。

---

## 5. 什么时候用 `recursive_mutex` 是合理的？

### 5.1 真实“重入不可避免”的场景

- 递归算法里需要保护全局/共享状态
    
- 或者一个函数上锁后，调用链深处又必须进入同一临界区
    

例如你写一个带缓存的递归计算：

```C++
std::recursive_mutex rm;
std::unordered_map<int,int> memo;

int fib(int n){
    std::lock_guard lk(rm);
    if (auto it = memo.find(n); it != memo.end()) return it->second;
    int v = (n<=1) ? n : fib(n-1) + fib(n-2);
    memo[n] = v;
    return v;
}
```

要保证 memo 线程安全，但 fib 递归自调用，所以重入是“结构性存在”的。

---

## 6. 什么时候不该用？（教授会重点提醒）

在工业代码里，`recursive_mutex` 经常被视为一个**坏味道（code smell）**，因为它可能掩盖设计问题。

### 6.1 它会隐藏锁边界错误

很多时候你用 recursive_mutex，是因为：

> “我搞不清楚谁该持锁、锁范围多大，所以干脆让它能重入。”

这会让代码维护变难：  
你看不出到底哪里真正需要锁、锁嵌套层级是多少。

### 6.2 它降低了你发现 bug 的机会

普通 mutex 的自死锁是“报警器”。  
你一旦在同线程二次 lock，立刻暴露问题。

recursive_mutex 会“让你以为没问题”，但其实可能：

- 锁范围设计不当
    
- 临界区太大
    
- 逻辑层级耦合太深
    

### 6.3 性能更差

每次 lock 都要：

- 读 owner
    
- 比较 thread id
    
- 维护计数  
    在高频/高竞争场景会明显慢于 mutex。
    

---

## 7. 一个经典反例（为什么它可能是错的）

```C++
std::recursive_mutex rm;

void f(){
    std::lock_guard lk(rm);
    g();
}

void g(){
    std::lock_guard lk(rm);  // “为了安全”再次加锁
    // ...
}
```

这种模式是很多人引入 recursive_mutex 的原因：  
f 可能被别的线程并发调用，所以 f 上锁；  
g 也可能被别的线程并发调用，所以 g 也上锁；  
结果形成“**锁嵌套**”。

更好的设计通常是：

- **明确锁属于哪一层**
    
- g 假设调用者已持锁（或者 g 拆成无锁版本 + 外层锁版本）
    

```C++
std::mutex m;

void g_unlocked(){
    // ... 假设已持锁
}

void g(){
    std::lock_guard lk(m);
    g_unlocked();
}

void f(){
    std::lock_guard lk(m);
    g_unlocked();  // 不重复加锁
}
```

这样锁边界清晰、无额外开销。

---

## 8. 相关类型：`recursive_timed_mutex`

如果你需要超时/try 能力：

```C++
std::recursive_timed_mutex rtm;

void h(){
    std::unique_lock lk(rtm, std::try_to_lock);
    if(!lk.owns_lock()) return;
    // ...
}
```

语义同 recursive_mutex，只是支持 timed/try。

---

## 9. 最终建议（工程准则）

你可以按这个决策树：

1. **同线程会不会重入同一把锁？**
    
    - 不会 → 用 `std::mutex`
        
    - 会 → 继续
        
2. **重入是“结构性不可避免”还是“锁设计不清晰导致”？**
    
    - 不可避免（递归算法、回调重入、框架限制）  
        → `recursive_mutex` 合理
        
    - 设计不清晰  
        → 重构锁边界，别用 recursive_mutex 逃避
        
3. **是否有更好的替代？**
    
    - 拆分无锁函数
        
    - 固定调用层级
        
    - 用消息队列/线程局部存储替代共享状态
        
    - 甚至把状态设计成不可变
        

---

一句话总结：

> `recursive_mutex` 不是“更强的 mutex”，而是“允许你在同线程重复加锁的特种工具”。  
> 只有当重入在结构上无法消除时才该用，否则它通常是在掩盖锁边界设计问题。