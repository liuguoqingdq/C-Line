```C++
#include <cstddef>

#include <new>

#include <memory>

#include <iostream>

#include <type_traits>

#include <vector>

  

// 每个大块（Chunk）大小，示例用 4KB

static constexpr std::size_t CHUNK_SIZE = 4096;

  

// ---------------------------------------------------------------------

// 一个 per-T 的块内存池 allocator：ChunkPoolAllocator<T>

// ---------------------------------------------------------------------

template <typename T>

class ChunkPoolAllocator {

public:

// --- 标准 allocator 所需的基本别名 -------------------------------

using value_type = T;

using pointer = T*;

using const_pointer = const T*;

using size_type = std::size_t;

using difference_type = std::ptrdiff_t;

  

// 给 allocator_traits / 容器 rebinding 用

template <class U>

struct rebind {

using other = ChunkPoolAllocator<U>;

};

  

// 一些传播属性（简单起见都设为 true/false，便于容器处理）

using propagate_on_container_move_assignment = std::true_type;

using propagate_on_container_swap = std::true_type;

using is_always_equal = std::true_type;

  

// --- 构造 / 拷贝构造（按 C++11 Minimal Allocator 要求） ----------

ChunkPoolAllocator() noexcept = default;

  

template <class U>

ChunkPoolAllocator(const ChunkPoolAllocator<U>&) noexcept {

// 不需要做额外事情，不同 T 的 allocator 有各自的 pool

}

  

// --- allocate: 分配 n 个 T 对象所需的原始内存 --------------------

pointer allocate(size_type n) {

if (n != 1) {

// 非单个对象的分配，直接走普通 new（简化处理）

std::cout << "[ChunkPoolAllocator] fallback allocate "

<< n << " * " << sizeof(T) << " bytes\n";

return static_cast<pointer>(::operator new(n * sizeof(T)));

}

return allocate_one();

}

  

// --- deallocate: 释放 n 个 T 的原始内存 --------------------------

void deallocate(pointer p, size_type n) noexcept {

if (!p) return;

  

if (n != 1) {

// 对应上面的 fallback 分配

std::cout << "[ChunkPoolAllocator] fallback deallocate "

<< n << " * " << sizeof(T) << " bytes\n";

::operator delete(p);

return;

}

deallocate_one(p);

}

  

private:

// -------------------------------------------------------------

// 内部数据结构：Chunk + Node

// -------------------------------------------------------------

struct Chunk;

  

// Node 表示池中的一个“槽位”：包含一个 T 的存储空间 + 元信息

struct Node {

Node* next_free; // 空闲链表指针

Chunk* owner; // 指向所属 Chunk

// 真正放 T 对象的地方：只提供原始字节，不自动构造/析构

alignas(T) unsigned char storage[sizeof(T)];

};

  

// 一个 Chunk 是一块大内存，里面包含若干 Node

struct Chunk {

Chunk* next_chunk; // 所有 Chunk 组成链表（主要为了调试 / 统计）

std::size_t capacity; // 该 Chunk 拆成多少个 Node

std::size_t live; // 当前有多少 Node “在用”（被 allocate 出去）

// Node 实际上紧跟在 Chunk 之后顺序排布，我们用指针指向开头

Node* nodes;

};

  

// --- 静态成员：per T 的全局 free list 和 chunk list（非线程安全） --

static Node* s_free_list; // 所有空闲 Node 构成的链表

static Chunk* s_chunks; // 所有 Chunk 构成的链表（可选）

  

// -------------------------------------------------------------

// 核心实现：单个对象的 allocate / deallocate

// -------------------------------------------------------------

static pointer allocate_one() {

if (!s_free_list) {

// 池子空了，向 OS 申请一个新的 Chunk

add_chunk();

}

  

// 从 free list 头取一个 Node

Node* node = s_free_list;

s_free_list = node->next_free;

  

// 更新所属 Chunk 的 live 计数

++node->owner->live;

  

// 把 Node 的 storage 视作 T* 返回

return reinterpret_cast<pointer>(node->storage);

}

  

static void deallocate_one(pointer p) noexcept {

// 通过 p 算回 Node*：p 指向 Node::storage，减去偏移即可

Node* node = node_from_pointer(p);

  

// 更新 Chunk 的 live 计数

if (node->owner->live > 0) {

--node->owner->live;

}

  

// 归还到 free list

node->next_free = s_free_list;

s_free_list = node;

  

// 这里示例版不做“live == 0 就归还整个 Chunk 给 OS”，

// 而是只做复用，让高水位内存常驻池子。

// 真要做回收，需要从 free_list 中剔除属于该 Chunk 的所有节点，

// 实现会复杂不少。

}

  

// -------------------------------------------------------------

// 帮助函数：从 T* 反推出 Node*

// -------------------------------------------------------------

static Node* node_from_pointer(pointer p) {

// p 指向 Node::storage 的起始位置

unsigned char* raw = reinterpret_cast<unsigned char*>(p);

// Node::storage 在 Node 内的偏移量

constexpr std::size_t offset = offsetof(Node, storage);

return reinterpret_cast<Node*>(raw - offset);

}

  

// -------------------------------------------------------------

// 新建一个 4KB Chunk，拆成若干 Node，全部挂入 free_list

// -------------------------------------------------------------

static void add_chunk() {

std::size_t bytes = CHUNK_SIZE;

  

// 1. 向 OS 申请一块原始内存

unsigned char* raw = static_cast<unsigned char*>(::operator new(bytes));

  

// 2. 在这块内存头部“原地构造”一个 Chunk 头

Chunk* chunk = new (raw) Chunk;

chunk->next_chunk = s_chunks;

chunk->capacity = 0;

chunk->live = 0;

chunk->nodes = nullptr;

  

s_chunks = chunk;

  

// 3. 剩余空间用来放 Node 数组

std::size_t space = bytes - sizeof(Chunk);

void* ptr = raw + sizeof(Chunk);

  

// 让 Node 对齐到 alignof(Node)

void* aligned = std::align(alignof(Node), sizeof(Node), ptr, space);

if (!aligned || space < sizeof(Node)) {

// 对齐失败或空间太小，直接抛异常

throw std::bad_alloc();

}

  

unsigned char* node_mem = static_cast<unsigned char*>(aligned);

std::size_t node_count = space / sizeof(Node);

  

chunk->capacity = node_count;

chunk->nodes = reinterpret_cast<Node*>(node_mem);

  

std::cout << "[ChunkPoolAllocator] new Chunk @ " << chunk

<< ", nodes = " << node_count << "\n";

  

// 4. 在这块区域里“原地构造”一个个 Node，并全部挂到 free_list

for (std::size_t i = 0; i < node_count; ++i) {

unsigned char* p = node_mem + i * sizeof(Node);

Node* node = new (p) Node;

node->owner = chunk;

node->next_free = s_free_list;

s_free_list = node;

}

}

};

  

// 静态成员定义

template <typename T>

typename ChunkPoolAllocator<T>::Node* ChunkPoolAllocator<T>::s_free_list = nullptr;

  

template <typename T>

typename ChunkPoolAllocator<T>::Chunk* ChunkPoolAllocator<T>::s_chunks = nullptr;

  

// allocator 之间的比较（按标准要求提供）

template <class T, class U>

bool operator==(const ChunkPoolAllocator<T>&,

const ChunkPoolAllocator<U>&) noexcept {

return true;

}

  

template <class T, class U>

bool operator!=(const ChunkPoolAllocator<T>&,

const ChunkPoolAllocator<U>&) noexcept {

return false;

}

  

// ---------------------------------------------------------------------

// 测试：把 ChunkPoolAllocator 用在 std::vector 里

// ---------------------------------------------------------------------

struct Widget {

char data[100];

Widget() { std::cout << "Widget()\n"; }

~Widget() { std::cout << "~Widget()\n"; }

};

  

int main() {

std::cout << "--- Start Testing ---\n";

  

// 使用自定义 allocator 的 vector

std::vector<Widget, ChunkPoolAllocator<Widget>> v;

  

v.reserve(10); // 会触发一到两次 chunk 分配

std::cout << "push_back...\n";

for (int i = 0; i < 5; ++i) {

v.emplace_back(); // 只要 n==1 的分配都会走 pool

}

  

std::cout << "clear...\n";

v.clear(); // 析构 Widget，但底层内存还在池子里，方便下次复用

  

std::cout << "push_back again...\n";

for (int i = 0; i < 3; ++i) {

v.emplace_back(); // 会从 free_list 复用刚才的 Node

}

  

std::cout << "--- End Testing ---\n";

}
```

*1* .Chunk块大小设置为4096B的大小
	内存池中的各种组件:
```C++
// -------------------------------------------------------------
// 内部数据结构：Chunk + Node
// -------------------------------------------------------------
struct Chunk;
// Node 表示池中的一个“槽位”：包含一个 T 的存储空间 + 元信息
struct Node {
Node* next_free; // 空闲链表指针
Chunk* owner; // 指向所属 Chunk
// 真正放 T 对象的地方：只提供原始字节，不自动构造/析构
alignas(T) unsigned char storage[sizeof(T)];
};
// 一个 Chunk 是一块大内存，里面包含若干 Node
struct Chunk {
Chunk* next_chunk; // 所有 Chunk 组成链表（主要为了调试 / 统计）
std::size_t capacity; // 该 Chunk 拆成多少个 Node
std::size_t live; // 当前有多少 Node “在用”（被 allocate 出去）
// Node 实际上紧跟在 Chunk 之后顺序排布，我们用指针指向开头
Node* nodes;
};

// --- 静态成员：per T 的全局 free list 和 chunk list（非线程安全） --
static Node* s_free_list; // 所有空闲 Node 构成的链表
static Chunk* s_chunks; // 所有 Chunk 构成的链表（可选）
```
###### `这里用静态的变量包括后面的静态方法，都是为了能让这些同类型<T>的共享同一个池子。（静态成员函数在不传入对象作为参数的条件下，只能调用静态成员）`

*2*.使用template模板来适应各种类型
*3*.适应接口：
```C++
// --- 标准 allocator 所需的基本别名 -------------------------------

using value_type = T;

using pointer = T*;

using const_pointer = const T*;

using size_type = std::size_t;

using difference_type = std::ptrdiff_t;
```
*4*. 内部转换
```C++
// 给 allocator_traits / 容器 rebinding 用

template <class U>

struct rebind {

using other = ChunkPoolAllocator<U>;

};
```
#现象：我明明给的是 `Allocator<T>`，容器内部怎么给别的类型分配？

比如你写：

```C++
using MyAllocInt = MyAllocator<int>; 
std::list<int, MyAllocInt> lst;
```

你给 `std::list` 的 allocator 类型是 `MyAllocator<int>`，也就是**“给 int 分配内存的 allocator”**。

但是 `std::list` 内部并不是直接存 `int`，而是类似：

```C++
struct Node {     
Node* prev;     
Node* next;     
int   value; 
};
```

那么问题来了：

> list 内部要给 `Node` 分配内存，**它怎么从 `MyAllocator<int>` 变成 `MyAllocator<Node>`？**

这一步“把 `Allocator<int>` → `Allocator<Node>`”的动作，就叫做 **rebinding（重绑定）**。  
对应的 allocator 要提供一种“**rebind 到别的类型**”的能力。

*5*.传播策略[[C++内存池传播策略]]
```C++
using propagate_on_container_move_assignment = std::true_type;
using propagate_on_container_swap            = std::true_type;
using is_always_equal                        = std::true_type;
```
*6*.内存池的构造
```C++
// --- 构造 / 拷贝构造（按 C++11 Minimal Allocator 要求） ----------

ChunkPoolAllocator() noexcept = default;
template <class U>

ChunkPoolAllocator(const ChunkPoolAllocator<U>&) noexcept {

// 不需要做额外事情，不同 T 的 allocator 有各自的 pool

}
```
当你写：

```C++
ChunkPoolAllocator<int>    a; 
ChunkPoolAllocator<double> b(a);
```

发生了什么？

- 编译期：
    
    - 左边：你要构造的是 `ChunkPoolAllocator<double>`，所以 `T = double`；
        
    - 实参：`a` 的类型是 `ChunkPoolAllocator<int>`，所以模板形参 `U = int`；
        
- 编译器选择的构造函数是：
    
    ```C++
    ChunkPoolAllocator<double>::ChunkPoolAllocator(const ChunkPoolAllocator<int>&);
    ```
    
- 运行时：
    
    - `b` 是一个全新的 `ChunkPoolAllocator<double>` 对象；
        
    - 构造函数体里什么都没做（空的），所以**没有从 `a` 身上拷任何“池子指针”之类的状态**。
        

所以这里没有“把 `a` 转换成 `b`”，只是**用 `a` 作为一个参数，来构造一个全新的、类型明确是 `double` 的 allocator 对象**。  
`T` / `U` 只是模板参数，用来区分重载，**不会在运行时乱变**。

*7*.allocate内存分配：
```C++
// --- allocate: 分配 n 个 T 对象所需的原始内存 --------------------

pointer allocate(size_type n) {

if (n != 1) {
// 非单个对象的分配，直接走普通 new（简化处理）
std::cout << "[ChunkPoolAllocator] fallback allocate "
<< n << " * " << sizeof(T) << " bytes\n";
return static_cast<pointer>(::operator new(n * sizeof(T)));
}
return allocate_one();
}
```
##### `这段代码只是单块分配的策略，如list、map这种，如果是vector这种连续分配走n！=1时的代码，如果是申请单块，就调用allocate_one()`[[C++内存池分配策略]]


*8*.内存的释放
```C++
// --- deallocate: 释放 n 个 T 的原始内存 --------------------------

void deallocate(pointer p, size_type n) noexcept {

if (!p) return;

  

if (n != 1) {

// 对应上面的 fallback 分配

std::cout << "[ChunkPoolAllocator] fallback deallocate "

<< n << " * " << sizeof(T) << " bytes\n";

::operator delete(p);

return;

}

deallocate_one(p);

}
```
##### `如果不是按块分配的，那就用opertor的方法释放掉，如果是按一块一块的方法释放掉就用deallocate_one(p)`[[C++内存池释放策略]]

