# 6.1 什么时候用 `std::atomic`？

先记一条总原则：

> **原子适合“单变量”的并发读写；  
> 一旦牵扯到“多个变量之间的关系/不变式”，就该用 `mutex`。**

### 6.1.1 原子能保证什么？

`std::atomic<int> cnt{0};`

对 `cnt` 做的操作（`++cnt`, `fetch_add`, `load`, `store`, …）有两层保证：

1. **原子性**：  
    不会出现半读半写的中间状态，要么看到旧值，要么看到新值；
    
2. **对“这个变量本身”的一致性**：  
    所有线程对 `cnt` 的修改有一个明确的“修改顺序”（modification order）。
    

但它**不自动帮你处理**：

- “`x` 增加时，`y` 必须也增加” 这种 **跨多个变量的不变式**；
    
- “整个对象结构”（比如链表、 map）的原子性。
    

这些多变量关系要么：

- 用锁保护整体（最常见），要么
    
- 用非常小心设计的 lock-free 算法（难度明显上一个台阶）。
    

### 6.1.2 典型适合用 atomic 的场景

1. **计数器、统计量**
    

```C++
std::atomic<long long> total_requests{0};

void handle_request() {
    total_requests.fetch_add(1, std::memory_order_relaxed); // 或 ++total_requests;
}
```

- 只是想在多线程下“正确统计次数”，不依赖这个计数去做复杂逻辑决策；
    
- 对结果的精确时序不敏感（只要最终计数正确即可），就非常适合 `relaxed`。
    

2. **标志位 / 状态位**
    

比如一个“退出标志”：

```C++
std::atomic<bool> stop{false};

// 工作线程：
while (!stop.load(std::memory_order_acquire)) {
    do_work();
}

// 控制线程：
stop.store(true, std::memory_order_release);
```

- 多线程下反复读写一个 bool，恰好是 atomic 的强项；
    
- 根据具体场景决定用 `relaxed` 还是 `acquire/release`。
    

3. **简单的无锁组件**
    

如：

- 单生产者单消费者 ring buffer 里的 head/tail 索引；
    
- 读多写少的“版本号、世代号”（generation counter）；
    
- lock-free 栈/队列的指针（配合 `compare_exchange`）。
    

这些都能靠 atomic 实现，但一旦逻辑复杂了，还是锁更安全。

### 6.1.3 什么时候不要硬上 atomic？

- 你需要保持：`account.balance` 与 `account.log` 同时更新、要么都成功，要么都失败  
    → 这是明显的多变量事务，应该用 mutex 包裹整个更新。
    
- 结构体里多个字段需要“一致观察”（要么看到旧版本，要么看到新版本）  
    → 通常也是用 mutex 或者版本号 + 拷贝双缓冲。
    

一句话：

> **atomic 是“单变量并发工具”；  
> “跨多个变量的一致性”是锁的领地。**

---

# 6.2 内存序（memory order）总览

所有 `std::atomic` 操作都有一个“内存序参数”，决定它对其它读写的**排序约束**。

最常见的是三种：

- `memory_order_relaxed`
    
- `memory_order_acquire` / `memory_order_release`
    
- `memory_order_seq_cst`
    

先把直觉建立起来：

|内存序|提供的保证|常见用途|
|---|---|---|
|`relaxed`|只保证原子性 & 自身修改顺序，不约束其它读写|计数/统计|
|acquire/release|一端发布、一端订阅，建立 happens-before|线程间传递数据/状态|
|`seq_cst`|最强，“看起来像大家排队按顺序执行”，调试更容易|逻辑复杂、不想推演时使用|

---

## 6.2.1 `memory_order_relaxed` —— 只要“不乱写坏”就行

### 语义（简化版）

`cnt.fetch_add(1, std::memory_order_relaxed);`

- 对 `cnt` 的操作是完全 **原子** 的；
    
- 所有线程对 `cnt` 的修改，仍然有一个严格的顺序；
    
- 但它**不对其它变量的读写顺序做任何约束**：
    
    - 编译器可以把你对其它普通变量的读写重排到前后；
        
    - CPU 也可以在缓存/总线层面乱序，只要对 `cnt` 的结果不冲突。
        

**重点：relaxed 不建立 happens-before。**

### 适用场景

1. **只关心最终计数，不靠它来同步其它数据**
    

```C++
std::atomic<long long> counter{0};

void worker() {
    // 做事
    counter.fetch_add(1, std::memory_order_relaxed);
}
```

- 你不靠 `counter` 去判断“别的线程的写是不是已经可见”；
    
- 只是最后汇总/监控用，`relaxed` 最合适。
    

2. **作为“统计/监控信息”**
    

比如记录 peak 值、错误次数、某个事件发生次数等，逻辑只用“差不多对”就行。

### 什么时候不能用 relaxed？

如果你写的是：

```C++
std::atomic<bool> ready{false};
int data;

void producer() {
    data = 42; // 普通写
    ready.store(true, std::memory_order_relaxed);
}

void consumer() {
    if (ready.load(std::memory_order_relaxed)) {
        // 希望这里能读到 data == 42？
        use(data);
    }
}
```

这就错了：

- 因为 `ready` 的读/写是 relaxed，不建立 happens-before；
    
- `data` 的写对 consumer 的读不保证可见；
    
- 也就是说：consumer 看到 `ready == true` 时，`data` 仍可能是旧值。
    

**总结：**

> `relaxed` 只能用于“不起同步作用”的场景：  
> 不要拿它做“状态标志 + 搭配普通变量”的发布-订阅。

---

## 6.2.2 `memory_order_acquire` / `memory_order_release` —— 发布-订阅

这是日常写 lock-free 代码时最重要的一对。

### 发布-订阅的直观模型

典型代码：

```C++
std::atomic<bool> ready{false};
int data = 0;

// 线程 A：生产数据
void producer() {
    data = 42;                                       // (1) 普通写
    ready.store(true, std::memory_order_release);    // (2)
}

// 线程 B：消费数据
void consumer() {
    if (ready.load(std::memory_order_acquire)) {     // (3)
        int x = data;                                // (4)
        use(x);
    }
}
```

内存模型保证：

> 只要 B 在 (3) 的 `load(acquire)` 看到的是 A 在 (2) 的 `store(release)` 写入的那次 true，  
> 那么 A 线程中 **(2) 之前** 的所有写（包括 (1) 对 `data` 的写），  
> 对 B 线程中 **(3) 之后** 的所有读都是“可见”的。

也就是建立了：

`A: data = 42;  happens-before  B: x = data;`

这就是 **happens-before**，也就是我们要的“跨线程可见性”。

### 具体类比：

- `store(release)`：**“我已经准备好了一切，发个信号出去”**
    
- `load(acquire)`：**“我收到这个信号就认为你之前的写都已经有效，我可以安全读了”**
    

### 对数据本身的要求？

上面例子中的 `data` 是普通 `int`，为什么也能被同步？

因为：

- 对 `data` 的写发生在 release 之前；
    
- 对 `data` 的读发生在 acquire 之后；
    
- 通过 `ready` 的 release/acquire 建立了 happens-before；
    
- 于是 `data` 的读写不会构成 data race，且可见性有保证。
    

**注意：**

- 前提是：`data` 仅通过这种“先写再 publish，再读取”的模式访问；
    
- 不能同时还被其它线程直接乱改；否则照样 data race。
    

### RMW 操作中的 `acq_rel`（顺带提一下）

对原子读改写，比如 `fetch_add`、`compare_exchange`：

`x.fetch_add(1, std::memory_order_acq_rel);`

同时具备：

- 对这个操作之前的写 → release 功效；
    
- 对这个操作之后的读 → acquire 功效。
    

常见于：

- 加锁式自旋锁的实现；
    
- 某些“既获取又发布”的状态转移。
    

---

## 6.2.3 `memory_order_seq_cst` —— 最强、默认、最容易理解

### 语义直觉

`seq_cst`（sequentially consistent，顺序一致）内存序带来的效果可以概括为：

> 所有使用 `seq_cst` 的原子操作，看起来像是被放在一个**全局总线**上排队执行，  
> 每个线程看到的顺序都是一致的。

换句话说：

- 它既提供 acquire/release 那种 happens-before；
    
- 又提供一个**全局“谁先谁后”的一致视图**。
    

例如：

```C++
 std::atomic<int> x{0}, y{0};

void t1() {
    x.store(1, std::memory_order_seq_cst);
    int r = y.load(std::memory_order_seq_cst);
}

void t2() {
    y.store(1, std::memory_order_seq_cst);
    int r = x.load(std::memory_order_seq_cst);
}
```

在纯 acq/rel 下，有些怪异组合理论上是可能的；  
而在全是 seq_cst 的情况下：

- 不会出现所有线程都“只看到自己写的那一半”的诡异情况；
    
- 你可以在脑子里按“某个交错顺序”执行这些操作做推理，而不用担心还有更奇怪的乱序。
    

### 工程上的用法建议

1. **不太熟悉内存模型、逻辑有点绕 → 就先用 `seq_cst`。**
    

默认构造的 `atomic` 成员函数，如果不传内存序参数，就是 `seq_cst`：

```C++
std::atomic<int> x{0};
x.store(1);          // 等价于 store(1, memory_order_seq_cst)
int v = x.load();    // 等价于 load(memory_order_seq_cst)
```

2. **热路径/高频路径** 上，确定只需要发布-订阅语义 → 用 acquire/release 去微调性能。  
    但前提是你非常确定自己的推理没问题。
    
3. 对很多应用来说，**锁 + 默认 seq_cst 的 atomic 已经足够**，  
    更细粒度的 order（特别是 relaxed）真的要慎用。
    

---

## 6.2.4 三者对比总结（你可以当小抄记下来）

|内存序|原子性|对自身修改顺序|对别的读写顺序|全局总顺序（所有线程一致看到）|类比场景|
|---|---|---|---|---|---|
|relaxed|✅|✅|❌|❌|只计数，不同步别的东西|
|acquire|✅|✅|“之后的读不能跑到之前”|❌|接收一批之前的写|
|release|✅|✅|“之前的写不能跑到之后”|❌|发布一批写，然后发信号|
|acq_rel|✅|✅|结合 acquire+release|❌|同时获取旧信息、发布新信息|
|seq_cst|✅|✅|acquire/release + 额外全局顺序|✅|大家排队走单行道|

---

## 6.3 实战中的选择策略（给你一个简单 checklist）

当你要写 `std::atomic` 时，可以问自己几句：

1. **这个变量是否只用来做“数量/统计”，不会驱动其它逻辑？**
    
    - 是 → `relaxed` ok
        
2. **这个变量是否用作“标志/状态”，表示“某些数据已经准备好”？**
    
    - 是 → 写端 `release`，读端 `acquire`
        
3. **我有没有能力严谨地推演 acq/rel 下所有交错？**
    
    - 没有 / 不想 → 用 `seq_cst`，人生轻松很多
        
4. **牵涉多个变量必须保持某种关系（不变式）？**
    
    - 有 → 请优先考虑 `mutex`，atomic 的 lock-free 写法留到更熟练时再玩
        

---

### 最后一口气总结这一节

> - `atomic` 解决的是“单变量的并发读写 + 一些同步语义”；
>     
> - `relaxed` 只保证“不写坏自己”，不能拿来同步其它数据；
>     
> - `acquire/release` 是真正用来做“发布-订阅”的核心内存序；
>     
> - `seq_cst` 在语义上最舒服，出错率最低，是默认值；
>     
> - 一旦涉及多变量不变式/复杂结构，用锁比强行玩 atomic 更安全。
