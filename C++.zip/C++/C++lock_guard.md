## 1. `lock_guard` 是什么？一句话

> `std::lock_guard<Mutex>` 是一个 **作用域锁（scope-based lock）**：  
> 构造时加锁，析构时解锁，**没有任何其他控制接口**。

你只要把它放进作用域里，就保证：

- 进入作用域时锁被拿到
    
- 离开作用域时锁一定释放（不管 return / throw / break）
    

---

## 2. 基本用法

```C++
std::mutex m;

void f() {
    std::lock_guard<std::mutex> lk(m); // 构造：m.lock()
    // 临界区
} // 析构：m.unlock()
```

这是现代 C++ 并发的“默认写法”。

---

## 3. 为什么要用 `lock_guard`？——异常安全与早返回安全

### 3.1 异常安全

手写 lock/unlock：

```C++
m.lock();
do_something();   // 这里可能 throw
m.unlock();       // throw 之后永远到不了
```

`lock_guard`：

```C++
std::lock_guard lk(m);
do_something();   // throw 也没事
```

析构函数会帮你 unlock。

### 3.2 早返回安全

```C++
std::lock_guard lk(m);
if (!ok()) return;  // return 时自动解锁
```

---

## 4. `lock_guard` 的接口极少（刻意的）

只有构造/析构：

```C++
template<class Mutex>
class lock_guard {
public:
    explicit lock_guard(Mutex& m);            // lock
    lock_guard(Mutex& m, adopt_lock_t);       // adopt
    ~lock_guard();                           // unlock

    lock_guard(const lock_guard&) = delete;  // 不可复制
    lock_guard& operator=(const lock_guard&) = delete;
};
```

**注意**：

- 不可复制/不可移动（因为“锁”这种东西不该被拷贝）
    
- 不提供 `unlock()` / `lock()` / `owns_lock()` 等能力
    

这就是它“硬”的地方。

---

## 5. 第二个构造：`adopt_lock`

这个很多人第一次看到会懵。

```C++
m.lock();
std::lock_guard lk(m, std::adopt_lock);
```

含义：

> “我知道你已经把 m 锁住了，  
> lock_guard 不再重复 lock，  
> 只负责在析构时 unlock。”

典型场景：配合 `std::lock` 一次性拿多把锁避免死锁。

```C++
std::mutex m1, m2;

void swap_two() {
    std::lock(m1, m2);  // 无死锁算法，同时 lock 两把

    std::lock_guard l1(m1, std::adopt_lock);
    std::lock_guard l2(m2, std::adopt_lock);

    // 临界区：同时持有 m1,m2
}
```

如果不用 adopt_lock，会把已经锁住的 mutex 再 lock 一次 → 自死锁。

---

## 6. `lock_guard` vs `unique_lock`（你一定要会区分）

|特性|lock_guard|unique_lock|
|---|---|---|
|构造时是否能延迟锁|❌ 不行|✅ defer_lock|
|能否 try_lock / timed_lock|❌ 不行|✅ try_to_lock / timed|
|能否中途 unlock / 再 lock|❌ 不行|✅ 可以|
|能否 move 转移锁所有权|❌ 不行|✅ 可以|
|开销|最小（几乎零）|略大（保存状态）|
|典型用途|固定范围临界区|条件变量、复杂锁策略|

**教授版判断：**

- 临界区简单固定 → `lock_guard`
    
- 需要“控制锁行为” → `unique_lock`
    

---

## 7. 典型使用模式（你可以直接套）

### 7.1 最常见：最小临界区

```C++
void push(int v) {
    std::lock_guard lk(m);
    q.push(v);
}
```

### 7.2 作用域缩小（重要的性能习惯）

```C++
void work() {
    {
        std::lock_guard lk(m);
        update_shared_state();
    } // 这里锁释放

    heavy_compute(); // 锁外做慢事
}
```

把锁尽量放在**小花括号**里，控制持锁时间。

### 7.3 和多个 return/throw 共存

```C++
int get() {
    std::lock_guard lk(m);
    if (empty()) return -1;
    return data;
}
```

---

## 8. 常见坑

### 8.1 lock_guard 里做长耗时操作

```C++
std::lock_guard lk(m);
network_io();   // ❌ IO / sleep / 大计算
```

后果：锁持有时间长 → 竞争加剧 → 吞吐下降、尾延迟变差。

正确：锁内只更新共享状态。

### 8.2 试图在 lock_guard 期间临时放锁（做不到）

很多人写到一半才发现需要提前 unlock：

```C++
std::lock_guard lk(m);
// ...
lk.unlock(); // ❌ 没这个接口
```

这说明你该用 `unique_lock`。

### 8.3 忘了 adopt_lock 的前提是“已经 lock”

```C++
std::lock_guard lk(m, std::adopt_lock); // ❌ 未 lock 就 adopt，析构时会 unlock 未持有锁 → UB
```

---

## 9. 一句话总结

> `lock_guard` 是最简单、最安全、最便宜的 RAII 锁：  
> **只要你的临界区范围固定、没花活，就优先用它。**  
> 一旦需要 try、timed、条件变量、提前 unlock 等控制，再换 `unique_lock`。