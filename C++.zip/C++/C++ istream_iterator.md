## 1. 它是什么？

`#include <iterator> #include <iostream>`

`std::istream_iterator<T>` 会从某个 `std::istream`（比如 `std::cin` 或 `ifstream`）里**按 `operator>>` 的规则连续抽取 T**，表现得像一个“从流里读出来的序列”。[en.cppreference.com+1](https://en.cppreference.com/w/cpp/iterator/istream_iterator.html?utm_source=chatgpt.com)

- **构造时就会读第一个元素**
    
- 之后每次 `++it` 再读下一个
    
- 解引用 `*it` 返回的是**“最近一次读到的那个值的拷贝”**[en.cppreference.com](https://en.cppreference.com/w/cpp/iterator/istream_iterator.html?utm_source=chatgpt.com)
    
- 默认构造一个 `istream_iterator` 表示 “end-of-stream（流结束迭代器）” [en.cppreference.com+1](https://en.cppreference.com/w/cpp/iterator/istream_iterator.html?utm_source=chatgpt.com)
    

---

## 2. 最典型用法：算法直接吃流

### 2.1 读所有 int 到 vector

```C++
#include <vector>
#include <iterator>
#include <iostream>

int main() {
    std::istream_iterator<int> it(std::cin); // begin
    std::istream_iterator<int> end;          // end-of-stream
    std::vector<int> v(it, end);             // 读完 cin 里所有 int
}
```

输入：

`1 2 3 4 5`

v 就是 `{1,2,3,4,5}`。

### 2.2 统计流里某个单词出现次数

```C++
#include <algorithm>
#include <fstream>
#include <iterator>
#include <string>
#include <iostream>

int main() {
    std::ifstream in("a.txt");
    std::istream_iterator<std::string> begin(in), end;

    std::cout << std::count(begin, end, "the") << "\n";
}

```

这类代码在教材里很常见。[angelikalanger.com](https://angelikalanger.com/Articles/C%2B%2BReport/StreamIterators/StreamIterators.html?utm_source=chatgpt.com)

---

## 3. 底层行为（为什么解引用不读，++ 才读？）

标准规定：

- **读取动作发生在构造时和递增时**
    
- 解引用只返回已经读到的缓存值[en.cppreference.com](https://en.cppreference.com/w/cpp/iterator/istream_iterator.html?utm_source=chatgpt.com)
    

你可以理解为：迭代器内部有一个 `T value_;`，构造/++ 时调用 `stream >> value_`，`*it` 就返回这个 `value_` 的拷贝。

---

## 4. 为什么它是 Input Iterator（单趟）？

核心原因：**流是会被消耗的**。

- 你拷贝一个 `istream_iterator`：
    
    ```C++
    auto it1 = std::istream_iterator<int>(std::cin); 
    auto it2 = it1;            // 拷贝 ++it1;                     
    // 读走一个
    ```
    
    `it2` 也“共享同一个流位置”，它不是独立的第二趟遍历。
    
- 标准要求 Input Iterator 算法必须**只走一遍**，不能指望回头、也不能先扫一遍再跑第二遍。[en.cppreference.com+1](https://en.cppreference.com/w/cpp/iterator/istream_iterator.html?utm_source=chatgpt.com)
    

换句话说：  
`istream_iterator` 只是“流读取的外壳”，底层数据源是一次性的。

---

## 5. 一个容易踩的坑

### 5.1 你以为 begin() 只是拿迭代器，其实它会消耗一个元素

`std::istream_iterator<int> it(std::cin); int first = *it; // 这里已经是构造时读到的第一个`

更隐蔽的坑：如果你写了个 range，每次 begin() 都重新构造 iterator，会导致跳过元素（Eric Niebler 这篇专门吐槽过）。[Eric Niebler](https://ericniebler.com/2013/11/07/input-iterators-vs-input-ranges/?utm_source=chatgpt.com)

## 1) 最小复现：begin() 被调用两次就跳过

假设你自己包装了一个 range：

```C++
#include <iterator>
#include <iostream>

struct IntStreamRange {
    std::istream& in;
    auto begin() { return std::istream_iterator<int>(in); } // 构造时就读一个 int
    auto end()   { return std::istream_iterator<int>(); }
};

int main() {
    IntStreamRange r{std::cin};

    auto b1 = r.begin();          // 读走第 1 个
    auto b2 = r.begin();          // 又读走第 2 个！

    std::cout << *b1 << " " << *b2 << "\n";
}
```

输入：`10 20 30`  
输出可能是：`10 20`  
你本来可能期望 b1、b2 都指向第一个元素，但实际上**第二次 begin 直接把下一个读掉了**。

原因就是 `istream_iterator` 的语义：**构造时读取首元素**，`++` 时继续读。[Eric Niebler](https://ericniebler.com/2013/11/07/input-iterators-vs-input-ranges/?utm_source=chatgpt.com)

---

## 6. 和 range-for 的结合

你可以这样写：

```C++
for (std::istream_iterator<int> it(std::cin), end; it != end; ++it) {
    std::cout << *it << "\n";
}
```

但不能直接：

`for (int x : std::cin) { } // ❌ istream 不是 range`

要做 range-for，可以自己包一层 range（C++20 ranges 里也有类似 view 的做法，但原理不变）。[Eric Niebler](https://ericniebler.com/2013/11/07/input-iterators-vs-input-ranges/?utm_source=chatgpt.com)

---

## 7. 什么时候用它？

适合：

- “把输入流当序列喂给算法/容器”
    
- 快速读文件、stdin
    
- 省掉手写 while(cin >> x)
    

不适合：

- 需要多趟扫描
    
- 需要随机访问
    
- 需要回退
    

---