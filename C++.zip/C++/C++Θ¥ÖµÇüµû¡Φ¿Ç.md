# C++ 静态断言（static_assert）完整笔记

## 1. 什么是 C++ 的静态断言？

**静态断言（`static_assert`）就是编译期断言。**

语法形式：

```cpp
// C++11 起
static_assert( 常量表达式 , "失败时的错误信息" );

// C++17 起可以省略消息
static_assert( 常量表达式 );
```

含义：

- `常量表达式` 必须在 **编译期就能求值**，也就是符合 `constexpr` 语义；
- 若结果为 `true`：编译器什么都不做；
- 若结果为 `false`：**直接编译错误**，程序不会通过编译，更不会运行。

### 1.1 与 `assert` 的区别

| 特性              | `assert`                           | `static_assert`                     |
|-------------------|------------------------------------|-------------------------------------|
| 检查时机          | **运行时**                         | **编译时**                          |
| 条件类型          | 任意运行时表达式                   | 必须是编译期常量表达式              |
| 失败后的行为      | 程序在运行时终止（`abort`）        | 直接编译失败，生成不了可执行文件   |
| 是否受 `NDEBUG` 影响 | 是，`NDEBUG` 时可能被去掉      | 否，永远生效                        |

可以理解为：

> `assert` 是“运行时保险丝”，
> `static_assert` 是“编译期保险丝”。

### 1.2 版本时间线

- **C++11**：第一次引入 `static_assert(bool_constexpr, const char* msg);`
- **C++17**：允许省略消息字符串：`static_assert(bool_constexpr);`

---

## 2. static_assert 怎么使用？

`static_assert` 可以出现在：

- 命名空间作用域（全局）；
- 类定义内部；
- 函数体内部；
- 模板定义内部。

唯一硬条件：**表达式是编译期常量布尔值。**

### 2.1 检查平台 / 编译环境假设

```cpp
#include <climits>

static_assert(CHAR_BIT == 8, "我们假设 1 字节 = 8 bit");
static_assert(sizeof(void*) == 8, "只支持 64 位平台");
```

适用场景：

- 程序对目标平台有硬约束（例如必须 64 位、必须 8bit 字节）；
- 希望这些前提不满足时，立刻在编译阶段失败，而不是运行时再出问题。

### 2.2 检查结构体布局 / 尺寸（ABI 假设）

```cpp
struct Header {
    std::uint32_t magic;
    std::uint16_t version;
    std::uint16_t flags;
};

static_assert(sizeof(Header) == 8, "Header 大小被改坏了");
```

常见于：

- 网络协议头；
- 文件格式头；
- 内存映射硬件寄存器；
- 与 C 接口 / 其他进程 / 磁盘格式共享数据结构时，必须保证布局不变。

这样，当有人修改字段顺序、类型或导致对齐规则变化时，可以第一时间把问题暴露在编译阶段。

### 2.3 模板类型约束（配合 `<type_traits>`）

```cpp
#include <type_traits>

template <class T>
T add(T a, T b) {
    static_assert(std::is_arithmetic_v<T>, "T 必须是算术类型");
    return a + b;
}
```

效果：

- 如果有人写 `add(std::string("a"), std::string("b"))`，编译会报错；
- 报错信息会直接包含 "T 必须是算术类型"；
- 比起模板爆栈一大堆晦涩错误消息要友好得多。

更复杂一点的组合：
[[C++travail类型]]
```cpp
template <class T>
struct PodBuffer {
    static_assert(std::is_trivially_copyable_v<T>,
                  "T 必须是 trivially copyable 类型");

    static_assert(sizeof(T) <= 64,
                  "T 太大了，不适合放在这个缓冲区里");

    T data[1024];
};
```

这类写法非常适合约束“只允许简单小对象”，避免误用复杂类型带来隐式开销或未定义行为。

### 2.4 编译期参数范围检查

```cpp
template <std::size_t N>
struct Buffer {
    static_assert(N > 0 && N <= 4096,
                  "N 必须在 (0, 4096] 范围内");

    char data[N];
};
```

或者：

```cpp
constexpr std::size_t MAX_SIZE = 1024;

template <std::size_t N>
void process(char (&arr)[N]) {
    static_assert(N <= MAX_SIZE, "数组太大了");
    // ...
}
```

这类 `static_assert` 能保证：

- 一旦有人传了非法大小的模板参数，直接编译期爆雷；
- 比运行时再抛异常/返回错误更适合做“配置上限”和“构建参数”的强约束。

### 2.5 结合自定义 constexpr 布尔函数使用

当条件比较复杂时，推荐封装成一个语义清晰的 `constexpr bool`，再放进 `static_assert` 中：

```cpp
#include <type_traits>

template <class T>
constexpr bool is_small_trivial_v =
    std::is_trivially_copyable_v<T> && sizeof(T) <= 64;

static_assert(is_small_trivial_v<int>, "int 不满足约束？");

struct MyType { /* ... */ };
static_assert(is_small_trivial_v<MyType>, "MyType 必须是小而简单的类型");
```

这样做的好处：

- 复杂的模板逻辑被藏在一个名字好的 trait 里；
- `static_assert` 只负责给出一句清晰的人类可读错误信息。

---

## 3. 在哪些场景下推荐使用？

可以用一句话概括：

> **只要“条件完全由编译期信息决定”，并且它是你代码的“硬前提”，就非常适合用 static_assert。**

典型推荐场景：

### ✅ 场景 1：模板的类型 / 属性约束

- 要求模板参数满足某些 `type_traits`：
  - 是算术类型 / 枚举类型；
  - 是 trivially copyable / standard layout；
  - 可默认构造 / 可移动 / 可拷贝等。
- static_assert + 自定义错误信息，使错误“语义化”。

```cpp
template <class T>
void serialize(const T& obj) {
    static_assert(std::is_trivially_copyable_v<T>,
                  "serialize 只支持 trivially copyable 类型");
    // ...
}
```

### ✅ 场景 2：结构体大小 / 对齐 / 布局的 ABI 保证

- 网络协议头、磁盘文件头、共享内存结构、IPC 消息等；
- 硬件寄存器 / DMA 描述符；
- 与 C 接口或其他语言共享二进制布局。

```cpp
struct Packet {
    std::uint8_t  type;
    std::uint8_t  flags;
    std::uint16_t len;
};

static_assert(sizeof(Packet) == 4, "Packet 布局改变了，需检查 ABI/协议");
```

### ✅ 场景 3：平台、编译器 / 编译选项前提

- 限制项目只能在 64 位编译；
- 限制某些宏组合必须满足特定关系；
- 限制必须是小端 / 大端（配合自定义端序检测）。

```cpp
static_assert(sizeof(long) == 8, "本项目假设 long 为 8 字节");

#ifdef ENABLE_FAST_PATH
static_assert(SOME_FLAG == 1, "ENABLE_FAST_PATH 需要 SOME_FLAG == 1");
#endif
```

### ✅ 场景 4：编译期参数合法性 / 配置上下限

- 非类型模板参数 N 的范围；
- 编译期选择的枚举值组合是否合法；
- 某种编译期开关之间不能冲突。

```cpp
template <int LEVEL>
struct Logger {
    static_assert(LEVEL >= 0 && LEVEL <= 3,
                  "LEVEL 必须在 0~3 之间");
};
```

---

## 4. 哪些场景下不推荐使用 / 根本用不了？

### ❌ 场景 1：依赖运行时数据的检查

```cpp
int n = read_from_user();
static_assert(n > 0, "n 必须 > 0");  // ❌ 错误：n 不是常量表达式
```

- 用户输入、配置文件内容、命令行参数、网络数据等，都属于 **运行时信息**；
- 这些应该用：
  - `if` + 异常 / 返回错误码；
  - 或运行时 `assert(n > 0);`；
  - 而不是 `static_assert`。

判断标准：

> **如果值会随程序运行而变化，就不能用 static_assert。**

### ❌ 场景 2：给最终用户看的业务错误

- `static_assert` 的错误是给“**写代码的人**”看的，而不是给终端用户看的；
- 所以“余额不足”“权限不足”这类，都应该是运行时行为，不属于 static_assert 的职责。

### ❌ 场景 3：过于复杂、难以理解的断言条件

- 复杂的模板 + `decltype` + 一堆嵌套 type_traits，直接写进 static_assert 会让错误信息非常难读；
- 更好的做法是：先封装成一个意义清晰的 trait，再断言那个 trait。

```cpp
// 不推荐：
static_assert(std::is_trivially_copyable_v<T> &&
              std::is_nothrow_move_constructible_v<T> &&
              sizeof(T) <= 64,
              "T 太复杂或太大");

// 推荐拆分：

template <class T>
constexpr bool is_small_fast_v =
    std::is_trivially_copyable_v<T> &&
    std::is_nothrow_move_constructible_v<T> &&
    sizeof(T) <= 64;

static_assert(is_small_fast_v<T>, "T 必须是小而易移动的类型");
```

### ❌ 场景 4：C++20 起，对外接口约束优先用 concepts

对于“**库对外暴露的模板接口**”，如果你用的是 C++20 及以上，
推荐用 `concepts` / `requires` 来约束，而不是大量 `static_assert`：

```cpp
#include <type_traits>

template <typename T>
concept Arithmetic = std::is_arithmetic_v<T>;

template <Arithmetic T>
T add(T a, T b) { return a + b; }
```

- `concept` 可以让模板错误更早、更清晰地在调用点暴露；
- `static_assert` 仍然非常适合用在 **内部不变量** / **布局 / 配置** 上。

---

## 5. 总结

1. **静态断言是编译期保险丝**：
   - 条件是编译期常量表达式；
   - 不满足就编译失败，程序根本跑不起来。

2. **推荐使用在**：
   - 模板参数 / 类型属性约束；
   - 结构体大小 / 布局 / 对齐等 ABI 假设；
   - 平台 / 编译器 / 宏配置前提条件；
   - 编译期参数范围控制与合法性检查。

3. **不适用或不推荐用在**：
   - 依赖运行时数据的校验（用户输入、文件内容、网络数据等）；
   - 需要给最终用户看的业务逻辑错误；
   - 过于复杂、难以理解的表达式；
   - C++20 后对外接口的类型约束（更推荐 concepts）。

把它当成：

> “**把所有‘只要不满足就绝对不能编过’的硬条件，都写进 static_assert 里。**”

这样一来，很多本应在用户现场才炸出来的问题，可以在你自己编译代码时就被截胡。