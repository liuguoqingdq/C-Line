`alignas` 是 C++11 引入的 **对齐说明符**，用来**显式指定一个类型/对象的对齐（alignment）要求**。简单说：你告诉编译器“这个东西的地址必须按多少字节对齐”。

---

## 1. 基本语法

```C++
alignas(N) type name;
alignas(type) type name;   // 按某个类型的对齐要求对齐
```

### 例子：让对象 16 字节对齐

```C++
alignas(16) int x;
static_assert(alignof(x) == 16);
```

### 例子：按 `double` 的对齐来对齐一个对象

```C++
alignas(double) char buf[32];
static_assert(alignof(buf) == alignof(double));
```

---

## 2. 可以用在哪些地方？

### (1) 普通变量

```C++
alignas(32) float a[8];
```

### (2) 结构体/类类型

```C++
struct alignas(16) Vec4 {
    float x, y, z, w;
};
static_assert(alignof(Vec4) == 16);
```

### (3) 成员变量

```C++
struct S {
    char c;
    alignas(8) int i;  // i 按 8 对齐
};
```

### (4) `new` 出来的对象也要满足

```C++
struct alignas(64) CacheLine {
    int x;
};

auto p = new CacheLine;  // 标准库会保证 64 对齐 (C++17 起)
```

---

## 3. `alignas` 和 `alignof` 的关系

- `alignas`：**我来指定对齐**
    
- `alignof`：**我来查询对齐**
    

```C++
struct alignas(32) A {};
static_assert(alignof(A) == 32);
```

---

## 4. 重要规则 / 限制

### 规则 1：只能“增大”对齐，不能降低到不合法

```C++
struct B { double d; };

struct alignas(1) Bad : B {}; 
// ❌ 1 小于 double 需要的对齐，非法
```

换句话说：**最终对齐 = max(自然对齐, 你指定的对齐)**。

---

### 规则 2：对齐值必须是 2 的幂（常见平台要求）

```C++
alignas(3) int x; // ❌ 非 2 的幂，通常不允许
```

---

### 规则 3：多个 `alignas` 取最大值

```C++
alignas(8) alignas(32) int x;
static_assert(alignof(x) == 32);
```

---

## 5. 典型用途

### (1) SIMD / 向量化加速

很多 SIMD 指令要求数据按 16/32/64 对齐：

```C++
alignas(32) float data[8];
```

### (2) cache line 对齐，减少伪共享（false sharing）

```C++
struct alignas(64) Counter {
    std::atomic<long> v;
};
```

### (3) 自己做内存池 / placement new

需要确保缓冲区足够对齐：

```C++
alignas(std::max_align_t) std::byte buf[1024];
```

---

## 6. 小坑提醒

1. **`alignas` 会影响 `sizeof`**（可能插 padding/扩大结构体）。
    
2. **over-aligned 类型**（比如 `alignas(64)`）在老标准/老库里用容器可能有坑；C++17 以后支持更好。
    
3. 对齐过大不一定更快，可能浪费内存、影响缓存利用率。
    

---

一句话总结：  
`alignas` 是“**我指定对齐**”，让类型/对象按你要求的字节边界对齐；常用于 SIMD、cache 优化、内存布局控制等底层场景。