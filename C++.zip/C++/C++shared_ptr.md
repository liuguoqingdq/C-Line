## 1. `shared_ptr` 的核心语义：共享所有权

- `std::unique_ptr<T>`：**独占所有权**，不能复制，只能移动。
    
- `std::shared_ptr<T>`：**共享所有权**，可以复制，复制增加引用计数。
    
- 当最后一个 `shared_ptr` 被销毁 / reset 时，对象析构（调用deleter）。
    

一句话：

> `shared_ptr` 通过“引用计数”管理对象寿命。

---

## 2. 内部结构：对象 + 控制块（control block）

`shared_ptr` 实际上是两个部分：

1. **指向对象的指针**（T*）
    
2. **控制块**（通常在堆上）：
    
    - `use_count`：强引用计数（多少个 `shared_ptr`）
        
    - `weak_count`：弱引用计数（多少个 `weak_ptr`，外加一个隐含weak保活）
        
    - deleter / allocator / type-erasure 信息等
        

示意：

```txt
shared_ptr<T> sp  --->  [pointer to T]
                     \
                      ---> Control Block { use=1, weak=1, deleter, ... }

```

**对象什么时候析构？**

- `use_count` 变成 0 时，析构对象（调用 deleter）。
    
- 控制块什么时候释放？  
    当 `use_count==0` 且 `weak_count==0` 时，释放控制块。
    

---

## 3. 基本用法与行为

### 3.1 创建

```C++
auto sp = std::make_shared<Foo>(1, 2, 3);
```

或

```C++
std::shared_ptr<Foo> sp(new Foo(1,2,3));  // 允许，但不推荐
```

### 3.2 复制 / 赋值

```C++
auto sp2 = sp;        // use_count++ 
sp2 = sp;             // 同样 use_count++
```

### 3.3 reset / 析构

`sp.reset();           // use_count--`

如果这是最后一个强引用，则对象析构。

### 3.4 访问

```C++
sp->method();
(*sp).method();
sp.get();             // 裸指针（不改变计数）
```

---

## 4. 为什么强烈推荐 `make_shared`？

`make_shared` 的关键优势：

1. **一次分配**
    
    - 对象和控制块通常一起分配在一块内存里
        
2. **更快、更省内存、更 cache-friendly**
    
3. **异常安全**
    
    - `shared_ptr(new T)` 涉及两次分配：对象一次、控制块一次
        
    - 若控制块分配失败（极少但可能），会泄漏对象
        
    - `make_shared` 不会发生这个问题
        

**例外什么时候不用 `make_shared`？**

- 你需要**自定义 deleter**
    
- 你想要对象和控制块分开（比如弱引用要延长控制块寿命一类的特殊设计）
    
- 你需要用特定 allocator（可用 `allocate_shared`）
    

---

## 5. 引用计数 API 的正确理解

```C++
sp.use_count();    // 强引用数（调试用）
sp.unique();       // C++17 仍有，但 C++20 起弃用（因为含义易误导）
```

教授提醒：

> **不要用 use_count() 写业务逻辑。**  
> 并发下它是瞬时值，逻辑会变得不可靠。

---

## 6. 线程安全：你必须知道的边界

- **控制块的引用计数增减是原子操作** → 多线程复制/销毁同一个对象的 `shared_ptr` 是安全的。
    
- **但对象本身不是自动线程安全的**  
    只保证“引用计数正确”，不保证 `T` 的内部无数据竞争。
    

例子：

```C++
// sp 在多个线程拷贝/销毁 OK
auto local = sp; // atomic use_count++

// 但对 *sp 的读写仍需你自己加锁
sp->x++; // 可能 data race
```

---

## 7. 自定义 deleter：让 `shared_ptr` 管 “非 new 的资源”

比如文件句柄、socket、第三方库对象：

```C++
std::shared_ptr<FILE> fp(
    fopen("a.txt", "r"),
    [](FILE* f){ if(f) fclose(f); }
);
```

**deleter 存在控制块里**，它有类型擦除，代价是控制块更大。
shared_ptr只有一个模板参数，unique_ptr有两个参数的原因在于，unique_ptr没有控制块，deleter要放在对象里，而shared_ptr有控制块，deleter在控制块里。

---

## 8. 与 `weak_ptr` 配合：解决循环引用

`shared_ptr` 最大的坑：

> 如果 A 持有 B 的 shared_ptr，B 也持有 A 的 shared_ptr，use_count 永远不为 0 → 内存泄漏。

解决：一边改用 `weak_ptr`。

```C++
struct B;

struct A {
    std::shared_ptr<B> b;
};

struct B {
    std::weak_ptr<A> a;   // 关键
};
```

使用 weak：

`if (auto spA = b->a.lock()) {     // spA 是临时 shared_ptr，确保对象活着 }`

---

## 9. aliasing constructor（别名构造）：高级但很有用

你可以让一个 `shared_ptr` **共享同一控制块**，但指向对象内部的子对象。

```C++
auto sp = std::make_shared<Foo>();
std::shared_ptr<int> spField(sp, &sp->field);
```

特点：

- `spField` 的 deleter 仍然由 `sp` 的控制块管理
    
- 只要 `spField` 活着，整个 `Foo` 也活着
    
- 非常适合“对外暴露子视图，但延长整体寿命”
    

---

## 10. `enable_shared_from_this`：对象内部安全地拿 shared_ptr

经典问题：类里想返回 `shared_ptr<this>`：

```C++
struct X {
    std::shared_ptr<X> getPtr() { return std::shared_ptr<X>(this); } // ❌灾难
};
```

这会创建**第二个控制块**，导致 double delete。

正确做法：

```C++
struct X : std::enable_shared_from_this<X> {
    std::shared_ptr<X> getPtr() {
        return shared_from_this();  // ✅共享同一控制块
    }
};
```

前提：**对象必须已经被 shared_ptr 管理**。

---

## 11. 性能与成本（工程视角）

`shared_ptr` 的成本主要来自：

1. **控制块分配**
    
2. **引用计数原子增减**（多线程下有缓存一致性开销）
    
3. **更大对象体积（通常两个指针大小）**
    

因此建议：

- **默认用 unique_ptr**  
    只有确实需要共享寿命时才上 shared_ptr
    
- 在热点路径避免频繁复制，能传引用就传引用
    
- 用 `make_shared` 降低分配成本
    

---

## 12. 常见坑总结（考试/面试/工程都会踩）

1. **用裸指针构造多个 shared_ptr**
    
    ```C++
    Foo* p = new Foo;
	std::shared_ptr<Foo> a(p);
	std::shared_ptr<Foo> b(p); // ❌ 两个控制块，double delete
    ```
    
    正确：只构造一次，然后复制。
    
2. **循环引用泄漏**  
    记住用 weak_ptr 断环。
    
3. **错误的 this shared_ptr**  
    记住 enable_shared_from_this。
    
4. **use_count 当逻辑判断**  
    并发下不可靠。
    
5. **用 shared_ptr 表示“共享数据”但忘了对象线程安全**  
    shared_ptr 不等于线程安全对象。
    

---

## 13. 何时应该用 shared_ptr？（决策准则）

✅ 典型场景：

- 多个模块/线程需要共享同一对象寿命
    
- 观察者 / 回调 / 异步任务需要延长对象活着的时间
    
- 图结构里需要共享节点（但要注意 break cycle）
    

❌ 反例：

- 只是“想省心不管 delete”  
    → 优先 unique_ptr
    
- 明确只有一个 owner  
    → unique_ptr 更清晰更快
    
- 不需要动态寿命管理  
    → 直接栈对象或成员对象


-------

## 答疑
先把代码抄一遍：

```C++
auto sp = std::make_shared<Foo>();
std::shared_ptr<int> spField(sp, &sp->field);
```

我们一行一行拆开讲。

---

## 1. 第一行：`auto sp = std::make_shared<Foo>();`

这行发生了什么？

- 在堆上**一次性**分配了一块内存，里面放：
    
    - 一个 `Foo` 对象
        
    - 一个控制块（control block），包含：
        
        - `use_count`（强引用计数）
            
        - `weak_count`（弱引用计数）
            
        - deleter 等信息
            
- 返回一个 `std::shared_ptr<Foo>`，记为 `sp`
    
- 此时控制块里：
    

```txt
对象： Foo
sp:   指向 Foo 的 shared_ptr<Foo>

Control Block:
    use_count  = 1   // 一个 shared_ptr (sp)
    weak_count = 1   // 隐含的 weak 引用，用来保控制块本身
    deleter    = ~Foo()
```

---

## 2. 关键：第二行用了“别名构造函数”（aliasing constructor）

```C++
std::shared_ptr<int> spField(sp, &sp->field);
```

这是 `shared_ptr` 的一个特殊构造函数，原型大致是：

```C++
template <class Y>
shared_ptr(const shared_ptr<Y>& r, element_type* p) noexcept;
```

也就是说：

- 第一个参数：`r` —— 一个已有的 `shared_ptr<Y>`（这里是 `shared_ptr<Foo>`）
    
- 第二个参数：`p` —— 一个裸指针 `T*`（这里 `T` 是 `int`，`p = &sp->field`）
    

**这个构造函数干的事情只有两件：**

1. **共享 r 的控制块**（也就是和 `sp` 共享同一个 control block）
    
2. **把内部指针换成你给的那个裸指针 p**
    

用图画一下你就懂了。

---

## 3. 对象关系图

假设 `Foo` 结构如下：

`struct Foo {     int field;     double other; };`

执行完两行代码后，结构大致是：

   ```txt
      sp    ─────────────┐
   (shared_ptr<Foo>)  │   指向 Foo 对象
                      v
                 [ Foo 对象 ]
                 field: int
                 other: double

   spField ──────┐
   (shared_ptr<int>) │
                     v
                   &Foo::field   // 指向 Foo::field 这个 int 成员

     两者共同指向 ↓ 同一个控制块 ↓

             [ Control Block ]
             use_count  = 2    // sp 和 spField 各占一个
             weak_count = 1    // 隐含 weak
             deleter    = 调用 Foo 的析构函数

   ```

注意两点非常重要：

1. **控制块是共享的**：`sp` 和 `spField` 的 `use_count` 是同一个计数
    
2. **指针值不同**：
    
    - `sp` 内部保存的是 `Foo*`
        
    - `spField` 内部保存的是 `int*`，指向 `Foo::field`
        

但是——**deleter 仍然是“销毁整个 Foo 对象”**。  
这意味着：最后一个 `shared_ptr` 销毁时，会整个 `Foo` 析构掉，而不是只析构那个 `int field`。

---

## 4. 生命周期行为到底是怎样的？

假设有如下代码：

```C++
auto sp = std::make_shared<Foo>();      // use_count = 1
std::shared_ptr<int> spField(sp, &sp->field); // use_count = 2

sp.reset();       // use_count 变成 1，Foo 还活着
spField.reset();  // use_count 变成 0，Foo 被析构，控制块释放
```

所以：

- **只要 `spField` 还活着，`Foo` 一定活着**，因为它们共用控制块
    
- `spField` 只是“引用”了 `Foo` 内部的一个成员，但负责托底整块 `Foo` 的生命周期
    

你可以把 `spField` 理解成：

> “我手上只拿着 `Foo::field` 这个成员指针，但我答应你：只要我没死，整块 `Foo` 不会被释放。”

---

## 5. 为什么要这么干？——典型用途

这种写法不是抽风，它是为了一个很实用的需求：**只对外暴露对象的一部分，但又希望保证整体活着**。常见场景：

- 暴露数组 / buffer 中的一段：  
    `shared_ptr<char> buf(basePtrShared, basePtr + offset);`
    
- 暴露结构体中的一个字段，但**不希望调用者知道整个结构体的存在**
    
- 对外只给出“视图”（view），但是通过 aliasing constructor，确保整个底层资源的寿命被正确管理
    

简单例子：

```C++
struct Data {
    std::vector<int> vec;
};

std::shared_ptr<Data> data = std::make_shared<Data>();
// 想把 vec.data() 暴露出去，但要保证 data 活着：
std::shared_ptr<int> begin(data, data->vec.data());
```

以后某个函数只拿到 `std::shared_ptr<int>`，完全不知道有个 `Data` 在背后，但由于共用控制块，只要这个 `shared_ptr<int>` 活着，`Data` 一定不会被释放。

---

## 6. 对比“错误用法”：你不能这么写

**错误示例：**

`// 千万不能这么写： std::shared_ptr<int> bad(&sp->field); // ❌ 极其危险`

问题：

- 这会创建一个 **全新的控制块**，假装自己“拥有”这块 `int` 内存
    
- 当 `bad` 析构时，会调用 `delete int*` 去释放 `&sp->field`，而这块内存本来是 `Foo` 对象的一部分
    
- 最终是 **未定义行为 / 崩溃**
    

所以：

> 如果你想让一个 `shared_ptr<U>` “附着”在另一个 `shared_ptr<T>` 上，一定要用 **aliasing constructor** 这种形式，而不是直接喂一个野生裸指针。

---

## 7. 用一句话总结这两行代码

```C++
auto sp = std::make_shared<Foo>();
std::shared_ptr<int> spField(sp, &sp->field);
```

**语义翻译：**

> 先创建一个由 `shared_ptr<Foo>` 管理的 `Foo` 对象，然后再创建一个 `shared_ptr<int>`，  
> 它：
> 
> - 和 `sp` 共用同一个引用计数（共享生命周期）
>     
> - 但对外表现为“持有一个 `int*`（指向 `Foo::field`）”
>     

所以它是一个 **“别名智能指针”**：别名指向子对象，生命周期绑在整体对象上。

---