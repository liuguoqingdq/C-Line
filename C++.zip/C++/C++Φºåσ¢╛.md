string_view
span

## 1. 什么是“视图（view）”？

在 C++ 里，“视图”不是单一类型，而是一类设计思想：

> **view = 对一段已有数据的“非拥有、轻量、通常惰性”的访问窗口**  
> 它不负责存储数据，只负责“怎么读/怎么遍历/怎么切片”。

### 视图的共同特征

1. **不拥有数据**：只是引用某个已有数据源
    
2. **零拷贝**：创建视图不会复制元素
    
3. **常常是惰性的**：遍历时才计算（Ranges view）
    
4. **生命周期敏感**：底层数据没了，视图就悬垂
    

典型视图类型：

- `std::string_view`：字符串视图（指针+长度）
    
- `std::span<T>`：连续内存视图（指针+长度）
    
- C++20 `std::ranges::view` 家族：`filter_view`、`transform_view` 等

-------
`std::string_view`（C++17）就是**字符串的“只读视图”**：不拥有数据、零拷贝地“看一段字符序列”。它和 `std::span<char>` 很像，但更专门针对文本。

---

## 1. 定义与本质

头文件：`#include <string_view>`

本质上就是：

> **指针 + 长度**  
> `const char* ptr; size_t len;`

它引用已有的字符内存，不负责分配/释放。

---

## 2. 为什么要用它？

### 2.1 避免拷贝（性能）

你写接口时如果用 `std::string` 按值传参，会拷贝。

```C++
void f(std::string s); // 可能拷贝
```

用 `string_view`：

```C++
void f(std::string_view s); // 零拷贝
```

这个函数可以接受：

- `std::string`
    
- 字面量 `"hello"`
    
- `char* / const char*`
    
- 甚至 `std::array<char, N>` / `std::span<char>`（可转换时）
    

### 2.2 方便切片/子串

`substr` 返回的也是 view，不复制：

```C++
std::string_view s = "abcdef";
auto t = s.substr(1, 3); // "bcd"，O(1)
```

---

## 3. 基本用法

### 3.1 创建

```C++
std::string str = "hello world";

std::string_view v1 = str;          // 从 string
std::string_view v2 = "hello";      // 从字面量
std::string_view v3(str.data(), 5); // 指针+长度
```

### 3.2 常用 API

和 `std::string` 看起来很像（只读）：

```C++
v.size(), v.empty()
v.front(), v.back(), v[i]
v.substr(pos, n)
v.find("xx"), v.rfind(...)
v.starts_with("he")   // C++20
v.ends_with("ld")     // C++20
```

### 3.3 比较/哈希

可以直接比较、放 unordered_map：

```C++
if (v == "hello") ...
std::unordered_map<std::string_view, int> mp; // ✅ 但必须保证 key 的生命周期
```

---

## 4. 最重要的坑：生命周期（和 span 一样）

`string_view` **不拥有底层字符**，底层没了它就悬垂。

### 4.1 错误例子：绑定临时 string

```C++
std::string_view bad() {
    std::string s = "hi";
    return s;   // ❌ 返回 view，s 退出作用域就销毁
}
```

### 4.2 错误例子：指向临时拼接结果

```C++
std::string_view v = std::string("a") + "b"; // ❌ 临时 string 立刻销毁
```

### 4.3 正确做法

- view 必须比原字符串活得短
    
- 如果要长期保存，存 `std::string`，不要存 view
    

```C++
std::string s = "hello";
std::string_view v = s; // ✅ v 只在 s 活着时用
```

---

## 5. 另一个坑：不保证以 `\0` 结尾

`string_view` 可以指向**任意一段字符**，可能不是 C 风格 null-terminated 字符串。

```C++
std::string_view v("abc\0def", 7);
```

- `v.size()==7`
    
- 但 `v.data()` 传给 C API（如 `printf("%s")`）会截断/越界。
    

**和 C 接口交互时要小心：**

```C++
std::string tmp(v);      // 拷贝成 string
c_api(tmp.c_str());      // ✅ 保证 \0
```

---

## 6. 典型工程写法（强烈推荐）

### 6.1 接口统一用 `string_view` 只读入参

`void parse(std::string_view line);`

调用方可以传任何字符串来源：

```C++
parse(str);
parse("literal");
parse(buf_view);
```

### 6.2 需要保存时再拷贝

```C++
struct Item {
    std::string name;  // 保存用 string
};

Item make_item(std::string_view s){
    return Item{std::string(s)}; // 只在这里拷贝一次
}
```

---

## 7. 和 `const std::string&`、`const char*` 对比

|参数类型|能接受的实参|是否拷贝|是否携带长度|是否有生命周期坑|
|---|---|---|---|---|
|`const std::string&`|只能 string|否|有|少|
|`const char*`|字面量/char*|否|没有|可能无界读取|
|`std::string_view`|string / 字面量 / char*|否|**有**|**有（需保证底层活着）**|

所以 `string_view` 是现代 C++ **最通用的只读字符串参数类型**。

---

## 8. 衍生类型

- `std::wstring_view`（宽字符）
    
- `std::u8string_view` / `std::u16string_view` / `std::u32string_view`（Unicode 码元视图）
    

用法同理。

---
## span
## . 本质与特点

- **非拥有（non-owning）**：span 不负责分配/释放内存
    
- **零拷贝**：创建 span 不会复制元素
    
- **连续内存**：只能指向连续存储（数组、vector、string、array 等）
    
- **带长度**：比裸指针安全
    
- **轻量**：通常就是两个字段：`T* data_` + `size_t size_`
    

---

## 2. 为什么要用 span？

传统函数参数常见两种问题：

### 只传指针：没长度

```C++
void f(int* p);   // ❌ 不知道有多少个
```

### 只传 vector：绑死容器类型

```C++
void f(const std::vector<int>& v); // ❌ 只能接 vector
```

用 span：

```C++
void f(std::span<const int> s);    // ✅ 任意连续容器都能接
```

能接受：

- C 数组 `int a[]`
    
- `std::vector<T>`
    
- `std::array<T, N>`
    
- `std::string` / `std::string_view`（对 char）
    
- 甚至一段裸内存 `T* + n`
    

---

## 3. 基本用法

### 3.1 作为函数参数

```C++
#include <span>
#include <vector>
#include <array>
#include <iostream>

void twice(std::span<int> s) {
    for (int& x : s) x *= 2;
}

int main() {
    int a[] = {1,2,3};
    std::vector<int> v{4,5,6};
    std::array<int,3> ar{7,8,9};

    twice(a);
    twice(v);
    twice(ar);

    for (auto x : v) std::cout << x << " "; // 8 10 12
}
```

### 3.2 切片（常用）

```C++
void demo(std::span<int> s) {
    auto first3 = s.first(3);
    auto last2  = s.last(2);
    auto mid    = s.subspan(1, 3); // 从1开始取3个
}
```

### 3.3 固定长度 span

```C++
std::span<int> s1;        // 动态长度
std::span<int, 3> s2;     // 静态长度（编译期检查长度=3）
```

---

## 4. 常见坑（必须注意）

### 4.1 生命周期问题

span 不拥有数据，所以底层没了就悬垂：

```C++
std::span<int> s;
{
    std::vector<int> v{1,2,3};
    s = v;          // s 指向 v 的内存
}                  // v 析构
// s 现在悬垂 ❌
```

**规则：span 的生命期必须短于它指向的数据。**

### 4.2 不能指向非连续容器

```C++
std::list<int> lst{1,2,3};
std::span<int> s = lst; // ❌ 不连续
```

### 4.3 span 不是容器

不能 `push_back`、不能改变大小，只是“窗口”。

---

## 5. 和 string_view / ranges::views 的关系

- `std::span<T>`：**连续内存视图**（指针+长度）
    
- `std::string_view`：**字符序列视图**（也是指针+长度，专门为字符串）
    
- `std::ranges::views::*`：**遍历/计算视图**（惰性 filter/transform 等）
    

span 更偏“数据切片/传参”，ranges view 更偏“惰性计算管道”。

---

### 一句话总结

`std::span` 就是 C++20 的 **“连续内存、零拷贝、带长度的视图”**，最适合用来做**通用函数参数和安全切片**。只要记住：**它不拥有数据，注意底层生命周期**。

----
## span 方法
## 1. 观察器（observers）

这些方法不改数据，只看 span 的状态。

```C++
s.size();        // 元素个数（size_t）
s.size_bytes();  // 总字节数 = size() * sizeof(T)
s.empty();       // 是否为空
s.data();        // 返回 T* 指向首元素（可能为 nullptr）
```

例子：

```C++
void info(std::span<const int> s){
    std::cout << s.size() << " elems, "
              << s.size_bytes() << " bytes\n";
    if(!s.empty()) std::cout << "first addr: " << s.data() << "\n";
}
```

---

## 2. 元素访问（element access）

```C++
s[i];        // 下标访问（不做越界检查）
s.front();   // 首元素引用
s.back();    // 末元素引用
```

例子：

```C++
void tweak(std::span<int> s){
    if(!s.empty()){
        s.front() += 1;
        s.back()  += 10;
        s[0] *= 2;
    }
}
```

> 注意：`span` 没有 `at()`（不像 vector），所以越界全靠你自己。

---

## 3. 子视图/切片（subviews）

这是 span 最好用的部分，全部 **O(1) 零拷贝**。

```C++
s.first(n);                 // 前 n 个元素的 span
s.last(n);                  // 后 n 个元素的 span
s.subspan(offset);          // 从 offset 到结尾
s.subspan(offset, count);   // 从 offset 起 count 个
```

例子：

```C++
void slices(std::span<int> s){
    auto head = s.first(3);        // [0,1,2]
    auto tail = s.last(2);         // [n-2, n-1]
    auto mid  = s.subspan(1, 3);   // [1,2,3]
}
```

---

## 4. 迭代器接口（iterators）

span 本质是个 range，所以遍历方法齐全：

```C++
s.begin(), s.end()
s.cbegin(), s.cend()
s.rbegin(), s.rend()
s.crbegin(), s.crend()
```

例子：

```C++
void print_rev(std::span<const int> s){
    for(auto it = s.rbegin(); it != s.rend(); ++it)
        std::cout << *it << " ";
}
```

也支持 range-for：

`for(int x : s) { ... }`

---

## 5. 构造与转换（常用来源）

span 的构造/隐式转换很灵活（前提是**连续内存**）：

```C++
int a[5];
std::array<int,5> ar;
std::vector<int> v;

std::span<int> s1(a);        // C 数组
std::span<int> s2(ar);       // std::array
std::span<int> s3(v);        // std::vector

std::span<const int> cs = s3;  // span<int> -> span<const int>
```

也能从“指针 + 长度”构造：

```C++
std::span<int> s(p, n);
std::span<int> s(p_begin, p_end); // 指针区间
```

---

## 6. 字节视图工具（很实用）

标准库提供两个自由函数（在 `<span>`）：

```C++
std::as_bytes(span<T>);           // -> span<const std::byte>
std::as_writable_bytes(span<T>);  // -> span<std::byte>（T 非 const）
```

例子：把结构体数组直接当字节写文件/发网络：

```C++
struct Node { int id; double w; };
std::vector<Node> v = ...;

auto bytes = std::as_bytes(std::span(v));
send(sock, bytes.data(), bytes.size_bytes(), 0);
```

---

## 7. 一个综合例子（切片 + 遍历 + 字节）

```C++
#include <span>
#include <vector>
#include <iostream>

void demo(std::span<int> s){
    if(s.size() >= 3){
        auto mid = s.subspan(1, s.size()-2);
        for(int& x : mid) x *= 10;
    }

    std::cout << "bytes: " << s.size_bytes() << "\n";
}

int main(){
    std::vector<int> v{1,2,3,4,5};
    demo(v); // v 变成 1,20,30,40,5
}
```

---

## 8. 再提醒两条 span 的“铁律”

1. **不拥有数据**：底层对象必须活得比 span 久
    
2. **只适用于连续存储**：vector/array/string/C数组可以，list/map 不行