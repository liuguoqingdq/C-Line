## 一、虚函数（virtual function）到底是什么机制？

### 1.1 目的

虚函数让你可以通过**基类指针/引用**调用到**派生类覆盖后的函数**，这叫**运行期多态**（dynamic polymorphism）。

```C++
struct Base {
    virtual void f() { std::cout << "Base\n"; }
};

struct Der : Base {
    void f() override { std::cout << "Der\n"; }
};

Base* p = new Der();
p->f();  // Der::f

```

叫“虚”不是玄学，是因为调用目标在编译期不确定，要到运行时通过表查。

---

### 1.2 vptr + vtable：对象布局与分发

**典型实现（绝大多数编译器）**：

- **每个含虚函数的类**都有一张 **虚函数表 vtable**  
    里面是该类每个虚函数的**函数地址**（或跳板 thunk 地址）。
    
- **每个对象**里有一个隐藏指针 **vptr**，指向该对象所属动态类型的 vtable。
    

想象布局：

```lua
对象(Base/Der) 内存:
+------------------+
| vptr ----------- |----> vtable(Der)
| data members...  |
+------------------+

vtable(Der):
slot0: &Der::f
slot1: &Der::~Der
...
```

调用 `p->f()` 时，大致发生：

1. 取出对象里的 vptr
    
2. vptr 指向 vtable
    
3. 按 f 的槽位(slot)取函数指针
    
4. 调用它（`this` 传进去）
    

> **槽位顺序由编译器决定**，但同一继承链上槽位会保持一致，以支持覆盖。

---

### 1.3 覆盖（override）是怎么落到 vtable 的？

派生类如果签名一致地重写虚函数：

```C++
struct Base { virtual void f(int); };
struct Der  : Base { void f(int) override; };
```

那么 **Der 的 vtable 里 f 的槽位会被 Der::f 替换掉**。  
所以基类指针调时会跳到派生实现。

---

### 1.4 纯虚函数（abstract）

`struct Base {     virtual void f() = 0;  // 纯虚 };`

含纯虚函数的类是**抽象类**：

- 不能实例化 Base
    
- 派生类必须 override，否则也抽象
    

实现上，纯虚槽位一般指向编译器提供的 `__cxa_pure_virtual` 之类报错入口。

---

### 1.5 虚析构为什么是必须的？

只要你打算“多态 delete”：

```C++
Base* p = new Der();
delete p;
```

**Base 必须有 virtual 析构**，否则只会调用 Base::~Base，Der 部分不会析构，导致资源泄漏/UB。

`struct Base {     virtual ~Base() = default; // 多态基类的铁律 };`
[[C++通过引用和对象访问虚函数]]

---

### 1.6 虚函数的代价

1. **每个对象多一个 vptr**（8 字节左右）
    
2. **每次虚调用多一次间接寻址**
    
3. **有时会阻碍内联**（但 LTO 可能优化）
    
4. 多重/虚继承时有额外指针调整（下面讲）
    

---

## 二、菱形继承问题是什么？

### 2.1 经典菱形

```txt
      A
     / \
    B   C
     \ /
      D
```

代码：

```C++
struct A { int x; };

struct B : A {};
struct C : A {};
struct D : B, C {};
```

`D` 里其实有 **两份 A 子对象**：

`D object: [ B-subobject [ A ] ] [ C-subobject [ A ] ]`

所以：

```C++
D d;
d.x = 1;  // ❌ 二义性：到底是 B::A::x 还是 C::A::x？
```

更隐蔽的问题：

- 两份 A 的状态可能不一致
    
- 你以为只有一个“祖先 A”，实际上复制了两份
    

---

## 三、虚继承（virtual inheritance）如何解决菱形？

### 3.1 写法

让中间层“虚继承 A”：

```C++
struct A { int x; };

struct B : virtual A {};
struct C : virtual A {};

struct D : B, C {};
```

含义：

> B 和 C **不各自包含一份 A**，而是共享“同一个虚基类 A 子对象”。

对象里只有一份 A：

```C++
D object:
[ B-subobject ]
[ C-subobject ]
[ shared virtual A-subobject ]
```

因此：

`D d; d.x = 1;   // ✅ OK，只有一份 A`

---

### 3.2 虚继承后构造顺序与责任

**虚基类 A 由“最底层派生类 D”负责构造**。

```C++
struct A { A(int) {} };

struct B : virtual A { B(): A(1) {} }; // 这句对最终A不生效
struct C : virtual A { C(): A(2) {} }; // 同上

struct D : B, C {
    D(): A(42), B(), C() {}  // ✅ 最终 A(42)
};
```

规则：

- **虚基类构造在最前**
    
- **只构造一次**
    
- 由最派生类（most-derived）决定参数
    

---

## 四、虚继承 + 虚函数表：对象模型更复杂在哪？

你已经知道 vtable，现在看虚继承会带来什么变化。

### 4.1 多重继承时的 vptr / vtable

如果一个类同时继承多个含虚函数的基类，通常会有**多个 vptr**（每个多态基类子对象一个）。

```C++
struct A { virtual void fa(); int ax; };
struct B { virtual void fb(); int bx; };

struct D : A, B {
    void fa() override;
    void fb() override;
};
```

布局（典型）：

```lua
D object:
[ A-subobject: vptrA, ax ]
[ B-subobject: vptrB, bx ]
[ D own members... ]
```

调用时：

- `A* pa = &d; pa->fa()` 用 vptrA 的表
    
- `B* pb = &d; pb->fb()` 用 vptrB 的表
    

**每条继承路径有自己视角的 vtable**。

---

### 4.2 虚继承时需要“虚基类偏移信息”

因为虚基类 A 不在固定位置了（不同 most-derived 可能放不同地址），  
所以当你从 B 或 C 访问 A 成员时，必须**运行期算偏移**。

实现上大概是：

- B/C 子对象里额外存一个指针/偏移（常叫 vbptr 或放 vtable 里）
    
- 通过它找到共享的 A 子对象地址
    

简化示意：

```less
D object:
[ B-subobject: vptrB + vbptrB ]
[ C-subobject: vptrC + vbptrC ]
[ virtual A-subobject ]
```

所以 `B* pb; pb->A::x` 不是编译期常量偏移，而是：

1. 读 vbptr / vtable 里的虚基偏移
    
2. 计算出 A 的实际地址
    
3. 再访问 x
    

> 这就是虚继承的核心成本：**多一次间接定位虚基类**。

---

### 4.3 虚继承 + 覆盖：thunk（this 调整）

在菱形/多重继承里，__Base_ 指向的并不一定是对象起始地址_*。  
派生对象里 Base 子对象可能在偏移处。

```C++
struct A { virtual void f(); };
struct B : virtual A { void f() override; };

D d;
A* pa = &d;     // pa 指向 A 子对象（共享虚基）
pa->f();        // 但 f 实现是 B/D 的
```

编译器必须保证：

- 调用派生的实现时，`this` 指向正确的子对象
    

所以 vtable 里可能存的不是直接 `&B::f`，而是一个 **thunk**：

> 先把 this 指针加/减一个偏移，调整到派生对象所需位置，再跳到真正函数。

这也是你会看到“vtable 里不是原函数地址而是跳板”的原因。

---

## 五、把“虚函数 + 虚继承”放一起的完整例子

```C++
#include <iostream>
using namespace std;

struct A {
    int x = 0;
    virtual void who() { cout << "A x=" << x << "\n"; }
    virtual ~A() = default;
};

struct B : virtual A {
    void who() override { cout << "B x=" << x << "\n"; }
};

struct C : virtual A {
    void who() override { cout << "C x=" << x << "\n"; }
};

struct D : B, C {
    void who() override { cout << "D x=" << x << "\n"; }
};

int main() {
    D d;
    d.x = 7;      // 只有一份 A::x

    A* pa = &d;   // 指向共享虚基 A
    pa->who();    // D::who

    B* pb = &d;
    pb->who();    // D::who

    C* pc = &d;
    pc->who();    // D::who
}
```

关键观察：

1. `x` 只有一份，各路径读到一样
    
2. 虚调用都分发到最派生 `D::who`
    
3. 多路径指针的 `this` 调整由 vtable/thunk 保证正确
    

---

## 六、什么时候用虚继承？什么时候别用？

### 用的场景

- 你想表达**“共享唯一的祖先状态/接口”**
    
- 典型：多接口组合 + 共同基类（比如 `IStream`、`IObject`）
    

### 避免的场景

- 你只想复用实现（用组合或普通继承更简单）
    
- 性能极致敏感的对象（虚继承寻址和多 vptr 成本）
    

经验：

> **虚继承是为了解决“菱形共享语义”而存在的，别为了复用代码去用它。**

---

## 七、你应该牢牢记住的“考试/工程点”

1. **虚函数通过 vptr/vtable 动态分发**
    
2. **覆盖就是替换 vtable 槽位**
    
3. **多态基类必须虚析构**
    
4. **菱形普通继承 → 两份基类子对象 → 二义性/状态复制**
    
5. **虚继承 → 共享虚基子对象 → 最派生类负责构造**
    
6. **虚继承多一个虚基定位成本（vbptr/偏移）+ thunk this 调整**