# C++ `auto` 关键字详解

> 核心一句话：**`auto` 让编译器根据初始化表达式来推导变量的类型，规则本质上和“模板类型推导”几乎一样。**

---

## 1. `auto` 是什么？历史演变

早期 C/C++ 里 `auto` 表示“自动存储期”，几乎没人用；

- C++11 重新赋予 `auto` 新含义：**类型推导**。
- 之后 C++14 / C++17 继续扩展：
  - C++14：`auto` 可用于函数返回值推导；
  - C++14：`auto` 参数的 **泛型 lambda**；
  - C++17：`auto` 作为类模板参数推导辅助（搭配 CTAD）；
  - C++20：`auto` 可用于模板参数（`template <auto N>`）等；

现代 C++ 中说 `auto`，几乎都是在说“类型推导”。

---

## 2. 最核心的用法：局部变量类型推导

```cpp
int x = 42;
auto a = x;         // a 被推导为 int

const int cx = 10;
auto b = cx;        // b 是 int（顶层 const 被去掉）

int& rx = x;
auto c = rx;        // c 是 int（引用被忽略，退化为值）

auto& d = rx;        // d 被推导为 int&（你显式声明成引用）
```

几点要点：

1. `auto` 必须有初始化式：
   ```cpp
   auto x; // ❌ 不合法，没有初值无法推导
   ```

2. `auto` 推导规则 ≈ 模板参数推导规则：
   - `auto v = expr;` 的推导类似 `template<class T> void f(T param); f(expr);` 时对 `T` 的推导；
   - 不写引用时，会**去掉引用、顶层 const，并且数组/函数退化**（见后文）。

---

## 3. 详细类型推导规则（和模板一致）

### 3.1 不带引用的 `auto`

```cpp
auto x = expr;
```

大致相当于：

- 忽略表达式的 **引用** 属性；
- 去掉顶层 `const` / `volatile`；
- 数组类型退化为指针；
- 函数类型退化为函数指针。

例子：

```cpp
int arr[5];
auto p = arr;           // p 的类型是 int*（数组退化为指针）

void foo();
auto pf = foo;         // pf 的类型是 void (*)()

const int n = 10;
auto v = n;            // v 是 int（顶层 const 去掉）
```

### 3.2 带引用的 `auto&` / `auto&&`

#### `auto&`

```cpp
int x = 0;
int& rx = x;
const int cx = 1;

auto& a = x;   // a: int&
auto& b = rx;  // b: int&
auto& c = cx;  // c: const int& （注意：引用本身不区分 const，const 体现在所引用的对象类型上）
```

#### `auto&&`（万能引用 / 转发引用）

```cpp
template <class T>
void wrapper(T&& x) {
    auto&& y = x;  // y 的类型会随 x 左右值变化
}
```

- 和模板中的 `T&&` 一样，`auto&&` 会对右值/左值做折叠，形成万能引用。

### 3.3 `const auto` / `auto*` 等组合

```cpp
int x = 0;
const auto a = x;   // a: const int
auto* p = &x;       // p: int*
const auto* cp = &x; // cp: const int*
```

`auto` 本身推导出“基础类型”，再叠加你写在左边/右边的修饰符。

---

## 4. 与 `std::initializer_list` 的特殊关系

用 **花括号初始化** 时，`auto` 有一些特殊规则。

### 4.1 `auto x = { ... }`

```cpp
auto x = {1, 2, 3};      // x 的类型是 std::initializer_list<int>

auto y = {1, 2.0};       // ❌ 错误：推导不出统一的 initializer_list<T>
```

`auto` 会尝试把 `{...}` 推导为 `std::initializer_list<T>`，要求所有元素可转成同一类型。

### 4.2 `auto x{...}` 的情况

注意：

```cpp
auto x{1};          // C++14/17 下，x 仍是 int（直接初始化）
auto y{1, 2};       // ❌ 错误，不能用这种形式推导出 initializer_list
```

区别：

- `auto x = {1, 2};` → initializer_list
- `auto x{1};` → 直接初始化，推导为 `int`

这块有些细节在不同标准版本里有差异，实际写代码时尽量避免 **在 `auto` 上玩复杂大括号初始化**，容易搞混。

**推荐做法**：

- 需要 `initializer_list` 明确写：`std::initializer_list<int> x = {1, 2, 3};`
- 或用 `std::vector<int> v{1, 2, 3};`

---

## 5. `auto` 与函数

### 5.1 trailing return type（C++11）

```cpp
template <class T, class U>
auto add(T x, U y) -> decltype(x + y) {
    return x + y;
}
```

这里 `auto` 只是占位，真正的返回类型是 `-> decltype(...)` 指定的。

### 5.2 返回值自动推导（C++14 起）

C++14 允许：

```cpp
auto add(auto x, auto y); // C++20 才允许参数也用 auto

auto add(int x, int y) {  // 返回值类型由 return 推导
    return x + y;         // 推导为 int
}
```

注意：

- 如果函数里有多个 `return`，**所有返回表达式类型必须一致**或可通过 usual rules 形成统一类型；
- 否则编译期报错。

### 5.3 `auto` 函数形参（C++20 统一到“占位符类型”）

你会看到类似：

```cpp
auto add(auto x, auto y) {
    return x + y;
}
```

- 这本质上是语法糖：编译器给你生成一个函数模板；
- 参数的 `auto` 也走类型推导，只不过是模板参数推导。

在 C++14 中，只有 **lambda 参数** 支持这种写法：

```cpp
auto lam = [](auto x, auto y) { return x + y; }; // 泛型 lambda
```

---

## 6. `auto` vs `decltype(auto)`

### 6.1 `auto` 会“退化”/丢掉引用信息

```cpp
int x = 0;
int& rx = x;

auto a = rx;          // a: int（引用信息丢了）

auto& b = rx;        // b: int&（显式声明成引用）
```

如果你想 **保留表达式的值类别和引用性**，就需要 `decltype(auto)`：

```cpp
int x = 0;
int& rx = x;

decltype(auto) a = rx;   // a: int&（保留引用）
```

对返回值尤为重要：

```cpp
int& foo();

auto f1() { return foo(); }         // 返回类型被推导成 int（值）

decltype(auto) f2() { return foo(); } // 返回类型是 int&（引用）
```

一般经验：

- 只在局部变量上用 → `auto` 足够，大部分时候更安全（避免意外返回引用）；
- 写“完美转发”、“转发引用”的高级模板时，才用 `decltype(auto)` 小心处理。

---

## 7. 何时应该用 `auto`？何时应该避免？

### 7.1 推荐使用场景

1. **右边类型极其冗长、读者很容易从右边看懂**

```cpp
std::unordered_map<std::string, std::vector<int>> mp;
for (auto& [key, vec] : mp) {   // C++17 结构化绑定
    // ...
}

auto it = mp.find("key");
```

2. **避免重复/保持一致**

```cpp
std::vector<int> v;

for (auto it = v.begin(); it != v.end(); ++it) { /* ... */ }
// 如果 later 把 vector 换成 list，for 不需要改类型
```

3. **配合模板/泛型代码**

```cpp
template <class Container>
void process(Container& c) {
    for (auto& x : c) { /* ... */ }
}
```

### 7.2 建议谨慎/避免的场景

1. **类型信息本身非常关键时**（如有符号/无符号、单位、语义）

```cpp
auto n = v.size();
// n 是 size_t，若你潜意识以为是 int，后续运算可能出问题；
// 如需要明确 int，最好写：int n = (int)v.size();（显式转换）
```

2. **可能发生隐式窄化转换的地方**

```cpp
double d = 3.14;
auto i = d;  // i: double，不会自动变成 int

int i2 = d;  // 明确写 int，至少窄化行为一眼可见
```

3. **容易被 `initializer_list` 规则坑的地方**

```cpp
auto x = {1, 2};  // std::initializer_list<int>
// 很多人以为是某个容器或数组，结果推导成 initializer_list
```

真实项目中，一般会配合代码规范（Coding Guidelines）规定：

- 可读性优先时，`auto` 只在**读者从右侧一眼就能看出类型**的地方使用；
- 类型本身承载语义时（ID、大小、强类型别名等）要写明具体类型。

---

## 8. `auto` 与模板类型推导的对应关系（稍进阶）

可以把 `auto` 当作“匿名模板参数”，很多规则是一致的：

```cpp
// 可以认为：

auto x = expr;
// 类似：
// template <class T>
// void fake(T param);
// fake(expr);
```

结合 `const`、`&`、`&&` 这些修饰符，就对应到模板的 `T` / `T&` / `T&&` 推导规则：

- `auto`        ↔ `T`           （按值）
- `auto&`       ↔ `T&`          （左值引用）
- `const auto&` ↔ `const T&`    （可绑定到临时量的 const 引用）
- `auto&&`      ↔ `T&&`         （万能引用 / 转发引用）

理解这一点，对你调试类型推导问题非常有帮助。

---

## 9. 小结

1. `auto` 是 **基于初始化表达式的类型推导**，核心规则几乎和模板参数推导一致；
2. 不带引用的 `auto` 会去掉引用、顶层 `cv`，并让数组/函数退化；
3. 配合 `&` / `&&` / `const` 可以精确控制“是值、是引用、是否 const”；
4. 和 `std::initializer_list` 有特殊交互，要小心大括号初始化；
5. `decltype(auto)` 保留表达式的引用和值类别，是更“原汁原味”的推导形式，多用于高级模板；
6. 工程实践中，`auto` 的目标是 **减少冗余 + 保持一致性 + 提高可读性**，而不是“到处乱用让类型变得不可见”。

掌握 `auto` 的本质是掌握“模板类型推导规则”。如果你愿意进一步深入，我们可以专门画一张表，把“模板推导场景”和 `auto` 推导场景一一对上，配合一些 tricky 例子（如数组、函数、初始化列表、转发引用）一起吃透。

