## 1. 是什么？和谁对比？

```C++
#include <unordered_set>
std::unordered_multiset<int> ums;
```

核心特点：

- **无序**：内部按哈希桶分布，不保证遍历顺序（甚至不同编译器/不同运行都可能不一样）。
    
- **允许重复**：同一个 key 可以插多次。
    
- **底层**：哈希表（链式/开链为主）。
    
- 查找 / 插入 / 删除 平均 **O(1)**，最坏退化到 **O(n)**（哈希冲突全撞到一个桶）。
    

和几个兄弟对比：

|容器|底层结构|有序性|允许重复|查找复杂度(平均)|
|---|---|---|---|---|
|`set`|平衡树|有序|否|O(log n)|
|`multiset`|平衡树|有序|是|O(log n)|
|`unordered_set`|哈希表|无序|否|O(1)|
|`unordered_multiset`|哈希表|无序|是|O(1)|

---

## 2. 模板参数

```C++
#include <unordered_set>
std::unordered_multiset<int> ums;
```

- `Key`：元素类型
    
- `Hash`：哈希函数类型（`size_t operator()(const Key&)`）
    
- `KeyEqual`：判断两个 key 是否相等的函数对象
    
- `Allocator`：一般不用管
    

如果你想自己写哈希，就改 `Hash`。  
如果你想用“忽略大小写比较字符串”，要同时改 `Hash` 和 `KeyEqual`。

---

## 3. 常用操作 & 复杂度（平均）

设元素个数为 n：

|操作|平均复杂度|说明|
|---|---|---|
|`insert(value)`|O(1)|插入一个值（允许重复）|
|`find(value)`|O(1)|返回某个等于 value 的元素迭代器（任意一个）|
|`count(value)`|O(k)|遍历该 key 对应桶里的 k 个等值|
|`erase(value)`|O(k)|删掉所有等于 value 的元素，返回删除数|
|`erase(it)`|O(1)|删掉迭代器指向的那个元素|
|`equal_range(value)`|O(k)|返回这个 key 对应的区间（桶内）|
|遍历 (`begin() -> end()`)|O(n)|无序遍历|
|`rehash / reserve`|O(n)|重新分配桶，全部元素重哈希插入|

> `k` 是该 key 出现的次数，平均来说桶里元素不多。

---

## 4. 基本用法示例

### 4.1 插入 + 统计重复

```C++
#include <iostream>
#include <unordered_set>

int main() {
    std::unordered_multiset<int> ums;

    ums.insert(10);
    ums.insert(20);
    ums.insert(10);
    ums.insert(30);
    ums.insert(10);

    std::cout << "count(10) = " << ums.count(10) << '\n';  // 3

    for (int x : ums) {
        std::cout << x << ' ';   // 顺序不保证
    }
}
```

适合的场景：

- 不在乎顺序；
    
- 需要允许重复；
    
- 频繁插入/查找/删除，希望平均 O(1)。
    

---

### 4.2 用 `equal_range` 遍历所有相等元素

```C++
std::unordered_multiset<int> ums = {1, 2, 2, 2, 3, 4};

auto [it1, it2] = ums.equal_range(2);
// 区间 [it1, it2) 中是所有等于 2 的元素（可能在同一个桶里的一个链）

for (auto it = it1; it != it2; ++it) {
    std::cout << *it << ' ';   // 打印所有 2
}
```
虽然叫 _unordered_，但 C++ 标准对**有重复键的无序容器**有一个关键要求（[unord.req]/6）：

> 在支持等价键的容器中，具有等价键的元素在容器的迭代顺序中是相邻的。[Stack Overflow](https://stackoverflow.com/questions/27606324/equal-range-and-stdunordered-multiset)

也就是说：

- 整体是“无序”的——不同 key 之间的相对顺序不规定；
    
- **但是相同 key 的元素必须连在一起**，形成一个“等价类块”。



注意：**对 unordered 容器来说，这个区间内部的顺序也不保证**。

---

### 4.3 删除某个 key 的“一个”或“全部”

```C++
std::unordered_multiset<int> ums = {1,2,2,2,3};

// 删除所有等于 2 的
std::size_t n = ums.erase(2);  // n == 3

// 只删除一个 2：
ums = {1,2,2,2,3};
auto it = ums.find(2);
if (it != ums.end()) {
    ums.erase(it);  // 只删掉一个
}
```

和 `multiset` 类似：

- `erase(value)` → 清掉所有这个值
    
- `erase(it)` → 精确删除某一个
    

---

## 5. 关于哈希、装载因子和 rehash

哈希表有几个重要概念：

- **bucket（桶）**：内部有很多桶，每个桶里是一个链表或小结构。
    
- **hash(key) % bucket_count** → 桶号。
    
- **load factor（负载因子）** = `size() / bucket_count()`  
    通常负载因子越大，冲突越多，性能下降。
    

常用接口：

```C++
std::unordered_multiset<int> ums;

// 预留大概 1000 个元素，减少 rehash 次数
ums.reserve(1000);

// 当前负载因子
float lf = ums.load_factor();

// 设置最大负载因子（可选）
ums.max_load_factor(2.0f);

// 强制重排桶数量
ums.rehash(2000);
```

**实践建议**：

- 知道大致元素数量时，先 `reserve` 一下，会少很多扩容和 rehash。
    
- 很少需要自己调 `max_load_factor`，默认一般够用。
    

---

## 6. 自定义类型 + 自定义哈希

### 6.1 简单结构体：自定义 `hash` + `equal_to`

```C++
struct Point {
    int x;
    int y;
};

struct PointHash {
    std::size_t operator()(const Point& p) const noexcept {
        // 简单地把 x,y 混一混（真实场景可用更好的混合函数）
        return std::hash<int>()(p.x) ^ (std::hash<int>()(p.y) << 1);
    }
};

struct PointEq {
    bool operator()(const Point& a, const Point& b) const noexcept {
        return a.x == b.x && a.y == b.y;
    }
};

std::unordered_multiset<Point, PointHash, PointEq> points;

points.insert({1,2});
points.insert({1,2}); // 允许重复
points.insert({2,3});
```

要点：

- `Hash` 负责“把 key 映射到 size_t 值”；
    
- `KeyEqual` 负责“两个 key 是否视为相等”；
    
- **必须配套**：相等的 key，哈希值最好也相同，否则性能会变差。
    

---

## 7. 遍历与删除时的注意点

### 7.1 遍历中删除元素

和其他容器一样，删当前迭代器要用它返回的新迭代器：

```C++
for (auto it = ums.begin(); it != ums.end(); ) {
    if (*it % 2 == 0) {          // 删掉偶数
        it = ums.erase(it);      // C++11 起 erase 返回下一个
    } else {
        ++it;
    }
}
```

---

## 8. 何时选 `unordered_multiset`，何时选 `multiset`？

**选 `unordered_multiset` 的情况：**

- 不需要有序；
    
- 重点是“查得快 / 插得快 / 删得快”；
    
- 常做“频次统计 + 多次查找”之类的操作。
    

**选 `multiset` 的情况：**

- 需要 **有序遍历**（比如按分数排序输出）；
    
- 需要用 `lower_bound`/`upper_bound` 做区间查询；
    
- 偶发退化到 O(n) 不可接受，宁可稳定 O(log n)。