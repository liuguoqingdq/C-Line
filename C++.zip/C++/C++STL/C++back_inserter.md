## 1. 是什么？长啥样？

头文件：

```C++
#include <iterator>
```

用法：

```C++
std::vector<int> v;
auto it = std::back_inserter(v);  // it 的类型就是 back_insert_iterator<vector<int>>
```

之后你可以像写迭代器一样写入：

```C++
*it = 10;     // 等价 v.push_back(10);
it = 20;      // 也等价 v.push_back(20);
++it; it++;   // 允许写，但基本是 no-op
```

---

## 2. 为什么需要它？

很多算法的接口是：

```C++
OutputIt out;
*out = value;
++out;
```

比如 `std::copy / std::transform / std::merge` 等。

如果你想把算法输出直接“追加”到 vector 尾部，手写循环当然可以，但 `back_inserter` 让你直接对接算法：

```C++
std::vector<int> src{1,2,3};
std::vector<int> dst;

std::copy(src.begin(), src.end(), std::back_inserter(dst));
// dst == {1,2,3}
```

---

## 3. 底层原理（它怎么做到的？）

`back_insert_iterator<C>` 内部只保存一个指向容器的指针 `C* c;`。

关键操作是重载了 `operator=`：

```C++
back_insert_iterator& operator=(const value_type& x) {
    c->push_back(x);
    return *this;
}
```

并且：

- `operator*()` 返回自己
    
- `operator++()` / `operator++(int)` 返回自己（不改变状态）
    

所以算法里的 `*out++ = x;` 就被“偷换成” `c->push_back(x);`。

---

## 4. 适用条件

容器必须支持 **`push_back`**（或等价的尾插语义）。

**能用**：

- `std::vector`
    
- `std::deque`
    
- `std::list`
    
- `std::basic_string`
    

**不能用**（没有 push_back）：

- `std::forward_list`（用 `front_inserter`）
    
- `std::set / map / unordered_set / unordered_map`（用 `inserter`）
    
- `std::array`（定长不能插）
    

---

## 5. 常见用法示例

### 5.1 copy / transform 输出到尾部

```C++
std::vector<int> v{1,2,3};
std::vector<int> out;

std::transform(v.begin(), v.end(),
               std::back_inserter(out),
               [](int x){ return x*x; });
// out = {1,4,9}
```

### 5.2 merge 两个有序序列

```C++
std::vector<int> a{1,3,5}, b{2,4,6};
std::vector<int> c;

std::merge(a.begin(), a.end(), b.begin(), b.end(),
           std::back_inserter(c));
// c = {1,2,3,4,5,6}
```

### 5.3 先 reserve 再 back_inserter（避免多次扩容）

```C++
std::vector<int> out;
out.reserve(src.size());                 // 提前开空间
std::copy(src.begin(), src.end(), std::back_inserter(out));
```

---

## 6. 和其它 inserter 的区别

- `back_inserter(c)` → 尾插（push_back）
    
- `front_inserter(c)` → 头插（push_front），用于 list/forward_list 等
    
- `inserter(c, pos)` → 在任意位置插入（insert），用于 set/map 等
    

例：

```C++
std::set<int> s;
std::copy(v.begin(), v.end(), std::inserter(s, s.end()));
```

---

## 7. 小坑提醒

1. **不要给定长容器用 back_inserter**
    
    `std::array<int,3> a; std::back_inserter(a); // ❌ 没 push_back`
    
2. **back_inserter 不会替你清空容器**  
    它只会“追加”。  
    如果你要覆盖原内容，先 `clear()` 或用普通迭代器输出。
    
3. **对 vector 扩容导致旧迭代器失效没关系**  
    因为 back_insert_iterator 不保存元素迭代器，它只保存容器指针，所以安全。
    

---

### 一句话总结

`std::back_inserter(v)` 把 `v.push_back(x)` 伪装成 `*out = x` 的迭代器写法，让所有“输出迭代器算法”都能直接把结果追加到容器尾部。