## 一、`std::list` 在 STL 里的定位

**头文件**：`<list>`  
**命名空间**：`std`  
**典型定义**（省略 allocator）：

```C++
template <class T, class Allocator = std::allocator<T>>
class list;
```

官方一句话概括（cppreference）：

> `std::list` 是一个**序列容器**，在容器任意位置插入和删除元素都是常数时间（O(1)），但不支持快速随机访问。通常实现为**双向链表**。

再加两点你要牢牢记住的**特性**：

1. **双向迭代器（bidirectional iterator）**，没有随机访问：
    
    - 可以 `++it`、`--it`，但不能 `it + 5`、不能 `list[i]`。
        
2. **迭代器/引用的稳定性极好**：
    
    - 元素在 list 中移动（包括 `splice`、`sort`、`merge`、`reverse`）时，迭代器和引用**仍然有效**；
        
    - 只有当对应元素被删除时，它的迭代器/引用才失效。
        

这是它和 `vector` / `deque` 完全不同的地方。

---

## 二、内部存储模型：典型实现长什么样

标准没有强制实现方式，但主流实现（libstdc++ / libc++）基本一致：  
**双向链表 + 哨兵节点（sentinel）+ size 计数**。

### 2.1 每个节点大致是这样：

```C++
template <class T>
struct list_node {
    list_node* prev;
    list_node* next;
    T          value;  // 真正的元素
};
```

示意：

   ```lua
      prev                prev                prev
  ┌─────┐   next     ┌─────┐   next     ┌─────┐
  │     │<---------> │     │<---------> │     │
  │ T0  │            │ T1  │            │ T2  │
  │     │----------> │     │----------> │     │
  └─────┘   prev     └─────┘   prev     └─────┘
   ```

每个节点存三个东西：前驱指针、后继指针、一个 `T`。

### 2.2 哨兵节点（end 节点）

为了简化边界处理，list 一般维护一个**环形的哨兵节点**，我们可以把它理解为 `end()` 所在的位置：

 ```lua
      ┌───────── sentinel (end) ─────────┐
     ↓                                  ↑
   +-----+      +-----+      +-----+    |
   | T0  | <--> | T1  | <--> | T2  |----┘
   +-----+      +-----+      +-----+
 ```

- `begin()` = `sentinel->next`
    
- `end()` = 指向 `sentinel`
    
- `sentinel->next` 指向第一个元素，`sentinel->prev` 指向最后一个元素
    

这样处理插入/删除时，就不用特判“空链表”或“头节点/尾节点了”。

### 2.3 list 对象自身大致包含什么？

概念上可以想象为：

```C++
template <class T>
class list {
    list_node<T>* sentinel;  // 环形链表的哨兵
    size_t        sz;        // 当前元素个数（C++11 起要求 size() 为 O(1)）
    Allocator     alloc;     // 节点分配器
};
```

- **所有节点（包括哨兵）都在堆上**；
    
- `list` 对象本身只存指针 + 计数（可以在栈上、作为成员、全局等等）。
    

> 注意：C++11 起标准要求所有标准容器的 `size()` 必须是 O(1)，  
> 所以 `std::list` 实现一般都会维护一个 `sz` 计数。

---

## 三、接口总览：有哪些成员函数

### 3.1 类型别名（典型）

你会经常看到这些：

```C++
using value_type      = T;
using size_type       = std::size_t;
using iterator        = /* 双向迭代器 */;
using const_iterator  = /* 双向迭代器 const 版本 */;
using reference       = T&;
using const_reference = const T&;
```

### 3.2 构造 / 赋值

常见的构造方式：

```C++
std::list<int> a;                // 默认构造，空表
std::list<int> b(10);            // 10 个 value-initialized 元素（int 为 0）
std::list<int> c(10, 42);        // 10 个值为 42 的元素
std::list<int> d{1, 2, 3, 4};    // 初始化列表
std::list<int> e(d.begin(), d.end());  // 迭代器区间
```

赋值：

```C++
b = d;
b.assign(5, 7);              // 五个 7
b.assign(d.begin(), d.end()); 
b.assign({1, 2, 3});
```

### 3.3 迭代器与遍历

```C++
std::list<int> lst = {1, 2, 3};

// 双向迭代器
for (auto it = lst.begin(); it != lst.end(); ++it) {
    std::cout << *it << "\n";
}

// 范围 for
for (int x : lst) {
    ...
}

// 反向迭代器
for (auto it = lst.rbegin(); it != lst.rend(); ++it) {
    ...
}
```

**重要**：`list` 的迭代器 **不是随机访问迭代器**，所以：

- ✅ `++it`, `--it`, 比较 `==` / `!=`
    
- ❌ `it + 5`，`it[3]`，`list[i]` —— 都不行
    

所以几乎所有依赖随机访问迭代器的算法（比如 `std::sort` 针对 `RandomAccessIterator` 的版本）不能直接用于 `list`。

### 3.4 容量相关

- `bool empty() const;` — O(1)
    
- `size_type size() const;` — C++11 起要求 O(1)
    
- `size_type max_size() const;`
    

### 3.5 元素访问

`list` 不支持下标，因此只有：

- `reference front();`
    
- `reference back();`
    

没有 `operator[]`，也没有 `at()`。

### 3.6 修改操作（通用）

#### 两端：

```C++
lst.push_front(x);
lst.push_back(x);
lst.pop_front();
lst.pop_back();
```

- 都是 O(1)，本质是链表头尾插入/删除一个节点。
    

#### 中间插入/删除：

```C++
auto it = lst.begin();
std::advance(it, 3);          // 移动到第四个元素

lst.insert(it, 42);           // 在 it 前插入 42，O(1)（知道 it 的前提下）
lst.erase(it);                // 删除 it 位置元素，O(1)
```

关于复杂度要小心说：

- “**按位置插入/删除是 O(1)**” 的前提是——你已经有这个位置的迭代器；
    
- 如果你是“按第 i 个元素插入”，那先找到这个位置就得 O(n)。
    

#### 其他：

- `clear()`：删除所有元素，O(n)
    
- `resize(new_size)`：增加则在尾部插入默认值，减少则从尾部删，整体 O(|差值|)
    

---

## 四、`list` 独有的算法型成员函数

这是 `list` 最“有性格”的地方，其他容器没有这么一套“成员版算法”。

### 4.1 `splice` —— O(1) 级别的“挪节点”

```C++
std::list<int> a = {1, 2, 3};
std::list<int> b = {10, 20, 30};

auto pos = std::next(a.begin());   // 指向 2

// 把 b 整个接到 a 的 pos 前面
a.splice(pos, b);                  // b 变空

// 或者：只搬一个元素
a.splice(pos, b, b.begin());       // 搬移 b 的第一个元素

// 或者：搬 b 的一个子区间 [first, last)
a.splice(pos, b, b.begin(), std::prev(b.end()));
```

特点：

- **全部是指针 relink 操作**，不拷贝/移动元素；
    
- 时间复杂度 O(1) 或 O(搬移元素个数)，但远小于“插入+删除”两个 O(n)；
    
- **所有被搬元素的迭代器和引用仍然有效，只是所属容器变了**。
    

在实际工程里，`splice` 是 `list` 的杀手锏。

### 4.2 `remove` / `remove_if`

```C++
list.remove(value);              // 删除等于 value 的所有元素
list.remove_if(pred);            // 删除满足 pred(e)==true 的所有元素
```

它们遍历一次链表，在满足条件的节点上调用 `erase`，整体 O(n)。

**如果你用的是 `<algorithm>` 里的 `std::remove` + `erase` 模式，反而不如直接用 `list.remove`**，因为后者是利用链表结构做的。

### 4.3 `unique` —— 删除“相邻重复元素”

```C++
lst.sort();          // 先排序让相同元素挨在一起
lst.unique();        // 删除相邻重复（保留第一份）
```

也可以传入二元谓词，自定义“相等”逻辑。

### 4.4 `merge` —— 合并两个有序 `list`

```C++
std::list<int> a = {1, 3, 5};
std::list<int> b = {2, 4, 6};

a.merge(b);   // a={1,2,3,4,5,6}, b 变空
```

关键点：

- 要求两个 list 都是**已排序**的；
    
- 内部用指针操作把元素“穿插”到一起；
    
- 复杂度 O(n1 + n2)，但不拷贝/移动元素；
    
- 被合并元素的迭代器仍然有效，只是现在归 `a` 管了。
    

### 4.5 `sort`

`list` 有**自己的成员 `sort()`**，因为泛型 `std::sort` 要求随机访问迭代器，不能用于 `list`。

```C++
std::list<int> lst = {3, 1, 4, 2};
lst.sort();                  // 默认按 < 排序
lst.sort(std::greater<>());  // 自定义比较
```

实现通常是**自底向上的归并排序（merge sort）**，因为对链表来说：

- 切分和合并很容易 O(1) 指针操作；
    
- 整体复杂度 O(n log n)，并且是稳定排序。
    

### 4.6 `reverse`

`lst.reverse();`

链表上反转只要把每个节点的 `next` / `prev` 换一换指向，O(n) 且不分配新节点。

---

## 五、时间复杂度与迭代器失效规则

### 5.1 复杂度（大致）

根据标准与常见实现：

- 插入/删除：
    
    - `insert(pos, x)`：O(1)（已知 `pos`）
        
    - `erase(pos)`：O(1)
        
    - 找到 `pos` 本身：O(n)（因为只能单步走）
        
- 访问：
    
    - `front/back`：O(1)
        
    - “第 i 个元素”：O(n)
        
- 其他：
    
    - `size()`：C++11 起要求 O(1)
        
    - `remove/remove_if/unique`：O(n)
        
    - `sort/merge`：O(n log n)
        
    - `reverse`：O(n)
        
    - `splice`：按搬运节点数线性，内部每个节点 relink 常数。
        

### 5.2 迭代器 / 引用失效规则（重点背）

对 `std::list` 来说，cppreference 的描述非常简洁：

> 在 list 内部增加、移除、移动元素（包括跨多个 list）**不会使任何迭代器或引用失效**；  
> **只有当某个元素被删除时，对应元素的迭代器/引用才会失效。**

也就是说：

- `push_front/back`：旧元素迭代器/引用全都仍然有效；
    
- `insert`：插入新元素不会影响已有迭代器；
    
- `splice/sort/merge/reverse`：元素只是在链上换位置，不会失效；
    
- `erase` / `remove` / `unique`：**被删元素本身的迭代器失效**，其它都有效；
    
- `clear()`：所有迭代器都失效（因为所有元素都删掉了）。
    

对比一下 `vector`/`deque` 的“动不动就迭代器全灭”，你就能理解为什么 list 在需要“长期持有迭代器/指针”的场景里很有价值。

---

## 六、与其他容器的对比（为什么现代工程中 list 不那么常用）

### 6.1 与 `vector` / `deque`

|特性|`vector`|`deque`|`list`|
|---|---|---|---|
|随机访问|O(1)|O(1)|❌ 无（只能 O(n) 走迭代器）|
|两端插入/删除|尾部 O(1)，头部 O(n)|头尾均摊 O(1)|头尾 O(1)|
|中间插入/删除（有迭代器）|O(n)（搬动元素）|O(n)（搬动一侧元素）|O(1)（改指针）|
|内存布局|单块连续数组|多块中等数组|每节点单独分配，完全不连续|
|cache 局部性|极好|尚可|很差|
|迭代器稳定性|扩容/插入易失效|多数插入/删除会失效|非常稳定，仅删除时失效|
|适用场景|数组/批量运算/排序|双端队列+随机访问|频繁中间插删 + 迭代器稳定需求|

现实中，由于 CPU cache 的存在，即便在有插删的场景，`vector` 也经常比 `list` 更快（哪怕时间复杂度上看是 O(n) vs O(1)）。这是面试里和工程里常见的一个“反直觉”点。

### 6.2 与 `std::forward_list`
[[C++forward_list]]
`std::forward_list` 是 C++11 新加的**单向链表**，对标 C 的 `slist`：

- 更省空间（少一个 `prev` 指针）；
    
- 只支持前向迭代；
    
- 不能 `--it`，很多操作需要前驱迭代器；
    
- 接口和 `list` 有所区别（比如没有 `size()`，默认 O(n) 扫链表）。
    

如果你只需要一遍向前走、不需要反向迭代，可以考虑 `forward_list`。

---

## 七、典型使用场景：什么时候值得用 `list`

在现代 C++ 工程里，我一般只在下面几类场景推荐 `list`：

1. **大量“中间位置插删”，且你手里有迭代器**  
    比如维护一个 job 列表，需要根据事件把 job 从一个列表移动到另一个列表，  
    这时 `splice` + O(1) `erase` 非常合适。
    
2. **需要稳定的迭代器 / 指针**
    
    - 例如某个索引结构里保存的是 `list<T>::iterator`，要求容器内部操作不让这些迭代器失效；
        
    - 典型如 LRU cache 的“热度链表”（当然工业界更多会用 intrusive list）。
        
3. **频繁使用 `splice` / `merge` / `sort` 这些“链表特化算法”**
    
    - 比如维护多个有序列表，常做合并、拆分；
        
    - 利用 `merge`/`splice` 做 O(1) 级别的结构重组。
        

**如果只是想“插入方便”**，而没有强需求要链表特性，**优先考虑 `vector` 或 `deque`**，这是现代 C++ 比较共识的经验。

---

## 八、综合小示例：用 `list` 实现一个简单的 LRU 顺序

下面是一个简化版的“只维护顺序”的例子（不做 map 查找，只演示 list 用法）：

```C++
#include <list>
#include <iostream>

struct Entry {
    int key;
    int value;
};

int main() {
    std::list<Entry> lru;

    // 新访问的放到前面（最近使用）
    auto touch = [&](int key, int value) {
        // 遍历找到是否已有
        for (auto it = lru.begin(); it != lru.end(); ++it) {
            if (it->key == key) {
                // 移到表头：splice O(1)
                lru.splice(lru.begin(), lru, it);
                it->value = value;  // 更新值
                return;
            }
        }
        // 没有就插入表头
        lru.push_front(Entry{key, value});
        // 控制容量
        if (lru.size() > 3) {
            lru.pop_back();  // 淘汰最久未使用
        }
    };

    touch(1, 100);
    touch(2, 200);
    touch(3, 300);
    touch(2, 250);   // 2 变成最近使用
    touch(4, 400);   // 触发淘汰

    for (auto &e : lru) {
        std::cout << e.key << ":" << e.value << "\n";
    }
}
```

这里利用了：

- `list` 的双向迭代器遍历；
    
- `splice` 在 O(1) 时间内把节点挪到头部；
    
- `pop_back` 在尾部删除也是 O(1)。


----
### 1. 基本类型别名

|成员|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`value_type`|`T`|`std::list<int>::value_type x;`|元素类型别名|
|`size_type`|`std::size_t`|`std::list<int>::size_type n;`|用于 `size()` 等的无符号整数类型|
|`difference_type`|带符号整数类型|迭代器差值|迭代器之间距离的类型|
|`reference`|`T&`|`list<int>::reference r = lst.front();`|元素引用类型|
|`const_reference`|`const T&`||只读元素引用|
|`iterator`|双向迭代器|`for (auto it = lst.begin(); it != lst.end(); ++it)`|可修改元素的迭代器|
|`const_iterator`|双向迭代器|`for (auto it = lst.cbegin(); it != lst.cend(); ++it)`|只读迭代器|
|`reverse_iterator`|反向迭代器|`for (auto it = lst.rbegin(); it != lst.rend(); ++it)`|反向遍历（从尾到头）|
|`const_reverse_iterator`|反向只读迭代器||只读反向遍历|

---

### 2. 构造 / 赋值 / 析构

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`list()`|—|`std::list<int> lst;`|默认构造，空链表|
|`list(size_type n)`|—|`std::list<int> lst(10);`|含 `n` 个默认值元素|
|`list(size_type n, const T& val)`|—|`std::list<int> lst(10, 42);`|含 `n` 个值为 `val` 的元素|
|`list(InputIt first, InputIt last)`|—|`std::list<int> lst(v.begin(), v.end());`|用迭代器区间构造|
|`list(std::initializer_list<T>)`|—|`std::list<int> lst{1,2,3};`|列表初始化|
|拷贝构造|—|`std::list<int> b(a);`|用另一个 `list` 拷贝构造|
|移动构造|—|`std::list<int> b(std::move(a));`|“窃取”另一个 list 的资源|
|拷贝赋值 `operator=`|`list&`|`b = a;`|拷贝整个链表|
|移动赋值 `operator=`|`list&`|`b = std::move(a);`|移动整个链表|
|`operator=(initializer_list)`|`list&`|`lst = {1,2,3};`|用初始化列表重新赋值|
|析构函数 `~list()`|—|`/* 自动调用 */`|释放所有节点|

---

### 3. 迭代器相关

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`begin()` / `end()`|`iterator`|`for (auto it = lst.begin(); it != lst.end(); ++it)`|正向迭代起止|
|`cbegin()` / `cend()`|`const_iterator`|`for (auto it = lst.cbegin(); it != lst.cend(); ++it)`|只读正向迭代起止|
|`rbegin()` / `rend()`|`reverse_iterator`|`for (auto it = lst.rbegin(); it != lst.rend(); ++it)`|反向迭代起止|
|`crbegin()` / `crend()`|`const_reverse_iterator`||只读反向迭代起止|

---

### 4. 容量相关

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`empty() const`|`bool`|`if (lst.empty()) { ... }`|是否为空|
|`size() const`|`size_type`|`auto n = lst.size();`|当前元素个数（O(1)）|
|`max_size() const`|`size_type`|`if (n > lst.max_size())`|理论最大可容纳元素数（实现相关）|

---

### 5. 元素访问（注意：**没有下标**）

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`front()`|`reference` / `const_reference`|`lst.front() = 10;`|访问第一个元素|
|`back()`|`reference` / `const_reference`|`int x = lst.back();`|访问最后一个元素|

> `list` 不提供 `operator[]` 和 `at()`，不能随机访问，只能通过迭代器走。

---

### 6. 修改操作：插入 / 删除 / 赋值

#### 6.1 assign 系列

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`assign(size_type n, const T& val)`|`void`|`lst.assign(5, 42);`|变为 5 个 42|
|`assign(InputIt first, InputIt last)`|`void`|`lst.assign(v.begin(), v.end());`|用区间重置|
|`assign(initializer_list<T>)`|`void`|`lst.assign({1,2,3});`|用列表重置|

#### 6.2 push / pop（两端）

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`push_front(const T& val)`|`void`|`lst.push_front(1);`|头部插入（拷贝）|
|`push_front(T&& val)`|`void`|`lst.push_front(std::move(x));`|头部插入（移动）|
|`push_back(const T& val)`|`void`|`lst.push_back(1);`|尾部插入（拷贝）|
|`push_back(T&& val)`|`void`|`lst.push_back(std::move(x));`|尾部插入（移动）|
|`pop_front()`|`void`|`lst.pop_front();`|删除第一个元素|
|`pop_back()`|`void`|`lst.pop_back();`|删除最后一个元素|

#### 6.3 emplace 系列（就地构造）

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`emplace_front(Args&&... args)`|`reference`|`lst.emplace_front(1, 2);`|在头部原地构造 T(args...)|
|`emplace_back(Args&&... args)`|`reference`|`lst.emplace_back(1, 2);`|在尾部原地构造|
|`emplace(const_iterator pos, Args&&... args)`|`iterator`|`auto it = lst.emplace(pos, 1, 2);`|在 `pos` 位置前原地构造一个元素|

#### 6.4 insert / erase / clear / resize / swap

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`insert(const_iterator pos, const T& val)`|`iterator`|`auto it = lst.insert(p, 42);`|在 `pos` 前插入一个元素|
|`insert(const_iterator pos, T&& val)`|`iterator`|`lst.insert(p, std::move(x));`|移动插入|
|`insert(const_iterator pos, size_type n, const T& val)`|`iterator`|`lst.insert(p, 3, 42);`|在 `pos` 前插入 n 个 val|
|`insert(const_iterator pos, InputIt first, InputIt last)`|`iterator`|`lst.insert(p, v.begin(), v.end());`|在 `pos` 前插入区间|
|`insert(const_iterator pos, initializer_list<T>)`|`iterator`|`lst.insert(p, {1,2,3});`|在 `pos` 前插入列表|
|`erase(const_iterator pos)`|`iterator`|`it = lst.erase(it);`|删除 `pos` 位置元素，返回下一个位置|
|`erase(const_iterator first, const_iterator last)`|`iterator`|`lst.erase(first, last);`|删除区间 `[first,last)`|
|`clear()`|`void`|`lst.clear();`|删除所有元素|
|`resize(size_type n)`|`void`|`lst.resize(10);`|调整大小（扩张用默认值，缩小从尾删）|
|`resize(size_type n, const T& val)`|`void`|`lst.resize(10, 42);`|扩张时用 `val` 填充|
|`swap(list& other)`|`void`|`lst.swap(other);` 或 `std::swap(lst, other);`|高效交换两个 list 的内容|

---

### 7. list 特有的“链表操作”成员

这些是 `list` 独有，其他序列容器没有这么一整套。

#### 7.1 splice（节点搬运，不拷贝元素）

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`splice(const_iterator pos, list& other)`|`void`|`a.splice(pos, b);`|把 `other` 的所有元素接到 `a` 的 `pos` 前，`other` 变空|
|`splice(const_iterator pos, list& other, const_iterator it)`|`void`|`a.splice(pos, b, it);`|把 `other` 中单个节点 `it` 接到 `a` 的 `pos` 前|
|`splice(const_iterator pos, list& other, const_iterator first, const_iterator last)`|`void`|`a.splice(pos, b, first, last);`|把 `[first,last)` 这个区间的节点从 `b` 搬到 `a` 的 `pos` 前|

> 全是指针 relink，复杂度按搬运节点个数，**不拷贝/移动元素，迭代器/引用保持有效（只是所属容器变了）**。

#### 7.2 remove / remove_if

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`remove(const T& val)`|`void`|`lst.remove(0);`|删除所有等于 `val` 的元素|
|`remove_if(Pred pred)`|`void`|`lst.remove_if([](int x){ return x%2==0; });`|删除所有满足谓词的元素|

#### 7.3 unique

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`unique()`|`void`|`lst.sort(); lst.unique();`|删除相邻重复元素（保留第一份）|
|`unique(BinaryPred p)`|`void`|`lst.unique([](auto&a,auto&b){ return abs(a-b)<0.01; });`|用自定义“相等”条件合并相邻元素|

> 注意：`unique` 只处理“相邻重复”，所以常配合 `sort()` 使用。

#### 7.4 merge（合并两个有序 list）

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`merge(list& other)`|`void`|`a.sort(); b.sort(); a.merge(b);`|将有序 `other` 合并进有序 `*this`，保持排序，`other` 变空|
|`merge(list& other, Compare comp)`|`void`|`a.merge(b, std::greater<>());`|使用自定义比较|

> 同样是节点级别操作，不拷贝元素，复杂度 O(n1 + n2)。

#### 7.5 sort（链表版本排序）

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`sort()`|`void`|`lst.sort();`|按 `<` 排序|
|`sort(Compare comp)`|`void`|`lst.sort(std::greater<>());`|自定义比较排序|

> 实现通常用归并排序，对链表很友好，稳定，复杂度 O(n log n)。

#### 7.6 reverse（反转链表）

|方法|返回值类型|用法示例|作用说明|
|---|---|---|---|
|`reverse()`|`void`|`lst.reverse();`|原地反转元素顺序，O(n)，只调指针|

---

### 8. Allocator 相关（一般不手写）

| 方法                      | 返回值类型       | 用法示例                                | 作用说明                   |
| ----------------------- | ----------- | ----------------------------------- | ---------------------- |
| `get_allocator() const` | `Allocator` | `auto alloc = lst.get_allocator();` | 获取用于节点分配的 allocator 副本 |