## 1. 是什么？

```C++
#include <set>
std::multiset<int> ms;
```

特点：

1. **有序**：内部按 `key` 排好序（默认 `std::less<T>`，即从小到大）。
    
2. **允许重复**：同一个值可以插入多次。
    
3. **底层通常是红黑树**（标准只说“平衡搜索树”）。
    
4. **只存 key，没有 value**：类似 `set`，只是去掉了“去重”的限制。
    

和几个兄弟对比一下：

- `set`：有序 + **不允许重复**
    
- `multiset`：有序 + **允许重复**
    
- `unordered_multiset`：**哈希表** + 允许重复 + **无序**
    

---

## 2. 常见模板参数

```C++
template<
    class Key,
    class Compare = std::less<Key>,
    class Allocator = std::allocator<Key>
> class multiset;
```

- `Key`：元素类型
    
- `Compare`：排序规则（`bool cmp(const Key&, const Key&)`）
    
- `Allocator`：一般不用管
    

---

## 3. 常用操作 + 复杂度大致印象

假设当前元素个数为 `n`：

|操作|复杂度|说明|
|---|---|---|
|`insert(value)`|`O(log n)`|插入一个值，允许重复|
|`find(value)`|`O(log n)`|找到某个等于 `value` 的元素迭代器|
|`count(value)`|`O(log n + k)`|返回等于 `value` 的个数（`k` 为重复数）|
|`erase(it)`|`O(1)` 均摊|通过迭代器删除|
|`erase(value)`|`O(log n + k)`|删除所有等于 `value` 的元素|
|`lower_bound(value)`|`O(log n)`|第一个 `>= value` 的迭代器|
|`upper_bound(value)`|`O(log n)`|第一个 `> value` 的迭代器|
|`equal_range(value)`|`O(log n)`|返回 `[lower_bound, upper_bound)`|
|遍历|`O(n)`|中序遍历，按排序顺序输出|

---

## 4. 基本用法示例

### 4.1 插入 + 遍历 + 重复元素

```C++
#include <iostream>
#include <set>

int main() {
    std::multiset<int> ms;

    ms.insert(3);
    ms.insert(1);
    ms.insert(2);
    ms.insert(3);  // 允许重复

    for (int x : ms) {
        std::cout << x << ' ';
    }
    // 输出：1 2 3 3

    std::cout << "\ncount(3) = " << ms.count(3) << '\n';  // 2
}
```

---

### 4.2 用 multiset 统计“有序多重集合”

比如：你想按升序输出所有分数（包括重复），适合用 `multiset`：

```C++
std::multiset<int> scores;
scores.insert(90);
scores.insert(100);
scores.insert(90);
scores.insert(60);
// 输出：60 90 90 100
for (int s : scores) std::cout << s << ' ';
```

如果你只是想统计频次，用 `map<int,int>` 或 `unordered_map` 更直接；  
如果还想**自动排序** + **保留每个出现**，`multiset` 就刚好合适。

---

### 4.3 `lower_bound / upper_bound / equal_range`

对于重复元素，常见模式：

```C++
std::multiset<int> ms = {1, 2, 2, 2, 3, 4};

auto it1 = ms.lower_bound(2); // 指向第一个 2
auto it2 = ms.upper_bound(2); // 指向第一个 >2 的元素，即 3

// 遍历所有等于 2 的元素：
for (auto it = it1; it != it2; ++it) {
    std::cout << *it << ' '; // 2 2 2
}

// equal_range 是 lower_bound+upper_bound 的封装
auto [l, r] = ms.equal_range(2);
for (auto it = l; it != r; ++it) {
    std::cout << *it << ' '; // 2 2 2
}
```

---

### 4.4 自定义排序（比如从大到小）

```C++
std::multiset<int, std::greater<int>> ms;  // 降序

ms.insert(3);
ms.insert(1);
ms.insert(2);
ms.insert(3);

// 输出：3 3 2 1
for (int x : ms) std::cout << x << ' ';
```

再复杂一点的 comparator：

```C++
struct Item {
    int id;
    int score;
};

struct Cmp {
    bool operator()(const Item& a, const Item& b) const {
        if (a.score != b.score) return a.score > b.score; // score 降序
        return a.id < b.id;                               // id 升序
    }
};
std::multiset<Item, Cmp> items;
```

**注意**：`Compare` 必须满足**严格弱序**，不能写出“自相矛盾”的比较，否则行为未定义。

---

## 5. 删除的坑点

### 5.1 `erase(value)` vs `erase(it)`

```C++
std::multiset<int> ms = {1,2,2,2,3};

// 方式1：删掉所有 2
ms.erase(2);  // 返回删除的个数

// 方式2：只删掉其中一个 2
auto it = ms.find(2);
if (it != ms.end()) ms.erase(it);
```

如果你只想删一个，一定要用 **迭代器版本**。  
`erase(value)` 是“清仓式”删除。

---

### 5.2 遍历中删元素

正确写法是**先保存下一个迭代器**：

```C++
for (auto it = ms.begin(); it != ms.end(); ) {
    if (*it % 2 == 0) {     // 删除所有偶数
        it = ms.erase(it);  // C++11 起，erase 返回下一个迭代器
    } else {
        ++it;
    }
}
```

不要 `erase(it); ++it;`，那样 `it` 已经失效了。

---

## 6. 和 `unordered_multiset` 的选择
[[C++unordered_multiset]]
- 需要 **有序遍历**、用 `lower_bound`/`upper_bound` 做区间查找 → `multiset`
    
- 只在乎 **存在性 / 频次**、不在乎顺序、追求常数复杂度 → `unordered_multiset`