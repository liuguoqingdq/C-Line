`std::for_each` 其实就是“把一段区间里的每个元素都丢给你指定的函数去处理”的通用形式化写法。

可以把它理解成：

```C++
for (auto it = first; it != last; ++it) {
    f(*it);
}
```

只是标准库帮你封装好了。

---

## 1. 基本函数签名（<algorithm\> 里的那个）

经典版本（C++98 一直到现在都有）：

```C++
#include <algorithm>

template<class InputIt, class UnaryFunction>
UnaryFunction for_each(InputIt first, InputIt last, UnaryFunction f);
```

含义：

- 遍历区间 `[first, last)`；
    
- 对每个元素 `*it` 调用 `f(*it)`；
    
- **返回 `f` 这个可调用对象（按值返回）**。
    

### 为什么返回 `f`？

因为 `f` 可能是一个**有内部状态的函数对象**（functor / lambda with captured state），遍历过程中它里面的成员被更新，最后通过返回值把这个“累计状态”带出来。

---

## 2. 行为等价写法

标准基本上就是这一段伪代码：

```C++
template<class InputIt, class UnaryFunction>
UnaryFunction for_each(InputIt first, InputIt last, UnaryFunction f) {
    for (; first != last; ++first) {
        f(*first);    // 对每个元素调用一次
    }
    return f;         // 返回（可能被修改过状态的）f
}
```

- 复杂度：正好调用 `f` `(last - first)` 次；
    
- 不保证任何顺序以外的额外行为。
    

---

## 3. 简单用法：遍历打印 / 操作数组

```C++
#include <algorithm>
#include <vector>
#include <iostream>

int main() {
    std::vector<int> v = {1, 2, 3, 4};

    std::for_each(v.begin(), v.end(),
                  [](int x) {
                      std::cout << x << ' ';
                  });
    // 输出：1 2 3 4
}
```

这里 lambda 的参数类型是 `int`，因为 `*it` 会被拷贝传给 `f`。  
如果你想在 lambda 里修改容器元素，可以用引用：

```C++
std::for_each(v.begin(), v.end(),
              [](int& x) { x *= 2; });
// v 变成 {2, 4, 6, 8}
```

---

## 4. 利用返回值做“累加 / 统计”——状态ful 函数对象

典型写法：

```C++
struct Sum {
    int s = 0;
    void operator()(int x) { s += x; }
};

int main() {
    std::vector<int> v = {1, 2, 3, 4};

    Sum sum_obj;
    sum_obj = std::for_each(v.begin(), v.end(), sum_obj);

    std::cout << sum_obj.s << "\n";  // 10
}
```

或者直接用 lambda + 外部变量捕获（更常用）：

```C++
int sum = 0;
std::for_each(v.begin(), v.end(),
              [&sum](int x) { sum += x; });
// sum == 10
```

这其实是两种思路：

- 使用返回值：算法接口惯用的老风格；
    
- 使用捕获变量：现代 C++（C++11+）更自然的写法。
    

---

## 5. 修改元素 vs 只读访问

关键看你传给 lambda 的参数类型：

```C++
// 只读访问，不修改容器
std::for_each(v.begin(), v.end(),
              [](int x) { /* 看看值、打印等 */ });

// 修改元素内容
std::for_each(v.begin(), v.end(),
              [](int& x) { x *= 2; });

// 如果容器是 const 的，只能得到 const 引用 / 拷贝，不能修改：
const std::vector<int> cv = {1,2,3};
std::for_each(cv.begin(), cv.end(),
              [](int x) { /* 只能读 */ });
```

`std::for_each` 对元素能不能改，**完全取决于迭代器类型 / 容器是否 const**，算法本身不加额外限制。

---

## 6. 和 range-based for 的关系

这两段是等价风格写法：

```C++
// 传统 for + 手动写逻辑
for (auto& x : v) {
    x *= 2;
}

// std::for_each 形式
std::for_each(v.begin(), v.end(),
              [](int& x) { x *= 2; });
```

差异更多是“风格 + 某些高阶用法”：

- **可读性**：简单逻辑时 `for (auto& x : v)` 往往更清晰；
    
- **可组合性**：`std::for_each` 可以跟其他算法一样被当成“算法流水线的一站”，也更容易写成模板里的一个策略参数；
    
- **返回值状态**：`for` 自己不会返回任何东西，而 `for_each` 会返回那个函数对象（如果你需要通过返回值取内部状态，这就有用）。
    

通常经验：

> 逻辑简单、只在一个地方用 → 直接写 range-for；  
> 在算法代码里想传“策略 / 回调” → 用 `std::for_each` 比较规范。

---

## 7. 不能“中途退出”的问题（重要）

`std::for_each` 没有内建“提前 break”的语义：  
你给的函数必须被调用完所有元素。

如果你要“找到第一个满足条件的元素就停”，应当用别的算法：

- `std::find_if`
    
- `std::any_of` / `std::all_of` / `std::none_of`
    

例子：

```C++
auto it = std::find_if(v.begin(), v.end(),
                       [](int x) { return x > 10; });
if (it != v.end()) {
    // 找到了
}
```

如果**硬要**用 `for_each` 来实现“提前退出”，常见但不推荐的 hack：

1. 在 functor 里抛异常（捕获后当作 break），比如：
    
    ```C++
    struct BreakFound {};

try {
    std::for_each(v.begin(), v.end(),
                  [](int x) {
                      if (x > 10) throw BreakFound{};
                      // 其他处理
                  });
} catch (BreakFound&) {
    // 当成 break 用
}
    ```
    
2. 在 functor 里维护一个标记，然后在内部判断“不再做事”：
    
    ```C++
    bool stop = false;
std::for_each(v.begin(), v.end(),
              [&stop](int x) {
                  if (stop) return;
                  if (x > 10) {
                      // 做一次处理
                      stop = true;
                  }
              });
    ```
    

但这两种都不“优雅”，通常直接换算法比较好。

---

## 8. 并行版本（C++17）和 ranges 版本（C++20）

### 8.1 并行执行策略（<execution\>）

C++17 起有执行策略参数的重载：

```C++
#include <algorithm>
#include <execution>

template<class ExecutionPolicy, class ForwardIt, class UnaryFunction>
UnaryFunction for_each(ExecutionPolicy&& policy,
                       ForwardIt first, ForwardIt last,
                       UnaryFunction f);
```

比如：

```C++
std::for_each(std::execution::par,      // 并行策略
              v.begin(), v.end(),
              [](int& x) { x *= 2; });

```

注意：

- 传入 `std::execution::par` 或 `par_unseq` 时，**函数必须是无数据竞争的**：
    
    - 不要写对共享变量的非同步写操作；
        
    - 不要依赖调用的顺序；
        
- 否则会有未定义行为。
    

### 8.2 C++20 `std::ranges::for_each`

C++20 引入 ranges 版本：

```C++
#include <algorithm>

namespace std::ranges {
    template<class Range, class Fun>
    for_each_result<borrowed_iterator_t<Range>, Fun>
    for_each(Range&& r, Fun f);
}
```

使用：

```C++
std::ranges::for_each(v, [](int& x) { x *= 2; });

// 支持直接对 range 调用，比如过滤后的 view：
auto odds = v | std::views::filter([](int x){ return x % 2 == 1; });
std::ranges::for_each(odds, [](int& x){ x *= 3; });
```

ranges 版的 `for_each` 返回一个结构体 `for_each_result{ .in = 迭代结束位置, .fun = 函数对象 }`，语义上也允许你取出状态ful functor。

---

## 9. 小结（你可以记住这些点）

1. **核心语义**：对 `[first, last)` 每个元素调用一遍 `f(*it)`；
    
2. **返回值**：返回 `f`（通常用于状态累积的 functor）；
    
3. **修改元素**：传 `int&` / `T&` 给 lambda 就能改，前提是容器本身不是 const；
    
4. **和 for-range 的关系**：功能上类似，for-range 更直观，`for_each` 更偏“算法风格”；
    
5. **不能自然 break**：要提前终止最好用别的算法（`find_if` / `any_of` 等）；
    
6. **C++17+ 有并行版本**，C++20 有 ranges 版本，对现代写法很友好。