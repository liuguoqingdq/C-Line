## 1. 创建和赋值

```C++
#include <string>
#include <iostream>
using namespace std;

```

常见赋值：

```C++
string s1;                    // 空字符串 ""
string s2 = "hello";          // 字面量
string s3("world");           // 构造函数
string s4(5, 'a');            // "aaaaa"
string s5 = s2;               // 拷贝
string s6 = s2 + " " + s3;    // 拼接 "hello world"
```

---

## 2. 访问字符

```C++
string s = "hello";

char c1 = s[0];               // 不做越界检查，越界 = UB
char c2 = s.at(1);            // 会检查，越界抛异常 std::out_of_range

s[0] = 'H';                   // 修改

```

获取 C 风格字符串指针：

```C++
const char* p = s.c_str();    // 只读
// C++11 起：
char* p2 = s.data();          // C++17 起 data() 返回可写指针（注意长度）

```

---

## 3. 长度与容量

```C++
string s = "hello";

size_t len = s.size();        // 长度 5
size_t len2 = s.length();     // 同 size()

bool empty = s.empty();       // 是否为空

s.reserve(100);               // 提前预留至少 100 个字符的容量（避免反复扩容）
size_t cap = s.capacity();    // 当前容量（实现相关）
s.shrink_to_fit();            // 尝试收缩多余容量（不保证一定收缩）

```

清空：

```C++
s.clear();                    // 长度变 0，容量通常保留

```
---

## 4. 拼接（append / + / push_back）

```C++
string s = "hello";

s += " world";                // 运算符 +=
s.append("!!!");              // 追加

s.push_back('!');             // 追加单个字符
// C++11 起也可以：
s.pop_back();                 // 删除最后一个字符（非空时）

```

---

## 5. 插入 / 删除 / 替换

### 5.1 插入 insert

```C++
string s = "heo";

s.insert(2, "ll");            // 在 index=2 的位置插入 "ll" → "hello"

string s2 = "abc";
s2.insert(1, 3, 'x');         // 在 index=1 插入 'x' 重复 3 次 → "axxxbc"

```

### 5.2 删除 erase

```C++
string s = "hello world";

s.erase(5);                   // 从下标 5 开始删到末尾 → "hello"
s.erase(0, 2);                // 从下标 0 删 2 个 → "llo"

```

结合 find 使用很常见。

### 5.3 替换 replace

```C++
string s = "hello world";
s.replace(6, 5, "C++");       // 从 6 开始替换 5 个字符为 "C++" → "hello C++"

```

---

## 6. 查找（find 系列）

```C++
string s = "hello world";

size_t pos1 = s.find("lo");      // 返回 3，找不到返回 string::npos
size_t pos2 = s.find('o');       // 返回第一个 'o' 的位置 4
size_t pos3 = s.rfind('o');      // 从后往前找，返回最后一个 'o' 的位置 7

// 从某个位置之后开始找：
size_t pos4 = s.find("or", 0);   // 从 0 开始找
size_t pos5 = s.find("or", 6);   // 从 6 开始找。结果无区别

```

还有一些变种：

```C++
s.find_first_of("abc");          // 找到第一个属于集合 "abc" 的位置
s.find_first_not_of(" \t\n");    // 找到第一个不是空白的字符
s.find_last_of(...)
s.find_last_not_of(...)

```

典型用法：去掉前后空白、解析简单格式等。

---

## 7. 子串 substr

```C++
string s = "hello world";

string s1 = s.substr(0, 5);    // "hello"   从0开始取5个
string s2 = s.substr(6);       // "world"   从6开始一直到末尾

```

---

## 8. 比较 compare / 运算符

```C++
string a = "abc";
string b = "abd";

bool eq  = (a == b);           // false
bool less = (a < b);           // 按字典序比较

int res = a.compare(b);        // <0 表示 a<b；=0 表示相等；>0 表示 a>b

```

`compare` 在需要明确“大小关系”时更常用，比如排序、手写字典序逻辑等。

---

## 9. 遍历字符串

### 9.1 经典 for

```C++
string s = "hello";

for (size_t i = 0; i < s.size(); ++i) {
    cout << s[i] << ' ';
}

```

### 9.2 range-based for（C++11）

```C++
for (char c : s) {
    cout << c << ' ';
}
for (auto ch : s) {
	cout<<ch<<endl;
}
for (auto &ch : s){
	cout<<ch<<endl;
}//ch是一个容器，加&与不加&符号区别在于，加&是本身，如果不加，是copy了一份1️⃣
```

### 9.3 迭代器

```C++
for (auto it = s.begin(); it != s.end(); ++it) {
    cout << *it << ' ';
}

```

---

## 10. 与数字 / C 字符串的转换

### 10.1 数字 → 字符串

```C++
int x = 42;
double y = 3.14;

string s1 = to_string(x);      // "42"
string s2 = to_string(y);      // "3.140000"（格式实现相关）

```

### 10.2 字符串 → 数字

```C++
string s = "123";

int a = stoi(s);               // string to int
long b = stol(s);              // string to long
double d = stod("3.14");       // string to double

```

注意：解析失败会抛异常 `std::invalid_argument` 或 `std::out_of_range`。

---

## 11. 和 C 风格字符串的区别（顺带一句）

- `std::string`：  
    管理内存、记录长度，会自动扩容、带很多成员函数。
    
- C 字符串 `char*` / `const char*`：  
    以 `'\0'` 结尾的字符数组，不自带长度，操作要用 `<cstring>` 里的函数（`strlen`, `strcpy`, `strcmp` ...）。
    

典型桥接方式：

```C++
string s = "hello";
const char* c = s.c_str();   // 传给需要 C 字符串的老接口
```

---
## emplace_back与push_back的区别
先给结论：

- **不是“emplace_back 一定比 push_back 更高级”**，而是**用途不一样**。
    
- 经验规则：
    
    - **已经有一个对象了** → 用 `push_back`（或 `push_back(std::move(x))`）。
        
    - **想在容器里“就地构造”一个对象** → 用 `emplace_back(args...)`。
        

下面细讲差异。

---

## 1. 行为上的根本区别

假设有：

`std::vector<std::string> v;`

### 1）push_back：往里“塞一个现成的 T”

```C++
std::string s = "hello";
v.push_back(s);             // 拷贝进 vector
v.push_back(std::move(s));  // 移动进 vector

v.push_back("world");       // 会先构造一个临时 std::string("world")
                            // 然后把这个临时对象拷贝/移动到 v 里
```

特点：

- 参数类型是 `const T&` 或 `T&&`，你给它一个“已经是 T 的对象”。
    
- 容器内部再拷贝 / 移动一份进去。
    

### 2）emplace_back：在 vector 内部“原地构造 T”

```C++
v.emplace_back("world");         // 直接在 v 的尾部用 "world" 调 std::string 的构造函数
v.emplace_back(5, 'x');          // 在尾部调用 std::string(5, 'x')，得到 "xxxxx"

```

特点：

- 参数是模板参数 `Args&&...`，**会原封不动转发给 `T` 的构造函数**：
    
    - 等价于：`new (尾部内存) T(std::forward<Args>(args)...);`
        
- 避免了“先造一个临时，再拷/移进去”这一步，中间可能少一次构造/移动。
    

---

## 2. 性能上差多少？

典型例子：

```C++
struct Foo {
    Foo(int a, double b, std::string c);
};

std::vector<Foo> v;

// 写法一：push_back
v.push_back(Foo(1, 2.0, "hi"));

// 写法二：emplace_back
v.emplace_back(1, 2.0, "hi");

```

理论上：

- 写法一：
    
    - 先构造一个临时 `Foo(1, 2.0, "hi")`；
        
    - 再把它 move/copy 到 `v` 的尾部；
        
- 写法二：
    
    - 直接在 `v` 的尾部内存上构造一个 `Foo(1, 2.0, "hi")`。
        

所以 **emplace_back 少一次移动 / 拷贝构造**，从教科书角度看更高效。

但现实里：

- 很多类型都是 cheap move（或者干脆是 trivially movable，编译器直接 memmove）；
    
- 编译器还可能把临时对象优化掉（NRVO/优化传值）；
    
- 所以“性能差距”在绝大多数场景下**微乎其微**，甚至完全没有体感。
    

**真正明显的优势是：语义更直接 + 对某些类型更方便**，比如：

- 不可拷贝但可构造的类型（`std::unique_ptr`）；
    
- 需要直接传构造参数的复杂对象。
    

---

## 3. 行为细节 & 差异点

### 3.1 是否必须已经有一个 T 对象？

- `push_back` 要的就是 “一个 `T` 对象”：
    
    - `push_back(T{...})`
        
    - `push_back(obj)`
        
- `emplace_back` 只要构造 `T` 的那一组参数：
    
    - `emplace_back(args...)` → 调用 `T(args...)` 构造。
        

例子（`std::vector<std::pair<int, std::string>>`）：

```C++
std::vector<std::pair<int, std::string>> vp;

// push_back 版本
vp.push_back(std::make_pair(1, "hi"));

// emplace_back 版本（更自然）
vp.emplace_back(1, "hi");

```

### 3.2 对 move-only 类型更好用（但不是唯一办法）

```C++
std::vector<std::unique_ptr<int>> v;

// push_back 写法
std::unique_ptr<int> p = std::make_unique<int>(42);
v.push_back(std::move(p));          // 必须 std::move，否则报错（不能拷贝）

// emplace_back 写法
v.emplace_back(new int(42));        // 在 vector 内部构造 unique_ptr<int>(new int(42))

```

两种都能用，只是 emplace_back 更自然一些。

### 3.3 返回值不同

- `push_back`：**返回值是 void**（对标准容器来说）。
    
- `emplace_back`：**返回值是对新插入元素的引用**。
    

`auto& ref = v.emplace_back(1, "hi"); // 可以直接用 ref 做进一步初始化`

有时这个很方便。

---

## 4. 那到底“更推荐哪个”？

给你一个简单、实用的习惯建议：

### ✅ 建议规则

1. **已经有现成对象时：**
    
    - 用 `push_back(obj);`
        
    - 或 `push_back(std::move(obj));`（你确定要把它搬进去，不再用原来的）
        
    
    例：
    
```C++
std::vector<std::string> v;
std::string s = "hello";

v.push_back(s);             // 拷贝
v.push_back(std::move(s));  // 移动

```
    
    这样读起来很直观：**“把这个对象 push 进去”**。
    
2. **需要在容器里现地构造对象时：**
    
    - 用 `emplace_back(args...)`。
        
    
    例：
    
```C++
std::vector<std::pair<int, std::string>> vp;
vp.emplace_back(1, "hi"); // 直接构造 pair<int,string>(1,"hi")
```
    
3. **别指望 emplace_back 魔法般提速**
    
    - 大多数日常场景下，push_back / emplace_back 性能差别可以忽略；
        
    - 选用标准应该是：**可读性 + 语义是否贴切**，而不是盯着那一点点潜在优化。
        

### 换句话说

> - 你手头**已经有 `T`** → push_back
>     
> - 你手头**只有构造 `T` 的参数** → emplace_back
>     

---

## 5. 有没有“全部都用 emplace_back”这种写法？

有的，有些代码风格就是：

`v.emplace_back(obj);          // 即便已经是对象，也用 emplace_back v.emplace_back(std::move(obj));`

这在语义上也说得通，而且不会出什么大问题。  
但它有两个小缺点：

1. 读代码的人不容易一眼看出你是“传了一个现成对象”还是“传的是构造参数”；
    
2. 极少数情况下，`emplace_back` 的构造重载解析可能和 `push_back` 行为略有区别（尤其是有 initializer_list 构造函数时），对新手来说会有点迷惑。