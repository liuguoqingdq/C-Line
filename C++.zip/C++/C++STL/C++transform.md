## 0. 总体心智模型

`std::transform` 做的事本质上就是：

> **对一个（或两个）输入区间的每个元素调用一个函数，把结果写入输出区间。**

可类比函数式里的 `map`：

- 一元：`[x1, x2, ...] --op--> [f(x1), f(x2), ...]`
    
- 二元：`[x1, x2, ...], [y1, y2, ...] --op--> [f(x1,y1), f(x2,y2), ...]`
    

---

## 1. 经典 STL 版：所有重载长什么样

头文件 `<algorithm>` 中的非 ranges 版（C++20 之前就有）：

```C++
// 一元版本
template<class InputIt, class OutputIt, class UnaryOp>
OutputIt transform(InputIt first1, InputIt last1,
                   OutputIt d_first, UnaryOp unary_op);         // (1)

// C++17 起：一元 + 执行策略（并行）
template<class ExecutionPolicy,
         class ForwardIt1, class ForwardIt2, class UnaryOp>
ForwardIt2 transform(ExecutionPolicy&& policy,
                     ForwardIt1 first1, ForwardIt1 last1,
                     ForwardIt2 d_first, UnaryOp unary_op);     // (2)

// 二元版本
template<class InputIt1, class InputIt2,
         class OutputIt, class BinaryOp>
OutputIt transform(InputIt1 first1, InputIt1 last1,
                   InputIt2 first2,
                   OutputIt d_first, BinaryOp binary_op);       // (3)

// C++17 起：二元 + 执行策略（并行）
template<class ExecutionPolicy,
         class ForwardIt1, class ForwardIt2,
         class ForwardIt3, class BinaryOp>
ForwardIt3 transform(ExecutionPolicy&& policy,
                     ForwardIt1 first1, ForwardIt1 last1,
                     ForwardIt2 first2,
                     ForwardIt3 d_first, BinaryOp binary_op);   // (4)
```

语义统一描述为：**对 `[first1,last1)` 的每个元素（以及第二个区间的配对元素）应用 `unary_op` / `binary_op`，结果依次写到从 `d_first` 开始的区间中**。

### 1.1 迭代器类别要求

从标准/CppReference：

- 一元/二元普通版本：
    
    - `InputIt*` 必须满足 **LegacyInputIterator**
        
    - `OutputIt` 必须满足 **LegacyOutputIterator**
        
- 带执行策略的版本：
    
    - `ForwardIt*` 必须满足 **LegacyForwardIterator**（因为并行算法可能多次遍历区间）
        

日常翻译一下：

- 普通版能吃「只读单向遍历」的迭代器，比如 `istream_iterator`；
    
- 并行版要求能多次遍历 → 至少前向迭代器（`vector::iterator`、`list::iterator` 等）。
    

---

## 2. 操作函数 `UnaryOp` / `BinaryOp` 的正规签名要求

标准对 `unary_op` / `binary_op` 要求大致是：

```C++
// UnaryOp
Ret f(const Type& a);
// BinaryOp
Ret f(const Type1& a, const Type2& b);
```

- `Type` / `Type1` / `Type2` 要求：  
    能从 `*InputIt` / `*InputIt1` / `*InputIt2` 隐式转换而来。
    
- `Ret` 要求：  
    能赋给 `*OutputIt`（即 `*OutputIt = Ret` 合法）。
    

实战里你直接写 lambda 就行，比如：

```C++
[](int x)        { return x * 2; }
[](int x, int y) { return x + y; }
```

编译器帮你推导类型，满足上面约束即可。

---

## 3. 精确语义 & 复杂度

### 3.1 一元版本：伪代码语义

规范等价实现：

```C++
template<class InputIt, class OutputIt, class UnaryOp>
OutputIt transform(InputIt first1, InputIt last1,
                   OutputIt d_first, UnaryOp unary_op)
{
    for (; first1 != last1; ++d_first, ++first1)
        *d_first = unary_op(*first1);

    return d_first;
}
```

- 对区间 `[first1, last1)` 中的每个元素，调用一次 `unary_op`，并把返回值写入 `*d_first`，然后两个迭代器都前进。
    
- 返回值是 **最后一个写入元素的“下一个位置”** 的迭代器（即 `d_first` 最终值）。
    

**复杂度：**

- 令 `N = distance(first1, last1)`，  
    一元版本必然调用恰好 `N` 次 `unary_op`。
    

### 3.2 二元版本：伪代码语义

```C++
template<class InputIt1, class InputIt2,
         class OutputIt, class BinaryOp>
OutputIt transform(InputIt1 first1, InputIt1 last1,
                   InputIt2 first2,
                   OutputIt d_first, BinaryOp binary_op)
{
    for (; first1 != last1; ++d_first, ++first1, ++first2)
        *d_first = binary_op(*first1, *first2);

    return d_first;
}
```

- 第二个区间隐式是 `[first2, first2 + N)`；
    
- 每对元素 `(*first1, *first2)` 调用一次 `binary_op`，写入输出区间。
    

**复杂度：**

- 同样是 `N` 次 `binary_op` 调用。
    

---

## 4. 关于「副作用」和「重叠区间」的严格规则

这是最容易踩坑、也最容易被误解的地方。

标准明确规定：如果 `unary_op` / `binary_op` 自己去“乱动”某些区间的元素，会 UB。

### 4.1 不允许在 op 内修改的区间

从 C++17 之后的描述：

- 对一元版本：如果 `unary_op` 使迭代器失效 **或修改** 下列区域任意元素，则行为未定义：
    
    1. `[first1, last1]`（注意右端闭区间）；
        
    2. 从 `d_first` 开始的 `N+1` 个元素的区间。
        
- 对二元版本：如果 `binary_op` 修改或导致失效：
    
    1. `[first1, last1]`；
        
    2. 从 `first2` 开始的 `N+1` 个元素区间；
        
    3. 从 `d_first` 开始的 `N+1` 个元素区间。
        

**重点：**

- 禁止的是在 `op` 里面**直接**去改这些区间的元素或迭代器；
    
- `transform` 本身对输出区间写入是没问题的（那是算法的职责）。
    

所以 **正确姿势** 是：

- `unary_op` / `binary_op` 只读参数，做纯计算；
    
- 所有「写操作」都由 `*d_first = ...` 完成，而不是在 op 里自己改容器。
    

### 4.2 输出区间允许怎样重叠？

文档里明确说明：`d_first` **可以等于** `first1` 或 `first2`。

也就是说这些用法是合法的：

```C++
// 一元，就地变换
std::transform(v.begin(), v.end(), v.begin(), op);

// 二元，输出写回第一个区间
std::transform(a.begin(), a.end(), b.begin(), a.begin(), op);

// 或者第二区间
std::transform(a.begin(), a.end(), b.begin(), b.begin(), op);
```

只要你自己的 `op` 不去乱动其它元素，这些都是标准支持的用法（cppreference 示例里就用了 `hello.cbegin(), hello.cend(), hello.begin()` 做 in-place toupper）。

**但更一般的复杂重叠（比如输出区间从中间开始，又和输入交错）就很危险**——标准没有保证行为，最好避免。

实战经验：

- 一元 in-place：`transform(v.begin(), v.end(), v.begin(), op)` 是完全常见且安全的写法；
    
- 二元：理论上可以 in-place 写回其中一个区间，但为了减少脑补难度，**建议输出区间单独放一个容器**，除非你非常确定不会搞乱。
    

---

## 5. 关于「调用顺序」：不能依赖 `transform` 的次序性

标准在 Notes 写得很直白：

> `std::transform` 不保证按顺序对元素应用 `unary_op` / `binary_op`。  
> 若你要保证按顺序应用，或者你的函数会修改序列元素，请使用 `std::for_each`。

这句话背后的含义：

- **即使是无执行策略版本**，标准也给实现留了优化空间（比如 vectorization / loop unrolling / 重新排序）；
    
- 所以你不能写出依赖“第 i 次调用一定发生在第 i-1 次之后”这种语义的副作用逻辑。
    

因此：

- **可以**：`op` 是一个纯函数（或只写某个外部 `std::atomic` 计数等，且不依赖顺序）；
    
- **不应该**：`op` 里做顺序敏感的 IO 或依赖前后状态（比如“遇到第一个 x>0 就停止后面逻辑”）。
    

需要“有序副作用”的场景 → `std::for_each` 或手写 for。

---

## 6. 典型模式 & 实战习惯

### 6.1 一元 transform：in-place vs 新容器

**就地修改：**

```C++
std::vector<int> v = {1,2,3,4};

std::transform(v.begin(), v.end(), v.begin(),
               [](int x){ return x * 2; });
// v = {2,4,6,8}
```

**生成新容器（提前 resize）：**

```C++
std::vector<int> v = {1,2,3,4};
std::vector<int> out(v.size());

std::transform(v.begin(), v.end(), out.begin(),
               [](int x){ return x * x; });
// out = {1,4,9,16}
```

**生成新容器（用 back_inserter）：**

```C++
std::vector<int> v = {1,2,3,4};
std::vector<int> out;

std::transform(v.begin(), v.end(),
               std::back_inserter(out),
               [](int x){ return x * x; });
// out 自动 push_back -> {1,4,9,16}
```

插入迭代器是 transform 的好搭档，尤其在不知道结果数量或不想手动 `resize` 时。

### 6.2 字符串大小写、映射

```C++
std::string s = "Hello World";

std::transform(s.begin(), s.end(), s.begin(),
               [](unsigned char c){
                   return std::toupper(c);
               });
// s -> "HELLO WORLD"
```

注意 `unsigned char` 以避免 `char` 为 signed 时的 UB。

### 6.3 二元 transform：逐元素加减、点运算

```C++
std::vector<int> a = {1,2,3};
std::vector<int> b = {10,20,30};
std::vector<int> c(a.size());

std::transform(a.begin(), a.end(), b.begin(), c.begin(),
               [](int x, int y){ return x + y; });
// c = {11,22,33}
```

常用于：

- 逐点加法、减法；
    
- 逐点 min / max（`std::min` / `std::max`）；
    
- 应用某种 pairwise 函数。
    

如果要做点积，其实更建议用 `std::inner_product` / `std::transform_reduce`，这里就不展开了。

---

## 7. 与其他算法的对比：`transform` vs `for_each` vs `copy`

你可以这么区分：

- `std::for_each`
    
    - 只对元素**做事**（打印、计数、外部累加），不关心输出位置；
        
    - 适合副作用逻辑（尤其需要顺序时）。
        
- `std::copy` / `copy_if`
    
    - 只“搬运”元素，不改变值类型；
        
    - `copy_if` 带过滤条件，但不会改值。
        
- `std::transform`
    
    - **既做运算（变形），又负责写入输出区间**；
        
    - 可以视作「带函数的 copy」。
        

同一个需求的不同写法对比：

```C++
// 1）简单 in-place：for-range
for (auto& x : v) x *= 2;

// 2）保持风格统一的算法式写法：for_each
std::for_each(v.begin(), v.end(),
              [](int& x){ x *= 2; });

// 3）构造新容器：transform
std::vector<int> out(v.size());
std::transform(v.begin(), v.end(), out.begin(),
               [](int x){ return x * 2; });
```

在 template 库/算法组件里，**transform 相比手写 for 的优点**是：

- 可组合：可以把 op 作为模板参数/策略传来传去；
    
- 语义集中：一眼就知道“这是 map/transform 操作”。
    

---

## 8. C++17 并行版本：配合 `<execution>`

并行版只是多了一个执行策略参数：

```C++
#include <execution>

std::transform(std::execution::par,
               v.begin(), v.end(), v.begin(),
               [](int x){ return x * 2; });
```

这里的执行策略可能是：

- `std::execution::seq`：顺序执行（相当于普通 transform）；
    
- `std::execution::par`：允许多线程并行；
    
- `std::execution::par_unseq`：并行 + 向量化。
    

对你来说最重要的点：

- **op 必须是无数据竞争的**：
    
    - 不要写入共享非原子变量；
        
    - 不要依赖调用顺序；
        
    - 不要在不同元素之间有逻辑依赖；
        
- 输出区间也不能在多个线程里“交叉写入同一个元素”。
    

简单说：**把 op 当成纯函数**，并保证每个输出元素只会被一个线程写一次，就安全。

---

## 9. C++20 Ranges：`std::ranges::transform` vs `views::transform`

C++20 增加了两类“transform”相关东西：

### 9.1 范围算法 `std::ranges::transform`

签名变成“直接对 range 操作”：

```C++
#include <algorithm>
#include <ranges>
std::ranges::transform(range, out_it, op);
std::ranges::transform(range1, range2, out_it, binary_op);
```

差异主要是：

- 接受 range（比如容器、view），而不是显式迭代器对；
    
- 返回 `unary_transform_result` / `binary_transform_result` 结构体（包含 in/out 迭代器）；
    
- 有概念约束（`input_range`, `weakly_incrementable` 等）。
    

使用体验更贴合现代 C++ 的 range pipeline。

### 9.2 懒视图 `views::transform` / `transform_view`

这是完全不同的东西：它**不立刻生成结果**，而是创建一个“视图”，遍历时才对元素做变换。

```C++
#include <ranges>

auto v    = std::vector<int>{1,2,3,4};
auto view = v | std::views::transform([](int x){ return x * 2; });
// 此时并没有新容器，只是一个 view

for (int x : view) {
    // 每次迭代时现算 x*2
}
```

- `std::transform`：**eager**，一次性写出结果；
    
- `views::transform`：**lazy**，谁迭代谁用、按需计算。
    

在写 pipeline / 组合复杂变换时，ranges + views 更有表现力；在普通业务代码、尤其偏“命令式”的 C++ 项目里，传统 `std::transform` 反而更常见。

---

## 10. 小结 – 你可以记住的核心点

1. 重载家族：一元/二元 + （可选）执行策略；统一语义是“对元素做函数映射，并写出结果”。
    
2. 类型约束：输入迭代器至少 InputIterator，输出迭代器是 OutputIterator；执行策略版要求 ForwardIterator。
    
3. op 的要求：
    
    - 签名等价 `Ret f(const T&)` / `Ret f(const T1&, const T2&)`；
        
    - 不能在内部修改 `[first1,last1]`、第二输入区间和输出区间，否则 UB。
        
4. 重叠区间：
    
    - `d_first` 可以等于 `first1`/`first2`，一元 in-place 变换是标准支持的；
        
    - 更复杂的交错重叠不要写，没标准保证。
        
5. 调用顺序：
    
    - 不保证按顺序执行 op；需要顺序副作用就用 `for_each` / 手写循环。
        
6. 典型模式：
    
    - in-place：`transform(v.begin(), v.end(), v.begin(), op)`；
        
    - 输出新容器：先 `resize` 或用 `back_inserter`；
        
    - 二元：常用于逐元素加减、pairwise 运算。
        
7. C++17 并行版本 & C++20 ranges 版：本质语义不变，只是增加执行策略和更现代的 range 接口。