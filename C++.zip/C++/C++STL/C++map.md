## 再一句话总结

> **`std::map<Key, T>` 是：有序、key 唯一、基于平衡搜索树的关联容器。**  
> 每个元素是 `pair<const Key, T>`，按 `Compare(Key, Key)` 排序，查找 / 插入 / 删除都是 `O(log n)`。

---

## 1. 类型与模板参数：把声明拆开看

标准声明大致是：

```C++
template<
    class Key,
    class T,
    class Compare = std::less<Key>,
    class Allocator = std::allocator<std::pair<const Key, T>>
> class map;
```

四个点：

1. **Key**：键类型
    
    - 比如 `int`、`std::string`、自定义 struct（需要可比较）。
        
2. **T（mapped_type）**：值类型
    
    - 一般就是你要存的东西，`int`、`double`、`std::vector<int>` 等。
        
3. **Compare**：排序规则
    
    - 要满足**严格弱序**（strict weak ordering），默认是 `std::less<Key>`（即 `<` 升序）。
        
    - 容器内部不会用 `==`，而是用 `Compare(a, b)` / `Compare(b, a)` 来判断谁小谁大以及“等价”。
        
4. **Allocator**：内存分配器，一般不自己改。
    

### 1.1 `value_type` 与 `const Key`

`map<Key, T>` 的 `value_type` 是：

`using value_type = std::pair<const Key, T>;`

为什么 `Key` 是 `const`？

- 因为 key 决定了节点在树中的位置，
    
- 一旦 `map` 内部把节点插到树的某个位置，**你不能通过迭代器随便改 key**，否则会破坏排序 & 树结构。
    

所以：

```C++
std::map<int, std::string> mp;
mp[1] = "a";

auto it = mp.find(1);
// it->first = 2;    // ❌ 编译错误：first 是 const int
```

想“改 key”的标准做法：

```C++
int key_old = 1;
std::string value = std::move(mp[key_old]);
mp.erase(key_old);

int key_new = 2;
mp.emplace(key_new, std::move(value));
```

---

## 2. 底层结构：平衡二叉搜索树 + Compare 语义

### 2.1 搜索树 + 高度 O(log n)

`map` 通常用 **红黑树** 实现（标准只要求是平衡树）。性质：

- 树按 key 排序，左子树 < 根 < 右子树（Compare 定义的“小于”）。
    
- 高度保持在 `O(log n)`，因此：
    
    - `find`、`insert`、`erase` 的路径长度 ~ `log n`；
        
    - 所以复杂度是 `O(log n)`。
        

### 2.2 Compare 决定“相等”的含义

标准中：不直接用 `==` 判断 key 是否“相等”，而用 Compare 定义的“严格弱序”。  
对任意 `a, b`：

- `Compare(a, b)` 为真 → `a` 在排序上比 `b` 小；
    
- `Compare(a, b)` 和 `Compare(b, a)` 都为假 → 在排序意义上 `a` 与 `b` 等价（视为相同 key）。
    

map 要求 **key 唯一**，实现方式是：

- 插入新 key 时，如果找到某个已有元素 `k`，和新 key `k_new` 满足：
    
    - `!Compare(k_new, k)` && `!Compare(k, k_new)`  
        → 认为两者等价 → 不再插入新的节点。
        

**所以：如果你自定义 Compare 的时候写得不满足传递性/严格弱序，很可能导致行为 undefined。**

示例问题 comparator（错误）：

```C++
struct BadCmp {
    bool operator()(int a, int b) const {
        return (a % 10) < (b % 10);   // 只按个位数比
    }
};
```

这样 `10`、`20`、`30` 会都被认为“等价”（个位数都为 0），map 无法正常维护唯一性 & 平衡树，会出各种诡异行为。

---

## 3. 常用接口逐个拆解

### 3.1 插入：`operator[]`, `insert`, `emplace`, `insert_or_assign`, `try_emplace`

#### 3.1.1 `operator[]`（最常用，也最容易踩坑）

```C++
T& operator[](const Key& key);
T& operator[](Key&& key); // C++11+
```

行为：

- 如果 key 已存在：返回该 key 对应的 `T&`；
    
- 如果 key 不存在：
    
    1. 插入一条记录 `{key, T()}`（值是默认构造的）；
        
    2. 返回这个新值的引用。
        

例子：

```C++
std::map<std::string, int> mp;
mp["a"] = 10;    // 插入 {"a", 10}
mp["b"] += 1;    // "b" 不存在 → 插入 {"b", 0} → 然后 0+1 → value=1

std::cout << mp.size();   // 2
std::cout << mp["c"];     // 输出 0，同时插入 {"c", 0}
```

**坑点**：`operator[]` 会“顺手插入”，所以不能用来“纯判断存在性”，会污染 map。

#### 3.1.2 `at`：不会插入，不存在会抛异常

```C++
T&       at(const Key& key);
const T& at(const Key& key) const;
```

- key 存在 → 返回引用；
    
- key 不存在 → 抛 `std::out_of_range`。
    

```C++
std::pair<iterator, bool> insert(const value_type& value);
std::pair<iterator, bool> insert(value_type&& value);
iterator insert(const_iterator hint, const value_type& value);
```

比 `operator[]` 更安全清晰。

#### 3.1.3 `insert`

几种常见形式：

```C++
std::map<int, std::string> mp;
auto [it1, ok1] = mp.insert({1, "one"}); // ok1 == true
auto [it2, ok2] = mp.insert({1, "uno"}); // ok2 == false，1 对应的 value 仍是 "one"
```

行为：

- key 不存在：插入成功，`pair.second == true`；
    
- key 已存在：不插入，返回已存在元素的迭代器，`pair.second == false`。
    

```C++
template<class... Args>
std::pair<iterator, bool> emplace(Args&&... args);
```

注意：**insert 不会覆盖已有值**，要覆盖见下面。

#### 3.1.4 `emplace`：就地构造

```C++
mp.emplace(1, "one");   // 等价于插入 pair<const int, std::string>(1, "one")
```

**不会先构造一个 pair 再拷贝/移动**，而是在树节点里直接构造。性能上比 `insert({key, value})` 理论上更好。

```C++
mp.insert_or_assign(1, "one");
// 若 1 不存在：插入 {1, "one"}
// 若 1 存在：更新成 new value

mp.try_emplace(2, 10, 'a');   // 假设 value_type 是 std::string
// 若 2 不存在：等价于 value = std::string(10, 'a')
// 若 2 存在：什么都不做，也不会构造临时 std::string(10, 'a')
```

#### 3.1.5 C++17：`insert_or_assign` / `try_emplace`

- `insert_or_assign(key, value)`：
    
    - key 不存在 → 插入；
        
    - key 存在 → **覆盖**原来的 value；
        
- `try_emplace(key, args...)`：
    
    - key 不存在 → 原地构造 value；
        
    - key 存在 → 不做任何事（连构造参数都不会评估）。
        

例子：

```C++
mp.insert_or_assign(1, "one");
// 若 1 不存在：插入 {1, "one"}
// 若 1 存在：更新成 new value

mp.try_emplace(2, 10, 'a');   // 假设 value_type 是 std::string
// 若 2 不存在：等价于 value = std::string(10, 'a')
// 若 2 存在：什么都不做，也不会构造临时 std::string(10, 'a')
```

`try_emplace` 很适合 value 构造成本很大，又不想在 key 已存在时浪费。

---

### 3.2 查找：`find`, `count`, `contains`

```C++
iterator       find(const Key& key);
const_iterator find(const Key& key) const;

size_type count(const Key& key) const;   // map 中结果只可能是 0 或 1

bool contains(const Key& key) const;     // C++20
```

- `find`：找不到返回 `end()`。
    
- `count`：在 `map` 中要么 0 要么 1（因为 key 唯一）。
    
- `contains`：C++20 直接给 bool，更符合语义，不用写 `find != end()`。
    

例子：

`if (mp.contains("alice")) {     std::cout << mp.at("alice") << "\n"; }`

---

### 3.3 范围查询：`lower_bound` / `upper_bound` / `equal_range`

这是 `map` 和 `unordered_map` 的最大差异之一。

```C++
iterator lower_bound(const Key& key);
iterator upper_bound(const Key& key);
std::pair<iterator, iterator> equal_range(const Key& key);
```

解释：

- `lower_bound(k)`：第一个 `key >= k` 的迭代器；（若都小于 k，则返回 `end()`）
    
- `upper_bound(k)`：第一个 `key > k` 的迭代器；
    
- `equal_range(k)`：返回 `[lower_bound(k), upper_bound(k))` 区间。
    

典型用法：**区间遍历**。

```C++
// 找出 [L, R) 之间所有 key 的元素
auto itL = mp.lower_bound(L);
auto itR = mp.lower_bound(R);

for (auto it = itL; it != itR; ++it) {
    // 所有 L <= it->first < R 的元素
}
```

如果你用的是 `unordered_map`，要做这种按范围的查询只能扫一遍所有元素，复杂度 `O(n)`；  
而 `map` 是 `O(log n + k)`（k 是区间内元素数目）。

---

## 4. 迭代器特性与失效规则

### 4.1 迭代器类型

`map` 是 **双向迭代器**（bidirectional iterator）：

- 支持 `++it` / `--it`；
    
- 不支持随机访问操作（`it + 3`、`it[i]` 等）。
    

可用接口：

```C++
iterator begin();
iterator end();
reverse_iterator rbegin(); // 逆序遍历
reverse_iterator rend();
```

### 4.2 有序遍历

```C++
std::map<int, std::string> mp;
mp[10] = "a";
mp[5]  = "b";
mp[20] = "c";

for (auto& [k, v] : mp) {
    std::cout << k << " -> " << v << "\n";
}
// 输出顺序：5, 10, 20
```

内部树结构保证是按 key 的 Compare 顺序。

### 4.3 迭代器失效规则（这个非常重要）

- **插入元素**：  
    所有已有迭代器、指针、引用都保持有效（除非你指向被删除的节点）。
    
- **删除元素**：
    
    - 指向被删元素的迭代器失效；
        
    - 其他迭代器保持有效。
        

这比 `vector` 要友好多了（`vector` 扩容后所有迭代器和指针都失效）。

因此你可以安全地：

```C++
for (auto it = mp.begin(); it != mp.end(); ) {
    if (需要删除某些元素) {
        it = mp.erase(it);   // C++11 起，erase 返回下一个迭代器
    } else {
        ++it;
    }
}
```

---

## 5. 自定义比较器：Compare 怎么写才安全？

### 5.1 写一个结构体比较器

比如 key 是字符串，我们想按长度排序，长度相同时按字典序：

```C++
struct StrCmp {
    bool operator()(const std::string& a, const std::string& b) const {
        if (a.size() != b.size())
            return a.size() < b.size();
        return a < b;  // 长度相同再按字典序
    }
};

std::map<std::string, int, StrCmp> mp;
```

要求是：

- **不可不对称**：不能出现 `comp(a,b)` 和 `comp(b,a)` 都为真；
    
- **必须传递**：`comp(a,b)` 且 `comp(b,c)` ⇒ `comp(a,c)`；
    
- **等价类概念**：`!comp(a,b) && !comp(b,a)` 时这两个 key 被视为“等价”，即 map 只保留一个。
    

### 5.2 用 lambda 也可以（需要带类型）

```C++
auto cmp = [](const std::string& a, const std::string& b) {
    return a.size() < b.size();
};

std::map<std::string, int, decltype(cmp)> mp(cmp);
```

注意：

- 模板参数必须是类型，不能直接写 lambda，需要 `decltype(cmp)`；
    
- 构造 map 时要把 comparator 对象传进去（`mp(cmp)`）。
    

---

## 6. C++17：节点句柄（node_handle）高级玩法

节点句柄是 C++17 引入的一个机制，用来**在容器之间搬运节点而不拷贝元素**。

```C++
auto nh = mp.extract(key);   // nh 是一个 node_handle
if (!nh.empty()) {
    // 可以修改 nh.key() 吗？对 map 来说 key() 仍然是 const Key&
    // 但可以拿到 nh.mapped() 修改 value
    other_map.insert(std::move(nh));
}
```

**用途：**

- 在两个 map 之间移动元素，**不重新分配内存、不重新构造 value**；
    
- 可以用来做一些复杂的数据结构重组，避免昂贵的拷贝。
    

（对你来说，如果不写复杂 container 逻辑，可以先知道有这个东西就行。）

---

## 7. 典型用法模式与选型

### 7.1 常见用法模式

1. **映射表 / 字典**：名字 → 分数、ID → 对象
    
    - 需要按 key 查找、插入、遍历。
        
2. **区间查找 / 上下界**：时间戳 → 事件、坐标 → 元素
    
    - `lower_bound` / `upper_bound` 非常好用。
        
3. **按 key 有序输出**：
    
    - 直接遍历 map 即可，不用额外排序。
        

### 7.2 map vs unordered_map 的选型

**用 `map`：**

- 你需要 **有序**；
    
- 你需要 `lower_bound` / `upper_bound` 做区间查找；
    
- 你在乎 **迭代器稳定性**（插入不会导致迭代器失效）；
    
- 数据量不是极端大，`log n` 能接受；
    

**用 `unordered_map`：**

- 不关心顺序；
    
- 主要操作是查找 / 插入 / 删除，性能敏感；
    
- 可以接受迭代器在 rehash 时全部失效；
    
- 懂得设置 `reserve`、注意哈希函数质量。
    

### 7.3 map vs multimap / map<Key, vector<T\>>

- 需要“一对一”：`map<Key, T>`
    
- 需要“一对多”：
    
    - 方案 1：`multimap<Key, T>`，直接插多条；
        
    - 方案 2：`map<Key, std::vector<T>>`，多个 value 放在 vector 里；
        
- 选择原则：
    
    - 需要按 key + value 组合排序遍历，多半用 `multimap`；
        
    - 需要随机访问/批量操作单个 key 下所有 value，多半用 `map<Key, vector<T>>` 更灵活。
        

---

## 8. 小结

更系统地看，`std::map` 的关键点是：

1. **底层**：平衡搜索树 + 严格弱序 Compare；
    
2. **接口语义**：
    
    - `operator[]` 会插入默认值；
        
    - `at` 安全但可能抛异常；
        
    - `insert` 不覆盖已有 key；
        
    - `insert_or_assign` / `try_emplace` 提供更细粒度控制；
        
3. **有序性**：
    
    - 遍历按 key 排序；
        
    - 支持各种基于 key 的区间查询；
        
4. **迭代器稳定**：
    
    - 插入不使迭代器失效；
        
    - 删除只使指向被删节点的迭代器失效；
        
5. **Compare / value_type / const Key**：决定了 map 的“语义正确性”。