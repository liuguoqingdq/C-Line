## 1. `std::vector` 是啥？——“会自动长大的连续数组”

特点先一口气说完：

- 元素在内存中是**连续存放**的（contiguous），就像 `T arr[N];` 一样；
    
- 可以动态增加/减少长度（`push_back`, `resize`, `insert`, `erase`…）；
    
- 支持随机访问：`v[i]`, `v.data()[i]`，时间复杂度 O(1)；
    
- 头尾插入删除：尾部 `push_back` / `pop_back` 是 **摊还 O(1)**，中间插入删除是 O(n)；
    
- 内部会自动扩容，但**扩容时可能搬家（realloc）**，旧指针和迭代器会失效。
    

典型代码使用：

```C++
#include <vector>
#include <iostream>

int main() {
    std::vector<int> v;

    v.push_back(1);
    v.push_back(2);
    v.push_back(3);

    std::cout << v[0] << " " << v[1] << " " << v[2] << "\n";  // 1 2 3

    for (int x : v) {
        std::cout << x << " ";  // 1 2 3
    }
    std::cout << "\n";
}

```

你可以把它当“带自动内存管理的 C 数组”。

---

## 2. vector 底下大概长啥样？

大多数实现里（libstdc++、libc++）`std::vector` 内部就是“3 个指针”：

```C++
template <class T, class Allocator = std::allocator<T>>
class vector {
    T* _begin;        // 指向第一个元素
    T* _end;          // 指向“已使用区域”的尾后（one past last）
    T* _end_cap;      // 指向“整个已分配空间”的尾后

    // 再加上 allocator 等
};

```

可以画成这样：

```csharp
内存块：
[  T  ][  T  ][  T  ][未使用][未使用][未使用]
 ^               ^      ^
 |               |      |
_begin          _end  _end_cap

size() = _end - _begin
capacity() = _end_cap - _begin

```

- **size()**：当前有多少个元素
    
- **capacity()**：当前这块内存最多能放多少元素（不重新分配的情况下）
    
- 当 `size() == capacity()` 再 `push_back` 时，就需要扩容（重新分配一块更大的内存，搬家）。
    

这就是它支持 **O(1) 随机访问** 和 **尾部摊还 O(1) 插入** 的基础。

---

## 3. 扩容 / 插入 / 删除时底层做了什么？

### 3.1 `push_back` / `emplace_back` 的流程

伪代码：

```C++
void push_back(const T& value) {
    if (_end == _end_cap) {
        grow();                   // 扩容
    }
    ::new ((void*)_end) T(value);  // 在尾部位置“就地构造”一个 T
    ++_end;                       // 尾后指针后移
}

```

`grow()` 大概会：

1. 计算新的容量（一般是旧容量的 1.5 倍 ~ 2 倍，标准没规定，具体由实现决定）；
    
2. 用 allocator 分配一块更大的内存；
    
3. 把旧元素逐个移动/拷贝到新内存（对每个元素调用移动构造 / 拷贝构造）；
    
4. 析构旧元素 & 释放旧内存；
    
5. 更新 3 个指针。
    

因此：

- **尾部 `push_back` 的均摊复杂度是 O(1)**：因为虽然扩容是 O(n)，但不经常发生；
    
- 但每次扩容时，**所有指向旧元素的指针、引用、迭代器都失效**——这一点非常重要。
    

### 3.2 `insert` / `erase` 中间位置

假设有：

`std::vector<int> v = {1, 2, 3, 4, 5}; //   index:           0  1  2  3  4`

#### `insert`：

`auto it = v.begin() + 2;      // 指向元素 3 v.insert(it, 99);             // 在 3 这个位置前插入 99 // 结果：1, 2, 99, 3, 4, 5`

底层需要做的事：

1. 如果 `size() == capacity()`，先扩容（搬家）；
    
2. 把 [pos, _end) 这段元素整体向后挪一格（使用 `move_backward`）；
    
3. 在空出来的位置构造新元素。
    

所以中间插入时间复杂度是 **O(n - pos)**，整体就是 O(n)。

#### `erase`：

`auto it = v.begin() + 2; v.erase(it);                  // 删除第 3 个`

底层：

1. 对被删元素调用析构；
    
2. 把 （pos+1, _end) 这段元素向前挪一格；
    
3. `_end--`。
    

也是 O(n) 级别。

**结论：**

- `vector` 擅长：
    
    - 尾部 `push_back` / `pop_back`
        
    - 按下标访问（随机访问）
        
- 不擅长：
    
    - 头部插入删除 / 中间频繁插入删除 → 会大量搬移元素，O(n)
        

如果你需要频繁在前面插入，`std::deque`、`std::list` 可能更适合（但又会失去随机访问效率）。

---

## 4. 元素类型 T 的构造 / 析构 / 移动

`vector<T>` 对元素的生命周期管理方式大致是：

- 分配一块原始内存（`operator new[]` / allocator）；
    
- 不立刻构造所有 T，只在你插入时才“就地构造”；
    
- 删除/缩小时，在不需要的地方调用析构函数；
    
- 给你返回引用 / 指针时，本质是 `_begin + index`；
    

对 trivial 类型（如 `int`、`double`）：

- 构造/析构几乎是 no-op；
    
- 可以用 `memcpy`/`memmove` 优化搬移。
    

对复杂类型（如 `std::string`、你自定义的类）：

- 插入/删除/扩容时，会调用**移动构造/拷贝构造**，拷来拷去；
    
- 所以写 vector 时，**元素类型是否支持高效移动（move）很关键**；
    
- 这也是现代 C++ 强调移动语义/右值引用的原因：  
    vector 扩容时可以 move 而不是 copy，代价小很多。

[[C++travail类型]]

---

## 5. size / capacity / reserve / shrink_to_fit

常用 API 的底层含义：

`std::vector<int> v; v.reserve(100);    // 提前分配至少 100 个元素的空间（不改 size，只改 capacity）`

- 提前 `reserve` 可以减少扩容次数，提高性能；
    
- 但不会调用构造函数，不会改变 `v.size()`。
    

`v.resize(50);      // 如果原来 size < 50，会补元素（调用 T 的默认构造）到 50                    // 如果原来 size > 50，会析构多余的元素，size 变 50`

`capacity()` 通常 >= `size()`，并不会因为 `resize` 变小就立刻缩容。

`v.shrink_to_fit(); // 建议实现尽量收缩 capacity 到接近 size`

`shrink_to_fit` 是一个“non-binding 请求”，实现可以选择是否真的缩容，但主流实现都会收缩。

---

## 6. 迭代器失效规则（很重要）

大致记两条：

1. **扩容时（reallocate）**：
    
    - 所有指向原 vector 元素的 **迭代器 / 指针 / 引用全部失效**。
        
2. **不扩容的情况下**：
    
    - 尾部 `push_back`：原有元素的引用/指针仍然有效，`end()` 失效；
        
    - 中间 `insert` / `erase`：
        
        - 被操作位置之后的元素迭代器/引用全部失效；
            
        - 之前的仍然有效。
            

所以这样写是危险的：

```C++
auto it = v.begin();
for (; it != v.end(); ++it) {
    if (some_condition) {
        v.push_back(*it);   // 可能触发扩容 -> it 失效 -> UB
    }
}

```

正确做法是先记录需要插入的东西到临时容器，再统一 push_back，或在循环里用 `index` 方式访问。

```C++
std::vector<int> v = {1,2,3,4,5};

std::vector<int> to_add;
to_add.reserve(v.size());          // 可选：减少 to_add 扩容

for (const auto& x : v) {          // 只读原 vector
    if (some_condition(x)) {
        to_add.push_back(x);
    }
}

v.insert(v.end(), to_add.begin(), to_add.end());  // 一次性追加
```
### `insert` 返回什么？

- **返回：指向“第一个被插入元素”的迭代器**。
    

```C++
auto it = v.insert(pos, x);              // it 指向新插入的 x
auto it2 = v.insert(pos, n, x);          // it2 指向第一个新插入的 x
auto it3 = v.insert(pos, first, last);   // it3 指向第一个新插入的元素
```

> 注意：如果触发扩容，原来的迭代器都可能失效，但**返回的这个迭代器是新的、有效的**。

---

### `erase` 返回什么？

- **返回：被删区间“后面那个元素”的迭代器**  
    （也就是下一次继续遍历应该从哪儿开始）
    
```C++
auto it = v.erase(pos);          // it 指向原 pos 后面的元素
auto it2 = v.erase(first, last); // it2 指向 last 后面的元素
// 如果删到末尾，返回 v.end()
```

---

## 7. 和普通数组 / list / deque 的区别简记

- `T arr[N];`：
    
    - 大小固定，编译期或栈上；
        
    - 不会扩容，不会搬家；
        
    - 不会自动管理大小；
        
- `std::vector<T>`：
    
    - 大小可变，堆上连续内存，自动扩容；
        
    - 支持随机访问；
        
    - 中间插入删除 O(n)，扩容时可能搬家。
        
- `std::list<T>`（双向链表）：
    
    - 每个元素单独分配，通过指针串起来；
        
    - 任意位置插入删除 O(1)，但不支持随机访问，cache 不友好；
        
- `std::deque<T>`：
    
    - 分段连续（多个小块），适合头尾插入删除；
        
    - 随机访问也可以，但实现更复杂，迭代器失效规则和 vector 不一样。
        

**一般推荐：**

> 除非有非常强的理由用别的容器，  
> **优先用 `std::vector`**。  
> 因为它最简单、cache 友好、配合移动语义性能也最好。


