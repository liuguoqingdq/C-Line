## 1. 一张“典型实现结构图”

先看典型（以 libstdc++/libc++ 为代表）的实现思路——注意：**标准不强制这样实现，但主流库都很像**。

```C++
struct deque {
    T**   map;        // 指针数组：每个元素指向一块 buffer
    size_t map_size;  // map 中 T* 槽位的个数

    iterator start;   // 指向首元素
    iterator finish;  // 指向尾后位置
};

struct iterator {
    T* cur;    // 当前元素位置
    T* first;  // 当前块的起始地址
    T* last;   // 当前块的尾后地址
    T** node;  // 指向 map 中对应块指针的“指针”
};
```

**map 是一维数组**，里面每个元素是一个 `T*`，指向一小块连续内存（我们叫“块”或 buffer）。每个块大小固定，比如 512 字节左右（实现有差异），块里存多个 `T`。

所以 `deque` 的逻辑顺序 = 从 `start` 所在块的 `cur` 出发，一直走到 `finish` 把中间的所有块走完。

---

## 2. block_size（块大小）怎么定？

主流实现一般有类似逻辑（伪代码）：

```C++
size_t block_size() {
    if (sizeof(T) < 256)
        return 512 / sizeof(T);   // 保证一块大概 512 字节
    else
        return 1;                 // 太大的元素就每块放 1 个
}
```

所以：

- 如果 `T` 很小，比如 `int`，一块可以放几十个元素；
    
- 如果 `T` 巨大，一个块可能只存 1~2 个元素。
    

好处：

- 对于小对象，**块大，迭代时 cache 友好**；
    
- 对于大对象，**避免一次性分配一个超大的连续数组**，分块更容易从堆上拿到。
    

---

## 3. `push_back` / `push_front` 的内部流程（源码级伪代码）

### 3.1 `push_back` 伪代码

```C++
void push_back(const T& x) {
    if (finish.cur != finish.last - 1) {
        // 当前尾块还有空位
        new (finish.cur) T(x);
        ++finish.cur;
    } else {
        // 当前块满了，需要分配新块
        push_back_aux(x);
    }
}
```

`push_back_aux` 里大致做几件事：

1. **检查 map 是否还有空的槽位可以挂新块**
    
    - 如果 `finish.node + 1` 还在 `map` 范围内：
        
        - 直接 `allocate_block()`，放到 `*(finish.node + 1)`；
            
    - 否则：
        
        - 需要**扩容 map**：分配更大的 `T**` 数组，把原有块指针搬过去，释放旧的 `map`；
            
2. 新块申请完后：
    
    - 在新块第一个位置构造元素；
        
    - `finish.node++` 指向新块；
        
    - 更新 `finish.first/last/cur`。
        

这就是为什么：

- 尾部插入总体是 **摊还 O(1)**：
    
    - 大部分时候只是“在当前块末尾构造一个对象”；
        
    - 偶尔分一块 + 偶尔扩容 map，但和 `vector` 那种“搬运所有元素”相比要便宜多了。
        

### 3.2 `push_front` 伪代码

`push_front` 完全对称，只是方向反过来：

```C++
void push_front(const T& x) {
    if (start.cur != start.first) {
        // 当前首块前面还有空位
        --start.cur;
        new (start.cur) T(x);
    } else {
        // 当前块前面满了，需要分配新块
        push_front_aux(x);
    }
}
```

`push_front_aux` 同理：

- 如果 `start.node != map_begin`，说明 map 最前面还有槽位，直接分新块挂到 `*(start.node - 1)`；
    
- 否则需要扩容 `map`，并把原 start/finish 都整体向中间“搬”一下，给前端留空间。
    

**这里的一个关键点**：  
`deque` 的扩容，绝大多数时候只是：

- 分配更多的指针槽位（map 扩容）；
    
- 分配一小块新的 buffer。
    

而不是像 `vector` 一样把所有元素搬家，所以**引用/指针多数情况下不会失效**，这就是它的卖点之一。

---

## 4. 随机访问：`operator[]` 真正做了什么？

迭代器内部就是 **“当前位置 + 所在块边界 + map 的节点指针”**，所以 `operator[]` 可以这样实现（简化版）：

```C++
T& deque::operator[](size_t n) {
    iterator it = start;
    it += n;
    return *it;
}
```

而 `iterator::operator+=` 大概是：

```C++
iterator& operator+=(difference_type n) {
    // 整体偏移 = 当前块内偏移 + n
    difference_type offset = n + (cur - first);
    if (offset >= 0 && offset < difference_type(block_size)) {
        // 仍在当前块内
        cur += n;
    } else {
        // 要跨块
        difference_type node_offset;
        if (offset > 0) {
            node_offset = offset / block_size;
        } else {
            node_offset = -((-offset - 1) / block_size) - 1;
        }
        node += node_offset;          // 切换块
        first = *node;
        last  = first + block_size;
        cur   = first + (offset - node_offset * block_size);
    }
    return *this;
}
```

要点：

- 每次随机访问要做的工作：
    
    - 一次整数加法；
        
    - 一次除法 + 取模（或者一些算术运算）；
        
    - 更新 `node` 指针、`first/last`；
        
- 仍然是 **O(1)**，但**常数比 vector 大得多**（vector 是简单指针加法）。
    

所以在数值密集场景、大型算法里，**`deque` 的随机访问性能比不过 `vector` 是正常的**。

---

## 5. `insert` / `erase` 的中间操作：怎么决定往前挪还是往后挪？

`deque` 中间插入/删除的策略一般是：

> 找到“中点”，然后**移动成本较小的那一半**元素。

以 `insert(pos, x)` 为例：

1. 计算 `pos` 与 `start` 的距离 `dist_front`，以及与 `finish` 的距离 `dist_back`。
    
2. 如果 `dist_front < dist_back`：
    
    - 说明 `pos` 更靠前，那么就：
        
        - 在前端多开一个位置（`push_front(front())` 之类）；
            
        - 然后把 `[start+1, pos)` 这段向前搬一格，为新元素腾出位置。
            
3. 否则：
    
    - 在后端多开一个位置（`push_back(back())`）；
        
    - 把 `[pos, finish-1)` 向后搬一格。
        

复杂度依旧是 O(n)，但实际搬运次数 ≈ `min(dist_front, dist_back)`，比“总是搬右半边”更省。

`erase(pos)` 反过来：

- 优先让较短一边覆盖这一点。
    
- 例如 `dist_front < dist_back`：
    
    - 把 `[start, pos)` 向后搬一格覆盖 pos；
        
    - 然后弹掉 `pop_front`。
        

---

## 6. 迭代器失效 —— 精细解释

从实现出发，很容易理解“为什么迭代器这么脆弱”。

### 6.1 迭代器里到底存了什么？

我们上面说过：

```C++
struct iterator {
    T*   cur;    // 当前元素
    T*   first;  // 当前块头
    T*   last;   // 当前块尾后
    T**  node;   // 指向 map 中当前块指针的那个槽位
};
```

**关键字段是 `node`**：

- `node` 指向 `map` 里某个指针槽；
    
- 一旦 `map` 扩容、重排，这个 `T**` 位置就可能“全换了”，原来的 `node` 就指向垃圾。
    

所以：

- 只要触发 map 扩容（比如两端增长超过原来 map 容量）——**所有迭代器都必然失效**。
    
- 事实上，标准为了保险，直接说很多操作都让所有迭代器失效。
    

### 6.2 引用/指针为什么通常还有效？

注意：**数据块本身通常不会搬家**。

- 扩容 `map` 时，只是搬运“指向块的指针”；块自己还在原来的堆内存。
    
- 开新块时，新块分配新内存，旧块不动。
    

因此，只要你手里的是：

`T& ref = dq[i]; T* ptr = &dq[i];`

而你之后的操作只是：

- 双端 `push_front`/`push_back`；
    
- 不删除这一个元素；
    

那大多数实现中，`ref` / `ptr` 指向的对象地址并不会变。标准也明确：这些操作**不会使已有元素本身的地址改变**，只是迭代器抽象失效。

> 工程实践：
> 
> - **迭代器能不用就不用，一旦修改结构就重新获取**；
>     
> - 需要稳定对象地址时，`deque` 比 `vector` 安全得多。
>     

---

## 7. 内存与 cache 局部性：为什么有时比 `list` 好很多？

从 CPU 角度：

- `list`：每个节点一块小内存，到处散落，遍历时几乎每步一个 cache miss。
    
- `deque`：**块内是连续的**，一个块通常几十个元素：
    
    - 一次 cache 加载进来一整块后，连续迭代时 cache 命中率非常高；
        
    - 块之间虽然不连续，但比 `list` 那种每个节点一个小块还是好很多。
        

所以在很多场景里：

- 随机插删不多，仅仅需要头尾 O(1) 操作和随机访问 → `deque` 性能明显比 `list` 好。
    
> 在典型实现里，`std::deque` 在堆上会分配**很多块（buffer）**，  
> **每一块本身就是一段连续的 `T[]` 数组，能存“多个元素”**，不是只存一个。

---

## 8. 异常安全与强异常保证

以 `push_back` 为例：

- 如果在新元素构造时抛异常：
    
    - `deque` 必须保证：
        
        - 原容器状态不变；
            
        - 不泄露内存。
            
- 典型实现顺序：
    
    1. 先确保 map & 块空间都已经分配好；
        
    2. 在目标位置上用 placement new 构造 `T(x)`；
        
    3. 最后更新 `finish`。
        

如果在构造 `T` 时抛异常，因为 `finish` 尚未更新：

- 逻辑上，container 里仍然看不到这个未构造成功的“元素”；
    
- 实现会调用析构（如果已经部分构造），然后释放这次分配的块或回滚指针。
    

类似地，`insert` 可能要搬运一长串元素，很多库会尽量在**搬运时使用 `move`**，并考虑异常中止时的回滚。

对你来说，结论：

- **大部分修容操作保证强异常安全**：要么成功，要么容器状态回到操作前；
    
- 这也部分解释了为什么实现这么复杂：要既保证性能，又保证异常安全。
    

---

## 9. 实战层面的“不要用 deque 的场景”

从工程视角，我会明确跟学生说，有些场景 `deque` 是不合适甚至危险的：

1. **需要把整个序列当作 C 数组用**
    
    - 需要 `&v[0]` + `size` 传给 C 接口、系统调用（`read`/`write`/`send`） → 用 `vector`。
        
    - `deque` 的块不连续，这样用是 UB。
        
2. **大量数值运算、线性代数**
    
    - 需要大块连续内存做 SIMD / BLAS / FFT → 用 `vector` 或专门的矩阵库。
        
3. **中间位置频繁插删**
    
    - 逻辑上“链表”才是合适数据结构（甚至更进一步用 `std::list` / 自己的 intrusive list）；
        
    - `deque` 的中间插删仍然要搬很多元素，只是不搬整块而已。
        
4. **非常在意迭代器长期稳定性**
    
    - 例如把迭代器放进别的容器长期保存；
        
    - 对这类需求其实 `list` 更适合，因为它保证 iterator 的稳定性（除非删除对应元素）。
        

---

## 10. 小结 + 下一步可以聊什么

再把核心“教授版”总结一遍：

1. **结构**：`deque` = 指针数组 `map` + 多个固定大小块（segmented array），用 `start/finish` 迭代器描述逻辑区间。
    
2. **复杂度**：
    
    - 头尾 `push/pop` 摊还 O(1)；
        
    - 中间 `insert/erase` O(n)，但智能选择前/后侧移动较小的一半；
        
    - 随机访问 O(1)，但常数 > `vector`。
        
3. **内存特性**：块内连续、整体不连续：
    
    - 比 `list` 有更好局部性；
        
    - 不能当作单块 C 数组使用。
        
4. **迭代器 vs 引用**：
    
    - 结构修改 → 迭代器几乎都失效；
        
    - 元素地址一般稳定，引用/指针在很多情况下仍有效。
        
5. **适用场景**：双端队列 + 随机访问，且不需要整体连续内存。