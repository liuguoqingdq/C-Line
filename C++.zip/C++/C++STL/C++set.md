## 一、`std::set` 是什么？——概念 & 定位

头文件：`<set>`

标准定义（简化后）：

```C++
template<
    class Key,
    class Compare   = std::less<Key>,
    class Allocator = std::allocator<Key>
> class set;
```

官方一句话：

> `std::set` 是一个 **有序关联容器（ordered associative container）**，  
> 存储一组 **唯一的 Key**，内部 **始终按 Compare 定义的顺序排好**，  
> 查找、插入、删除都具有 **O(log n)** 复杂度，  
> 典型实现是 **红黑树（Red–Black Tree）**。

几个关键词你要牢牢记住：

1. **有序**：所有元素按 `Compare` 排序（默认是从小到大）。
    
2. **唯一**：不允许有“等价”的两个 key（关于“等价”后面细讲）。
    
3. **关联容器**：按“键值”访问，而不是按下标。
    
4. **底层一般是红黑树**：平衡二叉搜索树，保证 O(log n)。
    

---

## 二、基本性质 & 类型别名

### 2.1 Key == Value

`set` 里每个元素“既是值，又是键”：

```C++
using key_type    = Key;
using value_type  = Key;    // 注意：value_type 和 key_type 是同一个
using key_compare   = Compare;
using value_compare = Compare;  // 同一个比较器
```

和 `map<Key, T>` 不同，`set` 没有 “key → value” 映射，只有 “key 本身”。

### 2.2 元素是不可修改的（通过迭代器）

迭代器解引用类型是 `const value_type&`，也就是 `const Key&`：

```C++
std::set<int> s{1,2,3};
auto it = s.begin();
// *it = 10;   // ❌ 不允许，元素是 const 的
```

原因：一旦你修改了 key，会破坏树的有序性和查找逻辑，所以标准**强制元素只读**。  
想“修改”一个元素，正确方法是：**erase + insert**。

---

## 三、内部实现视角：平衡搜索树 + 顺序性

标准不规定必须是红黑树，但 cppreference 明说“通常实现为红黑树”。

典型节点结构（概念上）：

```C++
template<class Key>
struct node {
    Key  value;
    node *left;
    node *right;
    node *parent;
    Color color;   // 红/黑
};
```

树的两个关键不变量：

1. **BST 性质（按 Compare 排序）**  
    对任意节点 `x`：
    
    - 左子树所有 key 对 `x.value` 都是 `comp(key, x.value) == true`；
        
    - 右子树所有 key 对 `x.value` 都是 `comp(x.value, key) == true`。
        
2. **红黑树平衡不变量**（高度约为 O(log n)）  
    保证最坏情况下树高度仍是 O(log n)，所以
    
    - 查找：O(log n)
        
    - 插入：O(log n)（查找插入位置 + 旋转/染色）
        
    - 删除：O(log n)
        

从这一点可以理解：**`set` 是“按 key 排序的平衡树视图”**。

---

## 四、时间复杂度 & 迭代器特性（必须背）

### 4.1 时间复杂度（典型）

根据标准和 cppreference：

- 插入 `insert` / `emplace` / `erase(it)` / `find`：  
    **O(log n)**（基于树高度）
    
- 遍历：  
    从 `begin()` 到 `end()` 线性：O(n)
    
- `size()` / `empty()`：O(1)（容器需要维护元素计数）
    
- `clear()`：O(n)（析构所有节点）
    

### 4.2 迭代器种类 & 失效规则

- 迭代器类型：**双向迭代器（bidirectional iterator）**
    
    - 可以 `++it`、`--it`，但不能 `it + 5`，也没有下标。
        
- 插入：
    
    - **不会使已有迭代器失效**（node-based 容器的特点）。
        
- 删除：
    
    - `erase(it)`：只使指向被删元素的迭代器/引用失效；
        
    - 其他元素的迭代器仍然有效。
        
- `clear()`：
    
    - 删除所有元素 → 所有指向元素的迭代器和引用都失效，`end()` 仍有效。
        

对比一下 `vector`（一插就全灭），你就知道 `set` 的迭代器“很稳定”。

---

## 五、接口总览（按功能分类）

我不逐个背原型，重点讲“返回值 & 典型用法”。

### 5.1 构造 & 赋值

常见几种：

```C++
std::set<int> s1;                   // 空
std::set<int> s2 = {1,2,3,4};       // 初始化列表
std::set<int> s3(s2.begin(), s2.end()); // 区间构造
std::set<int> s4(s2);               // 拷贝
std::set<int> s5(std::move(s2));    // 移动
s1 = s4;                            // 拷贝赋值
s1 = std::move(s4);                 // 移动赋值
```

> 注意：构造/赋值时会自动去重 & 排序。

---

### 5.2 迭代器 & 遍历

```C++
for (auto it = s.begin(); it != s.end(); ++it) {
    std::cout << *it << "\n";       // 迭代顺序 = 排序顺序
}

for (auto x : s) {                  // range-for
    ...
}
```

反向遍历：

```C++
for (auto it = s.rbegin(); it != s.rend(); ++it) {
    ...
}
```

---

### 5.3 容量

```C++
s.empty();    // 是否空
s.size();     // 元素个数
s.max_size(); // 理论最大容量（一般用不到）
```

---

### 5.4 插入 / 构造元素：`insert` / `emplace`

**核心点**：`set` 中元素唯一，所以插入有“成功/失败”之分。

#### 5.4.1 单元素插入

```C++
std::set<int> s;

auto [it, inserted] = s.insert(10);
// inserted == true  表示插入成功
// it 指向元素 10

auto res = s.insert(10);
// res 是 std::pair<iterator,bool>
// 第二次插入 10：res.second == false，it 指向已存在的 10
```

**返回值是 `std::pair<iterator,bool>`**：

- `iterator`：指向最终集合中的那个 key（新插入或旧的）；
    
- `bool`：这次是否真的插入了新元素。
    

#### 5.4.2 带 hint 的插入：`insert(pos, value)`

`auto it = s.insert(s.end(), 42);    // 使用 hint，返回插入位置`

- 返回：`iterator` 指向最终元素；
    
- `pos` 是给平衡树插入的“参考位置”，如果 hint 合理，插入能更快；  
    如果 hint 瞎写，最坏情况仍是 O(log n)，不会出错，只是浪费。
    

#### 5.4.3 区间插入 & 初始化列表插入

```C++
s.insert(v.begin(), v.end());  // 插入区间
s.insert({1, 2, 3, 4});        // 插入列表
```

都没有返回值（`void`），会自动去重。

#### 5.4.4 `emplace` / `emplace_hint`

适用于元素类型比较复杂，需要原地构造：

```C++
std::set<std::string> ss;
auto [it, inserted] = ss.emplace(10, 'a'); // 构造 "aaaaaaaaaa"
auto it2 = ss.emplace_hint(ss.begin(), 5, 'b'); // 带 hint
```

返回值和 `insert` 类似：

- `emplace`：`pair<iterator,bool>`
    
- `emplace_hint`：`iterator`
    

---

### 5.5 删除：`erase` / `clear` / C++17 的 `extract`

#### 5.5.1 按迭代器删除

```C++
auto it = s.find(10);
if (it != s.end()) {
    s.erase(it);        // 返回：下一个元素迭代器（C++11 前是 void）
}
```

复杂度：O(log n)（先找位置 + 调整树）。

#### 5.5.2 按 key 删除

```C++
size_t n = s.erase(10);    // 返回删除了多少个元素：set 中要么 0，要么 1
```

#### 5.5.3 删除区间

`s.erase(s.begin(), s.find(10));     // 删除一段`

#### 5.5.4 清空

`s.clear();  // O(n)，删光所有元素，size=0`

如前所述，`clear` 会让所有元素迭代器失效。

#### 5.5.5 C++17：`extract` / `merge`（节点句柄）

这是 STL 进化比较有意思的一块。

```C++
auto nh = s.extract(10);   // nh 是 node handle
if (nh) {
    nh.value() = 20;       // 可以修改 key（在树结构之外）
    s.insert(std::move(nh));
}
```

- `extract(key)` / `extract(it)`：  
    从 set 里“摘下”一个节点，变成一个 `node_type`，  
    不销毁元素，只是容器不再拥有。
    
- `node_type::value()`：可以修改 key —— 因为这时它不在树里，不影响有序性。
    
- `insert(node_type&&)`：把节点插回 set（此时可能因为 key 冲突插不进去）。
    

`merge` 可以在两个 `set` 之间移动节点：

```C++
s1.merge(s2);  // 把 s2 中“不跟 s1 冲突”的节点移到 s1 中，s2 剩下冲突的
```

这些都是“**节点级**”操作，典型复杂度 O(n log n)，但不做元素拷贝/移动，只改指针。

---

### 5.6 查找 & 范围查询

这些都是 **O(log n)** 搜索操作。

#### 5.6.1 `find` / `count` / `contains`

```C++
auto it = s.find(10);         // 找到返回迭代器，否则 end()
size_t n = s.count(10);       // 只可能是 0 或 1
bool ok = s.contains(10);     // C++20，返回 bool
```

`contains` 实质上就是 `find(key) != end()` 的语法糖。

#### 5.6.2 `lower_bound` / `upper_bound` / `equal_range`

```C++
auto it1 = s.lower_bound(10);   // >= 10 的第一个元素
auto it2 = s.upper_bound(10);   // >  10 的第一个元素
auto [lb, ub] = s.equal_range(10);
// lb = lower_bound(10)
// ub = upper_bound(10)
```

典型用途：按照有序性取出某个区间，比如所有在 `[a, b)` 范围内的元素：

```C++
for (auto it = s.lower_bound(a); it != s.lower_bound(b); ++it) {
    ...
}
```

这是有序容器相对 `unordered_set` 的核心优势之一。

---

### 5.7 比较器 & 观察者：`key_comp` / `value_comp`

`Compare` 充当两件事：

1. 决定排序顺序；
    
2. 决定“等价”的定义：  
    `!comp(a,b) && !comp(b,a)` 时，认为 a 和 b 等价，不允许同时存在。
    

`key_comp()` / `value_comp()` 可以拿到比较器副本：

```C++
auto comp = s.key_comp();
bool b = comp(x, y);   // 相当于 Compare{}(x, y)
```

### 5.8 自定义比较器例子

#### 升序/降序

```C++
std::set<int, std::greater<int>> s;   // 降序存储
```

#### 按长度排序字符串，长度相同再按字典序

```C++
struct ByLenThenLex {
    bool operator()(const std::string& a,
                    const std::string& b) const {
        if (a.size() != b.size())
            return a.size() < b.size();
        return a < b;
    }
};
std::set<std::string, ByLenThenLex> s;
```

注意：比较器必须满足**严格弱序（strict weak ordering）**，否则会导致树结构混乱甚至 UB。

---

## 六、使用示例：基本集合操作

```C++
#include <set>
#include <iostream>

int main() {
    std::set<int> s{5, 1, 3, 3, 2};

    // 自动去重 + 排序：s = {1,2,3,5}
    for (int x : s) std::cout << x << ' ';
    std::cout << "\n";

    // 插入
    auto [it, ok] = s.insert(4);
    std::cout << "insert 4 ok = " << ok << "\n";  // true

    // 再插入 3：不会产生新元素
    auto r2 = s.insert(3);
    std::cout << "insert 3 ok = " << r2.second << "\n"; // false

    // 查找
    if (s.contains(2)) {
        std::cout << "has 2\n";
    }

    // 区间 [2, 5) 的元素
    auto it1 = s.lower_bound(2);
    auto it2 = s.lower_bound(5);
    std::cout << "[2,5): ";
    for (auto it = it1; it != it2; ++it) {
        std::cout << *it << ' ';
    }
    std::cout << "\n";
}
```

---

## 七、`set` vs `unordered_set` vs `vector+sort`：什么时候用谁？

简单对比一张表：

|场景 / 特性|`std::set`|`std::unordered_set`|`std::vector` + `sort`|
|---|---|---|---|
|元素是否有序|✅ 有序|❌ 无序|✅（排序后）|
|查找复杂度|O(log n)|平均 O(1)，最坏 O(n)|O(log n) + 要先排序|
|支持范围查询（区间遍历）|✅ lower_bound / upper_bound|❌ 不支持基于顺序的区间|✅（手动用算法）|
|迭代器稳定性|插入不失效，删除只失删的|rehash 时迭代器会全失效|扩容/插入可能全失效|
|空间利用|每元素一个节点，指针额外开销大|hash 桶 + 节点，空间更大|最紧凑|
|典型实现|红黑树|哈希表|连续数组|
|适合场景|有序集合、需要区间查询|高性能查找、不关心顺序|批量构建、一次排序多次用|

经验规则：

- **如果你需要“有序 + 去重 + 动态插删 + 范围查询” → 用 `set`。**
    
- 只需要“判重/查找 + 不在乎顺序 + 更追求性能” → 首选 `unordered_set`。
    
- 静态数据、构建一次、之后只查不改 → `vector + sort + binary_search` 往往最快。
    

---

## 八、小结：把 `std::set` 放在脑子里的正确“模型”

你可以这样记住它：

1. **抽象上**：
    
    - 一个“数学集合”，元素唯一；
        
    - 同时是一个“按 Compare 排序的序列”。
        
2. **实现上**：
    
    - 一个基于比较器 `Compare` 的有序平衡二叉树（通常红黑树）；
        
    - 每个节点存一个 `Key`，节点在堆上；
        
    - 插入/删除/查找都是在树上做 O(log n) 操作。
        
3. **接口上**：
    
    - 支持所有关联容器通用操作：`insert`/`erase`/`find`/`lower_bound` 等；
        
    - 迭代器按排序顺序遍历，且插入不失效、删除只失去被删元素；
        
    - 提供 `merge`/`extract` 之类高级“节点级”操作。
        
4. **使用上**：
    
    - 几乎所有关于“有序集合”的算法问题，都可以直接映射到 `std::set`；
        
    - 工程中要根据“是否有序”“是否频繁插删”“是否需要区间查询”去选择 `set` / `unordered_set` / `vector`。