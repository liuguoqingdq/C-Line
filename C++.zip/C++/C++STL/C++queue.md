## 1. `std::queue` 是什么？头文件 & 模板声明

头文件：

```C++
#include <queue>
```

标准声明（简化版）：

```C++
namespace std {
    template<
        class T,
        class Container = std::deque<T>
    >
    class queue;
}
```

含义：

- `T`：队列里存的元素类型；
    
- `Container`：底层真正存数据的顺序容器，默认是 `std::deque<T>`；
    
- `queue<T, Container>` 只暴露“队列接口”：**只能从队尾入，从队头出**。
    

**FIFO 特性：**

- `push()` —— 从队尾入队
    
- `front()` / `back()` —— 查看队头 / 队尾元素
    
- `pop()` —— 从队头出队
    
- **先来的先走**：First In, First Out。
    

---

## 2. 底层容器 `Container` 的要求 & 选什么比较合适

`std::queue` 要求 `Container` 至少支持这几个操作：

- `empty()`
    
- `size()`
    
- `front()` / `const front()`
    
- `back()` / `const back()`
    
- `push_back(const T&)` / `push_back(T&&)`
    
- `pop_front()`
    

所以可以用的典型容器有：

```C++
std::queue<int> q1;                        // 默认：deque<int>
std::queue<int, std::deque<int>> q2;       // 和默认一样
std::queue<int, std::list<int>> q3;        // list 做底层
```

**一般不推荐 `std::vector`**，因为它没有 `pop_front()`，不能 O(1) 从头弹出 —— 所以不能直接用作 `queue` 的底层容器。

常用选择对比：

|作为底层容器|是否常用|入队/出队复杂度|备注|
|---|---|---|---|
|`deque<T>`|✅ 默认|`push_back` / `pop_front` 均摊 O(1)|内部是分段连续空间。|
|`list<T>`|⚠️ 可以|`push_back` / `pop_front` O(1)|双向链表，指针多、空间利用差，一般没必要。|

多数情况下：

- 用默认 `std::queue<T>`（底层 `deque`）就够用了；
    
- 只有你真的需要 list 的某些特性（比如稳定的迭代器等）才会改用 `list`。
    

---

## 3. 成员函数：构造 / 访问 / 修改 / 复杂度

### 3.1 构造 / 赋值

常见构造方式：

```C++
std::queue<int> q1;            // 默认：内部一个空 deque<int>

std::deque<int> dq = {1, 2, 3};
std::queue<int> q2(dq);        // 用已有 deque 拷贝构造：front=1, back=3

std::queue<int> q3(q2);        // 拷贝构造
std::queue<int> q4(std::move(q2)); // 移动构造
```

赋值同理：

`q3 = q4;                // 拷贝赋值 q3 = std::move(q4);     // 移动赋值`

### 3.2 容量相关

`bool empty() const;     // 是否为空 size_type size() const; // 元素个数`

复杂度：均摊 O(1)。

---

### 3.3 元素访问

```C++
reference       front();       // 队头元素（最早进入的）
const_reference front() const;

reference       back();        // 队尾元素（最新进入的）
const_reference back() const;
```

示例：

```C++
std::queue<int> q;
q.push(10);
q.push(20);
q.push(30);

std::cout << q.front() << "\n"; // 10
std::cout << q.back()  << "\n"; // 30

q.front() = 100;                // 可以修改队头元素
q.back()  = 300;                // 可以修改队尾元素
```

⚠️ **对空队列调用 `front()` / `back()` 是未定义行为（UB）**，必须先判断 `empty()`。

---

### 3.4 修改操作

```C++
void push(const T& value);
void push(T&& value);           // C++11 起

template<class... Args>
void emplace(Args&&... args);   // C++11 起，原地构造

void pop();

void swap(queue& other) noexcept;
```
语义：

- `push`：在**队尾**插入元素（底层用 `push_back`）；
    
- `emplace`：在队尾原地构造一个元素，避免临时对象；
    
- `pop`：从**队头**删除元素（底层用 `pop_front`），不返回值；
    
- `swap`：与另一个同类型队列交换内部容器。
    

**复杂度（以 deque 为例）**：

- `push` / `emplace` / `pop`：均摊 O(1)；
    
- `swap`：O(1)。
    

**为什么 `pop()` 不返回值？**

同 `stack` 一样，标准的设计是：

- 分离“访问元素”和“删除元素”的操作；
    
- 避免“边返回边删”时的异常安全复杂度。
    

使用方式：

`auto x = q.front();  // 拿到值 q.pop();             // 再删除`

---

## 4. 一个“简化实现”：你可以把 `queue` 理解成这样

下面是一个简化版的 `std::queue` 实现，帮助你理解其本质：

```C++
template<class T, class Container = std::deque<T>>
class queue {
public:
    using value_type      = T;
    using container_type  = Container;
    using size_type       = typename Container::size_type;
    using reference       = value_type&;
    using const_reference = const value_type&;

protected:
    Container c;  // 真正存储元素的容器

public:
    queue() = default;
    explicit queue(const Container& cont) : c(cont) {}
    explicit queue(Container&& cont) : c(std::move(cont)) {}

    // 容量
    bool empty() const noexcept { return c.empty(); }
    size_type size() const noexcept { return c.size(); }

    // 访问
    reference       front()       { return c.front(); }
    const_reference front() const { return c.front(); }

    reference       back()        { return c.back(); }
    const_reference back()  const { return c.back(); }

    // 修改
    void push(const value_type& value) { c.push_back(value); }
    void push(value_type&& value)      { c.push_back(std::move(value)); }

    template<class... Args>
    void emplace(Args&&... args) {
        c.emplace_back(std::forward<Args>(args)...);
    }

    void pop() { c.pop_front(); }

    void swap(queue& other) noexcept(noexcept(std::swap(c, other.c))) {
        using std::swap;
        swap(c, other.c);
    }
};
```

你会发现所有操作都只是对 `c` 的包装：

- 队头：`c.front()`
    
- 队尾：`c.back()`
    
- 入队：`c.push_back()`
    
- 出队：`c.pop_front()`
    

`std::queue` 就是把一个“双端容器”收缩成一个单端队列接口。

---

## 5. 常见使用场景

### 5.1 图/树的 BFS（广度优先搜索）

最经典的例子就是 BFS：

```C++
#include <queue>
#include <vector>

void bfs(int start, const std::vector<std::vector<int>>& graph) {
    int n = graph.size();
    std::vector<bool> vis(n, false);
    std::queue<int> q;

    vis[start] = true;
    q.push(start);

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        // 访问 u
        // ...

        for (int v : graph[u]) {
            if (!vis[v]) {
                vis[v] = true;
                q.push(v);
            }
        }
    }
}
```

队列天然适合“按层访问”（先进先出）。

---

### 5.2 简单任务队列 / 生产者–消费者模型（单线程版本）

比如你想在主线程里处理异步任务（当然真正多线程要自己加锁 / 条件变量）：

```C++
#include <queue>
#include <functional>

std::queue<std::function<void()>> task_queue;

void post_task(std::function<void()> f) {
    task_queue.push(std::move(f));
}

void process_all_tasks() {
    while (!task_queue.empty()) {
        auto f = std::move(task_queue.front());
        task_queue.pop();
        f(); // 执行任务
    }
}
```

在多线程版本里，一般会搭配 `std::mutex` + `std::condition_variable` 做一个简易线程安全队列。

---

### 5.3 模拟排队系统 / 消息队列

比如模拟一个简单的“窗口排队系统”，每个顾客按顺序排队处理；  
或者做个简单的消息队列，把消息按到达顺序进队，消费者逐个取出处理。

---

## 6. 和其他 STL 容器/适配器的对比

### 6.1 queue vs deque

`std::deque` 是“真正的容器”，`queue` 是它的适配器之一：

- `deque`：
    
    - 支持 `push_back/push_front/pop_back/pop_front`；
        
    - 支持随机访问（`operator[]` / `at`）；
        
    - 有迭代器，可以遍历、排序等。
        
- `queue`：
    
    - 只暴露 `front/back/push/pop/size/empty`；
        
    - 不提供遍历/随机访问；
        
    - 更贴近“抽象数据结构队列”的语义。
        

**经验：**

- 只是需要 FIFO 队列语义，操作简单 → 用 `queue` 表意更清楚；
    
- 同时需要“队列 + 遍历/随机访问”等高级操作 → 直接用 `deque`。
    

---

### 6.2 queue vs stack

两者都是“容器适配器”，区别在于：

|特性|`stack`（栈）|`queue`（队列）|
|---|---|---|
|行为|LIFO（后进先出）|FIFO（先进先出）|
|入口|一端|一端（队尾）|
|出口|同一端|另一端（队头）|
|典型操作|`top/push/pop`|`front/back/push/pop`|

- DFS 常用 `stack`；
    
- BFS 常用 `queue`。
    

### 6.3 queue vs priority_queue

`priority_queue` 也是一个适配器，不过它是基于堆的 **优先队列**：

- `queue`：
    
    - `front()` 返回**最早入队**的元素；
        
    - 完全按时间顺序（FIFO）。
        
- `priority_queue`：
    
    - `top()` 返回**优先级最高**的元素（默认是最大值）；
        
    - 内部维护堆结构，复杂度 `push/pop` 为 O(log n)。
        

如果你需要“总是先处理优先级最高的任务”，那就是 `priority_queue`；  
只要简单排队，按顺序处理，就是 `queue`。

---

## 7. 易错点 & 细节提醒

### 7.1 `queue` 没有迭代器，也没有下标

下面写法都是错的：

```C++
std::queue<int> q;
q.push(1);
q.push(2);

// ❌ queue 没有 begin/end
// for (auto it = q.begin(); it != q.end(); ++it) {}

// ❌ queue 没有 operator[]
// int x = q[0];
```

想遍历所有元素的几种办法：

1. 不在乎破坏队列：一边 `front()` 一边 `pop()`；
    
2. 换用底层容器（`deque`）而不是 `queue`；
    
3. 自己写一个包装器，维护底层容器引用（通常不推荐，容易破坏封装）。
    

### 7.2 `front()` / `back()` / `pop()` 在空队列上是 UB

标准不会帮你检查是否为空：

```C++
std::queue<int> q;
q.pop();      // UB
q.front();    // UB
q.back();     // UB
```

正确写法：

```C++
if (!q.empty()) {
    auto x = q.front();
    q.pop();
}
```

在复杂逻辑中（特别是解析、调度等）一定要先 `empty()`。

### 7.3 线程安全

和其他 STL 容器一样，`queue` **本身不是线程安全的**：

- 多线程同时对同一个 `queue` 做 `push/pop`，没加锁 → UB。
    
- 要做生产者–消费者模型，通常做法是：
    
    - 用 `std::queue<...>` 作为内部队列；
        
    - 外面包一层 `std::mutex` + `std::condition_variable` 来做同步。
        

### 7.4 底层容器的行为依然会“透传”进来

比如你用 `std::list` 做底层：

`std::queue<int, std::list<int>> q;`

- `push` / `pop` 成本依旧是 O(1)；
    
- 但 list 每个节点都有指针开销，空间局部性差，总体性能可能不如 deque。
    

大多数时候保持默认（`deque`）就行了。

---

## 8. 小结

你可以把 `std::queue` 记成：

1. **定义**：`template<class T, class Container = std::deque<T>> class queue;` —— 容器适配器；
    
2. **本质**：基于 `Container`（通常是 `deque`），对外只暴露 FIFO 队列接口；
    
3. **接口**非常小：
    
    - 容量：`empty()`, `size()`
        
    - 访问：`front()`, `back()`
        
    - 修改：`push()`, `emplace()`, `pop()`, `swap()`
        
4. **没有迭代器、没有下标访问**，只允许从头取、从尾放；
    
5. **使用场景**：BFS、任务队列、排队系统、消息队列等任何“先进先出”的场景；
    
6. **注意**：空队上调用 `front/back/pop` 是 UB，多线程要自己加锁。