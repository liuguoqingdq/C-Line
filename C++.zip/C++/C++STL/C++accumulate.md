`std::accumulate` 就是 C++ 里最标准的“**从一段区间里把东西一项一项叠加起来**”的算法（左折叠 / fold left）。

你可以把它当成：

```C++
T result = init;
for (auto it = first; it != last; ++it) {
    result = result + *it;   // 或自定义的 op(result, *it)
}
return result;
```

下面系统讲一遍：签名 → 语义 → 典型用法 → 容易踩坑的点。

---

## 1. 函数签名在哪儿、长什么样？

头文件：`<numeric>`（不是 `<algorithm>`）

```C++
#include <numeric>

// 版本一：用 operator+
template<class InputIt, class T>
T accumulate(InputIt first, InputIt last, T init);
// 版本二：自定义二元操作
template<class InputIt, class T, class BinaryOp>
T accumulate(InputIt first, InputIt last, T init, BinaryOp op);
```

解释：

- `InputIt`：输入迭代器类型（可以是 vector/list/数组等的迭代器）
    
- `T`：**累加结果的类型**（非常关键）
    
- `BinaryOp`：形如 `T f(T acc, ValueType x)` 的二元函数（lambda / 函数对象 / 函数指针）
    

---

## 2. 精确语义：它到底干了什么？

假设区间元素是：`a1, a2, ..., aN`，初始值 `init`。

### 2.1 默认版本（用 `+`）

`auto sum = std::accumulate(first, last, init);`

语义等价于：

```C++
T result = init;
for (; first != last; ++first) {
    result = result + *first;
}
return result;
```

也就是：

> 返回 `init + a1 + a2 + ... + aN`（按顺序，从左往右）。

### 2.2 自定义 op 的版本

```C++
auto res = std::accumulate(first, last, init, op);
```

等价于：

```C++
T result = init;
for (; first != last; ++first) {
    result = op(result, *first);
}
return result;
```

也就是：

> 返回 `op(... op(op(init, a1), a2) ..., aN)` 的结果（典型左折叠）。

---

## 3. 一个关键点：**第三个参数 init 决定返回类型 T**

例子：

```C++
std::vector<int> v = {1, 2, 3, 4};
auto s1 = std::accumulate(v.begin(), v.end(), 0);    // T 是 int
auto s2 = std::accumulate(v.begin(), v.end(), 0LL);  // T 是 long long
```

如果你写 `0`，T 是 `int`；  
如果你写 `0.0`，T 是 `double`；  
如果你写 `std::string{}`, T 就是 `std::string`。

这点很重要：**想用更大精度/更大范围做累加，就要把 init 写成那个类型**。

例如避免溢出：

`long long sum = std::accumulate(v.begin(), v.end(), 0LL);  // 不容易溢出`

---

## 4. 基础用法：几个经典例子

### 4.1 求和（默认 `+`）

```C++
std::vector<int> v = {1, 2, 3, 4};
int sum = std::accumulate(v.begin(), v.end(), 0);  // 10
```

### 4.2 求乘积（用自定义 op）

```C++
#include <functional> // std::multiplies
std::vector<int> v = {1, 2, 3, 4};
int product = std::accumulate(v.begin(), v.end(), 1, std::multiplies<int>());
// product = 24
```

也可以 lambda：

```C++
int product = std::accumulate(v.begin(), v.end(), 1,
                              [](int acc, int x) { return acc * x; });
```

### 4.3 字符串拼接

```C++
std::vector<std::string> words = {"hello", " ", "world"};

std::string s = std::accumulate(words.begin(), words.end(), std::string{});
// s == "hello world"
```

带分隔符：

```C++
std::vector<std::string> words = {"a", "b", "c"};

std::string joined = std::accumulate(
    std::next(words.begin()), words.end(), words[0],
    [](std::string acc, const std::string& x) {
        return acc + "," + x;
    });
// joined == "a,b,c"
```

---

## 5. 复杂一点：累加到“结构体 / pair / 自定义状态”

### 5.1 一边遍历一边统计多个量

例如：同时算和、平方和、计数，用一个 struct：

```C++
struct Stats {
    long long sum = 0;
    long long sq_sum = 0;
    int count = 0;
};

std::vector<int> v = {1,2,3,4};

Stats st = std::accumulate(
    v.begin(), v.end(), Stats{},
    [](Stats acc, int x) {
        acc.sum    += x;
        acc.sq_sum += 1LL * x * x;
        acc.count  += 1;
        return acc;
    });
```

然后可以算均值、方差等。

### 5.2 用 pair 做“加权平均数”

```C++
std::vector<std::pair<double,double>> data = {
    {2.0, 1.0},  // value, weight
    {4.0, 2.0},
    {5.0, 3.0}
};

auto [sum_wx, sum_w] = std::accumulate(
    data.begin(), data.end(), std::pair<double,double>{0.0, 0.0},
    [](auto acc, auto vw) {
        acc.first  += vw.first * vw.second; // Σ (x*w)
        acc.second += vw.second;            // Σ w
        return acc;
    });

double weighted_mean = sum_wx / sum_w;
```

---

## 6. 和 `for_each` / `transform` 的区别

- `for_each`：对每个元素执行操作（多是副作用），**不返回聚合结果**。
    
- `transform`：对每个元素做映射，**返回写到输出区间的“批量结果”**。
    
- `accumulate`：对每个元素做组合，**只返回一个聚合值**。
    

同一个需求的两种写法对比：

```C++
// for_each + 外部变量
int sum = 0;
std::for_each(v.begin(), v.end(),
              [&sum](int x){ sum += x; });

// accumulate
int sum2 = std::accumulate(v.begin(), v.end(), 0);
```

`accumulate` 版本语义更清晰：一眼就看出“这是求和”。

---

## 7. 容易踩坑的几个点

### 7.1 init 类型不对导致溢出 / 精度损失

```C++
std::vector<int> v = {1000000, 1000000, 1000000};

long long sum1 = std::accumulate(v.begin(), v.end(), 0);   // ❌ 先算成 int，再赋给 long long，可能溢出
long long sum2 = std::accumulate(v.begin(), v.end(), 0LL); // ✔ 全程 long long
```

**结论：**想用大类型，就把 init 写成大类型字面量。

### 7.2 浮点数：顺序敏感 & 精度问题

浮点数加法不满足严格的结合律：

```C++
double sum = std::accumulate(v.begin(), v.end(), 0.0);
// 和 手写不同顺序的加法结果可能略有差别（舍入误差）
```

`accumulate` 是固定从左到右，相对可控；  
并行 `std::reduce` 会改变结合顺序，误差可能更大。

如果需要数值稳定性，可以考虑：

- 把小值先加，大值后加；
    
- 使用补偿算法（Kahan sum），包在 BinaryOp 里。
    

### 7.3 在 BinaryOp 里做“奇怪的副作用”

`accumulate` 是**保证顺序执行的**（与 `transform` 不同），所以你可以在 BinaryOp 里做有顺序语义的事（计数、打印等）。但逻辑上最好仍然把它当“纯函数”，否则代码不易读。

如果你发现 BinaryOp 里做了很多复杂逻辑 / IO，其实应该换成显式的 for 循环更清晰。

---

## 8. 和 `std::reduce` / `inner_product` 等的关系

### 8.1 `std::accumulate` vs `std::reduce`（C++17）

- **accumulate**：
    
    - 顺序固定，从左到右；
        
    - 迭代器只要求 InputIterator；
        
    - 适合有顺序依赖的 BinaryOp；
        
- **reduce**：
    
    - 为并行设计，可以打乱结合顺序；
        
    - 迭代器要求至少 ForwardIterator；
        
    - BinaryOp 必须满足“结合律”、最好还能交换（加法/乘法这种）。
        

所以对你来说：

- 想要确定的顺序和行为 → `accumulate`
    
- 想并行 + BinaryOp 很规整（如加法）→ 可以考虑 `reduce`
    

### 8.2 `std::inner_product`

`inner_product` 相当于一个比 `accumulate` 更专业的“点积算法”：

```C++
template<class InputIt1, class InputIt2, class T>
T inner_product(InputIt1 first1, InputIt1 last1, InputIt2 first2, T init);
```

语义：

`init + a1*b1 + a2*b2 + ... + aN*bN`

它内部本质也是一个特殊形式的 accumulate，但提供了专门接口。

---

## 9. 一点“泛用套路”：accumulate 做计数 / 拼 map / 归约结构

你可以把 `accumulate` 当一个通用“归约工具”：

### 9.1 计数（虽然有现成的 `count_if`）

```C++
int cnt = std::accumulate(v.begin(), v.end(), 0,
                          [](int acc, int x) {
                              return acc + (x % 2 == 0);
                          });
// cnt = 偶数个数
```

### 9.2 把 vector 变成 map

```C++
struct Item { int id; int value; };
std::vector<Item> items = {/* ... */};

std::map<int,int> mp = std::accumulate(
    items.begin(), items.end(), std::map<int,int>{},
    [](auto acc, const Item& it) {
        acc[it.id] += it.value;
        return acc;
    });
```

当然从效率角度，连续插入 map 这样“值不断搬来搬去”不一定是最佳（可以传引用、或先 reserve 等），但语义上很干净。

---

## 10. 小结：你需要记住的关键点

1. **定义**：`accumulate(first, last, init [, op])` = 左折叠：从 init 开始，把区间里的每个元素按 `+` 或自定义 op 叠加起来。
    
2. **类型**：第三个参数 init 决定返回类型 T；想避免溢出 / 提高精度，就把 init 写成更大/更精的类型。
    
3. **默认行为**：不传 op 时用 `operator+`，本质是求“和”；其实也可以拼 string 等。
    
4. **自定义 BinaryOp**：可以用来做乘积、拼接、统计、多字段 struct 归约等。
    
5. **顺序**：是顺序执行的（不像 `reduce` 那样可重排），你可以依赖这个顺序。
    
6. **和其他算法**：`for_each` 做副作用、`transform` 做映射写出序列，而 `accumulate` 把整个区间归约成一个值。