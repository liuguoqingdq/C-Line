# 优先级队列（Priority Queue）详解

## 一、什么是优先级队列

**优先级队列（Priority Queue）** 是一种特殊的队列数据结构：

- 每个元素都有一个“优先级”
- 出队时，总是 **优先级最高（或最低）** 的元素先出
- 不强调“先进先出（FIFO）”，而强调“优先级顺序”

> 可以理解为：一个“自动帮你排序的队列（只保证队头是最优的）”。

---

## 二、优先级队列的常见应用

- 任务调度系统（操作系统、线程池）
- 图算法：
  - Dijkstra 最短路
  - Prim 最小生成树
- Top-K 问题
- 中位数维护
- 事件模拟系统

---

## 三、优先级队列的底层实现原理

### 1️⃣ 常见实现方式

| 实现方式 | 插入 | 删除最优 | 说明 |
|--------|------|---------|------|
| 有序数组 | O(n) | O(1) | 插入慢 |
| 有序链表 | O(n) | O(1) | 不常用 |
| 二叉堆（Heap） | O(log n) | O(log n) | ⭐ 主流 |
| 平衡树 | O(log n) | O(log n) | STL 中较少用 |

👉 **C++ STL 的 `priority_queue` 基于二叉堆（Heap）实现**。

---

## 四、二叉堆（Heap）简介（理解 priority_queue 的关键）

### 1️⃣ 堆的性质

以 **大顶堆（Max Heap）** 为例：

- 完全二叉树
- 任意结点 ≥ 其左右孩子
- 堆顶是最大值

> 小顶堆（Min Heap）则相反。

### 2️⃣ 时间复杂度

- 插入：`O(log n)`
- 删除堆顶：`O(log n)`
- 访问堆顶：`O(1)`

---

## 五、C++ STL 中的 priority_queue

### 1️⃣ 基本定义

```cpp
#include <queue>

priority_queue<int> pq;  // 默认：大顶堆
```

等价完整形式：

```cpp
priority_queue<int, vector<int>, less<int>> pq;
```

模板定义：

```cpp
template<
    class T,
    class Container = vector<T>,
    class Compare = less<T>
> class priority_queue;
```

---

### 2️⃣ 常用成员函数

| 函数 | 作用 |
|----|----|
| `push(x)` | 插入元素 |
| `pop()` | 删除堆顶 |
| `top()` | 访问堆顶 |
| `empty()` | 是否为空 |
| `size()` | 元素个数 |

⚠️ 注意：
- `pop()` 不返回值
- `top()` 只是访问

---

## 六、priority_queue 的三种常见用法

### 1️⃣ 默认：大顶堆（Max Heap）

```cpp
priority_queue<int> pq;
pq.push(3);
pq.push(10);
pq.push(5);

cout << pq.top(); // 10
```

---

### 2️⃣ 小顶堆（Min Heap）

```cpp
priority_queue<int, vector<int>, greater<int>> pq;
```

```cpp
pq.push(3);
pq.push(10);
pq.push(5);

cout << pq.top(); // 3
```

---

### 3️⃣ 自定义比较规则（结构体 / pair）

#### 方式一：重载 `operator<`

```cpp
struct Node {
    int x, y;
    bool operator<(const Node& other) const {
        return x > other.x; // x 小的优先
    }
};

priority_queue<Node> pq;
```

> ⚠️ 注意：这里写的是“反逻辑”，因为 priority_queue 默认是 **大顶堆**。

---

#### 方式二：自定义比较器（推荐）

```cpp
struct cmp {
    bool operator()(const Node& a, const Node& b) {
        return a.x > b.x; // 小顶堆
    }
};

priority_queue<Node, vector<Node>, cmp> pq;
```

---

### 4️⃣ priority_queue + pair（非常常用）

```cpp
priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;

pq.push({dist, node});
```

👉 常用于 **Dijkstra**。

---

## 七、priority_queue 的注意事项

### 1️⃣ 不能随机访问

- 只能访问堆顶
- 不能像 vector 一样遍历

### 2️⃣ 不能删除指定元素

- 只能 `pop()` 堆顶
- 常用 **延迟删除（lazy deletion）** 解决

### 3️⃣ 堆不保证完全有序

```cpp
priority_queue<int> pq;
// 内部不是排序数组，只保证 top 是最大
```

---

## 八、典型算法示例

### 示例：Top-K 最大元素
思路：堆里只保留 K 个元素，且堆顶是这 K 个里最小的；来了新数更大就替换它。

- 复杂度：`O(n log k)`，空间 `O(k)`
    
- 适合：n 很大、k 相对小（典型 Top-K 场景）

```cpp
priority_queue<int, vector<int>, greater<int>> pq;

for (int x : nums) {
    pq.push(x);
    if (pq.size() > k) pq.pop();
}

// pq 中就是最大的 k 个数
```
对于保留最大的k个数，小根堆，每次对于数据量大的数进来，堆顶是最小的那个数，弹出，最好剩下的就是最大的k个数。
**上面的方式无用操作带来的开销高**
```C++
class Solution {

public:

vector<int> smallestK(vector<int>& arr, int k) {

vector<int> heap;

if (k == 0) return heap;

  

for (int x : arr) {

if (heap.size() < k) {

heap.push_back(x);

siftUp(heap, heap.size() - 1); // 插入时上滤

} else if (x < heap[0]) {

heap[0] = x;

siftDown(heap, 0, heap.size()); // 替换堆顶，下滤

}

}

return heap;

}

  

private:

void siftUp(vector<int>& v, int i) {

while (i > 0) {

int p = (i - 1) / 2;

if (v[p] >= v[i]) break;

swap(v[p], v[i]);

i = p;

}

}

  

void siftDown(vector<int>& v, int i, int n) {

while (true) {

int largest = i;

int l = 2 * i + 1;

int r = 2 * i + 2;

  

if (l < n && v[l] > v[largest]) largest = l;

if (r < n && v[r] > v[largest]) largest = r;

  

if (largest == i) break;

swap(v[i], v[largest]);

i = largest;

}

}

};
```
## 2）关键差异：前者少了很多“无意义”的操作

你的前者是典型 Top-K 最小值写法（大顶堆维护 k 个最小）：

`else if (x < heap[0]) { ... }`

这句非常关键：

> 当 `x >= heap[0]` 时，**直接跳过**，不做任何堆操作。

也就是说，**很多元素不会触发 log k 的调整**。

而后者是：

`pq.push(c); if (pq.size()>k) pq.pop();`

这意味着：

- 每个元素 **必做一次 push（log k）**
    
- 且从第 k+1 个开始 **还必做一次 pop（log k）**
    
- 所以几乎每个元素都要进行 **2 次堆调整**
    

✅ 这才是最主要的差距：  
**前者是“有条件的堆操作”，后者是“强制每次都堆操作”。**

> 结论：即使两者都是 O(n log k)，后者的常数基本接近前者的 2 倍（甚至更高）。

---

## 3）比较次数也不一样（隐藏但重要）

- 前者每个新元素先做一次比较：`x < heap[0]`
    
    - 若不满足，直接 O(1) 跳过
        
- 后者每个新元素都会参与堆结构的比较/交换过程
    

堆调整里会发生多次比较（一路上滤/下滤），这就是常数差距来源。
---

### 示例：Dijkstra（核心部分）
[[dijkstra（迪杰斯特拉）算法详解]]
```cpp
priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;
pq.push({0, start});

while (!pq.empty()) {
    auto [dist, u] = pq.top(); pq.pop();
    if (dist > d[u]) continue;
    for (auto [v, w] : g[u]) {
        if (d[v] > dist + w) {
            d[v] = dist + w;
            pq.push({d[v], v});
        }
    }
}
```

---

## 九、priority_queue vs 其他容器

| 容器 | 是否有序 | 最值访问 | 随机访问 |
|----|----|----|----|
| `priority_queue` | ❌ | O(1) | ❌ |
| `set / multiset` | ✅ | O(1) | ❌ |
| `vector + sort` | ✅ | O(1) | ✅ |

---

## 十、总结

- `priority_queue` 是 **基于堆的优先级队列**
- 默认是 **大顶堆**
- 插入 / 删除复杂度 `O(log n)`
- 非常适合：
  - 动态维护最值
  - 贪心算法
  - 图算法

---

如果你愿意，我可以进一步：
- 用 **图解堆的调整过程**
- 对比 `set` / `multiset`
- 结合某一道 **经典算法题** 逐行讲 priority_queue 的使用

