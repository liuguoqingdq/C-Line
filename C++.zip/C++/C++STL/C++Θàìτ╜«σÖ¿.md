## 1. 空间配置器（allocator）到底是干什么的？

一句话：

> **容器管“放什么、怎么组织”，allocator 管“内存从哪儿要、怎么还”。**

如果没有 allocator，所有容器内部都只能写死用 `::operator new/delete`，你就没法：

- 换成内存池（避免频繁系统调用）
    
- 做对齐分配（SIMD / 特殊硬件）
    
- 做调试统计（记录谁在哪儿分了多少）
    
- 把多个容器的内存集中到同一个资源上（比如 arena）
    

所以标准容器基本长这样：

```C++
template<
    class T,
    class Allocator = std::allocator<T>
>
class vector;
```

`Allocator` 就是空间配置器类型，默认是 `std::allocator<T>`，你可以替换成自己的。

可以理解为：

> `vector<T, Alloc>` = “一个说话用 `Alloc` 这套内存管理规则的 vector”。

---

## 2. 一个最小的 allocator 长什么样？

现代 C++ 下，**最重要的是这三个成员**（简化版）：

```C++
template<class T>
struct MyAlloc {
    using value_type = T;

    MyAlloc() noexcept { /* 可以记录一下，这个 allocator 出现了 */ }

    // 分配 n 个 T（只分配原始内存，不构造对象）
    T* allocate(std::size_t n) {
        if (n > std::size_t(-1) / sizeof(T)) throw std::bad_alloc{};
        if (auto p = static_cast<T*>(::operator new(n * sizeof(T))))
            return p;
        throw std::bad_alloc{};
    }

    // 释放内存（不调用析构）
    void deallocate(T* p, std::size_t n) noexcept {
        ::operator delete(p);
    }
};
```

然后你就可以：

```C++
std::vector<int, MyAlloc<int>> v;
v.push_back(1);
v.push_back(2);
```

容器内部所有“分配/释放”都通过 `MyAlloc<int>::allocate/deallocate` 来完成。

> 注意：构造/析构对象的工作（调用构造函数/析构函数）一般不再由 allocator 负责，  
> C++11 之后标准推荐由 `std::allocator_traits` 来统一封装这一层。

---

## 3. 容器是怎么用 allocator 的？

以 `vector<T, Alloc>` 为例（简化）：

```C++
template<class T, class Alloc = std::allocator<T>>
class vector {
    using traits    = std::allocator_traits<Alloc>;
    using pointer   = typename traits::pointer;

    pointer begin_;  // 指向已构造元素区域的开始
    pointer end_;    // 指向已构造元素区域的下一位置
    pointer cap_;    // 指向已分配但尚未构造的末尾
    Alloc   alloc_;  // 一个 allocator 对象

public:
    void push_back(const T& x) {
        if (end_ == cap_) {
            // 不够了，需要扩容：先用 traits::allocate 分配更大空间
            // 再用 traits::construct 移动/拷贝旧元素
            // 再 destroy + deallocate 旧空间
        }
        traits::construct(alloc_, end_, x); // 在 end_ 位置“构造一个 T(x)”
        ++end_;
    }

    ~vector() {
        // 用 traits::destroy 把 [begin_, end_) 中的对象析构
        // 用 traits::deallocate 归还 [begin_, cap_) 内存
    }
};
```

**关键点：**

- 容器不直接写 `::operator new/delete`，而是调用 `traits::allocate/deallocate`；
    
- 容器不直接写 `new(p) T(args...)`，而是调用 `traits::construct/destroy`；
    
- 这样一来，只要你换一个 allocator 类型，整个容器的内存管理策略就跟着变了。
    

---

## 4. `std::allocator_traits`：真正的“allocator 适配器”

C++11 之后，标准引入了 `std::allocator_traits`，它本质就是一个**对 allocator 的适配器**：

- 老 allocator 写法五花八门（有的有 `rebind`，有的有自定义 pointer 类型……）；
    
- `allocator_traits` 把各种写法统一成一套接口，容器只和 traits 打交道。
    

典型用法：

```C++
template<class Alloc>
using traits = std::allocator_traits<Alloc>;

template<class T, class Alloc>
void foo(Alloc& a) {
    using U = SomeOtherType;

    // 通过 traits 重新绑定成 U 的 allocator 类型
    using AllocU = typename traits<Alloc>::template rebind_alloc<U>;

    AllocU au(a); // 从 a 派生一个给 U 用的 allocator

    U* p = traits<AllocU>::allocate(au, 10);             // 分配空间
    traits<AllocU>::construct(au, p, /* 构造参数... */); // 定位构造
    traits<AllocU>::destroy(au, p);                      // 析构
    traits<AllocU>::deallocate(au, p, 10);               // 释放空间
}
```

你可以把 `allocator_traits` 理解为：

> **把“各种各样 allocator 写法”适配成容器统一使用的一个“traits 接口”**。

---

## 5. 写一个简单“统计用 allocator”感受一下

这个例子不做复杂内存池，只做“统计总共分配了多少字节”。

```C++
template<class T>
struct CountingAlloc {
    using value_type = T;

    static inline std::size_t allocated_bytes = 0;

    CountingAlloc() noexcept = default;

    template<class U>
    CountingAlloc(const CountingAlloc<U>&) noexcept {} // 允许从别的 T rebinding

    T* allocate(std::size_t n) {
        std::size_t bytes = n * sizeof(T);
        allocated_bytes += bytes;
        std::cout << "[Alloc] " << bytes << " bytes, total = "
                  << allocated_bytes << "\n";
        return static_cast<T*>(::operator new(bytes));
    }

    void deallocate(T* p, std::size_t n) noexcept {
        std::size_t bytes = n * sizeof(T);
        allocated_bytes -= bytes;
        std::cout << "[Dealloc] " << bytes << " bytes, total = "
                  << allocated_bytes << "\n";
        ::operator delete(p);
    }
};

template<class T, class U>
bool operator==(const CountingAlloc<T>&, const CountingAlloc<U>&) { return true; }
template<class T, class U>
bool operator!=(const CountingAlloc<T>&, const CountingAlloc<U>&) { return false; }
```

使用：

```C++
std::vector<int, CountingAlloc<int>> v;
v.reserve(100);
v.push_back(1);
v.push_back(2);
v.resize(200); // 看看输出多少次分配/释放
```

你会看到 allocator 在整个容器生命周期中的行为轨迹。

---

## 6. 状态ful allocator & 传播属性（高级一点）

allocator 本身可以是有“状态”的，例如：

```C++
struct Arena {
    void* buffer;
    std::size_t size;
    // ...
};

template<class T>
struct ArenaAlloc {
    using value_type = T;
    Arena* arena_;  // 指向某个共享内存池

    ArenaAlloc(Arena& a) noexcept : arena_(&a) {}

    T* allocate(std::size_t n) {
        // 从 arena_->buffer 中分配空间
    }

    void deallocate(T* p, std::size_t n) noexcept {
        // 把空间还回 arena_
    }
};

```

这时会有几个问题：

- 当容器拷贝/移动时，**allocator 的状态要不要一起拷/移**？
    
- 不同容器实例如果 allocator 状态不同（指向不同 arena），容器之间赋值/交换时该怎么处理？
    

为此 C++11 引入了三个 trait，用在 `allocator_traits` 里：

```C++
struct MyAlloc {
    using propagate_on_container_copy_assignment = std::true_type;
    using propagate_on_container_move_assignment = std::true_type;
    using propagate_on_container_swap           = std::true_type;
    using is_always_equal                       = std::true_type;
};
```

简单理解：

- `propagate_on_container_xxx` = 在对应操作时，是否要**传播 allocator 的状态**；
    
- `is_always_equal = true` = “不同 allocator 对象可以认为是等价的”，容器不需要因为 allocator 不同而拒绝 copy/swap。
    

这块属于 **写高级自定义 allocator / 大型项目的内存池时才会碰到** 的内容，先知道有这么个机制就行。

---

## 7. C++17/20：`std::pmr` 多态 allocator（polymorphic_allocator）

传统 allocator 是模板参数：

```C++
std::vector<int, MyAlloc<int>> v;
```

一旦容器类型定下来了，allocator 类型就固定了，不容易在运行时切换“这批容器用 A 内存池，那批用 B 内存池”。

C++17 引入 `<memory_resource>` 和 `std::pmr` 命名空间，搞了一套“**运行时多态的内存资源**”机制：

核心几个类型：

```C++
namespace std::pmr {
    struct memory_resource;           // 抽象基类：do_allocate / do_deallocate
    class polymorphic_allocator<T>;   // allocator 的适配器，内部持有 memory_resource*
}
```

我们可以：

1. 定义/使用一个具体 `memory_resource`（比如 `monotonic_buffer_resource` 单调线性分配器）；
    
2. 用 `pmr::polymorphic_allocator<T>` 去适配；
    
3. 最后用 `std::pmr::vector<T>`（它其实是 `vector<T, polymorphic_allocator<T>>`）。
    

示意：

```C++
#include <memory_resource>
#include <vector>

int main() {
    char buffer[1024];
    std::pmr::monotonic_buffer_resource pool(buffer, sizeof(buffer));

    std::pmr::vector<int> v{ &pool };  // 使用这个 pool 作为内存资源
    v.reserve(100);
    v.push_back(1);
}
```

好处：

- 容器类型固定为 `std::pmr::vector<T>`；
    
- **但底下的内存资源可以在运行时决定**（不同 pool、不同线程的 arena 等）；
    
- `memory_resource` 把各种内存策略（系统堆、内存池、共享内存……）统一适配成一个抽象接口。
    

这算是 C++ 标准库在 allocator 上的“第二层适配器”：  
`memory_resource` 抽象 → `polymorphic_allocator` 适配 → pmr 容器使用。

---

## 8. 小总结：你现在应该对“空间配置器”有个整体轮廓了

1. **角色**：allocator 负责“分配/释放原始内存”，容器负责“在这些内存上构造/析构对象 + 布局逻辑”。
    
2. **基本接口**：
    
    - `using value_type = T;`
        
    - `T* allocate(std::size_t n);`
        
    - `void deallocate(T* p, std::size_t n) noexcept;`
        
3. **容器如何用它**：
    
    - 通过 `std::allocator_traits<Alloc>` 来统一调用 `allocate/deallocate/construct/destroy/rebind`；
        
    - 容器类型 `X<T, Alloc>` 的内存行为完全由 `Alloc` 决定。
        
4. **可以做什么事**：
    
    - 替换成内存池、对齐分配、内存调试/统计；
        
    - 做有状态 allocator（arena）、不同容器共享同一个池。
        
5. **更现代的扩展**：
    
    - `std::allocator_traits`：真正的 allocator 适配器；
        
    - C++17 `std::pmr::memory_resource + polymorphic_allocator`：运行时可切换的多态 allocator。

用配置器包装内存池：[[C++内存池]]