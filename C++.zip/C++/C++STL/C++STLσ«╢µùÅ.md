在经典的 STL 架构（以 SGI STL 源码分析为代表）中，STL 家族被划分为 **“六大组件”**。以下是这六大组件的详细家谱和底层逻辑：

---

### 1. 容器 (Containers) —— 数据的存放者

这是 STL 最显眼的部分，负责管理内存和存储数据。根据**数据结构和内存布局**，分为三类：

#### A. 序列式容器 (Sequence Containers)

特点：元素在内存中的物理/逻辑顺序由插入顺序决定。

- **`std::vector`** (数组)：
    [[C++vector]]
    - **底层**：单向开口的连续线性空间。
        
    - **特点**：尾插极快，随机访问 $O(1)$，中间插入/删除慢（涉及内存搬移）。支持 SSO（部分实现）。
        
- **`std::deque`** (通用序列)：[[C++ deque]]
    
    - **底层**：分段连续空间（由中控器 map 管理多个 buffer）。
        
    - **特点**：头尾插入都快，支持随机访问（比 vector 慢一点）。
        
- **`std::list`** (双向链表) / **`std::forward_list`** (单向链表，C++11)：[[C++forward_list]]、[[C++list]]
    
    - **底层**：非连续内存，通过指针链接。
        
    - **特点**：任意位置插入/删除 $O(1)$，不支持随机访问。
        
- **`std::array`** (C++11)：[[C++array]]
    
    - **底层**：栈上固定大小数组（是对原生数组的封装）。
        
    - **特点**：零开销，比 vector 更轻量，但不可扩容。
        

#### B. 关联式容器 (Associative Containers)

特点：元素自动排序，查找速度快。

- **`std::set` / `std::map`** (以及 `multi` 版本)：[[C++set]]、[[C++multiset]]
    
    - **底层**：通常是 **红黑树 (Red-Black Tree)**。
        
    - **特点**：高度平衡的二叉搜索树。查找、插入、删除均为 $O(\log n)$。Key 必须支持 `<` 比较。
        

#### C. 无序关联容器 (Unordered Containers, C++11)

特点：不排序，基于哈希。

- **`std::unordered_set` / `std::unordered_map`**：[[C++map]]
    
    - **底层**：**哈希表 (Hash Table)**，通常使用“开链法”解决冲突。
        
    - **特点**：理论上查找/插入是 $O(1)$。Key 必须支持 `hash` 函数和 `==`。
        

---

### 2. 迭代器 (Iterators) —— 泛型的“胶水”[[C++迭代器]]

算法不直接操作容器，而是通过迭代器来访问数据。迭代器是一种**泛化的指针**。

- **设计模式**：Iterator Pattern。
    
- **分类**（根据能力强弱）：
    
    1. **Input / Output**：只能读/写一次（如输入流）。
        
    2. **Forward**：只能向前（如 `forward_list`）。
        
    3. **Bidirectional**：可双向移动（如 `list`, `map`, `set`）。
        
    4. **Random Access**：可像指针一样跳跃访问 `it + 5`（如 `vector`, `deque`, `array`）。
        

---

### 3. 算法 (Algorithms) —— 数据的操作者

STL 提供了 100 多个算法，全部定义在 `<algorithm>` 和 `<numeric>` 中。

- **特点**：它们是全局函数模板，**不知道**容器的存在，只知道迭代器范围 `[begin, end)`。
    
- **常见成员**：
    
    - `std::sort` (通常是 IntroSort：快排+堆排+插排的混合)。
        
    - `std::find`, `std::binary_search`。
        
    - `std::transform`, `std::for_each`。[[C++for_each]]、[[C++transform]]
        
    - `std::accumulate` (累加)。[[C++accumulate]]
        

---

### 4. 仿函数 (Functors / Function Objects) —— 策略的制定者

算法通常需要用户指定“策略”（比如：降序排序、只查找大于 10 的数）。

- **本质**：重载了 `operator()` 的类对象。
    
- **现代演变**：在 C++11 之后，大部分传统仿函数（如 `std::less`, `std::bind1st`）的使用场景都被 **Lambda 表达式** 取代了。
    
- **例子**：
    
    C++
    
    ```
    // 旧式仿函数
    struct Greater { bool operator()(int a, int b) { return a > b; } };
    std::sort(v.begin(), v.end(), Greater());
    
    // 现代 Lambda
    std::sort(v.begin(), v.end(), [](int a, int b) { return a > b; });
    ```
    

---

### 5. 配接器 (Adapters) —— 接口的转换器

将一种组件的接口转换为另一种接口，起修饰作用。

- **容器配接器**：
    
    - `std::stack`：默认封装着 `deque`，只开放栈顶接口。[[C++stack]]
        
    - `std::queue`：默认封装着 `deque`，只开放头尾接口。[[C++queue]]
        
    - `std::priority_queue`：**非常重要**，内部封装着 `vector`，并在插入/删除时执行**堆算法 (Heap Algorithm)**。
        
- **迭代器配接器**：
    
    - `std::back_inserter`：将“赋值”操作转换为“push_back”操作。
        
    - `std::reverse_iterator`：让 `++` 变成向后移动。
        

---

### 6. 配置器 (Allocators) —— 幕后的内存管家[[C++配置器]]

这是 STL 中最神秘、普通用户最少接触的组件。

- **作用**：将内存的**分配 (allocate)** 和对象的**构造 (construct)** 分离开。
    
- **默认实现**：`std::allocator`。
    
- **SGI STL 特色**：早期 GCC 使用了著名的“次级配置器（内存池）”来减少内存碎片（维护 16 个自由链表）。但现在的默认实现通常直接调用 `new` / `malloc`，因为现代操作系统的 `malloc` 已经足够强大（如 jemalloc, tcmalloc）。
    
- **区别**：
    
    - **Allocator** 负责内存的来源（堆、栈、内存池）。
        
    - **Deleter** (智能指针用) 负责资源的释放逻辑（不仅是内存，也可以是关闭文件）。
        

---

### 一张代码图看懂全家福

这段代码展示了 6 大组件如何协同工作：

```C++
#include <vector>       // 1. 容器
#include <algorithm>    // 3. 算法
#include <iostream>
#include <functional>   // 4. 仿函数

int main() {
    // 6. 分配器 (默认隐藏在模板参数里)
    // std::vector<int, std::allocator<int>>
    std::vector<int> v = {10, 5, 8, 3, 1};

    // 4. 仿函数 (这里用 Lambda)
    auto my_policy = [](int a, int b) { return a > b; };

    // 3. 算法 (sort) + 2. 迭代器 (begin/end) + 4. 仿函数
    std::sort(v.begin(), v.end(), my_policy);

    // 5. 迭代器配接器 (ostream_iterator)
    // 将“写入迭代器”的操作转换为“输出到 cout”
    std::copy(v.begin(), v.end(), 
              std::ostream_iterator<int>(std::cout, " "));
    
    return 0;
}
```

### 现代 STL (C++17/20) 的新成员

STL 家族还在不断扩招，你需要关注这两个新概念：

1. **视图 (Views) / 范围 (Ranges) [C++20]**：
    
    - `std::ranges`。彻底改变了算法的调用方式，不再需要传 `begin(), end()` 两个参数，而是直接传容器。
        
    - 支持**惰性求值 (Lazy Evaluation)** 和**管道操作 (Pipe | )**。
        
2. **非拥有型容器**：
    
    - `std::string_view` (C++17)：只读字符串切片，无内存分配（零拷贝）。[[C++视图]]
        
    - `std::span` (C++20)：连续内存的切片（可以是数组、vector、原生指针），超级好用。