``std::stack` 在 STL 里其实不是“容器”，而是**容器适配器（container adapter）**：  
它把一个底层顺序容器（默认 `deque`）**包装成栈接口：LIFO，只有栈顶可见**。

我按这几个部分系统讲一遍：

1. 它是什么 & 头文件 / 模板声明
    
2. 底层容器（`Container`）的要求和选型
    
3. 成员函数：构造、访问、修改、复杂度
    
4. 一个简化版实现，帮你建立“脑内模型”
    
5. 使用场景 & 和直接用 `vector` 当栈的对比
    
6. 一些容易踩的坑（没有迭代器 / pop 不返回值 / 空栈行为）
    

---

## 1. 它是什么？头文件 & 模板形式

头文件：

```C++
#include <stack>
```

标准声明（略化）：

```C++
namespace std {
    template<
        class T,
        class Container = std::deque<T>
    >
    class stack;
}
```

你可以这样理解：

- `T`：栈里存的元素类型；
    
- `Container`：真正存数据的底层容器类型，**默认为 `std::deque<T>`**；
    
- `stack<T, Container>` 只是把 `Container` 的接口收缩成“栈的那几招”。
    

**LIFO 特性**：

- 只能在一端操作：
    
    - `push()` —— 压栈
        
    - `top()` —— 看栈顶
        
    - `pop()` —— 出栈
        
- 最后进来的是最先出去：**Last In, First Out**。
    

---

## 2. 底层容器 `Container` 要求 & 选型

`std::stack` 对 `Container` 的要求很少，只要支持以下操作：

- `empty()`
    
- `size()`
    
- `back()` / `const back()`
    
- `push_back(const T&)` / `push_back(T&&)`
    
- `pop_back()`
    

所以你可以用：

```C++
std::stack<int> s1;                     // 默认: deque<int>
std::stack<int, std::vector<int>> s2;   // 用 vector 做底层
std::stack<int, std::list<int>> s3;     // 用 list 做底层（不常见）
```

**常见选择对比：**

|作为底层容器|是否常用|push/pop 性能|备注|
|---|---|---|---|
|`deque<T>`|✅ 默认|O(1) 均摊|双端队列，首尾操作都高效；空间利用和扩容策略好|
|`vector<T>`|✅ 常见|O(1) 均摊|只在尾部操作，和把 vector 当栈类似|
|`list<T>`|⚠️ 不建议|O(1)|但有指针开销/空间浪费，没必要|

在绝大多数场景：

- 用默认 `std::stack<T>`（底层 `deque`）就足够；
    
- 偏向缓存友好/连续内存时，可以显式使用 `vector` 作为底层：
    
    `std::stack<MyType, std::vector<MyType>> st;`
    

---

## 3. 成员函数：构造 / 访问 / 修改 / 复杂度

### 3.1 构造 / 赋值

常用形式：

```C++
std::stack<int> s1;           // 默认构造，内部 deque<int> 为空

std::deque<int> dq = {1, 2, 3};
std::stack<int> s2(dq);       // 用已有 deque 拷贝构造一个栈（bottom=1, top=3）

std::stack<int> s3(s2);       // 拷贝构造
std::stack<int> s4(std::move(s2)); // 移动构造
```

赋值同理（拷贝赋值 / 移动赋值）：

`s3 = s4; s3 = std::move(s4);`

### 3.2 容量相关

`bool empty() const;   // 是否为空 size_type size() const; // 元素数量`

复杂度：O(1)。

### 3.3 元素访问

```C++
reference       top();       // 返回栈顶元素（可修改）
const_reference top() const; // 只读
```

示例：

```C++
std::stack<int> st;
st.push(10);
st.push(20);
std::cout << st.top(); // 20
st.top() = 99;         // 修改栈顶
```

⚠️ **注意：对空栈调用 `top()` 是未定义行为（UB）**，必须先 `empty()` 判断。

### 3.4 修改操作

```C++
void push(const T& value);
void push(T&& value);          // C++11

template<class... Args>
void emplace(Args&&... args);  // C++11，原地构造

void pop();

void swap(stack& other);

```

- `push`：在栈顶（底层容器的末尾）插入元素；
    
- `emplace`：在栈顶**原地构造**一个 `T` 对象，避免临时对象：
    
    ```C++
    std::stack<std::pair<int, std::string>> st;
	st.emplace(1, "hello"); // 直接在栈中构造 pair<int, string>
    ```
    
- `pop`：**只弹出、不返回值**：
    
    `st.pop(); // 如果空栈调用 pop：UB`
    

复杂度（假设底层是 deque 或 vector）：

- `push` / `emplace` / `pop`：O(1) 均摊；
    
- `swap`：O(1)。
    

**为什么 `pop()` 不返回值？**

设计上为了异常安全 & 一致性：  
如果写成 `T pop()`，标准实现必须：

1. 读取栈顶元素；
    
2. 把它返回/拷贝；
    
3. 出栈；
    

中途若发生异常，会比较麻烦。现在的习惯是：

`auto x = st.top(); st.pop();`

也强迫你自己处理“空栈”的情况。

---

## 4. 一个简化版实现：帮你彻底理解 `stack`

你可以把 `std::stack`「想象」成：

```C++
template<class T, class Container = std::deque<T>>
class stack {
public:
    using container_type = Container;
    using value_type     = T;
    using size_type      = typename Container::size_type;
    using reference      = value_type&;
    using const_reference= const value_type&;

protected:
    Container c;  // 真正存储数据的容器

public:
    stack() = default;
    explicit stack(const Container& cont) : c(cont) {}
    explicit stack(Container&& cont) : c(std::move(cont)) {}

    // 容量
    bool empty() const noexcept { return c.empty(); }
    size_type size() const noexcept { return c.size(); }

    // 访问
    reference top() { return c.back(); }
    const_reference top() const { return c.back(); }

    // 修改
    void push(const value_type& value) { c.push_back(value); }
    void push(value_type&& value) { c.push_back(std::move(value)); }

    template<class... Args>
    void emplace(Args&&... args) {
        c.emplace_back(std::forward<Args>(args)...);
    }

    void pop() { c.pop_back(); }

    void swap(stack& other) noexcept(noexcept(std::swap(c, other.c))) {
        using std::swap;
        swap(c, other.c);
    }
};
```

真正标准库实现会多一些构造/比较/异常保障，但核心思想就这么简单：

> **所有操作最终就是在 `c` 的 `back()` / `push_back()` / `pop_back()` 上做文章。**

---

## 5. 使用场景 & 和直接用 `vector`/`deque` 当栈的对比

### 5.1 典型使用场景

1. **深度优先搜索（DFS）非递归版**
    

```C++
std::stack<Node*> st;
st.push(root);

while (!st.empty()) {
    Node* cur = st.top(); st.pop();
    // 访问 cur
    for (Node* child : cur->children) {
        st.push(child);
    }
}
```

2. **括号匹配 / 表达式求值**
    

```C++
std::stack<char> st;
for (char ch : s) {
    if (ch == '(') st.push(ch);
    else if (ch == ')') {
        if (st.empty()) {/*不匹配*/ }
        st.pop();
    }
}
if (!st.empty()) {/*不匹配*/ }
```

3. **撤销/回退（undo stack）**
    

做一次操作就把前一状态/操作记录压栈，需要 undo 时出栈恢复。

4. **模拟函数调用栈 / 状态机**
    

自己写解释器/虚拟机时，很多时候会显式维护一个 `stack` 来记录调用帧或状态。

### 5.2 那我干嘛不用 `std::vector` 直接当栈？

`vector` 当栈的典型写法：

```C++
std::vector<int> v;
// push:
v.push_back(x);
// top:
int x = v.back();
// pop:
v.pop_back();
```

这和 `stack<int, vector<int>>` 行为几乎一样。区别：

- **`stack` 接口更“安全”**：  
    对使用者只暴露 `push/pop/top/empty/size`，避免误用随机访问/迭代器。
    
- **`vector` 更灵活**：  
    你可以遍历、随机访问、做更多操作。
    

经验规律：

- 如果你只是想表现这个结构是「栈」而不是「一般数组」，用 `std::stack` 语义更清晰；
    
- 如果你确实需要遍历、排序、下标访问等操作，**直接用底层容器（vector/deque）更合适**。
    

---

## 6. 一些容易忽略/踩坑的点

### 6.1 `std::stack` **没有迭代器**

这点和 `std::vector` 非常不一样：

```C++
std::stack<int> st;
st.push(1); st.push(2); st.push(3);

// 下面是错误的：stack 没有 begin()/end()
/*
for (auto it = st.begin(); it != st.end(); ++it) {}
*/
```

如果你需要遍历栈元素，有几种方案：

1. 自己一边 `top()/pop()` 一边处理（破坏栈）；
    
2. 直接改用 `vector` 或 `deque` 当栈，暴露迭代器；
    
3. 自己封装一个 adapter，同时暴露 `std::stack` 和底层容器（比较 hack）。
    

### 6.2 `top()` / `pop()` 在空栈上是未定义行为

标准 **不会检查** empty：

```C++
std::stack<int> st;
st.pop();     // UB
st.top();     // UB
```

正确写法：

```C++
if (!st.empty()) {
    auto x = st.top();
    st.pop();
}
```

在复杂逻辑里（比如解析表达式、模拟栈机）一定要注意先判断。

### 6.3 多线程安全

- 任意 STL 容器（包括 `stack`）在**多线程并发读写**下都不是线程安全的；
    
- 如果多个线程共享一个 `stack`，需要自己加锁（例如 `std::mutex`），或者用其他并发容器。
    

### 6.4 底层容器的行为依然会影响你

例如你用 `std::vector` 做底层：

`std::stack<int, std::vector<int>> st;`

- 当 `push` 导致底层 vector 扩容时，会移动所有元素；
    
- 如果你通过某种 hack 拿到了底层容器的引用（比如自定义类继承），就要小心迭代器失效等问题。
    

**正常情况下**你只通过 `stack` 的接口访问，不会接触扩容带来的细节。

---

## 7. 小总结

你可以把 `std::stack` 总结成：

1. **概念**：一个 LIFO 容器适配器 —— “只有栈顶可见”的容器；
    
2. **模板**：`template<class T, class Container = std::deque<T>> class stack;`
    
3. **接口**（都非常少）：
    
    - 容量：`empty()`, `size()`
        
    - 访问：`top()`
        
    - 修改：`push()`, `emplace()`, `pop()`, `swap()`
        
4. **底层容器**：默认 `deque<T>`；也可选择 `vector<T>` 等，只要支持 `back()/push_back()/pop_back()`。
    
5. **使用场景**：DFS、表达式解析、撤销栈、状态机等任何「后进先出」逻辑。
    
6. **注意事项**：
    
    - 没有迭代器、没有 begin/end；
        
    - `pop()` 不返回元素；
        
    - 对空栈使用 `top/pop` 是 UB，需要先 `empty()`；
        
    - 多线程下需自己加锁。