## 1. `std::array` 是什么？

一句话：

> **`std::array<T, N>` = 一个带 STL 接口的“定长数组”**，  
> 内部基本就是 `T elems[N];`，大小在编译期就固定。

几条关键特性：

- 大小 `N` 是模板参数，**编译期常量**；不能 `push_back`，没有 `resize`。
    
- 内部一般就是：
    
```C++
    template<class T, size_t N>
struct array {
    T elems[N];
};
```
    
- 支持 STL 风格接口：
    
    - `begin()/end()`、`size()`、`front()/back()`、`operator[]`、`at()`…
        
- 内存布局与 `T[N]` 基本等价：
    
    - 你可以 `&a[0]` 拿到底层指针；
        
    - 可以安全地与 C 接口交互。
        
- 是**聚合类型 + 标准布局**（只要 `T` 满足条件），非常轻量、高效，可用在 `constexpr` 场景。
    

---

## 2. 和 C 风格数组 `T a[N]` 的区别

| 特性                     | C 数组 `T a[N]`                     | `std::array<T, N>`                      |
| ---------------------- | --------------------------------- | --------------------------------------- |
| 大小                     | 编译期固定                             | 编译期固定                                   |
| 是否是对象类型                | ❌ 不是类，很多操作不允许                     | ✅ 是类，有成员函数                              |
| 赋值                     | `a = b;` 不合法                      | `arr1 = arr2;` 支持逐元素拷贝/移动               |
| 作为返回值                  | 会退化成指针，不方便                        | 可以按值返回 `std::array`                     |
| 与算法 / 范围for 配合         | 需要手写 `std::begin(a), std::end(a)` | 直接 `arr.begin(), arr.end()` 或 range-for |
| 大小接口                   | `sizeof(a)/sizeof(a[0])`          | `arr.size()`                            |
| `std::tuple_size` 等元编程 | 不支持                               | 支持，`std::get<Idx>(arr)`                 |
|                        |                                   | [[C++现代]]                               |

你可以理解为：

> 语义上还是“定长数组”，但披上了 **STL 容器 + tuple** 的外衣。

---

## 3. 基本用法示例

```C++
#include <array>
#include <iostream>

int main() {
    std::array<int, 4> a = {1, 2, 3, 4};

    // 访问
    std::cout << a[0] << "\n";     // 1
    std::cout << a.at(1) << "\n";  // 2，有越界检查（运行时抛异常）

    // 遍历
    for (int x : a) {
        std::cout << x << " ";
    }

    // 大小
    std::cout << "\nsize = " << a.size() << "\n";

    // 与 C API 交互
    int* p = a.data();
    // 现在 p 可以传给 C 风格函数，比如 write/read 等

    return 0;
}
```

`std::array` 本身大小就是 `sizeof(T) * N`（再加上可能的 padding），  
不会像 `std::vector` 那样额外在堆上分配。

---

## 4. `std::array` 成员函数一览（速查表）

### 4.1 类型别名

|成员|含义|
|---|---|
|`value_type`|`T`|
|`size_type`|通常是 `std::size_t`|
|`difference_type`|带符号整数，用于迭代器差值|
|`reference` / `const_reference`|`T&` / `const T&`|
|`pointer` / `const_pointer`|`T*` / `const T*`|
|`iterator` / `const_iterator`|指向 `T` 的指针类型（随机访问迭代器）|
|`reverse_iterator` / `const_reverse_iterator`|反向迭代器|

---

### 4.2 迭代器相关

|方法|返回值类型|作用|
|---|---|---|
|`begin()` / `end()`|`iterator`|正向迭代起止|
|`cbegin()` / `cend()`|`const_iterator`|只读正向迭代|
|`rbegin()` / `rend()`|`reverse_iterator`|反向迭代|
|`crbegin()` / `crend()`|`const_reverse_iterator`|只读反向迭代|

可以直接用于 range-for：

`for (auto &x : arr) { ... }`

---

### 4.3 容量 / 大小

|方法|返回值类型|作用|
|---|---|---|
|`size()`|`size_type`|返回编译期固定的 N，在运行时 O(1)|
|`max_size()`|`size_type`|同 `size()`，也是 N|
|`empty()`|`bool`|当 `N == 0` 时为真（大多情况是 false）|

> 注意：**`std::array<int, 0>` 是允许的**，只是没有元素。

---

### 4.4 元素访问

|方法|返回值类型|作用|
|---|---|---|
|`operator[](size_type i)`|`reference` / `const_reference`|不做边界检查，行为类似于 C 数组|
|`at(size_type i)`|`reference` / `const_reference`|运行时检查越界，越界抛出 `std::out_of_range`|
|`front()`|`reference` / `const_reference`|第一个元素|
|`back()`|`reference` / `const_reference`|最后一个元素|
|`data()`|`T*` / `const T*`|指向底层 `T[N]` 的指针，可用于 C 接口|

---

### 4.5 修改 / 其他操作

|方法|返回值类型|作用|
|---|---|---|
|`fill(const T& value)`|`void`|把所有元素赋值为 `value`|
|`swap(array& other)`|`void`|和另一同类型 `array` 交换元素（元素逐个交换或整体 move，取决于实现）|

> 没有 `push_back`、`insert`、`erase`、`resize` —— 大小是**编译期固定**的。

---

## 5. 构造与初始化细节（容易踩坑的地方）

### 5.1 列表初始化

```C++
std::array<int, 3> a1 = {1, 2, 3};      // OK
std::array<int, 3> a2{1, 2, 3};         // OK

// 不足长度时，剩余默认值初始化：
std::array<int, 5> a3 = {1, 2};         // {1,2,0,0,0}
```

`std::array` 是 **聚合类型**，所以聚合初始化规则适用。

### 5.2 默认构造的“未初始化 vs 0 初始化”问题

`std::array<int, 3> a;   // 成员是 *值初始化*，但值初始化 int => 未指定？要区分场景`

比较靠谱的记法：一般情况下（局部变量，非 static storage），  
**`std::array<int,3> a;` 里的元素不保证为 0**，你应该主动初始化：

`std::array<int, 3> a{};   // 全部 0`

或者：

`auto a = std::array<int, 3>{}; // 全部 0`

**习惯用 `{}` 初始化是个好习惯**。

---

## 6. 和 `std::vector` / C 数组的选型关系

你可以记一个简单三选一原则：

1. **大小在编译期就确定，且不会改变 → `std::array` / C 数组**
    
    - 如果你想要 STL 接口、支持赋值/返回值 → 选 `std::array`
        
    - 如果你只是写个小局部、只交给 C 接口用，C 数组也可以。
        
2. **大小在运行时才知道 / 会改变 → `std::vector`**
    
    - 支持动态扩容、`push_back`、`resize` 等。
        
3. 性能上（缓存友好性）：
    
    - `std::array` 与 C 数组一样，是连续内存，最友好；
        
    - `vector` 也是连续内存，只是会在堆上分配。
        

---

## 7. 一点“实现视角”的补充

大多实现基本就是：

```C++
template<class T, std::size_t N>
struct array {
    T elems[N];

    // 所有 begin/end/size/front/back/data 都是围绕 elems 写一层 inline 封装
};
```

所以：

- `sizeof(std::array<T, N>) == sizeof(T) * N`（加上可能的 alignment padding）；
    
- 不存在额外的指针/计数开销；
    
- 可以 `memcpy` / `std::bit_cast` 等视情况安全使用（前提是 `T` 满足 TriviallyCopyable 等约束）。
    

另外还支持一些 **tuple 相关的特性**：

```C++
#include <tuple>
#include <array>

std::array<int, 3> a{1, 2, 3};

auto x = std::get<0>(a);                       // 1
constexpr std::size_t n = std::tuple_size_v<decltype(a)>;  // n = 3
```

这在元编程里非常好用。