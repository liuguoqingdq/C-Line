## 1. 定义（它比 Forward 多了什么？）

**Bidirectional Iterator = Forward Iterator + `--it` 能力**

也就是说它必须满足：

- 可读（input）
    
- 可写（若非 const）
    
- 可以多趟遍历（multi-pass）
    
- `++it` 前进
    
- **`--it` 后退**
    

---

## 2. 必须支持的操作（标准语义）

对一个双向迭代器 `it`：

### 2.1 前进（来自 Forward）

```C++
++it; it++;
*it; it->member;
it1 == it2; it1 != it2;
```

### 2.2 后退（Bidirectional 特有）

`--it; it--;`

### 2.3 多趟（multi-pass）语义

拷贝出来的迭代器必须可以独立走：

```C++
auto it1 = it;
auto it2 = it;
++it1;          // it2 不受影响
```

这点把它和 Input Iterator（单趟）区分开了。

---

## 3. 典型容器与底层原因

### 3.1 `std::list` / `std::map` / `std::set`

- `list` 是**双向链表**：节点里有 `prev/next` 指针 → 天然支持 `--`。
    
- `map/set` 是**平衡树（红黑树）**：树节点有父指针/或可沿树回溯 → 可以找前驱/后继。  
    所以迭代器能 `++`（中序后继）也能 `--`（中序前驱）。
    

### 3.2 `std::forward_list`

只有 `next` 没有 `prev` → **只能 Forward**，不能 Bidirectional。

---

## 4. 对算法的直接影响

### 4.1 需要 Bidirectional 的算法（随机访问不要求）

典型如：

- `std::reverse(first, last)`  
    必须两头向中间走，所以至少要能 `--last`。
    
- `std::prev(it)` / `std::next(it)`  
    `prev` 要求至少 Bidirectional。
    

**示例**

```C++
std::list<int> l{1,2,3};
std::reverse(l.begin(), l.end()); // ✅ OK (bidirectional)
```

### 4.2 Bidirectional 仍然不能用的算法

需要 Random Access 的比如：

- `std::sort`
    
- `std::binary_search`（虽然能在 bidirectional 上跑，但复杂度会变差；标准实现通常要求 RandomAccess 或至少 Forward+距离操作较重）
    

```C++
std::list<int> l{3,1,2};
std::sort(l.begin(), l.end()); // ❌ 编译不过
l.sort();                      // ✅ list 自带归并排序
```

---

## 5. `std::advance / distance` 在 bidirectional 上的复杂度

- `std::advance(it, n)`  
    对 bidirectional：
    
    - `n>0` 用 `++` 走 n 次
        
    - `n<0` 用 `--` 走 |n| 次  
        → **O(|n|)**
        
- `std::distance(first, last)`  
    bidirectional 也只能一步步走 → **O(n)**  
    （RandomAccess 才是 O(1)）
    

---

## 6. 自己实现一个 Bidirectional Iterator（最小骨架）

以双向链表节点为例：

```C++
template<class T>
struct Node {
    T value;
    Node* prev;
    Node* next;
};

template<class T>
class ListIter {
public:
    using iterator_category = std::bidirectional_iterator_tag;
    using value_type        = T;
    using difference_type   = std::ptrdiff_t;
    using pointer           = T*;
    using reference         = T&;

    ListIter() : p(nullptr) {}
    explicit ListIter(Node<T>* x) : p(x) {}

    reference operator*()  const { return p->value; }
    pointer   operator->() const { return &p->value; }

    // ++it
    ListIter& operator++() { p = p->next; return *this; }
    // it++
    ListIter operator++(int) { auto tmp=*this; ++(*this); return tmp; }

    // --it
    ListIter& operator--() { p = p->prev; return *this; }
    // it--
    ListIter operator--(int) { auto tmp=*this; --(*this); return tmp; }

    friend bool operator==(ListIter a, ListIter b){ return a.p==b.p; }
    friend bool operator!=(ListIter a, ListIter b){ return a.p!=b.p; }

private:
    Node<T>* p;
};
```

关键点：

1. `iterator_category` 必须是 `bidirectional_iterator_tag`
    
2. `--` 必须是**常数复杂度**（否则不算合格的 bidirectional）
    
3. 多趟语义天然由指针拷贝保证
    

---

## 7. 常见坑

1. **`end()` 不能解引用**  
    但 **`--end()` 必须合法**（对非空容器）。
    
    `auto it = l.end(); --it;   // 指向最后一个元素`
    
2. **删除元素后被删位置迭代器失效**  
    但 `list/map` 这类容器只让“被删元素的迭代器失效”，其他仍有效。
    
3. **不要在 bidirectional 上假装能随机跳**  
    `it + n` / `it[n]` 只对 RandomAccess 有意义；  
    你在 list 上写这种代码要么编不过，要么变成 O(n) 的手动循环。
    

---

### 小总结

Bidirectional Iterator 的本质就是：  
**“可多次遍历 + 能前进也能后退一步”**。  
它让链表、树这些非连续结构也能支持大量 STL 算法（reverse、prev、双端扫描类算法），但仍不具备随机访问能力。