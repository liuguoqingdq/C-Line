`std::forward_list` 是 C++11 引入的**单向链表**容器：每个节点只存 “下一节点指针”，所以只能向前遍历。它满足 SequenceContainer 的大部分要求，但**刻意不提供 `size()`** 来避免维护长度带来的开销（取长度只能线性遍历）。[Stack Overflow+2C++ Reference+2](https://stackoverflow.com/questions/27881869/do-all-containers-have-a-size-function?utm_source=chatgpt.com)

---

## 1. 核心特性（和 list/vector 的直观差别）

- **单向链表（singly linked）**
    
    - 只能 `++it` 向前走，不能 `--it` 回退。
        
    - 迭代器类别是 **Forward Iterator**。[C++ Reference+2C++ Reference+2](https://en.cppreference.com/w/cpp/container/forward_list.html?utm_source=chatgpt.com)
        
- **不保存长度**
    
    - 没有 `.size()` 成员函数。长度要 `std::distance(fl.begin(), fl.end())`，复杂度 O(n)。[Stack Overflow+2C++ Reference+2](https://stackoverflow.com/questions/27881869/do-all-containers-have-a-size-function?utm_source=chatgpt.com)
        
- **节点分散分配**
    
    - 每个元素一个节点（值 + next 指针），内存不连续。
        
    - 随机访问不支持，`fl[i]` 不存在。
        
- **插入/删除任意位置 O(1)**（前提：你已经拿到“前驱”位置）
    
    - 因为只改几个指针即可。[C++ Reference+1](https://en.cppreference.com/w/cpp/container/forward_list/erase_after.html?utm_source=chatgpt.com)
        

---

## 2. 基本使用

```C++
#include <forward_list>
#include <iostream>

int main() {
    std::forward_list<int> fl = {3, 1, 4};

    fl.push_front(9); // 头插 O(1)

    for (int x : fl) std::cout << x << " ";
}
```

range-for 可以用，因为 forward_list 提供 `begin()/end()`。[C++ Reference+1](https://en.cppreference.com/w/cpp/container/forward_list.html?utm_source=chatgpt.com)

---

## 3. “after 系列”操作：为什么需要 before_begin / insert_after / erase_after？

单向链表**没有前驱指针**，所以要在中间插删时，必须知道“前一个节点”。于是 forward_list 设计成：

- 提供一个“**头前哨兵**”迭代器：`before_begin()`  
    它不可解引用，只用于 after 系列操作。[C++ Reference+1](https://en.cppreference.com/w/cpp/container/forward_list/before_begin.html?utm_source=chatgpt.com)
    
- 插入/删除都叫 `*_after`，语义是“在某节点之后操作”。[SACO Evaluator+1](https://saco-evaluator.org.za/docs/cppreference/en/cpp/container/forward_list/insert_after.html?utm_source=chatgpt.com)
    

例子：

```C++
std::forward_list<int> fl = {1,2,3};
auto prev = fl.before_begin();  // 指向“头前”

fl.insert_after(prev, 0);       // 在头前之后插 => 变成 {0,1,2,3}

auto it = fl.begin();           // 指向 0
fl.erase_after(it);             // 删掉 0 后面的元素(1) => {0,2,3}
```

- `insert_after / emplace_after`：O(1)，不会让其他迭代器失效。[SACO Evaluator](https://saco-evaluator.org.za/docs/cppreference/en/cpp/container/forward_list/insert_after.html?utm_source=chatgpt.com)
    
- `erase_after`：O(1) 删除一个元素；删除区间是线性的（走区间长度）。[C++ Reference+1](https://en.cppreference.com/w/cpp/container/forward_list/erase_after.html?utm_source=chatgpt.com)
    

---

## 4. splice_after：单向链表的“零拷贝拼接”

`splice_after` 可以把另一个 forward_list 的节点**直接搬过来**，不复制元素，指针一接就完事。迭代器/引用不失效（只是归属换了）。[tcs.rwth-aachen.de+1](https://tcs.rwth-aachen.de/docs/cpp/reference/en.cppreference.com/w/cpp/container/forward_list/splice_after.html?utm_source=chatgpt.com)

```C++
std::forward_list<int> a = {1,2};
std::forward_list<int> b = {10,20,30};

a.splice_after(a.before_begin(), b);  
// a = {10,20,30,1,2}, b 变空
```

---

## 5. 其它常用成员 & 复杂度

- `front()` 取头元素 O(1)
    
- `pop_front()` 头删 O(1)
    
- `remove / remove_if`：线性扫描删匹配元素 O(n)
    
- `reverse()`：O(n) 原地反转
    
- `sort()`：forward_list 自带排序（通常为归并排序，适合链表）O(n log n)[studyplan.dev+1](https://www.studyplan.dev/pro-cpp/forward-list?utm_source=chatgpt.com)
    
- `resize(count[, value])`：多了就删尾部，少了就补默认/指定值 O(n)[ece.uwaterloo.ca](https://ece.uwaterloo.ca/~dwharder/Standard_library/forward_list/?utm_source=chatgpt.com)
    

---

## 6. 典型使用场景（什么时候选它？）

选 `forward_list` 的理由通常是：

1. **极致省内存**  
    单向链表比 `list` 少一个 prev 指针（每节点省一个指针大小）。
    
2. **你只需要向前遍历**  
    不需要反向走、不需要随机访问。
    
3. **大量中间插删 + 迭代器稳定**  
    插删不影响其他位置的迭代器（链表优势）。[SACO Evaluator+1](https://saco-evaluator.org.za/docs/cppreference/en/cpp/container/forward_list/insert_after.html?utm_source=chatgpt.com)
    
4. **需要高效 splice（零拷贝拼接/移动节点）**  
    用在任务队列、free-list、邻接链表等很常见。[tcs.rwth-aachen.de](https://tcs.rwth-aachen.de/docs/cpp/reference/en.cppreference.com/w/cpp/container/forward_list/splice_after.html?utm_source=chatgpt.com)
    

不适合：

- 需要频繁 `size()`（它没有）
    
- 需要下标/二分/排序后随机访问
    
- 数据量很大且只遍历：`vector` 通常更快（缓存友好）
    

---

## 7. 一个工程级对照小结

|容器|结构|迭代器|随机访问|中间插删|size()|典型优势|
|---|---|---|---|---|---|---|
|`vector`|连续数组|RandomAccess+Contiguous|O(1)|O(n)|O(1)|遍历快、缓存友好|
|`list`|双向链表|Bidirectional|不行|O(1)|O(1)|可双向走、splice|
|`forward_list`|单向链表|Forward|不行|O(1)（需前驱）|**无**|更省内存、只前向、splice_after|

---