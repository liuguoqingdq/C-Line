## 一、文件 IO 流怎么用（使用方法）

### 1. 头文件与三类流

```C++
#include <fstream> 
using namespace std;
```

- `ifstream`：只读
    
- `ofstream`：只写
    
- `fstream`：读写
    

### 2. 打开与关闭文件

**构造时打开：**

```C++
ifstream fin("in.txt");
ofstream fout("out.txt");
```

**先创建再 open：**

```C++
fstream fs;
fs.open("data.txt", ios::in | ios::out);
```

**关闭：**

`fs.close(); // 可写可不写，析构会自动 close（RAII）`

**检查是否打开成功：**

```C++
if (!fin.is_open()) {     cerr << "open failed\n"; }
```

---

### 3. 打开模式 openmode（非常关键）

常用模式：

|模式|含义|
|---|---|
|`ios::in`|读|
|`ios::out`|写|
|`ios::app`|追加写（每次写都在文件末尾）|
|`ios::trunc`|打开就清空|
|`ios::ate`|打开后把指针放到末尾（但仍可 seek 回去）|
|`ios::binary`|二进制模式（不做换行转换）|

例子：

```C++
ofstream fout("log.txt", ios::out | ios::app);   // 追加日志
ifstream fin("img.bin", ios::in | ios::binary); // 读二进制
```

默认规则（容易踩坑）：

- `ifstream` 默认 `ios::in`
    
- `ofstream` 默认 `ios::out | ios::trunc`（会清空）
    
- `fstream` 默认不带 in/out，需要你写
    

---

### 4. 读取文件

#### 4.1 格式化读取（像 cin >>）

适合读结构化文本（空格分隔）

```C++
int a; double b; string s;
fin >> a >> b >> s; // 自动跳过空白，按类型解析
```

典型循环：

`int x; while (fin >> x) {     // ... }`

---

#### 4.2 按行读取：getline

适合日志/自然语言/一行一条记录

```C++
string line;
while (getline(fin, line)) {
    // line 不包含 '\n'
}
```

和 `>>` 混用时，先清掉残留换行：

```C++
int n;
fin >> n;
fin.ignore(numeric_limits<streamsize>::max(), '\n');
string line;
getline(fin, line);
```

---

#### 4.3 逐字符读取：get

适合自己做 parser/状态机

```C++
char c;
while (fin.get(c)) {
    // c 包含空格/换行等原始字符
}
```

---

#### 4.4 块读取：read（文本/二进制都可）

适合大文件、高性能、二进制结构

```C++
char buf[4096];
fin.read(buf, sizeof(buf));
streamsize n = fin.gcount(); // 实际读了多少字节
```

---

### 5. 写入文件

#### 5.1 格式化写（像 cout <<）

`fout << "hello " << 42 << "\n";`

> 注意 `"\n"` 不强制 flush；`endl` 才 flush（文件里一般不需要频繁 flush）

#### 5.2 单字符写 put

`fout.put('A');`

#### 5.3 块写 write

`fout.write(buf, n);`

---

### 6. 随机访问（seek / tell）

文件流维护**读指针(get)** 和 **写指针(put)**：

```C++
// 读指针
auto p = fin.tellg();//返回当前**读光标的位置**（从文件开头算起的偏移，单位是字节）。
fin.seekg(0, ios::beg);//`seekg(offset, dir)` = **seek get**把读光标移动到：`dir` 基准 + `offset` 偏移。`ios::beg` 表示**文件开头**。
fin.seekg(10, ios::cur);//`ios::cur` 表示**当前读光标位置**。读光标在原位置基础上向前移动 10 个字节
fin.seekg(-5, ios::end);//- `ios::end` 表示**文件末尾**。偏移可以为负数，表示从末尾往前数。所以这行：**把读光标移动到“文件末尾往前 5 个字节”的位置**。 注意：如果文件长度小于 5 字节，这个 seek 会失败，流会置 `failbit`。

// 写指针
auto q = fout.tellp();
fout.seekp(0, ios::end);
```

常见用途：索引文件、二进制结构、日志尾部追加、断点续写。

---

### 7. 状态位检查（和 cin 完全一样）

```C++
fin.good(); // 一切正常
fin.eof();  // 读到 EOF
fin.fail(); // 格式化读失败（类型不匹配最常见）
fin.bad();  // 底层 IO 错误
```

失败恢复（典型套路）：

`fin.clear(); fin.ignore(numeric_limits<streamsize>::max(), '\n');`

---

### 8. 性能常用技巧

`ios::sync_with_stdio(false); cin.tie(nullptr);`

对文件流也有帮助（减少同步/flush开销）。  
**前提：不要再混用 printf/scanf 与 cin/cout。**

---

## 二、这些用法背后的底层解释（原理）

### 1. 类层级与“谁真正干活”

你之前看到的 `basic_ios` 里的 `rdbuf_` 就是关键：

```bash
ifstream/ofstream/fstream
        |
   basic_istream/basic_ostream/basic_iostream
        |
     basic_ios  (保存状态、格式、tie、width...)
        |
   streambuf* rdbuf_  --->  filebuf  ---> OS 文件句柄/FD

```

- `ifstream/ofstream/fstream` 只是“外壳 API”
    
- **真正读写文件的是 `filebuf`（basic_filebuf）**
    
- `basic_ios::rdbuf_` 指向这个 `filebuf`
    

所以你调用 `fin >> x` 或 `getline(fin, line)`  
本质都是在跟 `filebuf` 要数据。

---

### 2. 缓冲区为什么能提速

`filebuf` 内部有一块缓冲区（实现决定大小）。

- **读**时：先一次性从 OS 读一大块到缓冲  
    之后 `>>/get/getline/read` 多次从缓冲里取  
    → 减少系统调用次数（syscall 很贵）
    
- **写**时：先写到缓冲  
    缓冲满 / flush / close 时才一次性写给 OS  
    → 同样减少 syscall
    

---

### 3. `>>`（格式化输入）到底怎么读

以 `fin >> int x` 为例：

1. 创建一个 `sentry` 对象
    
    - 检查流状态（`good()` 吗）
        
    - 跳过前导空白（`skipws`）
        
2. 把字符从 `rdbuf_` 拉出来
    
3. 调 locale 的 `num_get` facet 解析成 int
    
4. 成功 → 写入 x  
    失败 → 设置 `failbit`  
    到 EOF → 设置 `eofbit`
    

你在 `basic_ios` 里看到的 `rdstate_` 就是这个状态位集合。

---

### 4. `getline` / `get`（非格式化输入）

它们不走 `num_get` 这些解析逻辑，直接从 `rdbuf_` 取原始字符：

- `get(c)`：拿一个字符
    
- `getline`：循环 `sbumpc()`/`sgetc()` 直到遇到 `'\n'`
    

所以它们：

- 不会自动跳空白
    
- 速度往往比 `>>` 更快（少解析）
    

---

### 5. `read/write`（块 IO）

`read(buf, n)` / `write(buf, n)` 属于**非格式化、按字节**：

- `read`：请求 `filebuf::xsgetn`
    
- `write`：请求 `filebuf::xsputn`
    

底层直接搬运字节，不做任何类型/locale 解析。

---

### 6. `seekg/seekp` 怎么实现

它们最终都调用：

- `filebuf::pubseekoff`（相对移动）
    
- `filebuf::pubseekpos`（绝对位置）
    

再进一步走到 OS 的 `lseek` / `fseek` / `SetFilePointer` 等系统接口。

为什么 `app` 模式下 seekp 无效？  
因为 `ios::app` 语义规定：**每次写都强制定位到末尾**，库会在写之前再跑一遍“定位到尾部”。

---

### 7. flush/close 发生了什么

`flush()` 会触发 `filebuf::sync()`：

- 把写缓冲里还没下去的数据推给 OS
    
- 写成功 → 保持 good
    
- 写失败 → 设置 `badbit/failbit`
    

`close()` 会：

1. `flush`
    
2. 释放 OS 句柄
    
3. 断开 `rdbuf_` 与文件的绑定
    

---

### 8. 为什么状态位很重要

所有操作（`>> getline read seek write`）都会在失败时打标：

- 解析失败（类型不匹配）→ `failbit`
    
- 读到文件末尾 → `eofbit`
    
- 系统级 IO 错误 → `badbit`
    

而 `basic_ios::rdstate_` 存的就是它们的组合。  
所以你用 `while(fin >> x)`，本质是检查：

`!fin.fail() && !fin.bad()`

---

## 小结（把用法和原理对起来）

- **你用 ifstream/ofstream**  
    → 实际是让 `basic_ios` 绑一个 `filebuf` 到 `rdbuf_`
    
- **你用 `>>`**  
    → `sentry` + 跳空白 + locale facet 解析 + 更新 `rdstate_`
    
- **你用 `getline/get/read`**  
    → 直接从 `filebuf` 的缓冲里按字节取
    
- **你 seek/flush/close**  
    → 最终落到 `filebuf` 调 OS 接口