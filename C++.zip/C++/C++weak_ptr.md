## 1. `weak_ptr` 是什么？一句话定义

> `std::weak_ptr<T>` 是 **对某个 `shared_ptr` 控制块的非拥有（non-owning）引用**。  
> 它**不增加强引用计数**，因此**不延长对象寿命**。

换句话说：

- `shared_ptr`：我“拥有”对象，活着就算一份 owner。
    
- `weak_ptr`：我“观察”对象，不算 owner，只是留个“联系方式”。
    

---

## 2. 内部机理：强计数 vs 弱计数

控制块里有两种计数：

- `use_count`（强引用数）：多少 `shared_ptr` 在拥有对象  
    → 决定对象什么时候析构
    
- `weak_count`（弱引用数）：多少 `weak_ptr` 在观察对象  
    → 决定控制块什么时候释放
    

关键规则：

1. `use_count == 0` 时 **对象析构**
    
2. `use_count == 0 && weak_count == 0` 时 **控制块释放**
    

所以弱引用存在时，对象可以死，但控制块可能还活着，供 weak_ptr 判断对象是否还在。

---

## 3. `weak_ptr` 的基本用法

### 3.1 从 shared_ptr 创建

```C++
std::shared_ptr<Foo> sp = std::make_shared<Foo>();
std::weak_ptr<Foo> wp = sp;   // wp 观察 sp 管理的对象
```

这一步：

- `use_count` 不变
    
- `weak_count++`
    

### 3.2 访问对象：必须 `lock()`

`weak_ptr` 不能直接 `->` 或 `*`，因为对象可能已经死了。

```C++
if (auto spt = wp.lock()) {  // lock 成功：对象还活着
    spt->work();
} else {
    // 对象已析构
}
```

`lock()` 的语义：

- 若对象还活着（use_count > 0），返回一个新的 `shared_ptr`，并使 `use_count++`
    
- 若对象已死，返回空 `shared_ptr`
    

### 3.3 判活 API

```C++
wp.expired();    // bool：是否已过期（对象是否已析构）
wp.use_count();  // 当前强引用数（调试用，别写逻辑）
wp.reset();      // 释放 weak 引用
```

---

## 4. shared_ptr 循环引用为什么会泄漏？

看一个最小循环：

```C++
struct B;

struct A {
    std::shared_ptr<B> b;
    ~A(){ std::cout << "A died\n"; }
};

struct B {
    std::shared_ptr<A> a;
    ~B(){ std::cout << "B died\n"; }
};

auto a = std::make_shared<A>();
auto b = std::make_shared<B>();

a->b = b;
b->a = a;   // 形成环
```

此时引用计数：

- `a` 外部强引用 1
    
- `b` 外部强引用 1
    
- `a->b` 再给 `b` 强引用 +1
    
- `b->a` 再给 `a` 强引用 +1
    

结果：

```C++
A.use_count = 2
B.use_count = 2
```

外部把 `a`、`b` reset 后：

- `A.use_count` 变 1（因为 B 还强持有 A）
    
- `B.use_count` 变 1（因为 A 还强持有 B）
    

**永远不会到 0 → 永远不析构 → 泄漏**

这就是为什么“纯 shared 的双向关系”天生危险。

---

## 5. weak_ptr 如何解决？——断开所有权环

原则：

> 环里必须有一条边是“非拥有”的（weak），这样强引用计数就能降到 0。

改造 B 中的反向指针：

```C++
struct B {
    std::weak_ptr<A> a;      // 改成 weak
    ~B(){ std::cout << "B died\n"; }
};
```

然后：

```C++
auto a = std::make_shared<A>();
auto b = std::make_shared<B>();

a->b = b;   // strong
b->a = a;   // weak, 不增加 A.use_count
```

引用计数变为：

```C++
A.use_count = 1   // 只有外部 a
B.use_count = 2   // 外部 b + A->b
```

当外部释放：

1. 外部 `a` 释放 → `A.use_count` 从 1 到 0  
    → `A` 析构  
    → A 的成员 `b` 也随之释放
    
2. `A->b` 释放 → `B.use_count` 从 1 到 0  
    → `B` 析构
    
3. `B` 析构后 weak_ptr 不再影响对象（只影响控制块）  
    环被打断，内存正常回收。
    

---

## 6. 典型设计模式：谁用 shared，谁用 weak？

### 6.1 Parent-Child / 树结构

- Parent 拥有 Child：**shared/unique**
    
- Child 只“回看” Parent：**weak**
    

```C++
struct Node : std::enable_shared_from_this<Node> {
    std::vector<std::shared_ptr<Node>> children; // 拥有
    std::weak_ptr<Node> parent;                  // 非拥有
};
```

### 6.2 Observer / 回调

- Subject 持有 observers：shared（或裸指针但要更严谨的生命周期）
    
- Observer 反向指 Subject：weak
    

避免 subject 和 observer 互相“吊着命”。

---

## 7. 一些必须记牢的坑

1. **weak_ptr 不能直接用对象，一定 lock**
    
    `wp->foo();  // ❌ 不存在`
    
2. **不要拿 lock() 的返回值长期保存为 shared_ptr**
    
    - lock 返回的 shared_ptr 是临时“续命”，如果你长期保存它，就又变成强引用，可能再次形成环
        
    - 正确做法：**用完即弃**
        
3. **expired() + lock() 的竞态**
    
    - 多线程下：
        
        `if (!wp.expired()) { auto sp = wp.lock(); }`
        
        这不是原子保证的
        
    - 直接：
        
        `if (auto sp = wp.lock()) { ... }`
        
        才是正确姿势。
        

---

## 8. 你可以这样记（教授版口诀）

- **shared_ptr = ownership**
    
- **weak_ptr = observation**
    
- **凡是双向/环状结构：至少一边 weak**
    
- **想用 weak 指向对象：lock 一下再用**