### 第一部分：C++ 错误处理的演变体系

#### 1. 上古时代：返回码 (Return Codes)

这是从 C 语言继承来的方式。函数返回一个 `int` 或 `bool`，通过引用参数返回实际数据。

- **形式：** `int perform_task(Data* out_data);` (返回 0 成功，非 0 失败)
    
- **优点：** 性能极高（无运行时开销），控制流清晰。
    
- **缺点：**
    
    - **容易被忽略：** 调用者可以不检查返回值，导致错误扩散。
        
    - **接口不纯粹：** 返回值被错误码占用了，真实数据必须通过参数传出，导致代码难看。
        
    - **没有上下文：** 返回 `-1` 往往不知道具体发生了什么。
        

#### 2. 标准时代：异常 (Exceptions)

C++ 标准库主要采用的机制。

- **形式：** `throw std::runtime_error("Error");` 和 `try-catch`。
    
- **核心理念：** **错误处理与业务逻辑分离**。正常代码写在 `try` 块里，不用满屏 `if(err)`。
    
- **关键依赖：** **RAII (资源获取即初始化)**。当异常抛出，栈展开（Stack Unwinding）会自动调用局部对象的析构函数，防止内存泄漏。
    
- **优点：** 强制处理（不 catch 程序就挂），代码整洁（Happy Path），携带丰富信息（字符串、堆栈等）。
    
- **缺点：**
    
    - **性能不可预测：** Happy path（无异常）很快，但一旦抛出异常，性能开销巨大（此时不适合高性能热点路径）。
        
    - **二进制膨胀：** 需要生成额外的栈展开表。
        
    - **隐式控制流：** 你不知道哪一行代码会抛出异常，导致“异常安全（Exception Safety）”极难保证。
        

#### 3. 系统底层：`std::system_error` (C++11)

这是为了解决“返回码没有上下文”的问题。它把 `errno` 封装成面向对象的类，包含错误码（value）和错误类别（category）。虽然比较底层，但它是现代 C++ I/O 和网络库（如 Asio）的基础。

---

### 第二部分：C++ 能否实现像 Rust 那样的错误处理？

**答案是：完全可以，而且 C++23 已经标准化了这种机制。**

Rust 的错误处理核心在于 `Result<T, E>` 类型和模式匹配。这是一种 **代数数据类型（Sum Type）**，表示“要么是结果 T，要么是错误 E”。

#### 1. C++23 的 `std::expected<T, E>`

这就是 C++ 版本的 `Result<T, E>`。它在 `<expected>` 头文件中。

- **语义：** 一个 `std::expected` 对象包含一个预期值 `T`，**或者** 一个错误值 `E`。它就像一个带有“错误状态”的 `std::optional`。
    

**代码对比：**

**Rust 写法：**

Rust

```C++
fn divide(a: f64, b: f64) -> Result<f64, String> {
    if b == 0.0 {
        return Err("Division by zero".to_string());
    }
    Ok(a / b)
}

// 调用
match divide(10.0, 0.0) {
    Ok(val) => println!("Result: {}", val),
    Err(e) => println!("Error: {}", e),
}
```

**C++23 (`std::expected`) 写法：**

C++

```C++
#include <expected>
#include <string>
#include <iostream>

// 定义返回类型：要么是 double，要么是 string 错误
std::expected<double, std::string> divide(double a, double b) {
    if (b == 0.0) {
        // 返回错误类型 (unexpected)
        return std::unexpected("Division by zero");
    }
    // 返回正常值
    return a / b;
}

int main() {
    auto result = divide(10.0, 0.0);

    if (result.has_value()) {
        std::cout << "Result: " << result.value() << std::endl;
    } else {
        // result.error() 获取错误信息
        std::cout << "Error: " << result.error() << std::endl;
    }
    return 0;
}
```

#### 2. Monadic Operations (链式调用)

Rust 的一大精髓是 `and_then`, `map` 等链式调用。C++23 的 `std::expected` 也支持这些 **Monadic 操作**，这让代码非常优雅，完全摆脱了 `try-catch` 和 `if-else` 地狱。

C++

```C++
// 假设有三个步骤，每一步都可能失败
std::expected<Image, Err> load_image(string path);
std::expected<Image, Err> resize_image(Image img);
std::expected<void, Err>  save_image(Image img);

void process() {
    // 链式调用：任何一步失败，直接返回那个错误；全成功则继续
    // 类似于 Rust 的 ? 操作符逻辑
    auto result = load_image("photo.jpg")
        .and_then(resize_image)
        .and_then(save_image);

    if (!result) {
        std::cerr << "Pipeline failed: " << result.error() << "\n";
    }
}
```

#### 3. 第三方库（如果用不了 C++23）

如果你的编译器还不支持 C++23，你可以使用以下库来实现完全相同的效果：

- **`tl::expected`**：C++23 标准提案的参考实现（支持 C++11/14/17）。
    
- **`boost::outcome`**：功能更强大，被很多高性能库使用。
    
- **`absl::StatusOr<T>`**：Google 内部广泛使用的方案。
    

---

### 第三部分：C++ `std::expected` vs Rust `Result` 的差距

虽然机制一样，但 C++ 目前的体验比 Rust 稍差，主要差在 **模式匹配（Pattern Matching）** 上。

1. **Rust:** 使用 `match` 关键字，编译器强制你处理 `Ok` 和 `Err`，语法非常简洁。
    
2. **C++:** 目前通常使用 `if (res.has_value())` 或者 `result.value_or(...)`。
    
    - 虽然可以使用 `std::visit` 配合 `std::variant` 模拟模式匹配，但语法极其啰嗦。
        
    - **未来展望：** C++26 可能引入原生的 `inspect`（模式匹配），届时将完全看齐 Rust。
        

---

### 第四部分：总结与决策指南

在现代 C++ 项目中，你应该如何选择错误处理方式？

|**场景**|**推荐机制**|**理由**|
|---|---|---|
|**致命逻辑错误**|`assert` / `std::terminate`|比如数组越界、空指针解引用。这是 Bug，程序不该继续运行。|
|**可预期的运行时错误**|**`std::expected`** (Rust 风格)|比如文件不存在、网络解析失败、JSON 格式错误。**这是现代 C++ 的首选。** 它显式、零开销、类型安全。|
|**极少发生的异常情况**|**异常 (Exceptions)**|比如构造函数失败（构造函数没有返回值，必须抛异常）、内存耗尽。|
|**系统底层开发**|`std::error_code`|需要与 OS API 交互时。|

### 结论

**C++ 不仅可以，而且正在全面转向 Rust 风格的错误处理。**

`std::expected` 结合了返回码的性能（无堆栈展开开销）和异常的语义清晰度（值与错误分离）。除了由于缺乏原生的模式匹配语法导致写起来稍微比 Rust 啰嗦一点点外，核心机制是完全一致的。

---
### 一、 核心机制：栈展开 (Stack Unwinding)

这是 `try-catch` 最强大的地方，也是它和 `return error_code` 的根本区别。

当你执行 `throw` 时：

1. 程序流立即停止当前执行。
    
2. **逆向**沿着调用栈向上寻找最近的 `catch` 块。
    
3. **关键点**：在寻找的过程中，程序会**自动调用**当前作用域内所有已构造对象的**析构函数**。
    

**这就是为什么 C++ 强调 RAII（资源获取即初始化）**。只要你使用 `std::vector` 或 `std::unique_ptr`，异常发生时内存会自动回收，不会泄漏。

---

### 二、 C++ 标准异常家族族谱

所有的标准异常都继承自基类 `std::exception`。C++ 将错误大致分为两派：**逻辑错误（Logic Errors）** 和 **运行时错误（Runtime Errors）**。

#### 1. 基类：`std::exception`

- 位于 `<exception>`。
    
- 提供了一个虚函数 `virtual const char* what() const noexcept;` 用于返回错误信息。
    

#### 2. 第一大派系：`std::logic_error` (代码写错了)

位于 `<stdexcept>`。这代表**程序员的逻辑 Bug**。理论上，这些错误应该在发布前通过代码修复，而不是通过 `catch` 捕获。

- **`std::invalid_argument`**：参数不符合要求（最常用）。
    
    - _例子_：传入了一个空指针，或者设置年龄为 -5。
        
- **`std::out_of_range`**：超出有效范围。
    
    - _例子_：`std::vector::at(100)` 当数组只有 10 个大小时抛出。
        
- **`std::length_error`**：试图创建太大的容器。
    
- **`std::domain_error`**：数学域错误（如对负数开平方，但在 `cmath` 中很少用，通常返回 NaN）。
    

#### 3. 第二大派系：`std::runtime_error` (运气不好)

位于 `<stdexcept>`。这代表**不可预见的运行时错误**。代码逻辑没问题，但是外部环境（网络、磁盘、用户输入）出了问题。**这是你最应该在业务逻辑中捕获的类型。**

- **`std::runtime_error`**：最通用的运行时错误基类。
    
- **`std::range_error`**：计算结果无法用目标类型表示。
    
- **`std::overflow_error` / `std::underflow_error`**：算术上溢/下溢。
    
    - _注意_：C++ 基础类型（int）溢出通常是未定义行为，不会自动抛出这个，这些通常用于 `std::bitset` 或自定义数学库。
        
- **`std::system_error`** (C++11)：包含操作系统底层的错误码（`errno`）。
    

#### 4. 其他特殊异常

- **`std::bad_alloc`**：`new` 失败（内存耗尽）。
    
- **`std::bad_cast`**：`dynamic_cast` 对引用转换失败时。
    

---

### 三、 实战：如何正确使用 `runtime_error`

这是最标准的 C++17 错误处理写法。

#### 场景：一个负责读取配置文件并处理数据的函数

C++

```C++
#include <iostream>
#include <fstream>
#include <vector>
#include <stdexcept> // 必须包含
#include <string>

// 1. 定义一个特定的异常（可选，但推荐用于复杂系统）
// 继承自 runtime_error，这样通用的 catch 也能捕获它
class ConfigFileNotFound : public std::runtime_error {
public:
    ConfigFileNotFound(const std::string& filename)
        : std::runtime_error("Config file not found: " + filename) {}
};

// 2. 可能会抛出异常的业务函数
void load_config(const std::string& path, int retry_count) {
    // 检查逻辑错误 (Logic Error)
    if (retry_count < 0) {
        throw std::invalid_argument("Retry count cannot be negative");
    }

    std::cout << "Attempting to open " << path << "...\n";
    
    // 模拟文件不存在
    bool file_exists = false; 
    if (!file_exists) {
        // 抛出运行时错误 (Runtime Error)
        // 这里的 string 会被存储，之后可以通过 .what() 取出
        throw ConfigFileNotFound(path);
    }
}

// 3. 顶层调用
int main() {
    try {
        load_config("server.ini", 3);
    }
    // 【原则1】先捕获最具体的异常
    catch (const ConfigFileNotFound& e) {
        std::cerr << "[Config Error] " << e.what() << "\n";
        // 可以在这里执行降级策略，比如加载默认配置
    }
    // 【原则2】捕获通用的运行时异常
    catch (const std::runtime_error& e) {
        std::cerr << "[Runtime Error] " << e.what() << "\n";
    }
    // 【原则3】捕获逻辑错误（通常意味着需要修 Bug）
    catch (const std::logic_error& e) {
        std::cerr << "[Logic Bug] Programmer error: " << e.what() << "\n";
    }
    // 【原则4】最后捕获所有标准异常（兜底）
    // 注意：这里必须是 const reference (&)，否则会发生“对象切片(Slicing)”，丢失子类信息
    catch (const std::exception& e) {
        std::cerr << "[Unknown Standard Exception] " << e.what() << "\n";
    }
    // 【原则5】绝对兜底（捕获非标准异常，如 throw "error" 或 throw 1）
    catch (...) {
        std::cerr << "[Fatal] Unknown non-standard exception occurred.\n";
    }

    return 0;
}
```

---

### 四、 C++ 异常处理的四大“军规”

要写出健壮的 C++ 代码，请务必遵守以下规则：

#### 1. 抛出值，捕获引用 (Throw by value, Catch by reference)

- **Throw**: `throw std::runtime_error("msg");` (创建一个临时对象)
    
- **Catch**: `catch (const std::exception& e)`
    
- **原因**：如果你写 `catch (std::exception e)`（按值捕获），会发生**对象切片 (Object Slicing)**。如果抛出的是 `ConfigFileNotFound`，按值捕获后它就变成了一个普通的 `exception`，原本包含的特定信息可能会丢失，且多态失效。
    

#### 2. 析构函数绝不能抛出异常

- **原因**：如果程序因为异常 A 正在进行栈展开（Stack Unwinding），此时调用了析构函数。如果析构函数里又抛出了异常 B，C++ 运行时无法同时处理两个未被捕获的异常，会直接调用 `std::terminate()` **强行杀死程序**。
    
- **对策**：析构函数里的代码如果可能抛异常，必须在内部 `try-catch` 吞掉。
    

#### 3. 区分 `assert` 和 `exception`

- **Assert (断言)**：用于 `std::logic_error` 的场景，即“这种事绝不该发生，发生了就是代码写错了”。在 Release 模式下 assert 通常会被优化掉。
    
- **Exception**：用于“这种情况虽然不爽，但在生产环境中确实可能发生”，如断网、文件被锁定。
    

#### 4. 保证异常安全 (Exception Safety) - 使用 RAII

最常见的错误写法：

C++

```C++
void bad_func() {
    int* data = new int[100]; // 资源分配
    
    process(data); // <--- 如果这里抛出异常！
    
    delete[] data; // 这行永远不会执行，内存泄漏！
}
```

**正确写法**（使用智能指针）：

C++

```C++
void good_func() {
    // 即使 process 抛出异常，unique_ptr 的析构函数也会自动 delete data
    auto data = std::make_unique<int[]>(100); 
    process(data.get());
}
```

### 总结

标准的 C++ 错误处理其实就是：**业务层抛出 `std::runtime_error` 派生类，逻辑层利用 RAII 自动清理资源，顶层（Main loop 或 线程入口）统一 `catch` 记录日志。**

----
`boost::outcome` 是一个功能极其强大的库，它不仅是 C++23 `std::expected` 的原型，还针对高性能和系统编程做了大量优化。

在 C++17 环境下，它是实现 **Rust 风格错误处理（Result<T, E>）** 的最佳工业级选择。

我们要学的核心对象只有一个：**`boost::outcome_v2::result<T, E>`**。

---

### 第一步：环境准备

`boost::outcome` 从 **Boost 1.70** (2019年) 开始进入标准 Boost 库。 它是 **Header-only** 的，你只需要 `#include <boost/outcome.hpp>` 即可，不需要编译 `.lib` 或 `.a` 文件。

为了方便，我们通常定义一个命名空间别名：

C++

```C++
namespace outcome = boost::outcome_v2;
```

---

### 第二步：基础用法 (Hello World)

我们模拟一个简单的场景：转换字符串为整数。可能会失败（空字符串、非法字符）。

**核心逻辑：**

- 成功时：返回 `outcome::success(value)`
    
- 失败时：返回 `outcome::failure(error)`
    

C++

```C++
#include <boost/outcome.hpp>
#include <iostream>
#include <string>

namespace outcome = boost::outcome_v2;

// 1. 定义你的错误类型 (可以是 enum，也可以是 struct，或者 std::error_code)
enum class ParseError {
    EmptyInput,
    InvalidChar
};

// 2. 定义函数返回类型：result<成功类型, 失败类型>
// 类似于 Rust 的 Result<int, ParseError>
outcome::result<int, ParseError> parse_int(const std::string& str) {
    if (str.empty()) {
        return ParseError::EmptyInput; // 隐式转换为 failure
        // 或者显式写: return outcome::failure(ParseError::EmptyInput);
    }

    if (str.find_first_not_of("0123456789") != std::string::npos) {
        return ParseError::InvalidChar;
    }

    // 模拟转换
    return std::stoi(str); // 隐式转换为 success
    // 或者显式写: return outcome::success(std::stoi(str));
}

void use_it() {
    auto result = parse_int("123a");

    // 3. 检查是否有值 (类似于 std::optional 或 Rust 的 match)
    if (result.has_value()) {
        std::cout << "Success: " << result.value() << "\n";
    } else {
        // 4. 获取错误
        ParseError err = result.error();
        if (err == ParseError::EmptyInput) std::cout << "Error: Empty Input\n";
        else std::cout << "Error: Invalid Char\n";
    }
}
```

---

### 第三步：核心杀手锏 `BOOST_OUTCOME_TRY` (模拟 Rust 的 `?`)

这是使用 Outcome 最爽的地方。

在 Rust 中，如果你想说“执行这个函数，如果出错直接把错误抛给调用者，如果成功则把值取出来”，你会用 `?` 操作符。 在 C++ 中，`boost::outcome` 提供了宏 `BOOST_OUTCOME_TRY` 来实现完全相同的效果。这避免了层层嵌套的 `if-else`。

**场景**：

1. `get_data()` 获取字符串。
    
2. `parse_int()` 解析字符串。
    
3. `process()` 处理整数。
    

C++

```C++
#include <boost/outcome.hpp>
#include <string>
#include <iostream>

namespace outcome = boost::outcome_v2;

enum class AppError { InputEmpty, InvalidNumber, LogicError };

// 模拟各个步骤
outcome::result<std::string, AppError> get_data() {
    return "42"; 
}

outcome::result<int, AppError> parse(const std::string& s) {
    if (s.empty()) return AppError::InputEmpty;
    return 42;
}

// 组合函数：这一步展示 TRY 的威力
outcome::result<int, AppError> process_pipeline() {
    // 尝试获取数据
    // 逻辑：如果 get_data() 失败，process_pipeline 立刻返回那个错误。
    // 如果成功，str 就是结果字符串。
    BOOST_OUTCOME_TRY(auto str, get_data());

    // 尝试解析
    BOOST_OUTCOME_TRY(auto num, parse(str));

    // 如果都成功了，继续处理
    if (num < 0) return AppError::LogicError;

    return num * 2;
}

int main() {
    auto res = process_pipeline();
    
    if (res) {
        std::cout << "Final Result: " << res.value() << "\n";
    } else {
        std::cout << "Pipeline Failed with Error ID: " << (int)res.error() << "\n";
    }
}
```

**注意**：`BOOST_OUTCOME_TRY` 的语法在不同 Boost 版本略有微调。

- **Boost 1.70+**: `BOOST_OUTCOME_TRY(var, func())` （推荐）
    
- **老版本**: `BOOST_OUTCOME_TRY((var), func())` （注意那个双括号）
    

---

### 第四步：与系统错误 (`std::error_code`) 结合

在写底层库时，我们不想自己造 `enum`，而是想用标准的 `std::error_code`（就像文件系统、网络库那样）。

Outcome 对此支持极好。如果不指定第二个模板参数，它默认可能不是 `std::error_code`，但我们可以使用预定义的别名。

C++

```C++
#include <boost/outcome.hpp>
#include <system_error>
#include <iostream>
#include <fstream>

namespace outcome = boost::outcome_v2;

// std_result 默认将错误类型设为 std::error_code
// 相当于 outcome::result<T, std::error_code>
outcome::std_result<std::string> read_file(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        // 返回标准的系统错误：No such file or directory
        // make_error_code 是标准库函数
        return std::make_error_code(std::errc::no_such_file_or_directory);
    }
    
    std::string content;
    file >> content;
    return content;
}

void test() {
    auto res = read_file("nothing.txt");
    
    if (!res) {
        // 这里的 error() 返回的是 std::error_code
        std::cout << "System Error: " << res.error().message() 
                  << " (" << res.error().value() << ")\n";
    }
}
```

```C++
#include <boost/outcome.hpp>
#include <iostream>
#include <string>

namespace outcome = boost::outcome_v2;

// 1. 定义纯枚举
enum class ParseError {
    None,           // 0
    EmptyInput,     // 空输入
    Overflow,       // 数字太大
    InvalidChar     // 包含非数字字符
};

// 为了方便调试，通常写个辅助函数转字符串
std::string to_string(ParseError e) {
    switch(e) {
        case ParseError::EmptyInput: return "Input is empty";
        case ParseError::Overflow:   return "Number overflow";
        case ParseError::InvalidChar:return "Invalid character found";
        default: return "Unknown error";
    }
}

// 2. 定义 Result
using Result = outcome::result<int, ParseError>;

Result parse(const std::string& str) {
    if (str.empty()) return ParseError::EmptyInput;
    if (str.length() > 9) return ParseError::Overflow;
    return 42; 
}

void test() {
    auto res = parse("");
    if (!res) {
        // 直接处理枚举
        if (res.error() == ParseError::EmptyInput) {
            std::cerr << "Err: " << to_string(res.error()) << "\n";
        }
    }
}
```


---

### 第五步：进阶 —— `outcome::result` vs `outcome::outcome`

你可能会在文档里看到两个东西：

1. **`outcome::result<T, E>`** (推荐 99% 场景使用)
    
    - **语义**：要么是 T，要么是 E。
        
    - **类似于**：Rust `Result<T, E>`, C++23 `std::expected<T, E>`.
        
    - **特点**：轻量，零开销。
        
2. **`outcome::outcome<T, E, P>`** (除除非你有特殊需求)
    
    - **语义**：要么是 T，要么是 E，**要么是一个异常指针 P**。
        
    - **用途**：用于那些既想用返回码，又想在某些极端情况下携带异常信息（比如在不抛出异常的函数里捕获了异常并把它传出去）的场景。
        
    - **建议**：**初学者请直接忽略这个类**，它会增加心智负担。只用 `result` 就够了。
        

---

### 总结：Outcome 使用模板

要在你的 C++17 项目中优雅地使用错误处理，请遵循这个模板：

C++

```C++
// MyProjectError.h
#pragma once
#include <boost/outcome.hpp>

// 1. 简化命名空间
namespace outcome = boost::outcome_v2;

// 2. 定义你的 Result 别名，统一错误类型（可选，但推荐）
// 这样你在项目里只需要写 Result<int> 而不是 outcome::result<int, MyError>
enum class MyError { FailA, FailB };
template <typename T>
using Result = outcome::result<T, MyError>;

// 使用
// Result<int> func() { ... }
```

### 为什么选择它而不是直接用 `std::optional`？

`std::optional` 只能告诉你“失败了”（返回 nullopt），但不能告诉你“为什么失败”。`boost::outcome` 既能处理成功，又能携带失败的具体原因（Error Enum 或 Exception info），且通过 `TRY` 宏提供了极佳的代码可读性。