## 1. 读写锁的本质：把“读”和“写”的并发语义分开

普通 `std::mutex` 对读写一刀切：

> 只要你进临界区，无论读还是写，都必须独占。

但在很多系统里：

- 读操作极多（查询、look-up、遍历）
    
- 写操作极少（更新、插入、删除）
    

这时 mutex 把所有读者串行化了，浪费并发。

`std::shared_mutex` 的核心想法：

> **读者可以共享锁（并行），写者必须独占锁（排它）。**

这就是“读写锁 / reader-writer lock”。

---

## 2. 标准语义（C++17）与 happens-before 保证

### 2.1 两种锁态

1. **共享（shared）**：读锁
    
    - 允许多个线程同时持有
        
2. **独占（unique/exclusive）**：写锁
    
    - 同时只允许一个线程持有
        
    - 且写锁存在时，不允许任何读锁持有
        

### 2.2 内存可见性（重要）

C++ 标准规定：

- `lock()` / `lock_shared()` 具有 **acquire** 语义
    
- `unlock()` / `unlock_shared()` 具有 **release** 语义
    

所以：

> 写线程在 `unlock()` 之前的写入  
> 对之后获得（读/写）锁的线程可见。

这跟 mutex 一样，是**同步屏障**。

---

## 3. API 族和 RAII 封装

### 3.1 裸 API（你一般不用）

```C++
std::shared_mutex sm;

// 写锁
sm.lock();
sm.try_lock();
sm.unlock();

// 读锁
sm.lock_shared();
sm.try_lock_shared();
sm.unlock_shared();
```

### 3.2 RAII（现代 C++ 正确用法）

- **读锁**：`std::shared_lock<shared_mutex>`
    
- **写锁**：`std::unique_lock<shared_mutex>`（或 lock_guard）
    

```C++
std::shared_mutex sm;
int x = 0;

void reader() {
    std::shared_lock lk(sm); // 共享读锁
    // 只读访问 x
    auto v = x;
}

void writer() {
    std::unique_lock lk(sm); // 独占写锁
    ++x;
}
```

---

## 4. 实现直觉（为什么它比 mutex 复杂）

你可以把 `shared_mutex` 想成：

- 一个 **读者计数器**
    
- 一个 **写者锁**
    
- 再加一些调度策略（公平性）
    

伪模型：

```C++
class shared_mutex {
    mutex writer_gate;           // 控制写者独占
    atomic<int> reader_count{0}; // 当前读者数
    ...
};
```

读者 lock_shared：

1. 可能先检查是否有写者在等
    
2. reader_count++
    
3. 进入
    

写者 lock：

1. 先锁 writer_gate
    
2. 等 reader_count 变 0
    
3. 进入
    

这就解释了：

- 读写锁为什么开销比 mutex 大（多维护读者计数 + 唤醒）
    
- 为什么读锁时间越长写者越难插入
    

---

## 5. 公平性（读者优先/写者优先/公平）与饥饿

**标准不规定公平性**。不同平台实现不同：

1. **读者优先**
    
    - 读者来就进
        
    - 可能导致写者长期饿死（writer starvation）
        
2. **写者优先**
    
    - 一旦有写者等待，后续读者就挡住
        
    - 写延迟稳，但读吞吐可能抖动
        
3. **公平队列**
    
    - 按到达顺序排队
        
    - 稳但开销略高
        

**工程含义：**

> 如果“写必须及时生效”（比如状态更新、区块链路由表变更），要警惕写者饥饿。

**如何缓解写者饥饿？**

- 让读锁持有非常短
    
- 在读锁内只做“拷贝快照”，锁外做重计算
    
- 批量写、合并写，减少写频率
    
- 实在不行退回 mutex 或用版本化快照
    

---

## 6. 性能模型：什么时候 shared_mutex 真赚？

共享读锁能提速的前提是：

1. **读比例极高**（比如 ≥90%）
    
2. **读临界区很短**
    
3. **写比较稀疏且不长**
    

如果不满足，shared_mutex 可能更慢：

- 写锁更贵（要等所有读者）
    
- 读锁也更贵（原子计数、调度）
    
- 写频率高时，会频繁打断读者，读吞吐抖动
    

### 6.1 一个直觉对比

- mutex：每次读都要排队 → 串行 1x
    
- shared_mutex：读者并发 N 倍 → 近似 N x  
    **但前提是写者几乎不挡路**
    

---

## 7. “升级锁/降级锁”问题（很多人第一回都会踩）

### 7.1 shared_mutex 不支持原子升级

你不能这样：

```C++
std::shared_lock rlk(sm);
// ...读
// rlk 升级成写锁？ ❌ 标准不支持
```

正确做法是“释放读锁 → 抢写锁 → 二次检查”。

```C++
bool needWrite;

{
    std::shared_lock rlk(sm);
    needWrite = check();
    if (!needWrite) return;
} // 释放读锁

{
    std::unique_lock wlk(sm);
    if (check()) {  // 必须 double-check
        write();
    }
}
```

**为什么要 double-check？**  
因为释放读锁到抢到写锁之间，有窗口期，别的线程可能已经改了状态。

### 7.2 降级也没有直接 API

只好：

- 先释放写锁
    
- 再拿读锁  
    （同样有窗口期）
    

---

## 8. 经典设计模式（你可以照着用）

### 8.1 缓存 / 索引表（读多写少）

```C++
std::unordered_map<K,V> cache;
std::shared_mutex sm;

V get(const K& k){
    std::shared_lock lk(sm);
    auto it = cache.find(k);
    return it==cache.end() ? V{} : it->second;
}

void put(const K& k, const V& v){
    std::unique_lock lk(sm);
    cache[k] = v;
}
```

### 8.2 “快照读、写批处理”

读锁里只拿 snapshot：

```C++
std::vector<int> snapshot(){
    std::shared_lock lk(sm);
    return data; // 拷贝一份
} // 锁释放

void heavy_read(){
    auto snap = snapshot();
    // 锁外做长计算
}
```

写者不会被长读拖死。

### 8.3 结构体内多字段不变式

读者用 shared_lock，写者用 unique_lock，保持不变式一致。

---

## 9. 常见坑（教师会在作业里扣分那种）

1. **shared_lock 里做写操作**
    
    `std::shared_lock lk(sm); x++; // ❌ data race`
    
2. **读锁持有过长**
    
    - 写者饥饿
        
    - 系统尾延迟飙升
        
3. **把锁保护的对象引用/指针传出去**
    
    ```C++
    T& ref(){
    std::shared_lock lk(sm);
    return obj; // ❌ 锁释放后 ref 可能被写者改
}
    ```
    
4. **误把 shared_mutex 当“万能性能优化”**  
    写稍一多，它可能比 mutex 更惨。
    

---

## 10. 与其它方案的对比（让你会选）

### 10.1 mutex

- 稳、开销低
    
- 不怕写频繁
    
- 读并发度为 1
    

### 10.2 shared_mutex

- 读并发度高
    
- 写慢且可能饥饿
    
- 适合读多写少
    

### 10.3 版本化快照 / Copy-on-Write / RCU（更高级）

- 读几乎无锁
    
- 写创建新版本、原子替换
    
- 适合“极端读多写极少且读延迟要求极低”的系统  
    代价：内存、实现复杂度
    

---

## 11. 教授版决策树（最终你要会用）

1. **读比例高吗？**（>80~90%）
    
    - 否 → 用 mutex
        
    - 是 → 继续
        
2. **读锁能做到短吗？**
    
    - 否（读里要做复杂计算/IO） → mutex 或快照/RCU
        
    - 是 → shared_mutex 合适
        
3. **写的时效性要求高吗？**
    
    - 高（不能被拖太久） → 小心饥饿；读锁必须极短
        
    - 低 → shared_mutex 更安心
        

---

一句话总结：

> `shared_mutex` 让读者并行、写者独占；  
> 它是“读多写少 + 短读临界区”场景下的性能利器，但要警惕写者饥饿和升级锁窗口期。