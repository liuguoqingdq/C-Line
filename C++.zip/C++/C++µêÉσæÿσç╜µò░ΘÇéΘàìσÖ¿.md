## 1. 问题根源：成员函数指针太难用

先看最原始的东西：**成员函数指针**。

```C++
struct Foo {
    void print(int x) const {
        std::cout << "Foo: " << x << "\n";
    }
};

void use_raw_pointer_to_member() {
    void (Foo::*pmf)(int) const = &Foo::print; // 成员函数指针类型

    Foo obj;
    Foo* p = &obj;

    (obj.*pmf)(42);  // 调用方式 1：对象 + .* + 成员指针
    (p->*pmf)(42);   // 调用方式 2：指针 + ->* + 成员指针
}
```

你会发现几个问题：

1. 类型写起来很长：`void (Foo::*)(int) const`
    
2. 调用语法极丑：`(obj.*pmf)(...)` / `(ptr->*pmf)(...)`
    
3. STL 算法要的 callable 是 `f(T&)` 或 `f(T)` 这种形式，你直接给它一个成员函数指针没法用：
    
    ```C++
    std::vector<Foo> v(10);
	std::for_each(v.begin(), v.end(), &Foo::print); // ❌ 不行
    ```
    
    因为 `for_each` 期待的是一个“能直接 `f(x)` 调用”的函数对象，而成员函数指针不是。
    

> 于是就有了**成员函数适配器**：把“成员函数指针”包一层，变成“普通 callable”。

---

## 2. 现代版成员函数适配器：`std::mem_fn`

头文件：`<functional>`

原型（简化）：

```C++
template<class M, class T>
/*unspecified*/ mem_fn(M T::* pm) noexcept;
```

含义：

> `std::mem_fn` 接受一个「指向成员（函数或数据）的指针」，返回一个函数对象 `fn`。  
> 以后你可以写 `fn(obj, args...)`，它内部会帮你做 `(obj.*pm)(args...)` 或 `(obj.*pm)`。

### 2.1 最简单的用法

```C++
#include <functional>
#include <algorithm>
#include <vector>
#include <iostream>

struct Foo {
    void print() const {
        std::cout << "Foo\n";
    }
};

int main() {
    std::vector<Foo> v(3);

    std::for_each(v.begin(), v.end(),
                  std::mem_fn(&Foo::print));  // ✅

    // 效果等价于：
    // for (auto& e : v) e.print();
}
```

这里：

- `&Foo::print` 是 `void (Foo::*)() const`；
    
- `std::mem_fn(&Foo::print)` 生成一个函数对象 `fn`；
    
- `fn(e)` 时，相当于 `(e.*(&Foo::print))()`，也就是 `e.print()`。
    

### 2.2 支持对象 / 指针 / 智能指针

标准规定：`std::mem_fn` 返回的函数对象 `fn`，调用 `fn(t, a2, ..., aN)` 等价于 `std::invoke(pm, t, a2, ..., aN)`。

而 `std::invoke` 对「成员函数指针」的规则包括：

- 如果第一个参数是对象 `T` 或 `T` 的派生类 → `(obj.*pm)(...)`
    
- 如果是 `T*` → `(ptr->*pm)(...)`
    
- 如果是 `std::reference_wrapper<T>` → `ref.get().*pm`
    
- 很多实现也支持智能指针（通过 `operator->` 间接调用）
    

直观理解：**`mem_fn` 再也不用你写 `.*` / `->*`，你只管把对象/指针/（部分智能指针）丢进去，它自己搞定。**

例子：

```C++
struct Foo {
    void print() const { std::cout << "Foo\n"; }
};

int main() {
    Foo obj;
    Foo* p = &obj;
    auto sp = std::make_shared<Foo>();

    auto f = std::mem_fn(&Foo::print);

    f(obj);  // obj.print();
    f(p);    // p->print();
    f(sp);   // sp->print(); （大部分实现支持，基于 std::invoke）
}
```

---

## 3. 不止函数：数据成员也可以用 `mem_fn`

不仅是成员函数指针，**数据成员指针**也可以用 `mem_fn` 适配。

```C++
struct Foo {
    int value;
};

int main() {
    Foo obj{42};
    Foo* p = &obj;

    auto get_value = std::mem_fn(&Foo::value); // pointer-to-data-member

    std::cout << get_value(obj) << "\n"; // 等价 obj.value
    std::cout << get_value(p)  << "\n";  // 等价 p->value
}
```

再结合算法：

```C++
std::vector<Foo> v = {{1},{3},{2}};

std::vector<int> vals;
vals.reserve(v.size());

std::transform(v.begin(), v.end(), std::back_inserter(vals),
               std::mem_fn(&Foo::value));
// vals = {1, 3, 2}
```

你可以把 `mem_fn(&Foo::value)` 当作一个“字段提取函数”。

---

## 4. 和 STL 算法组合：典型范式

### 4.1 对容器中每个对象调用成员函数

```C++
struct Node {
    void flush() {
        std::cout << "flushing\n";
    }
};

std::vector<Node> nodes(5);

std::for_each(nodes.begin(), nodes.end(),
              std::mem_fn(&Node::flush));
```

### 4.2 对容器中每个「指针」调用成员函数

```C++
std::vector<std::unique_ptr<Node>> ptrs;
// 填一些元素……

// 方式一：lambda
std::for_each(ptrs.begin(), ptrs.end(),
              [](auto& p){ p->flush(); });

// 方式二：mem_fn（常见写法是配合 transform / bind，
// 实际使用中对 smart pointer 支持要看实现和 std::invoke 规则）
using std::placeholders::_1;
auto fn = std::mem_fn(&Node::flush);
// 再用 bind/front 等包装也可以
```

很多时候，**直接 lambda 更直观**，但 `mem_fn` 提供了一个更“泛型”的做法——只依赖成员指针，不关心对象是引用/指针。

### 4.3 把成员函数作为回调 / 放进 `std::function`

```C++
struct Handler {
    void on_event(int code) {
        std::cout << "event " << code << "\n";
    }
};

Handler h;

std::function<void(int)> cb =
    std::bind(std::mem_fn(&Handler::on_event), &h, std::placeholders::_1);

// 后面统一当函数对象用
cb(404);
```

当然现代 C++ 写成 lambda 更简单：

`std::function<void(int)> cb = [&h](int code){ h.on_event(code); };`

这里的 `mem_fn` 就是提供一种“**从成员指针 → 普通 callable**”的通用手段。

---

## 5. 重载成员函数：如何指定具体哪个版本？

有时成员函数是重载的：

```C++
struct Foo {
    void f();        // #1
    void f(int);     // #2
};
```

写 `&Foo::f` 是**不唯一的重载集合**，需要你选一个。

常见两种方式：

### 5.1 用 `static_cast` 指定准确类型

```C++
auto f0 = std::mem_fn(static_cast<void(Foo::*)()>(&Foo::f));   // 选 #1
auto f1 = std::mem_fn(static_cast<void(Foo::*)(int)>(&Foo::f)); // 选 #2

Foo obj;
f0(obj);    // 调用 Foo::f()
f1(obj, 42); // 调用 Foo::f(42)
```

### 5.2 利用 `std::mem_fn` 的模板参数（某些实现支持）

有些代码会写：

```C++
auto f0 = std::mem_fn<void(Foo::*)()>(&Foo::f);
auto f1 = std::mem_fn<void(Foo::*)(int)>(&Foo::f);
```

但标准推荐、兼容性最好的做法还是用 `static_cast` 显式选中一个重载。

---

## 6. `std::mem_fn` 的内部实现思路

从标准描述看，本质就一句话：

> `auto fn = std::mem_fn(pm);`  
> 那么 `fn(t, args...)` 的效果等价于 `std::invoke(pm, t, args...)`。

用伪代码写一个简单实现，大致是：

```C++
template<class PM>
struct mem_fn_wrapper {
    PM pm;  // 指向成员（函数或数据）的指针

    explicit mem_fn_wrapper(PM pm_) : pm(pm_) {}

    template<class T, class... Args>
    decltype(auto) operator()(T&& obj, Args&&... args) const {
        // 关键：统一用 std::invoke 处理对象/指针/reference_wrapper/智能指针
        return std::invoke(pm, std::forward<T>(obj),
                               std::forward<Args>(args)...);
    }
};

template<class M, class T>
auto mem_fn(M T::*pm) noexcept {
    return mem_fn_wrapper<M T::*>(pm);
}
```

所以你可以这么理解：

- 成员函数适配器 `mem_fn` 干的事就是“**存下一个成员指针，在 operator() 里用 std::invoke 调它**”；
    
- `std::invoke` 统一处理 `obj.*pm` / `ptr->*pm` / `ref.get().*pm` 等各种情况。
    

---

## 7. 老一代成员函数适配器：`mem_fun` / `mem_fun_ref`（了解即可）

在 C++11 之前的 STL 里，有一组老式适配器：

- `std::mem_fun` / `std::mem_fun_ref`
    
- 对应类型 `mem_fun_t` / `const_mem_fun_t` / `mem_fun1_t` ……
    

特点（现在都 **已弃用**）：

1. 只支持 0 或 1 个参数的成员函数；
    
2. `mem_fun` 只能作用于“指针容器”，`mem_fun_ref` 作用于“对象容器”；
    
3. 不支持智能指针；
    
4. 语法啰嗦、功能弱，被 `std::mem_fn` 完全取代。
    

示例（旧时代写法）：

```C++
std::vector<Foo*> vp;

// C++03 风格：
std::for_each(vp.begin(), vp.end(),
              std::mem_fun(&Foo::print));   // 只支持 Foo* 容器
```

现在统一用 `std::mem_fn` 或 lambda 就行了：

```C++
std::for_each(vp.begin(), vp.end(),
              [](Foo* p) { p->print(); });  // 推荐
// 或
std::for_each(vp.begin(), vp.end(),
              std::mem_fn(&Foo::print));    // 现代 mem_fn
```

---

## 8. 和 lambda / `std::bind` 的对比：什么时候还用 `mem_fn`？

**lambda 最好读：**

```C++
std::for_each(v.begin(), v.end(),
              [](Foo& x){ x.print(); });
```

**`mem_fn` 更“泛型” & “可复用”：**

- 需要把“成员函数”当成一个**参数/模板实参**传来传去；
    
- 需要和通用框架（比如某个库要求你传一个“`R(T&)` 函数对象”）协作。
    

比如你写一个通用工具：

```C++
template<class C, class M>
void call_all(C& container, M pm) {
    auto fn = std::mem_fn(pm);
    for (auto& x : container) {
        fn(x);  // 对每个元素调用成员
    }
}

// 用法：
std::vector<Foo> v(3);
call_all(v, &Foo::print);
```

这里 lambda 就不方便写，因为你提前并不知道 `pm` 是哪个类的哪个成员。

---

## 9. 小结：你要抓住的几个关键点

1. **成员函数适配器 = 把“成员函数指针”适配成“普通 callable”**：
    
    - 标准里就是 `std::mem_fn`；
        
    - 它返回的对象支持 `fn(obj, args...)` 这种自然调用方式。
        
2. `std::mem_fn(pm)` + `std::invoke`：
    
    - `fn(t, args...)` == `std::invoke(pm, t, args...)`；
        
    - 自动处理对象、指针、`reference_wrapper`，通常也能很好地配合智能指针。
        
3. 支持：
    
    - 成员函数指针：适配成 `fn(obj, args...)`；
        
    - 成员变量指针：适配成 `fn(obj)` 返回成员值。
        
4. 和算法结合：
    
    - `for_each(v.begin(), v.end(), std::mem_fn(&T::method));`
        
    - `transform(v.begin(), v.end(), out, std::mem_fn(&T::member));`
        
5. 重载成员函数要用 `static_cast` 明确选择具体版本。
    
6. 老的 `mem_fun` / `mem_fun_ref` 已经被淘汰，现代 C++ 全用 `mem_fn` + lambda。