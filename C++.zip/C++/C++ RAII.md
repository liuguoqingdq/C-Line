## 1. RAII 核心就一句话

**RAII（Resource Acquisition Is Initialization）= 资源获取即初始化。**

翻译成人话就是：

> **谁在构造函数里“拿”资源，谁就在析构函数里“还”资源。**  
> 把“成对调用”的东西（open/close、new/delete、lock/unlock…）  
> 绑到对象的“出生”和“死亡”上，交给编译器自动处理。

C++ 有“确定性析构”（对象离开作用域必然析构），RAII 就是把这个特性用到极致的编程风格。

---

## 2. 不用 RAII 会出什么问题？

比如你直接用 C API 操作文件：

```C++
void foo() {
    FILE* fp = fopen("data.txt", "r");
    if (!fp) return;

    char* buf = (char*)malloc(1024);
    if (!buf) {
        fclose(fp);      // 记得关文件
        return;
    }

    // 中间一堆逻辑……
    if (some_error) {
        free(buf);       // 记得 free
        fclose(fp);      // 记得 fclose
        return;
    }

    free(buf);
    fclose(fp);
}
```

问题：

- 各种 `return` 分支上，都得手动 `free` / `fclose`；
    
- 稍微复杂一点，你就**很容易漏写**、写重复、或者写错顺序；
    
- 一旦中间加了 `throw` 异常，更容易“资源没释放”或“死锁”。
    

这就是 RAII 要解决的事：**把“释放资源”变成自动行为，不靠人类记忆。**

---

## 3. 用 RAII 写同样的逻辑会是什么样？

我们把文件这个资源封装到一个类里：

```C++
class File {
public:
    File(const char* path, const char* mode) {
        fp_ = fopen(path, mode);
        if (!fp_) {
            throw std::runtime_error("open file failed");
        }
    }

    ~File() {
        if (fp_) {
            fclose(fp_);
        }
    }

    FILE* get() const { return fp_; }

    // 一般禁止拷贝，防止一个句柄被多次 fclose
    File(const File&) = delete;
    File& operator=(const File&) = delete;

private:
    FILE* fp_;
};
```

然后业务代码变成这样：

```C++
void foo() {
    File f("data.txt", "r");  // 构造时自动 fopen
    
    // 中间随便写逻辑，return 也好，throw 也好……
    
} // 走到这里，f 离开作用域，自动调用 ~File()，fclose 一定会执行

```

**你再也不用到处写 `fclose` 了。**  
这就是 RAII 的味道：**“作用域结束 = 自动清理”**。

---

## 4. C++ 是怎么保证“自动清理”的？

关键点就两个：

1. **栈上对象离开作用域时，析构函数一定会被调用**（包括因为异常离开）。
    
2. 多个局部对象，会按“构造的逆序”析构：
    

```C++
void bar() {
    A a;  // 先构造 a
    B b;  // 再构造 b
    C c;  // 再构造 c

    // 这里抛异常 / return 等

} // 出作用域：先 ~C()、再 ~B()、再 ~A()

```

所以，只要你把“资源释放”写在析构里，就不怕中途 `return` / `throw`，**编译器一定会帮你把析构跑完**。

---

## 5. RAII 的经典例子：智能指针 & 锁

### 5.1 智能指针：管理 new/delete

```C++
{
    std::unique_ptr<Foo> p = std::make_unique<Foo>(42);
    // 这里随便用 p
    
} // 出作用域，~unique_ptr() 自动 delete Foo

```

`unique_ptr` 的本质就是：

- 构造时接管 `new` 出来的指针；
    
- 析构时 `delete`；
    
- 禁止拷贝，只能移动，表示“独占所有权”。
    

### 5.2 `std::lock_guard`：管理 lock/unlock

不用 RAII：

```C++
std::mutex m;

void f() {
    m.lock();
    // 中间可能 return/throw
    m.unlock();  // 万一没执行到这里就死锁了
}

```

用 RAII：

```C++
std::mutex m;

void f() {
    std::lock_guard<std::mutex> lk(m);  // 构造时 lock
    // 临界区

} // 出作用域，lk 析构，自动 unlock

```

你就再也不用担心“忘记 unlock 导致死锁”了。

---

## 6. 自己写 RAII 类的一般套路

统一模板如下：

```C++
class Resource {
public:
    Resource() {
        // 构造：获取资源（new / fopen / socket / lock / ...）
    }

    ~Resource() {
        // 析构：释放资源（delete / fclose / close / unlock / ...）
    }

    Resource(const Resource&) = delete;
    Resource& operator=(const Resource&) = delete;

    // 如果需要，可以实现移动构造/移动赋值
    Resource(Resource&& other) noexcept { /* 接管资源 */ }
    Resource& operator=(Resource&& other) noexcept { /* 先释放自己，再接管 */ }

private:
    HandleType handle_;  // 比如 FILE*、int fd、指针、数据库连接等
};

```

**一句话记住：**

> 所有需要“成对调用”的操作，都可以封装成 RAII：  
> `new/delete`, `malloc/free`, `fopen/fclose`, `lock/unlock`, `open/close`, `begin/commit/rollback`…

---

## 7. 标准库里哪些东西就是 RAII？

- `std::vector`, `std::string`：管理动态内存（构造分配，析构释放）
    
- `std::unique_ptr`, `std::shared_ptr`：智能指针
    
- `std::ifstream`, `std::ofstream`, `std::fstream`：文件流（构造打开，析构关闭）
    
- `std::lock_guard`, `std::unique_lock`：锁的 RAII
    
- 你以后自己写的各种“资源管理类”：数据库连接、socket、线程句柄……
    

---

## 8. 一句话总结（再强调一遍）

> **RAII = 用 C++ 对象的生命周期来管理任何“必须释放”的资源。**  
> 构造=获取，析构=归还，  
> 只要对象是自动变量（栈上），不管函数怎么结束（正常结束 / return / throw），编译器都会帮你自动把资源收拾干净。