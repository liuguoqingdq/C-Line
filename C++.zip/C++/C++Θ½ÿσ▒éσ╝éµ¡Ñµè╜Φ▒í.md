按这个结构讲：

1. 为什么需要“高层异步抽象”：从“线程”到“任务”
    
2. 标准库第一层抽象：`std::future` / `std::promise` / `std::async`
    
3. 任务 + 线程池：用 `packaged_task` 封装一个简单 ThreadPool
    
4. Continuation 风格：基于 future 的“任务链”
    
5. C++20 协程：语言级的异步抽象（co_await）
    
6. 更高层的并发模型：actor / 消息队列 / pipeline
    

---

## 1. 从“线程”到“任务”：为什么要高层抽象？

直接用 `std::thread` 的典型痛点你已经感受到过：

- 线程创建/销毁很重（系统调用 + 栈空间）
    
- 线程生命周期要自己管：忘了 `join()` 就 `std::terminate()`
    
- 每个线程都要自己写锁、条件变量，容易 data race / 死锁
    
- **组合性差**：  
    “等 A 和 B 都算完再继续”、“哪个先完成先用谁”——用裸线程很难写清晰
    

从现代并发设计角度，更好的抽象是：

> 真正的单位不是“线程（thread）”，而是“任务（task）”。

- 任务：**“做一件事情 + 最终给一个结果”**
    
- 线程：只是**执行任务的载体**（调度器用来跑任务的“工人”）
    

高层抽象的目标：

1. **把“我想做什么”写成任务**（函数/协程）
    
2. **把“在哪个线程上跑 / 什么时候跑”交给框架**（线程池 / 执行器）
    
3. 我拿到的是一个“将来会有结果的对象”（future），而不是某个线程句柄
    

---

## 2. 标准库第一层：`std::future` / `std::promise` / `std::async`

### 2.1 `std::future<T>`：一次性结果占位符

可以把 `future<T>` 理解为：

> “会在未来某个时间点产生一个 `T` 的容器”。

特点：

- 只能 **`get()` 一次**（一次性取走结果）
    
- `get()` 会阻塞当前线程，直到结果 ready 或抛异常
    
- 支持 `wait()` / `wait_for()` / `wait_until()` 非阻塞等待
    

简单例子：

```C++
#include <future>
#include <iostream>

int slow_add(int a, int b) {
    // 假装很慢
    std::this_thread::sleep_for(std::chrono::seconds(1));
    return a + b;
}

void example_future() {
    std::future<int> fut = std::async(std::launch::async,
                                      slow_add, 1, 2);
    // 这里主线程可以干别的事情
    int result = fut.get(); // 阻塞直到 slow_add 完成
    std::cout << result << "\n";
}
```

### 2.2 `std::promise<T>`：手工“注入结果”的一端

`future` 是“消费端”；`promise` 是“生产端”。  
它们成对使用：

```C++
#include <thread>
#include <future>

void worker(std::promise<int> p) {
    try {
        // 做一些计算
        int result = 42;
        p.set_value(result);         // 把结果塞进 promise
    } catch (...) {
        p.set_exception(std::current_exception()); // 把异常传给 future
    }
}

void example_promise() {
    std::promise<int> p;
    std::future<int> f = p.get_future();

    std::thread t(worker, std::move(p)); // p 不可复制，只能 move
    t.detach();
    int x = f.get(); // 阻塞等待 worker 调用 set_value
}
```

这几步发生了：

1. `p` 和 `f` 通过 `get_future()` 建立了一块 shared state：
    
    `p-->p.set_value()---> shared state ---->p.get_future()---->f--->f.get()`
    
2. `std::thread t(worker, std::move(p));`
    
    - 这里 `worker` 的形参类型是 `std::promise<int>`（按值传递）；
        
    - 你传入的是 `std::move(p)`，于是：
        
        - 在新线程里构造了一个**新的 `promise<int>` 对象（记为 `p_worker`）**，  
            它通过 **move 构造**从原来的 `p` 接管了那块 shared state 指针；
            
        - 原来的 `example_promise` 作用域里的 `p` 变成 **moved-from 状态**，  
            即“不再关联任何 shared state”（内部指针置空）。
            

此时关系变成：

```txt
example_promise 里的 p   (moved-from, 空了)
                                   \
                                    X  不再指向 shared state

worker 线程里的 p_worker  --->  [ shared state ]  <---  f
```

**所以：**

> move 之后，`promise` 的“控制权”已经在 worker 线程里那个 `p_worker` 手上，  
> `example_promise` 里那个 `p` 已经被掏空了。

1. 当 `worker` 返回时，`p_worker` 被析构：
    
    - `p_worker` 释放对 shared state 的“promise 端引用”。
        

但是 shared state 依然被 `future f` 持有：

```C++
( p_worker 已经析构 )
                        [ shared state: value=42, ready ]  <---  f
```

**此时“控制权”的状态是：**

- 没有任何 `promise` 了（promise 端已经销毁）；
    
- shared state 还活着，因为 future 端的 `f` 仍在；
    
- 一旦 `f.get()` 被调用，就把值取出；
    
- 当 `f` 也析构掉之后，shared state 最终被释放。



可以看到：

- 你用 `promise` 在一个线程里手动 `set_value`，
    
- 另一个线程通过 `future` 在 `get()` 里拿到结果。
    

> 这是底层构件，一般会被封装在更高层，比如线程池或者 async 框架里。

### 2.3 `std::async`：最简单的“任务+线程”的封装

`std::async` 本质上干的事就是：

1. 启动一个异步任务（可能是新线程，也可能延迟执行）
    
2. 返回一个 `std::future<R>` 作为结果占位符
    

```C++
auto fut = std::async(std::launch::async, []{
    // 后台干活
    return 42;
});
// ...
int x = fut.get();
```

第二个参数是 callable，后面跟参数列表。  
启动策略：

```C++
std::async(std::launch::async, f, args...);    // 立即在新线程异步执行
std::async(std::launch::deferred, f, args...); // 延迟，直到你第一次 get()/wait() 时才在当前线程执行
```

不写时，编译器可以自行选择（可能 async，也可能 deferred），  
**所以工程中建议显式写 `std::launch::async`**，避免行为不确定。

---

## 3. 再往上一层：基于 `packaged_task` 封装一个线程池

你会发现 `std::async` 有几个问题：

- 它通常为每个任务创建新线程，没有线程池，频繁建/销线程很重
    
- 没有统一的任务队列，也不好做复杂调度
    
- 不能轻易做“自定义排队策略”
    

更实用的是把任务抽象成：

`std::packaged_task<R()> task;`

然后丢进线程池里跑，拿回一个 `future<R>`。

### 3.1 `std::packaged_task`：callable → future 的适配器

例子：

```C++
std::packaged_task<int(int,int)> task(slow_add);
std::future<int> fut = task.get_future();
std::thread t(std::move(task), 1, 2); // 在线程里执行 task(1,2)
t.detach();
int result = fut.get(); // 等 slow_add 完成
```

`packaged_task` 做了什么？

- 把一个可调用对象（函数/lamda）包一层；
    
- 调用它时自动把结果或者异常写进自己内部的 `promise`；
    
- 外部通过它的 `future` 拿结果。
    

这是构建线程池的完美积木。

### 3.2 极简 ThreadPool 示例（核心思想）

只展示核心模式，不写所有边界检查：

```C++
#include <vector>
#include <thread>
#include <future>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <functional>

class ThreadPool {
public:
    explicit ThreadPool(size_t n) : stop_(false) {
        for (size_t i = 0; i < n; ++i) {
            workers_.emplace_back([this]{
                for (;;) {
                    std::function<void()> task;
                    {
                        std::unique_lock<std::mutex> lk(m_);
                        cv_.wait(lk, [&]{
                            return stop_ || !tasks_.empty();
                        });
                        if (stop_ && tasks_.empty()) return;
                        task = std::move(tasks_.front());
                        tasks_.pop();
                    }
                    task(); // 在锁外执行任务
                }
            });
        }
    }

    ~ThreadPool() {
        {
            std::lock_guard<std::mutex> lk(m_);
            stop_ = true;
        }
        cv_.notify_all();
        for (auto& t : workers_) {
            if (t.joinable()) t.join();
        }
    }

    template<typename F, typename... Args>
    auto submit(F&& f, Args&&... args)
        -> std::future<std::invoke_result_t<F, Args...>>
    {
        using R = std::invoke_result_t<F, Args...>;

        auto task = std::make_shared<std::packaged_task<R()>>(
            std::bind(std::forward<F>(f),
                      std::forward<Args>(args)...)
        );

        std::future<R> fut = task->get_future();
        {
            std::lock_guard<std::mutex> lk(m_);
            tasks_.emplace([task]{ (*task)(); });
        }
        cv_.notify_one();
        return fut;
    }

private:
    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    std::mutex m_;
    std::condition_variable cv_;
    bool stop_;
};
```

用法：

```C++
ThreadPool pool(4);

auto f1 = pool.submit([]{ return heavy_compute1(); });
auto f2 = pool.submit([]{ return heavy_compute2(); });

int r1 = f1.get();
int r2 = f2.get();
```

**你看到的高层抽象是：**

- “提交任务 → 拿一个 future”
    
- 而线程创建 / 阻塞等待 / 任务队列 / 条件变量都被封装在 ThreadPool 里了
    

这就是典型的**高层异步抽象：任务 + future + 线程池**。

---

## 4. Continuation 风格：任务链 vs 阻塞等待
[[C++Continuation 风格：任务链 vs 阻塞等待]]
标准库的 `future.get()` 是阻塞式的：调用者停下来等结果。  
很多库会提供一个 **continuation 风格**的 API：

```C++
auto fut2 = fut1.then([](int x){
    // fut1 完成之后，用结果 x 再启动下一个异步任务
    return x * 2;
});
```

这样你可以写“异步任务链”，而不是：

```C++
auto f1 = pool.submit(...);
auto f2 = pool.submit(...);
// 阻塞等待
int x = f1.get();
int y = f2.get();
```

标准库现在还没有官方的 `.then()`，但很多第三方库（如 folly、boost、cppcoro 等）都提供类似概念：**future + continuation**，这就是更高抽象的异步任务组合。

---

## 5. C++20 协程：语言级的异步抽象[[C++协程]]

前面所有东西本质上都是“**多线程 + 阻塞**”：

- future.get() 阻塞等待
    
- condition_variable 阻塞等待
    

**协程（coroutine）**带来的是另外一类抽象：

> **把“异步状态机”变成看起来像同步的代码写法，但实际在等待时不阻塞线程。**

### 5.1 直觉对比：线程 vs 协程

- 线程：
    
    - 每个线程有自己的调用栈（stackful）
        
    - 切换由 OS / 运行时决定（抢占式）
        
    - `std::this_thread::sleep_for` 会占用一个 OS 线程
        
- 协程：
    
    - 是“编译器帮你生成的状态机”（stackless）
        
    - 切换点由你显式写 `co_await` 决定（协作式）
        
    - `co_await 某个异步操作` 时，协程可以被挂起，线程归还给线程池去干别的
        

### 5.2 一个极简的协程 Task 示例（概念示意）

你可以想象有一个自定义的 `task<T>` 类型，支持 `co_await`：

```C++
task<int> fetch_remote_data();
task<void> process_all() {
    int x = co_await fetch_remote_data(); // 看起来像同步写法
    int y = co_await fetch_remote_data();
    co_return; // 完成
}
```

**但运行时行为是：**

- 调用 `process_all()` 时，不一定立刻跑完；遇到 `co_await` 时挂起自己；
    
- 底层网络库（或线程池）在 IO 完成时把协程“唤醒”，继续从挂起点往下执行；
    
- 整个过程不需要一直占用一个物理线程。
    

标准库提供的是**语法层面**的东西（`co_await/co_yield/co_return` + coroutine_traits），  
真正的“`task<>` 类型、事件循环、定时器、IO 库”通常由框架提供（如 Boost.Asio, cppcoro, etc）。

### 5.3 协程与我们前面讲的 future 的关系

你可以这样理解：

- `std::future` 提供“**一个值稍后可用**”的容器；
    
- 协程 + `co_await` 提供“**当这个值没准备好时，我先挂起自己，让线程去干别的**”。
    

很多现代库会把：

- “异步 IO / 异步计算返回一个 awaitable 对象（本质上也含有类似 future 的语义）”
    
- 协程 `co_await` 这个 awaitable，编译器帮你把整个函数改写成状态机
    

这就是**更高层的异步抽象**：  
你用的是“类似同步的写法”，底层还是在用线程池、事件循环、原子、锁。

---

## 6. 更高层的并发模型：actor / 消息队列 / pipeline

在任务、future、协程之上，工程里常见还有更高一层的“模型化”抽象。

### 6.1 Actor 模型（消息驱动的对象）

一个典型的 Actor 模式是：

- 每个 actor：
    
    - 有自己的**私有状态**
        
    - 只通过**消息队列**接收外部请求
        
    - 通常由一个线程顺序处理队列里的消息（或者在某个执行器上串行调度）
        

优点：

- 不共享可变状态 → 基本不需要细粒度锁
    
- 并发问题变成了“消息顺序 + 队列容量”的问题
    

你可以用 C++ 写一个简化版：  
actor 内部用一个 `BlockingQueue<Message>` + 单独线程/协程消费消息。

### 6.2 Pipeline / Stage 模式

典型模式：

1. 读取 → 解析 → 处理 → 写回
    
2. 每个阶段一个线程池或 actor，之间通过队列连接：
    

`[producer threads] → [Parse Stage] → [Compute Stage] → [Sink Stage]`

这是更宏观的**并行化抽象**。  
底层仍然用：

- 阻塞队列（生产者-消费者）
    
- future / promise 传递结果
    
- 或 coroutine + channel
    

---

## 小结：把这一章压成几句话

1. **底层原语**：`thread` / `mutex` / `condition_variable` / `atomic`
    
    - 解决的是“如何正确地并发读写内存”
        
2. **第一层高抽象**：`future` / `promise` / `packaged_task` / `async`
    
    - 把“线程”抽象成“任务 + 返回值”
        
3. **线程池 + 任务队列**：
    
    - 多任务跑在有限线程上 → 提高资源利用率，简化任务生命周期管理
        
4. **Continuation + 协程**：
    
    - 把“异步状态机”写成像同步一样的代码
        
    - `co_await` / `co_return` 让编译器帮你生成状态机
        
5. **更高层模型（actor / pipeline）**：
    
    - 站在系统架构视角组织并发，尽量减少共享状态和锁