## 0. `unique_ptr` 的定位

一句话：

> `unique_ptr<T>` 是**独占所有权**的智能指针，负责在生命周期结束时自动 `delete`（或自定义 deleter）。

独占 = **同一资源同时只能被一个 unique_ptr 拥有**。  
所以它：

- **不可拷贝**
    
- **可移动**
    
- 几乎零开销（通常大小≈一个裸指针）
    

---

## 1. 为什么要用它？（解决裸指针痛点）

### 裸指针常见灾难

```C++
Foo* p = new Foo();
do_something();
if (error) return;  // 泄漏！忘了 delete
delete p;
```

异常/早退/多路径一多就炸。

### unique_ptr 的 RAII

```C++
auto p = std::make_unique<Foo>();
do_something();
if (error) return;  // 自动析构 + delete，无泄漏
```

---

## 2. 基本创建方式

### 2.1 推荐：`std::make_unique`

```C++
#include <memory>
auto p = std::make_unique<int>(42);
auto q = std::make_unique<Foo>(arg1, arg2);
```

优点：异常安全、代码更短。

### 2.2 也可以手动 `new`

```C++
std::unique_ptr<Foo> p(new Foo());
```

但不推荐在复杂表达式里交叉写 `new`（不够安全、可读性差）。

---

## 3. 所有权语义：不可拷贝，可移动

### 3.1 不可拷贝

```C++
auto p = std::make_unique<Foo>();
auto q = p; // ❌ 编译错误：copy deleted
```

### 3.2 移动（转移所有权）

```C++
auto p = std::make_unique<Foo>();
auto q = std::move(p);  // ✅ p 变空，q 接管资源
```

移动后的 `p`：

- 仍然是合法对象
    
- 但**不再拥有资源**（通常等于 `nullptr`）
    

---

## 4. 常用接口（你必须熟练）

假设：

```C++
std::unique_ptr<Foo> p = std::make_unique<Foo>();
```

### 4.1 访问

```C++
p->bar();  // 像指针一样
(*p).bar();
Foo* raw = p.get();  // 只“借用”裸指针，不转移所有权
```

### 4.2 判空

```C++
if (p) { ... }          // bool 检查
if (p == nullptr) { ... }
```

### 4.3 释放/重置/换指向

```C++
p.reset();              // delete 当前对象，p 变空
p.reset(new Foo());     // delete 旧的，再接管新的

Foo* raw = p.release(); // 放弃所有权，不 delete，p 变空
// 你必须手动 delete raw 或交给另一个 smart pointer
delete raw;
```

> `release()` 是“转交前的最后逃生门”，用完一定要有人接管或 delete。

---

## 5. 自定义 deleter（管理非 new 的资源）

## 1. unique_ptr 的模板长什么样？

```C++
template<class T, class Deleter = std::default_delete<T>>
class unique_ptr;
```

也就是说：**deleter 是模板参数的一部分**，它不是运行时的“可选回调”，而是**编译期类型的一部分**。
[[C++删除器]]
所以：

```C++
std::unique_ptr<FILE>                 // deleter = default_delete<FILE>
std::unique_ptr<FILE, decltype(&fclose)>
```

是 **两种完全不同的类型**。

这会影响：

- `sizeof(unique_ptr)` 的大小
    
- 它能不能互相赋值/移动
    
- 能不能放进同一个容器
    
- API 设计（返回类型要写对 Deleter）
    

---

## 2. Deleter 的要求是什么？

Deleter 需要是一个“可调用对象”，能被这样用：

`Deleter d; d(ptr);  // ptr 的类型是 T*`

也就是满足：

- 函数对象（`operator()(T*)`）
    
- 函数指针
    
- lambda（有 `operator()`）
    

---

## 3. 什么时候会调用 deleter？

**只要 unique_ptr 认为自己“拥有一个非空指针”，就会在释放时调用 deleter。**

释放时刻包括：

1. 析构
    
2. `reset()`（先删旧的）
    
3. move 赋值覆盖旧资源
    

但 **`release()` 不会调用 deleter**（它放弃所有权）。

```C++
auto p = ...;
p.reset();    // 调 deleter(p.get())
auto raw = p.release(); // 不调 deleter
```

---

## 4. 为什么 deleter 是“类型的一部分”？

因为 C++ 想让 deleter **零开销抽象**：

- 如果 deleter 编译期就确定，编译器可以内联、优化掉虚调用。
    
- 不需要额外的 type-erasure/虚表/堆分配。
    

代价就是：不同 deleter → 不同类型。

---

## 5. deleter 会影响 unique_ptr 大小（EBO）

unique_ptr 内部大致像这样：

```C++
T* ptr;
Deleter del;
```

所以 sizeof 看 deleter 是否“占空间”。

### 5.1 空 deleter（stateless）通常不增加大小

比如 `std::default_delete<T>`、无捕获 lambda、空 functor  
编译器会用 **EBO（空基类优化）** 把 `del` 压成 0 字节。

结果是：

`sizeof(unique_ptr<T>) == sizeof(T*)`

### 5.2 有状态 deleter 会让 unique_ptr 变大

比如捕获 lambda、带成员的 functor：

```C++
struct D {
    int tag;
    void operator()(Foo* p) const { /*...*/ delete p; }
};

std::unique_ptr<Foo, D> p(new Foo, D{7});
```

这时：

- unique_ptr 里要存一个 `D`（tag=7）
    
- size = 指针 + deleter 的大小（再受对齐影响）
    

---

## 6. 函数指针 deleter（你例子 5.1）

```C++
auto fp = std::unique_ptr<FILE, decltype(&fclose)>(
    fopen("a.txt", "r"), &fclose);
```

解释：

1. `decltype(&fclose)` 是类型：`int(*)(FILE*)`
    
2. unique_ptr 存了：
    
    - `FILE*`
        
    - 一个“函数指针 deleter”（8 字节左右）
        
3. 析构时会做：
    
    `if (ptr) fclose(ptr);`
    

**优缺点：**

- ✅ 简单、类型统一、可放容器
    
- ❌ deleter 是函数指针 → usually 不能 EBO，所以 unique_ptr 变大
    
- ❌ 函数指针不能携带额外状态
    

更“现代”的等价写法（更清晰）：

```C++
using FilePtr = std::unique_ptr<FILE, int(*)(FILE*)>;
FilePtr fp(fopen("a.txt","r"), fclose);
```

---

## 7. lambda deleter（你例子 5.2）

你写的是“把 lambda 转成函数指针”的版本：

```C++
auto sock = std::unique_ptr<int, void(*)(int*)>(
    new int(fd),
    [](int* p){ close(*p); delete p; }
);
//模板参数int指的是被接管变量的原始类型（T* ptr）
```

这里 lambda **没有捕获**，所以可以隐式转换为函数指针 `void(*)(int*)`。

### 7.1 更常见写法：直接用 lambda 的闭包类型

```C++
auto del = [](int* p){ close(*p); delete p; };
std::unique_ptr<int, decltype(del)> sock(new int(fd), del);
```

- `decltype(del)` 是一个**匿名闭包类型**
    
- 这个闭包类型是空的（无捕获） → 可能 EBO，unique_ptr 不一定变大
    
- 但类型很“长”，而且每个 lambda 都是不同类型
    

### 7.2 捕获 lambda（有状态 deleter）

```C++
int tag = 7;
auto del = [tag](Foo* p){ log(tag); delete p; };

std::unique_ptr<Foo, decltype(del)> p(new Foo, del);
```

- deleter 有状态 → unique_ptr 里得存 tag
    
- size 会变大
    
- 这种写法非常适合“释放时要带参数”的场景
    

---

## 8. “不同 deleter 是不同类型”带来的实际影响

### 8.1 不能互相赋值/移动（除非满足可转换）

```C++
auto d1 = [](Foo* p){ delete p; };
auto d2 = [](Foo* p){ delete p; };

std::unique_ptr<Foo, decltype(d1)> p1(new Foo, d1);
std::unique_ptr<Foo, decltype(d2)> p2 = std::move(p1); // ❌ 类型不同
```

即使逻辑一样，也不行，因为 d1/d2 闭包类型不同。

### 8.2 解决办法：统一 deleter 类型

**方案 A：用函数指针类型统一**

```C++
using Del = void(*)(Foo*);
void delFoo(Foo* p){ delete p; }

std::unique_ptr<Foo, Del> p(new Foo, delFoo);
std::unique_ptr<Foo, Del> q = std::move(p); // ✅
//用函数做参数，他会变成函数指针，所以是指针类型
```
**方案 B：用同一个 functor 类型**

```C++
struct Del {
    void operator()(Foo* p) const { delete p; }
};
//而这里结构体直接原地构造，用Del结构体类型就行
std::unique_ptr<Foo, Del> p(new Foo, Del{});
std::unique_ptr<Foo, Del> q = std::move(p); // ✅
```

### 8.3 放进容器的影响

容器要求元素类型一致，所以：

```C++
std::vector<std::unique_ptr<Foo, decltype(lambda1)>> v; // 只能放同一种 deleter
```

如果你想混放不同 deleter 或不同指针类型，通常要：

- 把 deleter 统一
    
- 或用 `std::variant`
    
- 或退回 `shared_ptr`（type-erasure）
    

---

## 9. `make_unique` 为啥没法直接带 deleter？

`make_unique<T>(...)` 只能返回

```C++
std::unique_ptr<T, std::default_delete<T>>
```

如果要自定义 deleter，你必须显式写 unique_ptr 类型/构造函数：

```C++
auto del = [](Foo* p){ /*...*/ };
std::unique_ptr<Foo, decltype(del)> p(new Foo(args...), del);
```

---

## 10. 小结（记住这 4 句话）

1. **Deleter 是 unique_ptr 类型的一部分**：不同 deleter → 不同 unique_ptr 类型。
    
2. **unique_ptr 内部会存 deleter**，有状态 deleter 会让它变大。
    
3. **析构 / reset / 覆盖赋值时调用 deleter**；`release()` 不调用。
    
4. 想让不同 unique_ptr 可互转/可放容器，**统一 deleter 类型**（函数指针/同一 functor）。
---

## 6. unique_ptr 管数组：`unique_ptr<T[]>`

```C++
std::unique_ptr<int[]> a(new int[10]);
a[3] = 7;
```

- 删除时会用 `delete[]`。
    
- **不能用 `make_unique<int[]>(n)` 之外的形式造数组时，也能手动 new。**
    

推荐（C++14+）：

```C++
auto a = std::make_unique<int[]>(10); // 10 个 int，值默认初始化为 0
```

---

## 7. 传参/返回：工程里最重要的用法

### 7.1 函数**接管所有权**

```C++
void take(std::unique_ptr<Foo> p) {
    // p 拿到所有权
}

take(std::make_unique<Foo>());     // 直接传右值
take(std::move(p));                // 从调用者转移
```

### 7.2 函数**只使用，不接管**

用裸指针/引用：

```C++
void use(const Foo* p);
void use(const Foo& r);

use(p.get());
use(*p);
```

这样调用者依然拥有资源。

### 7.3 函数返回 unique_ptr（最常见）

```C++
std::unique_ptr<Foo> make() {
    return std::make_unique<Foo>();
} // RVO/move，零成本
```

---

## 8. 多态场景（基类指针拥有派生对象）

```C++
struct Base { virtual ~Base() = default; };
struct Der  : Base {};

std::unique_ptr<Base> p = std::make_unique<Der>(); // ✅ 向上转型
```

> 关键：**基类析构函数必须是 virtual**，否则 delete Base* 会 UB。

---

## 9. 底层/性能直觉

- unique_ptr 通常只存 **一个指针**（+ deleter）
    
- deleter 若是空类，会触发 **EBO（空基类优化）**，从而不增加大小  
    所以大多数情况：`sizeof(unique_ptr<T>) == sizeof(T*)`
    
- **无引用计数，无原子操作**  
    所以比 shared_ptr 轻得多，且更符合“谁拥有谁负责”的直觉。
    

---

## 10. 常见坑（你一定会遇到）

1. **忘了 move**
    
    ```C++
	    std::unique_ptr<Foo> p = std::make_unique<Foo>();
	    std::unique_ptr<Foo> q = p; // ❌
		auto q = std::move(p);      // ✅
    ```
    
2. **release 后没人接管**
    
    ```C++
    Foo* raw = p.release(); // p 不再 delete
// raw 泄漏 unless delete/交给另一个 smart ptr
    ```
    
3. **管理同一裸指针两次**
    
    ```C++
    Foo* raw = new Foo;
std::unique_ptr<Foo> a(raw);
std::unique_ptr<Foo> b(raw); // ❌ double delete
    ```
    
    只允许一个 unique_ptr 接管。
    
4. **Base 析构非 virtual**
    
    ```C++
    struct Base { ~Base(){} };
	struct Der: Base {};
	std::unique_ptr<Base> p = std::make_unique<Der>(); // ❌ delete Base* UB
    ```
    

---

## 11. 什么时候选 `unique_ptr`？

几乎所有“单一拥有者”的资源都优先用它：

- 容器元素（vector<unique_ptr<T>>）
    
- 工厂函数返回
    
- 树/图结构的所有权边
    
- Pimpl（隐藏实现）
    
- 任何需要异常安全释放的资源
    

只有当你真的需要“多方共享生命周期”时，再考虑 `shared_ptr`。