## 1) 写文本文件（最常见）

```C++
#include <fstream>
#include <iostream>
#include <string>

int main() {
    std::ofstream fout("out.txt"); // 默认 ios::out | ios::trunc：打开并清空
    if (!fout.is_open()) {
        std::cerr << "open failed\n";
        return 1;
    }

    int x = 42;
    std::string s = "hello";

    fout << "x=" << x << "\n";
    fout << "s=" << s << "\n";

    // fout.close(); // 可省略，析构会自动 close
    return 0;
}
```

要点：

- `<<` 和 `cout` 写法一样。
    
- `"\n"` 不强制刷新，速度更好；一般不需要 `endl`。
    

---

## 2) 追加写（不覆盖旧内容）

```C++
#include <fstream>

int main() {
    std::ofstream fout("log.txt", std::ios::app); // 追加模式
    fout << "new line\n";
}

```

---

## 3) 写二进制文件（字节精确）

比如写一个结构体数组：

```C++
#include <fstream>
#include <vector>

struct Node {
    int id;
    double score;
};

int main() {
    std::vector<Node> v = {{1, 3.5}, {2, 7.9}};

    std::ofstream fout("data.bin", std::ios::binary | std::ios::trunc);
    fout.write(reinterpret_cast<const char*>(v.data()),
               static_cast<std::streamsize>(v.size() * sizeof(Node)));
    fout.flush(); // 可选：把缓冲推给 OS
}

```

要点：

- 一定加 `std::ios::binary`，避免 Windows 文本模式换行转换。
    
- `write(buf, n)` 是按字节写，不做格式化。
    
## 1) 为什么要这样打开文件？

`std::ofstream fout("data.bin", std::ios::binary | std::ios::trunc);`

- `std::ios::binary`：**二进制模式**  
    让库不要做任何文本层转换。  
    尤其在 Windows，如果不加 `binary`：
    
    - 写出的 `\n` 可能会被自动变成 `\r\n`
        
    - 读写字节数会对不上  
        二进制文件（图片、模型、结构体 dump 等）必须用它。
        
- `std::ios::trunc`：**打开就清空原文件**  
    你要“重新写一份完整文件”，就用 trunc。  
    如果你想在末尾追加，则用 `std::ios::app`。
    

---

## 2) `write()` 为什么要 `reinterpret_cast<const char*>`？

`fout.write(reinterpret_cast<const char*>(v.data()), ...);`

`write` 的签名是：

`ostream& write(const char* s, streamsize n);`

也就是说它只认识：

> “给我一个字节指针 + 要写多少字节”

但是 `v.data()` 的类型是 `Node*`（指向结构体），不是 `char*`。  
所以必须把它**视为一段连续字节内存**：

- `reinterpret_cast<const char*>(v.data())`  
    把 `Node*` 强转成 “指向首字节的指针”。  
    这只是**告诉编译器按字节看这段内存**，不改变内容。
    

---

## 3) 为什么字节数这样算？

`static_cast<std::streamsize>(v.size() * sizeof(Node))`

- `v.size()`：有多少个 `Node`
    
- `sizeof(Node)`：一个 `Node` 占多少字节
    
- 相乘得到**总字节数**
    

而 `write` 的第二个参数类型是 `std::streamsize`（有符号整型）。  
`v.size() * sizeof(Node)` 结果是 `size_t`（无符号）。  
为了避免类型警告/潜在溢出歧义，显式 cast 到 `streamsize`。

---

## 4) 这写法的前提（非常重要）

这种“原样 dump 内存”只有在 **`Node` 是可平凡拷贝(trivially copyable / POD-like)** 时才安全，例如：

`struct Node {     int id;     double score; };`

✅ 这种没问题。

但如果 `Node` 里有：

- `std::string`
    
- 指针
    
- 虚函数 / 继承
    
- 自己管理资源的成员  
    那你写出去的只是**指针值/内部地址**，读回会全坏。
---

## 4) 同时读写：`fstream`

```C++
#include <fstream>
#include <string>

int main() {
    std::fstream fs("data.txt", std::ios::in | std::ios::out);
    if (!fs) return 1;

    fs.seekp(0, std::ios::end); // 写指针挪到末尾
    fs << "append via fstream\n";
}

```

---

## 5) 写入失败的检查方式

### 方式 A：写完检查状态

`fout << "abc\n"; if (fout.fail()) {     // 写失败（磁盘满/权限问题等） }`

### 方式 B：让流抛异常（更工程）

```C++
std::ofstream fout("out.txt");
fout.exceptions(std::ios::failbit | std::ios::badbit);

try {
    fout << "hello\n";
} catch (const std::ios_base::failure& e) {
    // 处理写失败
}

```

---

## 6) 一个“稳妥的批量写模板”（按行写）

```C++
#include <fstream>
#include <vector>
#include <string>

void write_lines(const std::string& path,
                 const std::vector<std::string>& lines) {
    std::ofstream fout(path, std::ios::out | std::ios::trunc);
    if (!fout) throw std::runtime_error("open failed");

    for (auto& line : lines) {
        fout << line << '\n';
    }
}

```
