## 1. 为什么需要锁？——从内存模型讲起

多线程问题的根源是：**共享可变状态（shared mutable state）**。

假设两个线程同时改同一个 `int x`：

`x = x + 1;`

这不是原子操作，实际拆成：

1. 读 x
    
2. 加 1
    
3. 写回 x
    

两个线程交错时就会丢失更新。更糟的是，**编译器/CPU 还会重排指令**，导致“你以为的执行顺序”不一定是真的。

### 锁提供两类保证

1. **互斥（Mutual Exclusion）**  
    同一时刻只允许一个线程进入临界区。
    
2. **同步/可见性（Synchronization / Visibility）**  
    C++ 标准规定：
    
    - `mutex.unlock()` 具有 **release** 语义
        
    - `mutex.lock()` 具有 **acquire** 语义  
        于是：
        
    
    > 在 A 线程 unlock 前发生的写入，对 B 线程 lock 后可见。  
    > 这叫 **happens-before**。
    

所以锁不仅“防并发写冲突”，还“强制建立跨线程的可见性顺序”。

---

## 2. `std::mutex` 家族（互斥量类型）

### 2.1 `std::mutex`（最常用）

- 非递归
    
- 不可复制
    
- `lock()` 会阻塞直到拿到锁
    
- `try_lock()` 立即返回 bool
    

```C++
std::mutex m;
m.lock();
// 临界区
m.unlock();
```

### 2.2 `std::recursive_mutex`

同一线程可重复加锁（内部有计数）。
[[C++recursive_mutex]]
```C++
std::recursive_mutex rm;

void dfs(int n){
    std::lock_guard lg(rm);
    if(n) dfs(n-1); // 同线程二次 lock 不会死锁
}
```

**谨慎用**：递归锁往往掩盖了糟糕的设计（比如不清晰的锁边界）。

### 2.3 `std::timed_mutex` / `std::recursive_timed_mutex`

支持超时锁：

```C++
std::timed_mutex tm;
if (tm.try_lock_for(std::chrono::milliseconds(10))) {
    // 抢到了
    tm.unlock();
} else {
    // 10ms 内没抢到
}
```

适合“抢不到就退避/降级”的系统。

### 2.4 `std::shared_mutex`（读写锁，C++17）

- 读锁（共享锁）可并发
    
- 写锁（独占锁）互斥且排它
    

```C++
std::shared_mutex sm;

void reader(){
    std::shared_lock lk(sm); // 多读者并行
    // read-only
}

void writer(){
    std::unique_lock lk(sm); // 写者独占
    // write
}
```

读多写少时性能显著优于普通 mutex。[[C++ shared_mutex]]

---

## 3. RAII 锁封装（你提到的 lock_guard 等）

### 3.1 `std::lock_guard`：最小、最硬的 RAII

```C++
std::lock_guard<std::mutex> lk(m);
```

特性：

- 构造时 `lock()`
    
- 析构时 `unlock()`
    
- **没有任何别的接口**
    
- 不能 move / copy
    

用途：

> 临界区范围固定，不需要中途解锁。[[C++lock_guard]]

### 3.2 `std::unique_lock`：可控的 RAII

```C++
std::unique_lock<std::mutex> lk(m);
lk.unlock();
// ...
lk.lock();
```

支持能力：

- **提前解锁**
    
- **延迟加锁**
    
- **try / timed lock**
    
- **可 move（转移锁所有权）**
    
- **配合 condition_variable**
    

#### 延迟加锁例子

```C++
std::unique_lock lk(m, std::defer_lock);
// 做一些不需要锁的准备工作
lk.lock(); 
```

#### 尝试加锁例子

```C++
std::unique_lock lk(m, std::try_to_lock);
if(!lk.owns_lock()) return;
```

#### 重要 API

- `owns_lock()`：当前是否持锁
    
- `release()`：放弃对 mutex 的管理（不解锁，返回裸 mutex*）
    
- `mutex()`：取回内部 mutex 指针
    
[[C++unique_lock]]
### 3.3 `std::scoped_lock`：多锁无死锁（C++17）

```C++
std::scoped_lock lk(m1, m2, m3);
```

它内部等价于：

```C++
std::lock(m1, m2, m3);
std::lock_guard l1(m1, std::adopt_lock);
std::lock_guard l2(m2, std::adopt_lock);
std::lock_guard l3(m3, std::adopt_lock);
```

所以它能避免常见的“交叉锁顺序导致死锁”。

---

## 4. `std::lock` / `std::try_lock`（低层多锁工具）

你也可以手动组合多锁：

```C++
std::lock(m1, m2); // 无死锁同时加锁

std::lock_guard l1(m1, std::adopt_lock);
std::lock_guard l2(m2, std::adopt_lock);
```

`adopt_lock` 的意思是：

> “这把 mutex 已经 lock 过了，你别再 lock 了，只负责析构 unlock。”

如果你想“尽量抢到全部锁，否则一个都不要”：

```C++
if (std::try_lock(m1, m2) == -1) {
    // 两把都抢到了
} else {
    // 抢失败，try_lock 会把已拿到的锁自动释放
}
```

---

## 5. 条件变量：锁 + 等待/唤醒

条件变量是“线程在某条件满足前睡眠”的机制。  
必须配合 **unique_lock**，因为 wait 期间要临时解锁。

```C++
std::mutex m;
std::condition_variable cv;
bool ready = false;

void consumer(){
    std::unique_lock lk(m);
    cv.wait(lk, [&]{ return ready; }); // 推荐谓词版本
    // 条件满足了，继续
}

void producer(){
    {
        std::lock_guard lk(m);
        ready = true;
    }
    cv.notify_one();
}
```

### 为什么一定要用谓词版本？

因为 **虚假唤醒（spurious wakeup）** 是标准允许的。  
不用谓词你就得手写 while 重新检查条件。
[[C++condition_variable]]

---

## 6. 死锁：成因与系统化规避

### 6.1 两大成因

1. **锁顺序不一致**  
    A 线程锁 m1→m2  
    B 线程锁 m2→m1
    
2. **持锁等待外部事件**  
    比如持锁做 IO、sleep、等待回调、等待别的线程 join。
    

### 6.2 规避规则（工业界通用）

- **固定锁顺序**（比如总是按地址从小到大锁）
    
- **多锁用 scoped_lock / std::lock**
    
- 临界区内只做“更新共享状态”，不要做慢操作
    
- 必要时做 **锁分层（lock hierarchy）**
    

---

## 7. 锁粒度与性能

锁正确了不代表快。常见性能坑：

### 7.1 大锁（coarse-grained lock）

全部共享数据一把锁 → 吞吐低。

优化：

- 拆锁（不同资源用不同 mutex）
    
- 分段锁（sharding / stripes）
    
- 读写锁
    

### 7.2 临界区过大

锁内做太多工作，比如：

- 网络收发
    
- 磁盘 IO
    
- 复杂计算
    

优化：

- 临界区只保护共享状态
    
- 先把数据拷出来，锁外处理
    

### 7.3 竞争导致 cache 抖动

高竞争下原子计数/锁会导致缓存一致性“来回打架”。

优化：

- 减少共享写热点（例如分桶计数）
    
- 使用 thread-local 聚合后再合并
    

---

## 8. 什么时候用锁？什么时候用 atomic？

### atomic 适合：

- 单变量计数器、标志位
    
- “无锁结构”的基础组件
    

```C++
std::atomic<int> cnt{0};
cnt.fetch_add(1, std::memory_order_relaxed);
```

### lock 适合：

- 多变量要维持不变式（invariant）
    
- 跨结构的复合更新
    

```C++
struct S { int a, b; }; 
// 要保证 a<=b
std::mutex m;
S s;

void update(){
    std::lock_guard lk(m);
    s.a++;
    s.b += 2;
}
```

**核心：只要你要维护“关系”，就用锁。**

---

## 9. 常见错误清单（你做系统/测量时极易踩）

1. **从临界区返回引用/指针**
    
    ```C++
    T& get(){
    std::lock_guard lk(m);
    return data;   // ❌ 锁一释放，外部可能并发改 data
	}
    ```
    
2. **锁内调用外部回调**  
    外部回调可能再来锁你 → 自死锁。
    
3. **析构里抢锁**  
    复杂生命周期下会形成“析构链死锁”。
    
4. **忘了锁是“可见性屏障”**  
    只用 atomic 但又跨变量考虑顺序，仍可能错。
    

---

## 10. 选型总结（更细化一点）

- **范围简单、无条件等待**  
    ✅ `lock_guard`
    
- **需要 wait/notify、提前 unlock、try/timed**  
    ✅ `unique_lock`
    
- **一次拿多把锁**  
    ✅ `scoped_lock` / `std::lock`
    
- **读多写少**  
    ✅ `shared_mutex + shared_lock`
    
- **递归结构必须重入**  
    ⚠️ `recursive_mutex`（先检查设计）
    

---