#### `volatile` 的本质：告诉编译器“这个值很可能被你看不见的东西改动”

语言层面一句话：

> **`volatile` 告诉编译器：对这个对象的读写，绝对不能被优化掉、合并、缓存，必须每次都真的去内存里“动一次手”。**

比如：

```C++
volatile int flag;

void spin() {
    while (flag == 0) {
        // busy wait
    }
}

```

如果没有 `volatile`，编译器可能这样想：

- `flag` 在这个函数里从来没被修改；
    
- 又没看到别的代码改它；
    
- 那我完全可以把 `flag == 0` 读一次，放在寄存器里，然后把 `while` 优化成死循环：
    
    ```C++
    int tmp = flag;           // 读一次 
    while (tmp == 0) {}       // 优化后：永远不再读内存
    ```
    

加上 `volatile` 后，编译器必须按照语言规则：

- **每次 `flag` 的读取都要真的发一次“读内存”的指令**；
    
- 不能把它缓存到寄存器里当成不变的值。
    

所以：

`while (flag == 0) {}`

会被编译成类似：

```C++
.L1:
    mov eax, [flag]    ; 每次循环都从内存读 flag
    test eax, eax
    je .L1

```

这是 `volatile` 的**核心语义**：  
**对这个变量的每一次读写“都有副作用”，不能按 as-if 规则随便优化。**

---

## 2. 很重要：`volatile` 只是约束“编译器优化”，不是“线程同步原语”

这句话很关键：

> **`volatile` 不保证：**
> 
> - 多线程可见性（memory visibility）
>     
> - 原子性 (`++x` 仍然可能被拆成读-改-写，存在竞争）
>     
> - 顺序性（不同 volatile 变量之间的重排、跨线程先后）
>     

它只保证：

- 对同一个线程的源码里写的 `volatile` 读/写不会被删除、不会被合并；
    
- 那一条语句内，对这个变量的访问顺序按你写的来；
    
- 但是对**其他普通变量**、对**多线程交互**，它不插手。
    

### 举个“看起来很像同步，实际上不行”的例子：

```C++
volatile int ready = 0;
int data = 0;

void producer() {
    data = 42;     // 普通写
    ready = 1;     // volatile 写
}

void consumer() {
    while (ready == 0) {}  // volatile 读
    std::cout << data << "\n";
}

```

你直觉上可能以为：

- `ready` 变成 1 之前，`data` 已经写好了；
    
- consumer 看到 `ready == 1` 时，`data` 一定是 42。
    

但标准层面：

- 对 `data` 的读写没有任何同步保证；
    
- CPU 和编译器可以对 `data` 的写、`ready` 的写、consumer 里的读重排；
    
- 这是**数据竞争（data race）+ 未定义行为**。
    

正确做法需要 `std::atomic` + 合法的内存序（`memory_order_seq_cst` / `release/acquire` 等），而不是 `volatile`。

> 结论：  
> **多线程同步、线程间通信，不要指望 volatile，应该用 `std::atomic`、mutex、condition_variable 等。**

---

## 3. 那 `volatile` 到底有啥用？

三个“经典”用途：

### 3.1 内存映射 I/O（Memory-mapped I/O）

在嵌入式 / 驱动 / 操作系统里，经常会把硬件寄存器映射到某段内存地址：

```C++
#define REG_STATUS  (*reinterpret_cast<volatile uint32_t*>(0x40000000))

uint32_t read_status() {
    return REG_STATUS;
}

```

- 这个地址不是“普通 RAM”，而是硬件寄存器；
    
- 读一次可能触发硬件行为（比如清除中断、启动 DMA 等）；
    
- 写一次也可能是一条指令；
    
- 编译器**绝不能把读写优化掉 / 合并 / 重排**。
    

这里 `volatile` 的意思是：

> “对这个地址的每一次读写都必须实打实地去做，因为它有副作用，而不仅仅是‘拿个值’。”

---

### 3.2 信号处理、`setjmp`/`longjmp` 等异步控制流

C/C++ 标准还提到：

- 在 `signal` handler 中；
    
- 或 `setjmp` / `longjmp` 那类跳跃控制流中；
    

**只有 `volatile` 变量在这些跨跳转操作后仍然有定义良好的值**。

例子（简化思路）：

```C++
volatile sig_atomic_t g_flag = 0;

void handler(int) {
    g_flag = 1;   // 在信号处理函数中修改
}

int main() {
    while (!g_flag) {
        // do something
    }
}

```

这里 `volatile` 保证：

- 在主循环里，编译器必须每次重新读 `g_flag`；
    
- 而不是缓存到寄存器认为它一直是 0。
    

---

### 3.3 极少数“手写忙等”的场景

比如你在某些硬件 / OS 接口下，操作系统 / 其他线程 / 中断会改某个内存标志位，而你在当前线程只能通过读取它来判断状态。

在一些旧的 C/cpp 代码里会看到类似：

```C++
volatile bool stop = false;

// 在另一个上下文里把 stop 改成 true

while (!stop) {
    // busy wait
}

```
但现代 C++ 里更推荐把这个设计成 `std::atomic<bool>`。

---

## 4. 和 `const` 的关系：可以一起用

`const volatile int reg = *addr;`

- `const`：从 C++ 代码逻辑上看，这个变量不能被程序修改；
    
- `volatile`：从编译器优化角度看，每次读都必须真的去访问底层（可能是硬件寄存器），不能缓存。
    

约等于：

> “**我不会改它，但有我看不见的东西在改，所以每次读都要去内存里看一眼**。”

---

## 5. `volatile` 修饰函数/成员函数的情况（少见但存在）

注意，这里不要和成员函数的 `const` 混淆——那是：

`struct X {     void foo() const;    // this 是 const X*，表示逻辑上不修改对象 };`

而 `volatile` 也可以修饰成员函数：

`struct X {     void foo() volatile;             // this 是 volatile X*     void foo() const volatile;       // this 是 const volatile X* };`

它们之间彼此都可以构成重载。  
但这一套极少用，大多只在一些非常底层的库里出现（比如用于区分 volatile 对象的访问）。

---

## 6. 相比 `std::atomic`，volatile 在多线程里几乎没价值

现代 C++11 之后，如果你在讨论的是“**线程之间的可见性 / 顺序 / 原子性**”，那正确工具是：

- `std::atomic<T>`
    
    - 保证原子读写；
        
    - 提供内存序（memory order）控制；
        
    - data race-free。
        

而不是：

- `volatile T`
    
    - 不保证原子；
        
    - 不保证跨线程可见性；
        
    - 不提供任何跨线程的顺序约束；
        
    - 依然可能 data race。
        

所以你可以直接给自己定一个认知：

> **在“普通应用开发 / 多线程并发”里，几乎永远不要考虑用 `volatile` 做同步。**  
> 真要跨线程通信，用 `std::atomic`、锁、条件变量。

---

## 7. 小结（帮你形成清晰 mental model）

你可以这样记：

1. **`volatile` 是对“编译器优化”的约束：**
    
    - 每次读写都必须真的去访问那块存储；
        
    - 不能把它当成死常量、不能合并/删除这些访问；
        
    - 适合应用在**会被外部因素改变的内存位置**（硬件寄存器、中断修改的标志位等）。
        
2. **它不是：**
    
    - 不是“多线程同步 primitive”；
        
    - 不是“原子操作”；
        
    - 不是“禁止 CPU 重排”的工具；
        
    - 不是“线程可见性”的保证。
        
3. **典型 legitimate 用法：**
    
    - memory-mapped I/O；
        
    - `sig_atomic_t` / 信号处理中的标志位；
        
    - 某些和 C 接口 / 内核交互的场景。
        
4. **如果你在普通业务代码里用 volatile 来玩并发，大概率是在制造 UB。**