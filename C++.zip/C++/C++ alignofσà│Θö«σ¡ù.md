`alignof` 是 C++11 引入的关键字/运算符，用来**在编译期查询一个类型或对象的对齐要求（alignment requirement）**，单位是字节。

---

## 1. `alignof(T)` 返回什么？

返回 **类型 T 的对齐值**（`std::size_t`），也就是：

> **T 的对象地址必须是多少字节的倍数。**

比如地址必须是 8 的倍数，就说对齐是 8。

---

## 2. 基本用法

### 查询类型对齐

```C++
#include <iostream>

int main() {
    std::cout << alignof(int) << "\n";
    std::cout << alignof(double) << "\n";
}
```

### 查询表达式/对象对齐

```C++
struct S { int a; double b; };
S s;
auto a1 = alignof(S);   // 类型
auto a2 = alignof(s);   // 表达式（等价于 alignof(S)）
```

---

## 3. 对齐和 `sizeof` 的区别

- `sizeof(T)`：对象占多少**字节大小**
    
- `alignof(T)`：对象地址需要满足的**对齐倍数**
    

例子：

```C++
struct A { char c; int x; };

sizeof(A)   // 可能是 8
alignof(A)  // 可能是 4
```

`sizeof` 受 padding 影响；`alignof` 只看最严格成员的对齐需求。

---

## 4. 结构体对齐规则（直观版）

结构体的对齐通常是 **所有成员对齐的最大值**：

```C++
struct X {
    char c;   // align 1
    int  i;   // align 4
};
alignof(X) == 4
```

结构体内会插 padding，让每个成员都满足自己的对齐。

---

## 5. 配合 `alignas` 改对齐

`alignas` 用来**指定**对齐，`alignof` 用来**查询**对齐。

```C++
struct alignas(16) Vec4 {
    float x, y, z, w;
};
static_assert(alignof(Vec4) == 16);
```
[[C++alignas关键字]]
### 注意：只能“加大”对齐，不能降低到非法值

```C++
struct B { double d; };
struct alignas(1) Bad : B {}; // ❌ 1 不够 double 的对齐要求，非法
```

---

## 6. over-aligned 类型

如果你指定的对齐 **超过平台默认最大对齐**，它就是 over-aligned：

```C++
struct alignas(64) CacheLine {
    int x;
};
alignof(CacheLine) == 64
```

这类类型用 `new`/容器时，标准库会保证满足对齐（C++17 起更完善）。

---

## 7. 常见用途

### (1) 手搓内存池/placement new 时算偏移

```C++
std::byte buf[128];

std::size_t off = 0;
off = (off + alignof(double) - 1) / alignof(double) * alignof(double);
double* p = new (buf + off) double(3.14);
```

### (2) 模板里做静态检查

```C++
template<class T>
void foo() {
    static_assert(alignof(T) <= alignof(std::max_align_t),
                  "T is over-aligned for this allocator");
}
```

### (3) SIMD / cache 对齐优化

```C++
alignas(32) float data[8];
static_assert(alignof(decltype(data)) == 32);
```

---

## 8. `std::max_align_t`

`alignof(std::max_align_t)` 是**该平台“默认 new 能保证的最大对齐”**（不是绝对上限，但很常用来判断是否 over-aligned）。

---

## 9. 小坑提醒

1. `alignof` 是编译期常量，但对**不完整类型**不行：
    
    `struct F;  alignof(F); // ❌ F 不完整`
    
2. `alignof(void)` 也是非法。
    
3. 不要把“对齐值”理解成“大小”；对齐常常小于大小，也可能大于某些成员大小。
    

---

一句话总结：  
`alignof` 用来告诉你 **“这个类型的对象地址必须按多少字节对齐”**，  
通常和内存布局、性能优化、手写分配器、二进制协议打交道时非常关键。