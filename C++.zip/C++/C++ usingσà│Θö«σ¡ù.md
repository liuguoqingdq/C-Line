```C++
using F1 = void(*)(); 
using F2 = void(*)(int);
```

这里的 `using` 不是“`using namespace std;`” 那个用法，而是 **“类型别名（type alias）” 的语法**。

---

## 1. 这两行到底干了什么？

```C++
using F1 = void(*)();
using F2 = void(*)(int);
```

等价于老式的 `typedef` 写法：

`typedef void (*F1)(); typedef void (*F2)(int);`

也就是说：

- `F1` 是一个类型：**指向“无参、无返回值函数”的函数指针类型**
    
    - 即：`void (*)()`
        
- `F2` 是一个类型：**指向“接收一个 int 参数、无返回值函数”的函数指针类型**
    
    - 即：`void (*)(int)`
        

用起来就是：

```C++
void foo() {}
void bar(int) {}

F1 p1 = &foo;   // OK
F2 p2 = &bar;   // OK

p1();      // 调用 foo
p2(42);    // 调用 bar(42)

```

所以这两行的作用就是：**给复杂的类型起一个更好记的名字**。

---

## 2. `using 别名` 的一般语法

通用形式是：

`using 新名字 = 某个类型;`

例如：

```C++
using i32 = int; 
using String = std::string; 
using IntVec = std::vector<int>;
```

等价于：

```C++
typedef int i32;
typedef std::string String;
typedef std::vector<int> IntVec;
```
---

## 3. 为啥要用 `using`，不用 `typedef`？

有两个主要原因：

### 3.1 可读性好，尤其遇到函数指针 / 模板时

比较一下函数指针：

`typedef void (*Func)(int);       // typedef 写法 using Func = void(*)(int);       // using 写法`

更明显的是模板里：

```C++
// typedef 写别名模板很麻烦，几乎写不了
template<typename T>
typedef std::vector<T> Vec;   // ❌ 不行

// using 可以写别名模板
template<typename T>
using Vec = std::vector<T>;   // ✅ OK
```
这个叫 **“别名模板（alias template）”**，在现代 C++ 里非常常用。

例如：

```C++
template<typename K, typename V>
using HashMap = std::unordered_map<K, V>;

HashMap<std::string, int> mp;   // 就是 std::unordered_map<std::string, int>
```
### 3.2 语序更自然

`typedef` 的“声明顺序”很怪：

`typedef 原类型 新名字;`

而 `using` 的顺序更正常：

`using 新名字 = 原类型;`

看复杂类型（比如函数指针 / 成员指针）时就很明显。

---

## 4. 和 `using namespace std;` 有什么区别？

**完全不是一回事，只是语法都叫 `using`。**

- `using 类型别名`：
    
    `using F1 = void(*)();   // 起一个类型别名`
    
- `using namespace std;`：  
    是 **引入命名空间里所有名字到当前作用域**，和类型别名无关。
    

还有一种是“using 声明”：

`using std::cout;   // 只把 std::cout 引进当前作用域`

和你问的这句也不是同一个功能。

你现在看到的这一段：

`using F1 = void(*)(); using F2 = void(*)(int);`

只跟“类型别名”相关，等价于 `typedef`，跟 namespace 没关系。