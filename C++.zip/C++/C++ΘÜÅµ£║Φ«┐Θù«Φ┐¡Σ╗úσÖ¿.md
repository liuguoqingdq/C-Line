Random Access Iterator（随机访问迭代器）就是**“像指针一样用的迭代器”**：在双向迭代器基础上，进一步保证你能 **O(1) 跳到任意位置、算距离、做下标访问**。它是 STL 里“能力最强（除 contiguous 外）”的迭代器类别之一。

-----
## 1. 定义：它比 Bidirectional 多了什么？

**Random Access Iterator = Bidirectional Iterator + 随机跳跃/距离 O(1)**。[eel.is+2Medium+2](https://eel.is/c%2B%2Bdraft/iterator.requirements?utm_source=chatgpt.com)

必须支持这些额外操作（都要是**常数复杂度**）：

### 1.1 跳跃与算术

```C++
it + n, it - n
it += n, it -= n
```

### 1.2 距离（差值）

```C++
it2 - it1   // 返回 difference_type，O(1)
```

### 1.3 下标

`it[n]   // 等价于 *(it + n)`

### 1.4 全序比较

`it1 < it2, <=, >, >=`

再加上 Bidirectional 的 `++/--` 和 `*it`。[Medium+1](https://medium.com/%40joao_vaz/c-iterators-and-implementing-your-own-custom-one-a-primer-72f1506e5d71?utm_source=chatgpt.com)

---

## 2. 直觉语义（“像指针一样”）

把 Random Access Iterator 当成指针看几乎不会错：  
**它支持指针算术和下标，所以 STL 算法可以做二分、堆、快排等操作。**

例如：

```C++
auto mid = first + (last - first)/2;  // 指针风格
```

对 RandomAccess：这是 O(1)。  
对 list/forward_list：根本不存在这些操作。

---

## 3. 典型容器（谁提供 Random Access？）

- **`std::vector`**：RandomAccess + **Contiguous**（元素真连续）[CPP Reference+2Hitchcock Codes+2](https://en.cppreference.com/w/cpp/container/vector.html?utm_source=chatgpt.com)
    
- **`std::array`**：同上
    
- **`std::deque`**：RandomAccess 但 **非 contiguous**（分段连续）[Medium+1](https://medium.com/%40joao_vaz/c-iterators-and-implementing-your-own-custom-one-a-primer-72f1506e5d71?utm_source=chatgpt.com)
    
- 原生指针 `T*`：RandomAccess + Contiguous（迭代器体系的基石）[eel.is](https://eel.is/c%2B%2Bdraft/iterator.requirements?utm_source=chatgpt.com)
    

---

## 4. 对算法的影响：哪些算法“必须” Random Access？

### 4.1 直接要求 Random Access

- `std::sort`
    
- `std::nth_element`
    
- `std::partial_sort`
    
- 堆算法：`make_heap / push_heap / pop_heap / sort_heap`
    

它们依赖 `it + n`、`it2 - it1`、下标等能力。[Medium+1](https://medium.com/%40joao_vaz/c-iterators-and-implementing-your-own-custom-one-a-primer-72f1506e5d71?utm_source=chatgpt.com)

```C++
std::vector<int> v{3,1,2};
std::sort(v.begin(), v.end()); // ✅ OK

std::list<int> l{3,1,2};
std::sort(l.begin(), l.end()); // ❌ 编译不过（不是 random access）
```

### 4.2 复杂度差异显著的算法

- `std::distance`：
    
    - RandomAccess：`last - first` O(1)
        
    - 非 RandomAccess：逐个 ++ O(n)[CPP Reference+1](https://en.cppreference.com/w/cpp/iterator/random_access_iterator.html?utm_source=chatgpt.com)
        
- `std::advance(it, n)`：
    
    - RandomAccess：`it += n` O(1)
        
    - Bidirectional/Forward：循环走 |n| 次 O(n)
        

所以你在 `vector` 上写二分、滑窗、index 相关算法会比链表快很多（缓存友好 + O(1) 跳）。[Wikipedia+1](https://en.wikipedia.org/wiki/Sequence_container_%28C%2B%2B%29?utm_source=chatgpt.com)

---

## 5. 底层实现直觉：为什么 vector/deque 能随机访问？

- **vector**：迭代器基本就是 `T*`，`it+n` 就是指针加偏移 → 天然 O(1)。[CPP Reference+1](https://en.cppreference.com/w/cpp/container/vector.html?utm_source=chatgpt.com)
    
- **deque**：内部是“分段数组 + map 索引”，迭代器持有  
    `(指向当前块, 块内指针)`，`it+n` 通过算块号+块内偏移实现 O(1)，但不保证整段连续。[Medium+1](https://medium.com/%40joao_vaz/c-iterators-and-implementing-your-own-custom-one-a-primer-72f1506e5d71?utm_source=chatgpt.com)
    

---

## 6. 最小骨架：一个 Random Access Iterator 需要哪些运算符

假设底层就是指针 `T* p;`：

```C++
template<class T>
class VecIter {
public:
    using iterator_category = std::random_access_iterator_tag;
    using value_type        = T;
    using difference_type   = std::ptrdiff_t;
    using pointer           = T*;
    using reference         = T&;

    explicit VecIter(T* x=nullptr) : p(x) {}

    reference operator*() const { return *p; }
    pointer operator->() const { return p; }

    VecIter& operator++(){ ++p; return *this; }
    VecIter& operator--(){ --p; return *this; }

    VecIter& operator+=(difference_type n){ p += n; return *this; }
    VecIter& operator-=(difference_type n){ p -= n; return *this; }

    friend VecIter operator+(VecIter it, difference_type n){ it += n; return it; }
    friend VecIter operator-(VecIter it, difference_type n){ it -= n; return it; }

    friend difference_type operator-(VecIter a, VecIter b){ return a.p - b.p; }

    reference operator[](difference_type n) const { return p[n]; }

    friend bool operator<(VecIter a, VecIter b){ return a.p < b.p; }
    friend bool operator==(VecIter a, VecIter b){ return a.p == b.p; }

private:
    T* p;
};
```

这就是“指针迭代器化”的模板。真正的 `vector::iterator` 也类似。[eel.is+1](https://eel.is/c%2B%2Bdraft/iterator.requirements?utm_source=chatgpt.com)

---

## 7. 常见坑

1. **Random Access ≠ Contiguous**  
    `deque` 是 RandomAccess，但不是连续存储；`&v[0]` 连续，`&d[0]` 不保证连续。[Hitchcock Codes+2StudyPlan+2](https://hitchcock.codes/blog/cpp-iterators-in-depth?utm_source=chatgpt.com)
    
2. **不要假设 Random Access 就能 `memcpy` 优化**  
    只有 **Contiguous Iterator** 才保证内存相邻，C++20 用 concept/`contiguous_iterator_tag` 区分。[Hitchcock Codes+1](https://hitchcock.codes/blog/cpp-iterators-in-depth?utm_source=chatgpt.com)
    
3. **迭代器失效（vector 扩容）**  
    RandomAccess 很强，但 `vector` 只要 reallocate，所有迭代器/指针/引用全失效。
    

---

### 一句话总结

Random Access Iterator 的本质是：  
**支持指针算术/下标/距离 O(1) 的迭代器**。  
它让 STL 能对 `vector/deque/array` 这类结构使用快排、堆、二分、滑窗等高效算法。