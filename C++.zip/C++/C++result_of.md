在线程池里看到的这一句：

`using return_type = typename std::result_of<F(Args...)>::type;`

就是它最典型的用法之一。

分四块讲：

1. `std::result_of` 是什么，它长什么样
    
2. 最常见的用法和例子（包括你线程池里的用法）
    
3. 更“严谨”的写法：和 `F&&` / `Args&&...` 的关系
    
4. 它已经在 C++17 里被废弃，该用什么替代（`std::invoke_result`）
    
- **C++11**：引入 `std::result_of`
    
- **C++14**：引入别名模板 `std::result_of_t`
    
- **C++17**：`std::result_of` / `std::result_of_t` **被弃用（deprecated）**
    
- **C++20**：`std::result_of` / `std::result_of_t` **被移除（removed）**
    
- 替代品：**`std::invoke_result` / `std::invoke_result_t`**（也是 `<type_traits>`，自 C++17 起推荐）
```C
typename std::result_of<F(Args...)>::type
```
---

## 1. `std::result_of` 是什么？

**一句话：**

> `std::result_of`：在**编译期**根据“可调用对象类型 + 参数类型”，推导出调用结果的类型。

官方原型（C++11/14）大致是：

```C++
template <class F>
struct result_of;  // 主模板

template <class F, class... ArgTypes>
struct result_of<F(ArgTypes...)> {
    using type = 调用 F(ArgTypes...) 后的返回类型;
};
```

典型使用方式：

```C++
template<class F, class... Args>
using result_of_t = typename std::result_of<F(Args...)>::type;
```

它支持的 F 可以是：

- 普通函数指针
    
- 函数引用
    
- 函数对象（重载了 `operator()` 的类）
    
- 成员函数指针/成员变量指针（结合 `std::mem_fn` 等）
    

**注意：它本身不是函数，不会在运行期做任何事，只是“生成一个类型”。**

---

## 2. 最常见的用法和例子

### 2.1 最简单的例子：普通函数

```C++
#include <type_traits>
#include <iostream>

int foo(double) { return 42; }

int main() {
    using R = typename std::result_of<decltype(foo)(double)>::type;
    // R 被推导为 int

    std::cout << std::boolalpha
              << std::is_same<R, int>::value << "\n"; // true
}
```

解释：

- `decltype(foo)` 是函数类型 `int(double)` 或函数指针；
    
- `std::result_of<decltype(foo)(double)>::type` 就是“调用它并传一个 `double` 的返回值类型”，结果是 `int`。
    

### 2.2 配合函数对象 / lambda

```C++
auto lambda = [](int x) { return x * 1.5; }; // 返回 double

using F = decltype(lambda);
using R = typename std::result_of<F(int)>::type;
// R = double
```

这样你在模板里，即使不知道 F 是函数还是 lambda，只要它**能被当作函数调用**，`result_of` 就能推演出返回类型。

---

## 3. 在泛型封装里的典型用法（和你的线程池相关）

你线程池里那段：

```C++
template<class F, class... Args>
auto enqueue(F&& f, Args&&... args) 
    -> std::future<typename std::result_of<F(Args...)>::type> {
    
    using return_type = typename std::result_of<F(Args...)>::type;
    ...
}
```

语义是：

> 对于任意可调用对象 `f` 和参数 `args...`，  
> 推导出“`f(args...)` 的返回类型”，将 `enqueue` 的返回值设成 `std::future<那个类型>`。

也就是说，如果有人这样调用：

```C++
int add(int, int);

ThreadPool pool(4);
auto fut = pool.enqueue(add, 1, 2);
```

那：

- `F` 推成 `int(*)(int,int)`；
    
- `Args...` 推成 `int, int`；
    
- `std::result_of<F(Args...)>::type` 就等价于 `int`；
    
- 所以 `enqueue` 返回的是 `std::future<int>`。
    

这就是 `result_of` 在**“泛型任务封装 + future”**里的典型用法。

> **注意**：严格一点的写法，其实应该用：
> 
> `std::result_of<F&&(Args&&...)>::type`
> 
> 这样才算把“值类别”也考虑进来（后面第 3 节说）。

---

## 4. 更严谨的写法：和转发引用 / `F&&` 有啥关系？

在一个完美转发的封装里，我们常写：

```C++
template <class F, class... Args>
auto wrapper(F&& f, Args&&... args)
    -> typename std::result_of<F&&(Args&&...)>::type;
```

为什么是 `F&&(Args&&...)`，而不是简单的 `F(Args...)`？

这里和你前面问过的“转发引用推导”是同一套逻辑：

- 传左值时，`F` 会被推导成引用类型 `U&`；
    
- 传右值，`F` 推导成非引用 `U`；
    
- 于是 `F&&` 根据引用折叠规则会变成正确的“真实引用类型”。
    

举个例子：

```C++
struct Foo {
    int operator()(int) &;   // 左值调用版本
    int operator()(int) &&;  // 右值调用版本
};

template <class F, class... Args>
auto call(F&& f, Args&&... args)
  -> typename std::result_of<F&&(Args&&...)>::type
{
    return std::forward<F>(f)(std::forward<Args>(args)...);
}
```

如果你传的是一个左值 `Foo foo; call(foo, 1);`：

- `F` = `Foo&`；
    
- `F&&` = `Foo& &&` 折叠成 `Foo&`；
    
- `result_of<F&&(Args&&...)>::type` = 调用 `Foo&::operator()(int)` 的返回类型。
    

如果你传的是右值 `call(Foo{}, 1);`：

- `F` = `Foo`；
    
- `F&&` = `Foo&&`；
    
- 会匹配右值版本的 `operator()`。
    

所以更“类型论洁癖一点”的写法是：

`using return_type = typename std::result_of<F&&(Args&&...)>::type;`

**你的线程池写成 `F(Args...)` 也照样能跑，大部分场景没问题，  
但没有严格考虑所有花式可调用对象的 value category 和 ref-qualifier。**

---

## 5. 现实情况：`std::result_of` 已经在 C++17 里被弃用了

这一点很重要，尤其你写的是新代码：

- 在 C++17 标准里，`std::result_of` 被标记为 **deprecated（已废弃）**；
    
- 在 C++20 里甚至可能直接没有（取决于实现）；
    
- 标准委员会推荐用 **`std::invoke_result`** 代替。
    

### 5.1 替代品：`std::invoke_result` / `std::invoke_result_t`

新写法长这样：

```C++
template<class F, class... Args>
using return_type_t = std::invoke_result_t<F, Args...>;
```

它配套的是 `std::invoke`，语义更清晰，也更统一：

```C++
template<class F, class... Args>
auto enqueue(F&& f, Args&&... args)
    -> std::future<std::invoke_result_t<F, Args...>>;
```

和 `result_of` 相比的好处：

- 直接给出 `F, Args...`，不用那种奇怪的 `F(Args...)` 语法；
    
- 和 `std::invoke` 一致，支持更多 callable 形式（成员函数指针、`std::reference_wrapper` 等）；
    
- 这是标准委员会推荐的“新世界”用法。
    

如果你用的是 C++17 及以后，**推荐把 `std::result_of` 全部换成 `std::invoke_result_t`**，线程池也一样：

```C++
template<class F, class... Args>
auto enqueue(F&& f, Args&&... args)
    -> std::future<std::invoke_result_t<F&&, Args&&...>>   // 严谨版
{
    using return_type = std::invoke_result_t<F&&, Args&&...>;
    ...
}
```

---

## 6. 压缩一下核心记忆点

你问的是“`C++ result_of 函数`”，我帮你把重点压缩成几句：

1. **`std::result_of` 不是函数，是类型 traits**：  
    `std::result_of<F(Args...)>::type` 表示“调用 F(Args...) 返回的类型”。
    
2. 它典型用在 **泛型封装里需要“先知道返回类型再写函数签名”的地方**，  
    比如线程池的 `enqueue` 要返回 `std::future<调用结果类型>`。
    
3. 在完美转发的场景中，严格写法是：  
    `std::result_of<F&&(Args&&...)>::type`，这样才能正确处理 `F` 本身的引用限定。
    
4. 在 C++17 起，**`std::result_of` 已经被弃用**，应该改用：  
    `std::invoke_result_t<F, Args...>`，配合 `std::invoke`，语义更统一。
    
5. 你线程池里的：
    
    `using return_type = typename std::result_of<F(Args...)>::type;`
    
    在 C++11/C++14 完全可用，逻辑是：  
    “F 是可调用对象，Args... 是参数类型，推导出返回值类型”。