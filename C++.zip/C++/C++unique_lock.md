## 1. `unique_lock` 的定位（它到底解决什么问题）

> `unique_lock<Mutex>` 是一个 **对互斥量锁状态的“可编排 RAII 拥有者”**。  
> 它把“锁/解锁”变成一个对象的生命周期与显式操作，提供比 `lock_guard` 更高的可控性。

核心差异：

- `lock_guard`：只支持 **“进来就锁、出去就解”**，硬、快、简单。
    
- `unique_lock`：支持 **延迟锁、尝试锁、超时锁、提前解锁、再上锁、转移锁所有权**。
    

一句话：

> 你需要除“固定范围临界区”以外的任何锁策略，就用 `unique_lock`。

---

## 2. 内部不变式（你要有这个心智模型）

`unique_lock` 内部维护大致三样：

1. `Mutex* pm` ：指向被管理的 mutex
    
2. `bool owns` ：当前是否持有锁
    
3. （可选）调度/时间相关状态（仅限 timed 操作）
    

所以你要记住：

- **`owns == true` 才能 unlock**
    
- **`pm != nullptr` 才能 lock**
    
- **析构只有在 owns==true 时才会 unlock**
    

---

## 3. 构造函数体系（最关键的一部分）

设 `Mutex m;`

### 3.1 空锁（不绑定、不持锁）

```C++
std::unique_lock<Mutex> lk;
```

- `lk.mutex() == nullptr`
    
- `lk.owns_lock() == false`
    

用途：占位、后面 move 进来。

---

### 3.2 绑定并立刻加锁（默认模式）

```C++
std::unique_lock<Mutex> lk(m);
```

含义：

- `pm = &m`
    
- 调用 `m.lock()`
    
- `owns = true`
    

---

### 3.3 延迟加锁：`std::defer_lock`

```C++
std::unique_lock<Mutex> lk(m, std::defer_lock);
```

含义：

- `pm = &m`
    
- **不调用 lock**
    
- `owns = false`
    

典型写法（缩短临界区）：

```C++
std::unique_lock lk(m, std::defer_lock);
prepare_outside_lock();  // 锁外慢活
lk.lock();               // 需要共享状态时再锁
update_shared();
```

---

### 3.4 尝试一次加锁：`std::try_to_lock`

```C++
std::unique_lock<Mutex> lk(m, std::try_to_lock);
```

含义：

- `pm = &m`
    
- 调用 `m.try_lock()`
    
- 成功 `owns=true`，失败 `owns=false`
    

典型写法（抢不到就走降级）：

```C++
std::unique_lock lk(m, std::try_to_lock);
if (!lk.owns_lock()) return fallback();
critical();
```

---

### 3.5 接管已持有锁：`std::adopt_lock`

```C++
m.lock();
std::unique_lock<Mutex> lk(m, std::adopt_lock);
```

含义：

- 你已经手动 `lock()` 了
    
- `unique_lock` **不再 lock**，只接管“析构时解锁”
    

用途：**多锁一次性获取（避免死锁）**：

```C++
std::lock(m1, m2);  // 同时无死锁拿两把

std::unique_lock l1(m1, std::adopt_lock);
std::unique_lock l2(m2, std::adopt_lock);
// 临界区
```

> adopt_lock 的前提非常硬：**当前线程必须已持锁**，否则 UB。

---

### 3.6 超时构造（仅 timed mutex 家族）

当 `Mutex` 是 `timed_mutex` / `recursive_timed_mutex` / `shared_timed_mutex` 等：

#### 相对超时

```C++
std::unique_lock<std::timed_mutex> lk(tm, 50ms); // try_lock_for(50ms)
```

#### 绝对时间点超时

```C++
auto deadline = std::chrono::steady_clock::now() + 50ms;
std::unique_lock<std::timed_mutex> lk(tm, deadline); // try_lock_until(deadline)
```

构造后要检查：

`if (!lk.owns_lock()) { /* 超时失败 */ }`

---

## 4. 成员函数（你真正会用到的）

### 4.1 上锁/解锁族

```C++
lk.lock();          // 阻塞直到拿到
lk.try_lock();      // 立即尝试
lk.unlock();        // 释放锁
```

timed 版本（只对 timed mutex 有效）：

```C++
lk.try_lock_for(10ms);
lk.try_lock_until(tp);
```

### 4.2 状态查询

```C++
lk.owns_lock();  // 是否持锁
lk.mutex();      // 返回 Mutex*（没绑定则 nullptr）
lk.operator bool();  // 同 owns_lock()，常用于 if(lk)
```

### 4.3 释放管理权：`release()`

`Mutex* pm = lk.release();`

含义：

- `lk` 不再管理这把 mutex
    
- **不会 unlock**
    
- 你必须自己负责以后 unlock
    

非常少用（框架级代码才用）。

---

## 5. 可移动不可复制（“unique” 的真正含义）

```C++
std::unique_lock lk1(m);
std::unique_lock lk2 = std::move(lk1);
```

move 以后：

- `lk2` 接管 `m` 和锁状态
    
- `lk1` 变成空锁（`mutex()==nullptr`、`owns==false`）
    

**为什么允许 move？**  
因为你可能想把锁“传给调用者”继续持有：

```C++
std::unique_lock<std::mutex> lock_and_return() {
    std::unique_lock lk(m);
    // 做点事
    return lk; // move 出去
}
```

lock_guard 做不到。

---

## 6. 与条件变量的硬绑定关系

`std::condition_variable::wait` 必须接收 `unique_lock`，因为 wait 要：

1. **原子地 unlock + sleep**
    
2. 被唤醒时再 **lock**
    

```C++
std::unique_lock lk(m);
cv.wait(lk, [&]{ return ready; });
```

> 这是一条标准级别的约束：没有 unique_lock 就没有正确的 wait。

---

## 7. 典型组合模式（工程里常用）

### 7.1 “锁外准备 + 锁内短更新”

```C++
std::unique_lock lk(m, std::defer_lock);
prepare();  // 锁外
lk.lock();
update_shared_state(); // 锁内短
```

### 7.2 “抢不到就略过”（统计、cache、日志）

```C++
std::unique_lock lk(m, std::try_to_lock);
if (!lk) return;    // 失败直接走
fast_update();
```

### 7.3 “提前释放锁避免长阻塞”

```C++
std::unique_lock lk(m);
copy_snapshot();  // 锁内快
lk.unlock();      // 提前解锁
heavy_compute();  // 锁外慢
```

### 7.4 “多锁无死锁 + RAII 接管”

```C++
std::lock(m1, m2, m3);
std::unique_lock l1(m1, std::adopt_lock);
std::unique_lock l2(m2, std::adopt_lock);
std::unique_lock l3(m3, std::adopt_lock);
// 同时持有三把
```

---

## 8. 成本与选型（为什么不是总用 unique_lock）

`unique_lock` 的成本比 `lock_guard` 多一点：

- 存 mutex 指针 + owns 状态
    
- `lock()/unlock()` 会多一层状态判断
    
- timed/try 还涉及更复杂路径
    

**选型准则：**

- 临界区简单固定 → **lock_guard**
    
- 需要任何可控行为 → **unique_lock**
    

---

## 9. 常见坑（你必须会避）

1. **try_to_lock/timed 后不检查 owns**
    
    ```C++
    std::unique_lock lk(m, std::try_to_lock);
	critical(); // ❌ 可能没持锁
    ```
    
2. **adopt_lock 没先 lock**
    
    ```C++
    std::unique_lock lk(m, std::adopt_lock); // ❌ UB
    ```
    
3. **重复 unlock / 未持锁 unlock**  
    `unique_lock` 允许你显式 unlock，所以更容易写错。
    
4. **锁内做慢事**  
    unique_lock 再灵活也不改变“临界区要短”的铁律。
    

---

## 10. 最终一句话总结

> `unique_lock` 是“带状态的 RAII 锁”：  
> 它让你按需要选择 **立刻锁、延迟锁、尝试锁、超时锁、提前解锁、再锁、转移锁**；  
> 只要你需要这些控制能力（尤其条件变量），它就是正确工具。

---