## 一、背景：为什么会有 `std::invoke_result`

以前用的是：(invoke是C++17才有的)
[[C++result_of]]
```C++
typename std::result_of<F(Args...)>::type
```

问题有几个：

1. 语法怪：`F(Args...)` 这种写法很不直观；
    
2. 和现代的 `std::invoke` 机制不完全对齐；
    
3. 标委会觉得不好用，于是在 C++17 里把 `std::result_of` 标成 **deprecated**，正式推荐用 `std::invoke_result`。
    

所以你现在应该优先用：

```C++
std::invoke_result_t<F, Args...>
```

代替旧的 `std::result_of<F(Args...)>::type`。

---

## 二、`std::invoke` 是底层动作，`invoke_result` 是“返回类型萃取”

先看 `std::invoke` 干嘛的（C++17 引入的统一调用工具）：

```C++
#include <functional>

std::invoke(f, args...);   // 等价于“以最合理的方式调用 f(args...)”
```

它支持：

- 普通函数 / 函数指针：`f(args...)`
    
- 函数对象 / lambda：`f(args...)`
    
- 成员函数指针：`(obj.*pmf)(args...)` 或 `(ptr->*pmf)(args...)`
    
- 成员变量指针：`obj.*pmd` 或 `ptr->*pmd`
    

**`std::invoke_result` 的语义就是：**

> “如果我用 `std::invoke(std::declval<F>(), std::declval<Args>()...)` 去调用，返回值类型是什么？”

所以原型是（简化版理解）：

```C++
template<class F, class... Args>
struct invoke_result {
    using type = decltype( std::invoke(std::declval<F>(), std::declval<Args>()...) );
};

// 别名模板
template<class F, class... Args>
using invoke_result_t = typename invoke_result<F, Args...>::type;
```

---

## 三、最常见用法：推导“调用结果类型”

### 3.1 普通函数

```C++
int foo(double);

using R1 = std::invoke_result_t<decltype(foo), double>; 
// R1 = int
```

等价于：

```C++
using R1 = decltype( foo(std::declval<double>()) );
```

### 3.2 函数对象 / lambda

```C++
auto lam = [](int x, double y) -> long {
    return (long)(x + y);
};

using F = decltype(lam);
using R2 = std::invoke_result_t<F, int, double>; 
// R2 = long
```

### 3.3 成员函数指针

```C++
struct X {
    int f(double) { return 0; }
};

using PMF = int (X::*)(double);

using R3 = std::invoke_result_t<PMF, X&, double>;
// 调用方式等价于：std::invoke(pmf, x, 3.14) → x.f(3.14)
// R3 = int
```

你不用自己纠结 `(x.*pmf)(args...)` / `(ptr->*pmf)(args...)` 这些细节——`std::invoke` 帮你处理了，`invoke_result` 只管把返回值类型萃取出来。

---

## 四、和 `std::result_of` 的区别 & 优点

旧写法（你线程池里的）：

```C++
using return_type = typename std::result_of<F(Args...)>::type;
```

新写法：

```C++
using return_type = std::invoke_result_t<F, Args...>;
```

区别：

1. **语法更自然**：直接写 `<F, Args...>`，而不是 `F(Args...)` 这种“看起来像在声明函数”的怪语法。
    
2. **语义对齐**：标准库统一以 `std::invoke` 为“调用中心”，所有跟“能否调用”“返回值类型”相关的 type traits（`is_invocable` 家族）都围着它打转：
    
    - `std::is_invocable<F, Args...>`
        
    - `std::is_invocable_r<R, F, Args...>`
        
    - `std::invoke_result_t<F, Args...>`
        
3. `std::result_of` 已被 C++17 标记为 **deprecated**，新代码应该直接用 `invoke_result` 系列。
    

---

## 五、在泛型封装里正确使用：F、Args 要怎么写？

典型场景：你有一个“通用调用封装”，比如线程池的 `enqueue`、`call_wrapper` 等：

```C++
template<class F, class... Args>
auto call(F&& f, Args&&... args)
    -> std::invoke_result_t<F&&, Args&&...>
{
    return std::invoke(std::forward<F>(f),
                       std::forward<Args>(args)...);
}
```

这里有两个点：

1. 模板参数是 `F, Args...`，形参是 `F&& f, Args&&... args`：  
    这是我们前面讲过的“**转发引用 + 完美转发**”套路。
    
2. 在 `invoke_result_t` 里用的是 `F&&, Args&&...` 而不是简单的 `F, Args...`：  
    这是为了保持和 `std::forward`、`std::invoke` 一致的值类别推导（左值 / 右值）。
    

不过在很多工程里，大家也会偷懒写成：

```C++
std::invoke_result_t<F, Args...>
```

在绝大多数“简单 callable” 场景下没问题；  
只有在那种 **带 ref-qualifier 的奇技淫巧函数对象** 上才有差别（你现在可以先不用纠结这块）。

---

## 六、回到你的线程池：如何用 `invoke_result_t` 重写 `enqueue`

你的原版是：

```C++
template<class F, class... Args>
auto enqueue(F&& f, Args&&... args) 
    -> std::future<typename std::result_of<F(Args...)>::type> {
    
    using return_type = typename std::result_of<F(Args...)>::type;
    ...
}
```

一个现代 C++17 写法可以这样改：

```C++
#include <type_traits>
#include <functional> // std::invoke_result

class ThreadPool {
public:
    template<class F, class... Args>
    auto enqueue(F&& f, Args&&... args)
        -> std::future<std::invoke_result_t<F&&, Args&&...>>
    {
        using return_type = std::invoke_result_t<F&&, Args&&...>;

        auto task = std::make_shared<std::packaged_task<return_type()>>(
            // 建议这里顺便把 std::bind 也换掉：
            [fn = std::forward<F>(f), ...as = std::forward<Args>(args)]() mutable {
                return std::invoke(std::move(fn), std::move(as)...);
            }
        );

        std::future<return_type> res = task->get_future();
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            if (stop)
                throw std::runtime_error("enqueue on stopped ThreadPool");
            tasks.emplace([task]{ (*task)(); });
        }
        condition.notify_one();
        return res;
    }
    ...
};
```

这里你可以观察到一条很干净的链条：

- **类型方面**：用 `std::invoke_result_t<F&&, Args&&...>` 推导 `return_type`；
    
- **调用方面**：用 `std::invoke(std::move(fn), ...)` 真正执行任务；
    
- **异步结果方面**：用 `std::packaged_task<return_type()>` + `std::future<return_type>` 把结果送给调用方。
    

`invoke_result_t` 正好跟 `std::invoke` 对齐，抽象层次很统一。

---

## 七、配套工具：`std::is_invocable` 家族

了解一下就好，今后你写模板约束会用到：

```C++
std::is_invocable_v<F, Args...>         // 能不能被 std::invoke(F, Args...) 调用？
std::is_invocable_r_v<R, F, Args...>    // 能否调用且返回类型可转换为 R？
std::invoke_result_t<F, Args...>        // 返回值类型是什么？
```

例如可以写一个“只有在 F 可调用时才启用”的模板：

```C++
template<class F, class... Args,
         std::enable_if_t<std::is_invocable_v<F, Args...>, int> = 0>
auto safe_call(F&& f, Args&&... args)
    -> std::invoke_result_t<F&&, Args&&...>
{
    return std::invoke(std::forward<F>(f),
                       std::forward<Args>(args)...);
}
```

这是 C++20 以前常见的 SFINAE 写法，C++20 后可以用 concepts / `requires` 简化。

---

## 八、压缩成你可以直接记住的几句话

1. **`std::invoke_result<F, Args...>`** 是一个 type trait，  
    它的 `::type` 就是“`std::invoke(F, Args...)` 的返回类型”。
    
2. **`std::invoke_result_t<F, Args...>`** 是它的别名模板写法，  
    等价于：`typename std::invoke_result<F, Args...>::type`。
    
3. 它是 **`std::result_of` 的现代替代品**，C++17 之后应该优先用它。
    
4. 在“完美转发”场景中，更严谨地写法是：
    
    `std::invoke_result_t<F&&, Args&&...>`
    
    这样能和 `std::forward` / `std::invoke` 的值类别推导保持一致。
    
5. 在你的线程池 `enqueue` 里，就是用它来决定：
    
    > “用户传进来的这个任务 F 和参数 Args... 调用之后，  
    > 它的返回类型是什么，我就把 `future<这个类型>` 返回给用户。”