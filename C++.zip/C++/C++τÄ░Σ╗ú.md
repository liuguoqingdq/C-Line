### override与final

## 1. `override`：明确“我要重写基类虚函数”

### 1.1 作用

加在派生类函数后面，告诉编译器：

> “这个函数必须重写（override）某个基类的 virtual 函数，否则报错。”

```C++
struct Base {
    virtual void f(int) {}
    virtual ~Base() = default;
};

struct Der : Base {
    void f(int) override {}   // ✅ 正确重写
};
```

### 1.2 为什么要用？

防止你“以为重写了，实际没重写成功”。

**经典错误：签名不一致导致没重写**

```C++
struct Base {
    virtual void f(int) {}
};

struct Der : Base {
    void f(double) override {} // ❌ 编译报错：没有可重写的 Base::f(double)
};
```

如果不写 `override`，上面会变成“新函数 + 隐藏基类同名函数”，非常隐蔽的 bug。

### 1.3 常见会导致 override 失败的差异

- 参数类型不同
    
- `const` 限定不同
    
- 引用限定（`&` / `&&`）不同
    
- 返回类型不同（允许协变返回，但得满足规则）
    

例子：

```C++
struct Base {
    virtual int g() const { return 0; }
};

struct Der : Base {
    int g() override { return 1; } // ❌ 少了 const，不是重写
};
```

### 1.4 最佳实践

**所有重写都加 `override`**  
（现代 C++ 基本是强制规范）

---

## 2. `final`：禁止继续被重写/继承

`final` 有两种用法：

### 2.1 修饰虚函数：不允许派生类再重写

```C++
struct Base {
    virtual void f() final {} // Base 的 f 到此为止
};

struct Der : Base {
    void f() override {} // ❌ 编译报错：f 被 final 禁止重写
};
```

用途：

- 你明确某个虚函数行为不希望被后续类改动（保证语义稳定）
    
- 让编译器更好优化（虚调用有时可去虚拟化）
    

---

### 2.2 修饰类：不允许再派生

```C++
struct Base final {
    virtual void f() {}
};

struct Der : Base {}; // ❌ 编译报错：Base 是 final 类
```

用途：

- 某个类设计成“继承树叶子节点”
    
- 防止别人基于它继续扩展造成不受控行为
    
- API / 安全边界更清晰
    

---

## 3. `override` vs `final` 的关系

- `override`：**我在派生类里重写了一个虚函数**（对基类行为做替换）
    
- `final`：**到此为止，不许再重写/派生**（封口）
    

它们可以一起用：

```C++
struct Base {
    virtual void f() {}
};

struct Der : Base {
    void f() override final {} // Der 重写 Base::f，但禁止再往下重写
};
```

含义：

1. `override` 保证这真的是重写
    
2. `final` 让这个重写成为“最终版本”
    

---

## 4. 小总结（记法）

- **override = 重写检查器**  
    让编译器帮你抓“签名不一致但你以为重写了”的 bug
    
- **final = 终止点**  
    终止继承/终止某虚函数继续被重写
-----

### 静态断言

#### 0. 静态断言一句话定义[[C++静态断言]]

`static_assert` 是 **编译期断言**：

> **在编译阶段检查一个条件必须为真；否则直接编译报错。**

它把“本来可能运行时才发现的错误”提前到编译期。

---

## 1. 基本语法与版本差异

### 1.1 C++11 语法

`static_assert(condition, "message");`

- `condition`：必须是编译期常量表达式（能在编译期算出 true/false）
    
- `message`：报错信息（字符串字面量）
    

### 1.2 C++17 起可省略 message

`static_assert(condition);`

---

## 2. condition 必须是“编译期常量表达式”意味着什么？

### 2.1 能当 condition 的东西

- 字面量/constexpr 变量
    
- `sizeof` / `alignof`
    
- `std::is_xxx_v<T>` 这类 type traits
    
- `requires`/concepts 的布尔结果（C++20）
    
- 可在编译期求值的 `constexpr` 函数调用
    

例子：

```C++
constexpr int N = 16;
static_assert(N % 2 == 0);

static_assert(sizeof(int) == 4);
static_assert(std::is_trivially_copyable_v<MyType>);
```

### 2.2 不能当 condition 的东西

任何需要运行期才能确定的值，比如：

`int n = read(); static_assert(n > 0); // ❌ n 不是编译期常量`

---

## 3. 静态断言的“底层意义”

编译器看到：

`static_assert(expr, "...msg...");`

会做两件事：

1. 在编译期对 `expr` 求值
    
2. 若为 false **拒绝生成目标文件**，并把 msg 打入错误日志
    

所以 `static_assert` 对运行时零成本：

> **它不产生任何可执行指令。**

---

## 4. 和运行时 `assert` 的对比

|特性|`static_assert`|`assert`|
|---|---|---|
|时机|编译期|运行期|
|条件|必须编译期可求值|任意 bool|
|失败|编译失败|运行中断（Debug）|
|可关闭|不可关闭|`NDEBUG` 可关闭|
|主要用途|类型/布局/常量约束|运行时逻辑检查|

一眼区分：

- **编译期必须成立的事实** → `static_assert`
    
- **运行中可能不成立的条件** → `assert`
    

---

## 5. 典型用途（按工程场景分类）

### 5.1 模板/泛型约束（最常用）

你想限制模板只接受某类 T：

```C++
#include <type_traits>

template<class T>
T add_one(T x){
    static_assert(std::is_integral_v<T>, "T must be integral");
    return x + 1;
}
```

这样 `add_one(3.14)` 会编译期报错，而不是运行期才炸。

---

### 5.2 验证类型推导/traits 结果

特别适合你前面学的“模板推导/别名模板/decltype”：

```C++
template<class T>
using Clean = std::remove_cvref_t<T>;
static_assert(std::is_same_v<Clean<const int&>, int>);
```

---

### 5.3 检查常量逻辑（边界/不变量）

```C++
constexpr int PAGE_SIZE = 4096;
static_assert((PAGE_SIZE & (PAGE_SIZE-1)) == 0,
              "PAGE_SIZE must be power of two");
```

---

### 5.4 检查 ABI / 内存布局 / 对齐

系统软件里超常见：

```C++
struct Header {
    uint32_t magic;
    uint16_t ver;
    uint16_t len;
};

static_assert(sizeof(Header) == 8, "Header size mismatch");
static_assert(alignof(Header) == 4, "Header alignment mismatch");
```

用于确保协议/文件格式不会因为编译器差异跑偏。

---

### 5.5 配合 `constexpr` 算法做编译期验证

```C++
constexpr int fib(int n){
    return n<=1 ? n : fib(n-1)+fib(n-2);
}
static_assert(fib(10) == 55);
```

---

## 6. 进阶：在不同语法位置用 static_assert

### 6.1 在类/命名空间作用域

```C++
static_assert(sizeof(long) >= 8, "need 64-bit long");
```

### 6.2 在函数内部

```C++
template<class T>
void foo(){
    static_assert(sizeof(T) <= 16, "T too big");
}
```

每个实例化都会检查一次。

---

## 7. 常见坑与正确写法

### 7.1 “以为是编译期，实际不是”

```C++
int n = 3;
static_assert(n == 3); // ❌ n 不是 constexpr
```

修：

```C++
constexpr int n = 3;
static_assert(n == 3);
```

---

### 7.2 `static_assert(false)` 会让模板直接爆炸

经典“模板里写死 false”会导致**即使没用到也报错**：

```C++
template<class T>
void f(){
    static_assert(false, "no such type"); // ❌ 任何实例化都会报
}
```

正确的“依赖型 false”写法：

```C++
template<class>
inline constexpr bool always_false_v = false;

template<class T>
void f(){
    static_assert(always_false_v<T>, "no such type"); // ✅ 仅当 f<T> 被实例化时才报
}
```

---

### 7.3 信息写得太泛，定位困难

坏：

```C++
static_assert(std::is_integral_v<T>, "bad type");
```

好：

```C++
static_assert(std::is_integral_v<T>,
              "add_one<T>: T must be an integral type");
```

---

## 8. 与 Concepts 的关系（C++20）

Concepts 是“更语法化的静态约束”，本质上仍然是编译期检查。

没有 concepts 时你用：

`template<class T> void f(T x){     static_assert(std::is_integral_v<T>); }`

有 concepts 后可以写：

`template<std::integral T> void f(T x){}`

**什么时候仍然用 static_assert？**

- 你要给出更定制的报错信息
    
- 检查不是简单概念能表达的复杂常量/布局约束
    
- 在实现内部做“二次防御”
    

---

## 9. 小结（你要形成的直觉）

1. `static_assert` = **编译期保险丝**
    
2. 条件必须是 **编译期常量表达式**
    
3. 不产生运行时成本
    
4. 最常用场景：
    
    - 模板类型约束
        
    - traits/推导验证
        
    - 协议/结构体布局检查
        
    - 编译期常量不变量检查
        
5. 模板里不要写死 `false`，要用依赖型 false
----

### 字面量：用户定义字面量、二进制字面量
## 一、二进制字面量（Binary literals）

### 1. 语法（C++14 起）

用 `0b` 或 `0B` 前缀：

```C++
int x = 0b1010;   // 10
int y = 0B1111;   // 15
```

允许用 `'` 做数字分隔（C++14 起）：

`int mask = 0b1111'0000'1010'0101;`

### 2. 类型与后缀规则

二进制字面量本质是**整数字面量**，类型推断与十进制/八进制/十六进制一致。

你可以加整数后缀：

```C++
auto a = 0b1010u;   // unsigned int
auto b = 0b1010ul;  // unsigned long
auto c = 0b1010ll;  // long long
```

不加后缀时，编译器会按能容纳该值的最小类型选：  
`int → long → long long → unsigned ...`（和其它整数常量同规则）。

### 3. 常见用途

- 位掩码/权限位写得更直观
    
- 协议字段、硬件寄存器（按位含义清晰）
    
- 用于 `constexpr` 的位运算
    

例子：

```C++
constexpr int READ  = 0b001;
constexpr int WRITE = 0b010;
constexpr int EXEC  = 0b100;

int perm = READ | WRITE; // 0b011
```

### 4. 常见坑

1. **不是字符串**，不能写 `0b10.01`（二进制浮点字面量不存在）
    
2. **前导 0 不代表二进制**：  
    `010` 是八进制，二进制必须 `0b010`
    
3. **溢出规则一样**：写太长会溢出或变 unsigned。
    

---

## 二、用户定义字面量（User-defined literals, UDL）

UDL 让你能写出这种“带单位/语义”的常量：

```C++
auto t = 10s;     // 10 秒（chrono）
auto d = 3.5km;   // 3.5 公里（自定义）
auto x = 0xff_u8; // 强制 uint8_t（自定义）
```

### 1. 语法形式

**字面量 + 后缀标识符**：

```C++
123_km
"hello"_sv
3.14_rad
```

后缀必须是**合法标识符**，通常以下划线开头来避免与标准后缀冲突：`_km`, `_rad`, `_u8`。

---

### 2. UDL 的实现方式：重载 `operator "" suffix`

你需要定义一个特殊的字面量运算符：

```C++
// 例：定义 _km（公里）字面量
constexpr long double operator"" _km(long double x) {
    return x * 1000.0L; // 转成米
}

constexpr unsigned long long operator"" _km(unsigned long long x) {
    return x * 1000ULL;
}
```

然后使用：

```C++
auto a = 1.5_km; // long double 1500.0
auto b = 2_km;   // unsigned long long 2000
```

---

### 3. UDL 支持哪些“参数形态”？

字面量运算符的参数类型有限定（标准规定），常见几种：

1. **无符号整数**（处理整数常量）
    
    ```C++
    constexpr T operator"" _x(unsigned long long v);
    ```
    
2. **长双精度**（处理浮点常量）
    
    ```C++
    constexpr T operator"" _x(long double v);
    ```
    
3. **字符串字面量**
    
    ```C++
    constexpr T operator"" _x(const char* str, size_t n);
// 或 wchar_t / char8_t / char16_t / char32_t 版本
    ```
    
4. **字符字面量**
    
    ```C++
    constexpr T operator"" _x(char c);
    ```
    
5. **模板形式（C++20，编译期拿到每个字符）**
    
    ```C++
    template<char... Cs>
	constexpr T operator"" _x();
    ```
    
    适合做编译期解析（比如二进制字符串 → 数值）。
### 例子：`10101_bin` 在编译期转成整数 21

```C++
#include <cstdint>

template<char... Cs>
consteval std::uint64_t operator"" _bin() {
    constexpr char s[] = { Cs... };  // 把字符包变成数组方便遍历
    std::uint64_t v = 0;

    for (char c : s) {
        if (c == '0' || c == '1') {
            v = (v << 1) + (c - '0');  // 二进制累积
        } else {
            // 编译期报错：字面量里出现非 0/1 字符
            []<bool ok = false>() {
                static_assert(ok, "binary literal can contain only 0 or 1");
            }();
        }
    }
    return v;
}

int main() {
    constexpr auto x = 10101_bin;   // 注意：这里没有引号，是“数值字面量”
    static_assert(x == 21);

    constexpr auto mask = 1111'0000_bin; // 允许用 ' 分隔
    static_assert(mask == 240);
}

```

**解释关键点：**

1. `10101_bin` 是一个“带后缀的数值字面量”。
    
2. 编译器会把后缀前的那串字符 `{'1','0','1','0','1'}` 当成 **模板参数包 Cs...** 传给 `operator"" _bin`。
    
3. 因为是 `consteval`，所以**必须在编译期求值**；解析失败会直接编译报错。
    
4. 最终 `x` 是一个真正的 `uint64_t` 常量。

5.constexpr auto x = 10101_bin;这里我没有用引号，是数值字面量，那问什么能当char类型的字符包 

因为：因为**字面量运算符模板（literal operator template）有一条特殊语法规则**：只要你写的是“用户定义整数字面量” `123_suffix` / `0xFF_suffix` / `10101_suffix`，而你又提供了这种形参形式

`template<char... Cs> consteval T operator"" _suffix();`

那么**编译器不会把 `10101` 当成一个数去传参**，而是把它在源码里对应的那串 **“字面量 token 的字符”** 拆成一个 `char` 参数包 `Cs...` 传进去。

也就是说，这不是普通的模板推导，而是 **UDL 语法规定的“按字符传递”**。
3) 想两种都支持？可以同时定义两个运算符
```C++
// ① 整数字面量版本：10101_bin
template<char... Cs>
consteval std::uint64_t operator"" _bin() {
    constexpr char s[] = { Cs... };
    std::uint64_t v=0;
    for(char c: s){
        if(c=='0'||c=='1') v=(v<<1)+(c-'0');
        else []<bool ok=false>(){ static_assert(ok,"only 0/1"); }();
    }
    return v;
}

// ② 字符串字面量版本："10101"_bin
template<typename CharT, CharT... Cs>
consteval std::uint64_t operator"" _bin() {
    constexpr CharT s[] = { Cs... };
    std::uint64_t v=0;
    for(CharT c: s){
        if(c=='0'||c=='1') v=(v<<1)+(c-'0');
        else []<bool ok=false>(){ static_assert(ok,"only 0/1"); }();
    }
    return v;
}

int main(){
    constexpr auto a = 10101_bin;   // ✅
    constexpr auto b = "10101"_bin; // ✅
    static_assert(a==b && a==21);
}

```

---

### 4. 标准库里自带的 UDL（你可能见过）

来自不同命名空间，需要 `using namespace`：

1. **chrono 时间单位**（`std::chrono_literals`）
    
```C++
    using namespace std::chrono_literals;
auto t = 100ms;
auto s = 2s;
auto m = 3min;
```
    
2. **string_view**（`std::string_view_literals`）
    
    ```C++
    using namespace std::string_view_literals;
	auto v = "hello"sv;  // std::string_view
    ```
    
3. **complex**（`std::complex_literals`）
    
    ```C++
using namespace std::complex_literals;
auto z = 1.0 + 2.0i;
    ```
    

---

### 5. 常见用途

1. **带单位的数值**
    
    - 时间、长度、角度、存储大小等
        
2. **编译期解析**
    
    - `"1010"_bin` 转成二进制
        
3. **类型安全**
    
    - 强化类型而不是裸 `int/double`
        
4. **提升可读性**
    
    - 代码像“领域语言（DSL）”
        

---

### 6. 常见坑（必须知道）

1. **后缀冲突/污染**
    
    - UDL 需要放命名空间里，使用时 `using namespace xxx_literals;`
        
    - 自己写后缀最好用 `_xxx` 避免撞标准/第三方
        
2. **整数字面量参数类型固定是 unsigned long long**
    
    - 所以别指望它区分 `int/long long`，你要自己检查范围。
        
3. **UDL 不是宏，它是真函数调用**
    
    - 但多数可 `constexpr`，编译期折叠。
        
4. **对字符串 UDL，传入不是 C++ string**
    
    - 你得到的是 `const char* + size` 或字符包，需要自己构造 `std::string`/`string_view`。
        

---

## 三、一个综合小例子：自定义二进制字符串字面量

```C++
#include <cstddef>
#include <stdexcept>

// "10101"_bin -> unsigned long long
constexpr unsigned long long operator"" _bin(const char* s, size_t n) {
    unsigned long long v = 0;
    for (size_t i = 0; i < n; ++i) {
        v <<= 1;
        if (s[i] == '1') v |= 1;
        else if (s[i] != '0') throw "not binary";
    }
    return v;
}

int main() {
    auto x = "10101"_bin; // 21
}
```

---

### 一句话总结

- **二进制字面量**：`0b...`，只是“用二进制写整数”，类型规则和普通整数一样。
    
- **用户定义字面量（UDL）**：`literal_suffix`，让字面量自动变成你定义的类型/单位/语义，本质是 `operator "" _suffix(...)`。



------

### 数字分隔符
数字分隔符（digit separator）是 C++14 引入的一个语法：**在数字字面量里用单引号 `'` 把数字分组，让人更好读**。它**只影响可读性，不影响数值**——编译器会把 `'` 当成“忽略的分隔符”。

---

## 1. 基本例子

```C++
int a = 1'000'000;          // 一百万，等价于 1000000
long long b = 9'223'372'036'854'775'807LL;  // 更好读
```

---

## 2. 各种进制都能用

```C++
int x = 0b1111'0000'1010;   // 二进制分组
int y = 0xDEAD'BEEF;        // 十六进制分组
int z = 0123'456;           // 八进制分组（不常用）
```

---

## 3. 浮点字面量也能用

```C++
double p = 3.1415'9265'3589;  // π 的分组
double q = 1.23'45e-6;        // 科学计数法里也能分组
```

---

## 4. 典型用途

- 大数/金额/计数更直观：`1'000'000'000`
    
- bitmask 更清晰：`0b1010'0011'1100`
    
- 十六进制常量按字节分：`0x12'34'56'78`
    

---

## 5. 规则/限制（常见坑）

1. **不能放在数字开头或结尾**
    
    `int a = '123;   // ❌ int b = 123';   // ❌`
    
2. **必须夹在数字之间**  
    不要连续放多个 `'`：
    
    `int a = 1''000; // ❌`
    
3. **它不是字符常量**
    
    `int a = 1'2; // ✅ 等价于 12，不是 '2'`
    
4. **不改变进制语义**  
    `0b1010'10` 还是二进制；`010'10` 还是八进制。
    

---

## 6. 和用户定义字面量（UDL）一起用

分隔符会被当成“忽略字符”，不会影响 UDL 的解析含义（对整数字面量模板来说通常不进入字符包）：

`constexpr auto x = 1111'0000_bin;  // 仍然按 11110000 解析`

---

一句话总结：  
**数字分隔符就是 C++ 的“数字里可以插的可读性逗号”**：写起来更清楚，编译器会直接忽略它。

------

### 枚举类和指定枚举的底层类型
## 1. 枚举的本质 & 底层类型是什么

枚举值在机器里最终要存成一个整数。这个“用来存枚举值的整数类型”就叫 **底层类型（underlying type）**。  
比如底层类型是 `int`，那枚举对象大小通常就是 4 字节（跟平台有关）。

---

## 2. C++98/03 的普通枚举（unscoped enum）

`enum Color { Red, Green, Blue };`

特点：

1. **不带作用域**：枚举值会直接注入到外层作用域  
    例如 `Red` 在全局可见，容易冲突。
    
2. **可隐式转成 int**：
    
    `int x = Red; // ok`
    
    这让它更像“整型常量集合”，但也带来类型不安全。
    
3. **底层类型默认由编译器决定**
    
    - 一般是能容下所有枚举值的“最小整型”，但 **标准只保证是整型**，具体可能是 `int/unsigned int/long...`，跟编译器和枚举值范围有关。
        
    - 也就是说：**不写底层类型时，大小/符号可能变化**。
        

---

## 3. C++11 的枚举类（enum class / scoped enum）

`enum class Color { Red, Green, Blue };`

特点：

1. **带作用域**：必须写 `Color::Red`
    
    `Color c = Color::Red;`
    
2. **不允许隐式转 int**（类型安全）
    
    ```C++
    int x = Color::Red; // error
	int y = static_cast<int>(Color::Red); // ok
    ```
    
3. **也有底层类型**
    
    - 默认底层类型是 `int`（scoped enum 默认固定为 int）。
        
    - 但你仍然可以显式指定。
        

---

## 4. 指定枚举底层类型（fixed underlying type）

语法：

```C++
enum class Status : std::uint8_t { Ok = 0, Fail = 1 };
enum ErrorCode : unsigned short { E1, E2 };
```

作用/好处：

1. **控制大小**（节省内存 / 做网络协议 / 文件格式）
    
```C++
    enum class MsgType : std::uint8_t { Ping=1, Pong=2 };
	static_assert(sizeof(MsgType) == 1);
```
    
2. **控制符号**（有无符号）
    
3. **稳定 ABI / 序列化**  
    你写死底层类型后，不同编译器/版本也不容易变。
    
4. **允许前向声明**
    
    - 普通枚举无法前置声明（因为大小未知）
        
    - 固定底层类型后可以：
        
        ```C++
        enum class Mode : std::uint16_t; // forward declare ok
        ```
        

限制：

- 枚举值必须能被该底层类型表示，否则编译报错/警告：
    
    ```C++
    enum class Big : std::uint8_t { A=0, B=300 }; // 300 放不下 -> error
    ```
    

---

## 5. 枚举类 + 底层类型的常用写法

```C++
#include <cstdint>
#include <type_traits>

enum class Role : std::uint8_t {
    User = 1,
    Admin = 2,
};

int main() {
    Role r = Role::Admin;

    // 取底层类型
    using U = std::underlying_type_t<Role>;//`std::underlying_type_t<E>` 的作用一句话：**在编译期把一个枚举类型 `E` 映射成它实际用于存储的整数类型（底层类型）**。
    U v = static_cast<U>(r); // v == 2
}
```

---

## 6. 枚举类做 bitmask（位标志）的小提示

枚举类不自动转 int，所以做位运算要自己重载：

```C++
#include <cstdint>
enum class Perm : std::uint8_t {
    Read = 1<<0,
    Write= 1<<1,
    Exec = 1<<2,
};

inline Perm operator|(Perm a, Perm b){
    return static_cast<Perm>(
        static_cast<std::uint8_t>(a) |
        static_cast<std::uint8_t>(b));
}
```

---

## 7. 什么时候该指定底层类型？

**建议指定**的场景：

- 需要节省空间（大量枚举存在容器里）
    
- 跨语言/跨网络协议/磁盘序列化
    
- 做硬件寄存器映射、二进制协议
    
- 想前向声明枚举
    

**可不指定**的场景：

- 纯内部逻辑、不会序列化/暴露 ABI
    
- 枚举成员范围不大，性能/空间不敏感

-----
### byte类型
## 1. `std::byte` 是什么？

`#include <cstddef>   // std::byte 在这里`

`std::byte` 是一个 **强类型的字节（8-bit）占位类型**，本质上是一个 **枚举类型**：

- 用来表示“原始内存中的一个字节”
    
- **不是字符**、也 **不是整数**
    
- 主要用于低层内存/二进制操作，避免把它误当数字做算术
    

---

## 2. 为什么需要它？

以前大家用：

- `unsigned char`
    
- `std::uint8_t`
    
- `char`
    

来表示字节。但这些类型**都能当整数算术**，容易写出语义不清的代码，比如：

`uint8_t b = 10; b += 5;  // 这到底是“数值”还是“字节缓冲区里的一个位置”？不清晰`

`std::byte` 通过 **禁止算术运算** 来强制你显式表达意图。

---

## 3. 能做什么运算？

`std::byte` **只支持位运算**：

```C++
#include <cstddef>
#include <cstdint>

std::byte b1{0x0F};
std::byte b2{0xF0};

auto b3 = b1 | b2;  // OK
auto b4 = b1 & b2;  // OK
auto b5 = b1 ^ b2;  // OK
auto b6 = ~b1;      // OK
```

不支持加减乘除：

`auto x = b1 + b2;   // ❌ error`

---

## 4. 怎么把 `std::byte` 转成整数？

必须显式转换：

### C++17/20：

```C++
#include <cstddef>
#include <cstdint>
#include <type_traits> // std::to_integer 在 <cstddef> 也有，但有些库放这里

std::byte b{0x2A};
auto v = std::to_integer<std::uint8_t>(b); // v = 42
```

### 或手动：

`auto v = static_cast<std::uint8_t>(b); // 也可`

---

## 5. 常见用法（字节缓冲区）

```C++
#include <vector>
#include <cstddef>
#include <cstring> // memcpy

struct Header {
    std::uint32_t magic;
    std::uint16_t len;
};

Header h{0xAABBCCDD, 12};

std::vector<std::byte> buf(sizeof(Header));
std::memcpy(buf.data(), &h, sizeof(Header)); // 把结构体按字节拷进去
```

读取回去：

```C++
Header h2;
std::memcpy(&h2, buf.data(), sizeof(Header));
```

---

## 6. `std::byte` vs `uint8_t` / `unsigned char`

|类型|语义|可算术？|适合场景|
|---|---|---|---|
|`std::byte`|“原始字节”|❌ 只能位运算|二进制缓冲、内存视图、协议|
|`std::uint8_t`|“8位无符号整数”|✅|数值计算、比特位处理也行|
|`unsigned char`|“字节/字符存储单元”|✅|老代码、与 C API 交互|
|`char`|“字符”|✅|文本/字符处理|

**经验法则**：

- 你想表达“这是原始内存/字节流” → 用 `std::byte`
    
- 你想表达“这是一个 0~255 的数字” → 用 `uint8_t`
    

---

## 7. 和你前面枚举底层类型的关系

如果你想让枚举底层就是“一个字节宽度”，可以写：

```C++
#include <cstdint>

enum class OpCode : std::uint8_t {
    Ping = 1,
    Pong = 2
};
```

注意：**不能用 `std::byte` 当枚举底层类型**，因为底层类型必须是整型，而 `std::byte` 是枚举。

-----

### 多元组tuple

`std::tuple`（多元组）就是 C++ 里的“**异构小容器**”：能把不同类型的值打包成一个对象，并按索引/类型访问。你可以把它理解成“泛化版 struct，但按位置而不是按名字”。

---

## 1. 基本概念

- 头文件：`#include <tuple>`
    
- 类型：`std::tuple<T1, T2, ...>`
    
- 每个元素类型可以不同，数量任意。
    

```C++
#include <tuple>
#include <string>

std::tuple<int, double, std::string> t{1, 3.14, "hi"};
```

---

## 2. 创建 tuple 的几种方式

### (1) 直接构造

```C++
std::tuple<int, char> t(42, 'x');
std::tuple<int, char> t2{42, 'x'};
```

### (2) `std::make_tuple`（自动推导类型）

```C++
auto t = std::make_tuple(1, 2.5, std::string("ok"));
// t 的类型是 tuple<int, double, string>
```

### (3) `std::tie`（把变量“绑”成 tuple 的引用，用于解包/忽略）

```C++
int a; double b; std::string c;
std::tie(a, b, c) = std::make_tuple(1, 3.14, "hi");
```

忽略某个值：

```C++
int x; double y;
std::tie(x, std::ignore, y) = std::make_tuple(10, 20, 30.0);
// x=10, y=30.0
```

### (4) 生成引用 tuple

```C++
int v = 5;
auto tr = std::forward_as_tuple(v); // tuple<int&>
```

---

## 3. 访问元素

### (1) 按索引 `std::get<I>(t)`

```C++
auto t = std::make_tuple(1, 2.5, "hi");
int i = std::get<0>(t);
double d = std::get<1>(t);
```

### (2) 按类型 `std::get<T>(t)`（类型必须唯一）

```C++
auto t = std::make_tuple(1, 2.5, "hi");
double d = std::get<double>(t);  // ok
```

---

## 4. 解包 tuple

### (1) 结构化绑定（C++17 最常用）

```C++
auto t = std::make_tuple(1, 2.5, "hi");
auto [i, d, s] = t;   // i,d,s 各自是拷贝

auto& [ri, rd, rs] = t; // 引用解包，可修改 t 内部
```

### (2) `std::tie`

上面已经示范，适合“把返回值分给老变量”。

---

## 5. tuple 常见用途

### (1) 函数返回多个值

```C++
std::tuple<int, bool> parse() {
    return {42, true};
}

auto [val, ok] = parse();
```

### (2) 泛型编程里绑定不同类型参数

比如把一堆参数存起来再 `apply`：

```C++
#include <tuple>
#include <utility>

void f(int a, double b) { /*...*/ }

auto args = std::make_tuple(1, 3.14);
std::apply(f, args);  // 等价 f(1, 3.14)
```

---

## 6. 重要工具/类型萃取

```C++
using T = std::tuple<int, double, char>;

constexpr size_t N = std::tuple_size_v<T>; // 3
using Second = std::tuple_element_t<1, T>;  // double
```

---

## 7. 拼接、比较

### (1) 拼接

```C++
auto a = std::make_tuple(1, 2);
auto b = std::make_tuple('x', 3.0);
auto c = std::tuple_cat(a, b); // (1,2,'x',3.0)
```

### (2) 比较（字典序）

```C++
std::tuple<int,int> t1{1,2}, t2{1,3};
bool less = (t1 < t2); // true
```

---

## 8. 和 struct 的区别（怎么选）

- `struct`：**有名字、语义清晰**，长期维护/对外接口优先用
    
- `tuple`：**临时打包/返回多个值/泛型参数容器** 很方便  
    语义不强时别滥用，不然读代码的人得靠索引猜含义。
    

---

## 9. 小坑提醒

1. `std::get<T>` 要求类型唯一，否则编译报错。
    
2. tuple 可以存引用，但**要注意生命周期**：
    
    ```C++
    auto t = std::make_tuple(std::string("hi")); // OK
	auto r = std::forward_as_tuple(std::string("hi")); // ❌ 引用悬空
    ```
    
3. 结构化绑定默认是拷贝；想改原 tuple 要用 `auto& [...]`.
    

---