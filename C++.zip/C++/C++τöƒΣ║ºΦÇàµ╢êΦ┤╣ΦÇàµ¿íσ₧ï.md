## 一、生产者–消费者模型本质在干嘛？

场景抽象：

- 有一端负责**产生任务/数据**（生产者 producer）
    
- 有一端负责**取出任务执行**（消费者 consumer）
    
- 中间通过一个**共享缓冲区**（通常是队列 queue）传递数据
    

目标：

- 生产者**尽快写入**数据，不被消费者慢拖住
    
- 消费者**有活就干，没活就阻塞等待**，而不是傻傻 busy-wait
    
- 多线程环境下要保证：
    
    - 不数据竞争（data race）
        
    - 不丢数据、不重复消费
        
    - 不死锁
        

典型结构图：

`[producer threads]  --->  [共享队列]  --->  [consumer threads]`

---

## 二、最经典的实现：`mutex + condition_variable`

我们先看一个最小可用版：  
**一个队列，多生产者、多消费者，队列无限长（不考虑容量上限）。**

### 2.1 共享数据与同步原语

```C++
#include <mutex>
#include <condition_variable>
#include <queue>

std::mutex m;
std::condition_variable cv;
std::queue<int> q;   // 共享缓冲区
bool done = false;   // 标记“生产结束”
```

- `m` 保护对 `q` 和 `done` 的所有访问
    
- `cv` 用来让消费者“睡觉 + 被唤醒”
    
- `done` 用来告诉消费者：“不会再有新的数据了，可以退出了”
    

---

### 2.2 生产者线程：`push + notify_one`

```C++
void producer(int id, int count) {
    for (int i = 0; i < count; ++i) {
        int v = id * 1000 + i; // 生产一个数据

        {
            std::lock_guard<std::mutex> lk(m); // 上锁保护 q
            q.push(v);
        } // 解锁（lock_guard析构）

        cv.notify_one();  // 通知一个等待的消费者：有新数据了
    }

    // 所有生产者都结束时，通常由某一个线程设置 done=true
}
```

关键点：

- **修改共享队列时必须持锁**
    
- `notify_one()` 要在解锁之后调用（锁内/锁外都可以，但锁外通常更高效）
    

---

### 2.3 消费者线程：`wait + 谓词`

```C++
void consumer(int cid) {
    while (true) {
        int v;
        {
            std::unique_lock<std::mutex> lk(m);
            cv.wait(lk, [] { 
                return !q.empty() || done; 
            });
            // 醒来之后，一定满足：队列非空 或者 已经 done

            if (q.empty()) {
                // 只有在 done == true 且队列已空的情况下才会走到这里
                // 没活干了，退出循环
                break;
            }

            v = q.front();
            q.pop();
        } // 解锁

        // 在锁外处理数据，减小临界区
        // do_something(v);
    }

    // consumer 正常退出
}
```

**几件非常重要的事情：**

1. `wait(lk, pred)` 这个写法是标准推荐写法  
    它等价于：
    
    `while (!pred()) {     cv.wait(lk); // 可能存在虚假唤醒 }`
    
    这样可以抵抗：
    
    - 虚假唤醒（cv.wait 可能在没有 notify 时返回）
        
    - 被唤醒时条件还不满足（例如被别的消费者抢先取走）
        
2. 判断 `done` 和 `q.empty()` 都必须在**持锁下**完成，否则会有竞态
    
3. 处理数据 `do_something(v)` 必须放在锁外，防止锁内长时间占用 → 阻塞其他线程
    

---

## 三、封装成通用组件：`BlockingQueue<T>`

在工程里，生产者–消费者模式通常会封装成一个“**线程安全阻塞队列**”，而不是到处裸写 `mutex` 和 `cv`。

### 3.1 不带 `done` 的基础版本（只演示 push/pop）

```C++
template<typename T>
class BlockingQueue {
public:
    void push(T value) {
        {
            std::lock_guard<std::mutex> lk(m_);
            q_.push(std::move(value));
        }
        cv_.notify_one();
    }

    T pop() {
        std::unique_lock<std::mutex> lk(m_);
        cv_.wait(lk, [&]{ return !q_.empty(); }); // 没数据就阻塞
        T value = std::move(q_.front());
        q_.pop();
        return value;
    }

private:
    std::mutex m_;
    std::condition_variable cv_;
    std::queue<T> q_;
};
```

用法：

```C++
BlockingQueue<int> bq;

void producer() {
    for (int i=0; i<100; ++i) {
        bq.push(i);
    }
}

void consumer() {
    while (true) {
        int x = bq.pop();
        // ...
    }
}
```

这个版本有个问题：**不知道什么时候退出**。  
`pop()` 永远在等新数据，如果生产者结束了，消费者会永远卡着。

---

### 3.2 加上“关闭/结束”机制的版本

我们加一个 `closed_` 标志，并在 `pop` 返回一个 `std::optional<T>`，表示可能已经没有数据了。

```C++
#include <optional>

template<typename T>
class BlockingQueue {
public:
    // 生产者推入数据。如果队列已关闭，可以选择丢弃或抛异常
    void push(T value) {
        {
            std::lock_guard<std::mutex> lk(m_);
            if (closed_) {
                throw std::runtime_error("push on closed queue");
            }
            q_.push(std::move(value));
        }
        cv_.notify_one();
    }

    // 消费者取数据。当队列已关闭且为空时，返回空 optional
    std::optional<T> pop() {
        std::unique_lock<std::mutex> lk(m_);
        cv_.wait(lk, [&]{
            return closed_ || !q_.empty();
        });

        if (q_.empty()) {
            // closed_ == true && 队列为空
            return std::nullopt;
        }

        T value = std::move(q_.front());
        q_.pop();
        return value;
    }

    // 关闭队列，通知所有等待的消费者退出
    void close() {
        {
            std::lock_guard<std::mutex> lk(m_);
            closed_ = true;
        }
        cv_.notify_all();
    }

private:
    std::mutex m_;
    std::condition_variable cv_;
    std::queue<T> q_;
    bool closed_ = false;
};
```

使用示例：

`BlockingQueue<int> bq;  void producer() {     for (int i = 0; i < 100; ++i) {         bq.push(i);     }     // 所有生产者结束后调用一次     bq.close(); }  void consumer() {     while (true) {         auto opt = bq.pop();         if (!opt) break;       // 队列关闭且空，退出         int x = *opt;         // 处理 x     } }`

这样：

- 多个消费者在 `close()` 后都能被 `notify_all` 唤醒
    
- 如果队列空且已关闭，它们就自然退出
    
- 整个生命周期非常干净
    

---

## 四、多生产者 / 多消费者：是否需要额外处理？

### 4.1 多生产者

多个线程同时 push：

```C++
void producer(int id) {
    for (...) {
        bq.push(...);
    }
}
```

- `push` 内部已经用 mutex 保护了队列 → 不会 data race
    
- `notify_one()` 会唤醒一个消费者来处理数据
    

### 4.2 多消费者

多个线程同时 pop：

```C++
void consumer(int cid) {
    while (true) {
        auto item = bq.pop();
        if (!item) break;
        // 处理 *item
    }
}
```

- `pop` 也是持锁访问队列
    
- 唤醒时多个消费者会**一起争锁**，但因为我们用 `wait(lk, pred)`，只有真正拿到锁且条件满足的线程才会取走数据，其余继续睡，有竞争但不会错乱。
    
- 如果每次只 push 一个元素，用 `notify_one` 即可；如果一次 push 很多、你希望多个消费者都尽快被唤醒，可以用 `notify_all`（但要注意惊群效应）。
    

---

## 五、常见坑与注意事项

### 5.1 忘记用谓词版 `wait`（或忘记写 while）

**错误写法：**

```C++
cv.wait(lk); // ❌
if (q.empty()) { ... }    // 这里可能依然为空
```

C++ 标准明确：**允许虚假唤醒**。并且在 `notify` 与 `wait` 之间条件也可能已被别人改掉。

**正确写法：**

```C++
cv.wait(lk, [&]{ return 条件; });
// 或：
while (!条件) {
    cv.wait(lk);
}
```

---

### 5.2 在没有锁保护的情况下访问共享队列

```C++
if (!q.empty()) {   // 没有加锁，看起来很“省”
    int v = q.front();
    q.pop();        // data race + 竞态条件
}
```

如果多个线程这么做，可能在 `empty()` 之后立刻被别的线程 pop，导致 UB。

必须变成：

```C++
std::unique_lock<std::mutex> lk(m);
cv.wait(lk, [&]{ return !q.empty() || closed_; });
// 然后在持锁下访问 q
```

---

### 5.3 把耗时操作放在锁里做

```C++
{
    std::unique_lock<std::mutex> lk(m);
    auto item = q.front(); q.pop();
    // ❌ 在锁内做大量计算、IO、sleep
    heavy_compute(item);
}
```

后果：

- 所有其它线程都在等这个锁
    
- 生产者 push 等锁、消费者 pop 等锁 → 性能大幅下降
    

**正确策略：**

- 锁内只完成“共享状态更新”（push/pop、改标志）
    
- 真正的业务逻辑在锁外执行
    

---

### 5.4 `notify_one` vs `notify_all`

经验规则：

- 每次 push 一个元素 → `notify_one()` 即可  
    唤醒一个消费者来取就够了。
    
- `close()` 或 push 批量大任务 → `notify_all()`  
    比如你想唤醒所有等待线程，让它们都判断一下是否退出。
    

---

## 六：更高级一点：bounded queue / 无锁队列（了解即可）

真实系统中经常需要**有界缓冲区**（bounded buffer），防止生产者无限生产撑爆内存。典型方法：

- 再加一个条件变量 `cv_not_full`
    
- 当队列满时，`push` 阻塞等待 `not_full`
    
- 当 `pop` 取走元素时，通知 `not_full`
    

再往上的层次，就是：

- 用 `std::counting_semaphore` 或 C++20 并发原语实现
    
- 用 lock-free ring buffer + 原子索引，实现无锁生产者/消费者（难度和复杂度明显上升）
    

在你完全掌握 **“mutex + condition_variable + BlockingQueue”** 这一套之前，先不用急着上无锁。

---

## 总结一句话（你可以直接作为记忆锚点）：

> **C++ 多线程生产者–消费者模型 =  
> “一个互斥锁保护队列 + 一个条件变量负责阻塞/唤醒 + 一个结束标志控制退出”。**  
> 核心模板就是：
> 
> - 生产者：`锁内 push，锁外 notify`
>     
> - 消费者：`持锁 wait(谓词)，条件满足后 pop，再锁外处理`
>