[[constexpr练习题]]
#### 1. 核心直觉：什么是 `constexpr`？

一句话：

> **`constexpr` = 能在编译期算就尽量在编译期算，如果做不到也可以在运行期算。**

例如：

```C++
constexpr int add(int a, int b) {
    return a + b;
}

constexpr int x = add(1, 2);  // 编译期算出 x = 3
int y = 10;
int z = add(x, y);            // 这次在运行期算
```

- `add` 标成 `constexpr` 后，如果实参是编译期常量，编译器就**直接在编译阶段把结果算出来**。
    
- 但它 **不强制**所有调用都必须在编译期完成——参数不是常量时，就正常在运行期执行。
    

---

#### 2. `constexpr` 变量

##### 2.1 基本用法

```C++
constexpr int N = 10;
constexpr double PI = 3.141592653589793;

int arr[N];  // OK：数组大小需要编译期常量，N 是 constexpr

```
特点：

- **必须**用一个**常量表达式**初始化；
    
- `constexpr` 变量**隐式带 `const`**（顶层的、非 `mutable` 成员）。
    

```C++
constexpr int a = 1;
// 等价于
const int a = 1;  // 但 const 不保证是编译期常量，这点见下面
```

##### 2.2 `const` vs `constexpr`

简单对比表：

|特性|`const`|`constexpr`|
|---|---|---|
|是否必须编译期求值|否|**是**（初始化表达式必须是常量表达式）|
|是否意味着只读|是|是（顶层）|
|是否保证能当数组大小等常量用|不一定，看初始化是不是常量表达式|**一定可以**|

例子：

```C++
int n = 10;
const int c1 = n;       // 运行期初始化，c1 不是编译期常量
int arr1[c1];           // C++ 标准里不合法（很多编译器当作扩展）

constexpr int c2 = 10;  // 编译期已知
int arr2[c2];           // 标准 C++ 合法
```

---

#### 3. `constexpr` 函数

##### 3.1 基本形式

```C++
constexpr int square(int x) {
    return x * x;
}

constexpr int a = square(5);  // 编译期计算，a = 25

int b = 3;
int c = square(b);            // 运行期执行

```

**性质：**

- 函数前加 `constexpr` 表示：  
    “在所有实参都为常量表达式时，这个函数**可以**在编译期求值”；
    
- 如果某次调用不满足条件，就当普通函数调用。
    

##### 3.2 C++11 vs C++14/17 中 `constexpr` 函数限制（简单版）

- C++11：`constexpr` 函数的函数体几乎只能有一个 `return`，不能有复杂控制流；
    
- C++14 开始放宽，可以有：
    
    - `if`，`for`，`while`，局部变量等，只要整体仍然能在编译期求值；
        
- C++20 又放宽了更多（甚至能 `constexpr` 一些 STL 容器操作），这里就不展开了。
    

##### 3.3 常见示例：编译期阶乘

```C++
constexpr int factorial(int n) {
    int result = 1;
    for (int i = 2; i <= n; ++i) {
        result *= i;
    }
    return result;
}

constexpr int F5 = factorial(5);  // 编译期计算 F5 = 120
int x = factorial(4);             // 运行期计算

```

这种写法经常用来**生成编译期表、查表、预计算常量等**。

---

#### 4. `constexpr` 构造函数 & 对象

你可以给类的构造函数、成员函数加 `constexpr`，让这个类型支持**编译期对象**。

##### 4.1 `constexpr` 构造函数

```C++
struct Point {
    int x;
    int y;

    constexpr Point(int xx, int yy) : x(xx), y(yy) {}
    constexpr int manhattan() const { return x + y; }
};

constexpr Point p1(1, 2);       // 编译期构造
constexpr int d = p1.manhattan();  // 编译期计算 d = 3

```

要求（按 C++ 标准简化一下说）：

- 成员本身要能在编译期初始化（比如都是基本类型 / 其他 constexpr 类型）；
    
- 构造函数体不能做明显的运行期行为（比如 I/O，动态分配等）；
    
- 成员函数要想在 `constexpr` 上下文中用，也需要声明为 `constexpr` / `consteval`。
    

---

#### 5. `constexpr if`（不要和单独的 `constexpr` 混淆）

`constexpr if` 是 C++17 引入的语法，用来做**编译期条件分支**，常出现在模板里：

```C++
template<typename T>
void print_type_info(const T& x) {
    if constexpr (std::is_integral_v<T>) {
        std::cout << "integral: " << x << "\n";
    } else if constexpr (std::is_floating_point_v<T>) {
        std::cout << "float: " << x << "\n";
    } else {
        std::cout << "other type\n";
    }
}

```

区别于普通 `if` 的关键点：

- 条件在编译期就能算出；
    
- **不被选中的分支会直接被丢弃**，甚至不会检查语法 / 实例化；
    
- 这对模板元编程非常有用。
    

注意：`if constexpr` 是 **`if` + `constexpr` 的组合语法**，跟“函数前面一个 `constexpr`”不是一回事。

---

#### 6. `constexpr` 常见使用场景

1. **编译期常量配置**
    
    - 数组大小、哈希表 bucket 数量、缓冲区大小等：
        
    
    ```C++
    constexpr std::size_t BufferSize = 4096;
char buffer[BufferSize];

    ```
2. **非类型模板参数**
    ```C++
    template<int N>
struct Vec {
    int data[N];
};

constexpr int k = 8;
Vec<k> v;  // OK：k 是 constexpr
    ```
    
3. **编译期计算 / 查表生成**
    
    - sin/cos 预计算、插值系数表、CRC 表等；
        
4. **更安全的“魔法数字”替代**
    
    - 用 `constexpr` 变量代替裸字面量，既可读又能用于编译期场景。
        

---

#### 7. 常见坑 & 注意点

##### 7.1 以为 `const` 一定是编译期常量

```C++
int n = 10;
const int c = n;   // 运行期初始化
int arr[c];        // 标准 C++ 不保证合法（有些编译器扩展允许）
```

所以：

- **需要编译期常量时，用 `constexpr` 更保险**。
    

##### 7.2 `constexpr` 变量必须立即初始化

`constexpr int x;   // ❌ 错：必须有初始化式`

##### 7.3 `constexpr` 函数不是“只能”在编译期执行

很多人会误以为：

> `constexpr` 函数 = 只能在编译期调用

其实不是，它只是**“可以在编译期执行”**，不代表运行期不能用。