## 1. 基本规则

1. **只能重载已有运算符**，不能发明新符号（比如 `**` 不行）。
    
2. **不能改变运算符的优先级/结合性/操作数个数**  
    比如 `+` 还是双目；`++` 还是单目；优先级不变。
    
3. 必须至少有一个操作数是**自定义类型**  
    例如不能重载 `int + int`。
    
4. 有些运算符**禁止重载**：
    
    - `::` 作用域
        
    - `.` 成员访问
        
    - `.*` 成员指针访问
        
    - `?:` 三目
        
    - `sizeof / typeid / alignof / noexcept` 等
        

---

## 2. 成员函数重载 vs 非成员函数重载

### 2.1 作为成员函数

形式：

```C++
class A {
public:
    A operator+(const A& rhs) const;
};

```

调用等价于：

`a1.operator+(a2)`

**特点：**

- 左操作数必须是 `A` 对象（`*this`）。
    
- 适合“修改自身/明显属于类的操作”。
    

### 2.2 作为非成员（自由函数）

形式：

`A operator+(const A& lhs, const A& rhs);`

调用：

`operator+(a1, a2)`

**特点：**

- 左右两边都可以发生隐式转换（更对称、更自然）。
    
- **`<<`/`>>` 必须是非成员**（因为左边是 `ostream/istream`）。
    

> 非成员若需要访问 `private`，就用 `friend`（你前面已经理解了）。

---

## 3. 常见运算符重载模板

### 3.1 算术运算符（`+ - * /`）

推荐“**复合赋值做成员，普通算术用非成员复用**”。

```C++
class Vec2 {
public:
    double x, y;

    Vec2(double x=0, double y=0): x(x), y(y) {}

    // 复合赋值：成员
    Vec2& operator+=(const Vec2& rhs) {
        x += rhs.x; y += rhs.y;
        return *this;
    }
};

// 普通加法：非成员，复用 +=
inline Vec2 operator+(Vec2 lhs, const Vec2& rhs) {
    lhs += rhs;
    return lhs;
}
//第一个函数是+=，而第二个函数是c=lhs+rhs，是的到求和值
```

好处：

- 代码复用
    
- 语义对称
    
- 支持 `v + w` 和 `v += w`
    

---

### 3.2 比较运算符（`== != < > <= >=`）

C++20 起可以用 `<=>` 一次性生成一堆比较，但先给传统写法：

```C++
class A {
    int v;
public:
    bool operator==(const A& rhs) const { return v == rhs.v; }
    bool operator<(const A& rhs) const  { return v < rhs.v; }
};

inline bool operator!=(const A& a, const A& b){ return !(a==b); }
inline bool operator>(const A& a, const A& b){ return b<a; }
inline bool operator<=(const A& a, const A& b){ return !(b<a); }
inline bool operator>=(const A& a, const A& b){ return !(a<b); }

```

---

### 3.3 自增自减（`++ --`）

前置/后置都能重载，但后置有一个哑元 `int` 区分。

`class Counter {     int v; public:     Counter(int v=0): v(v) {}      // ++x 前置：返回引用     Counter& operator++() {         ++v;         return *this;     }      // x++ 后置：返回旧值     Counter operator++(int) {         Counter old = *this;         ++(*this);         return old;     } };`

---

### 3.4 下标运算符（`[]`）

必须是成员函数。

```C++
class Arr {
    std::vector<int> a;
public:
    int& operator[](size_t i) { return a[i]; }
    const int& operator[](size_t i) const { return a[i]; }
};//前一个const对象是返回只读引用，后一个const是不会修改对象，优先匹配const变量
```

---

### 3.5 函数调用运算符（`()`）

让对象像函数一样用（常用于仿函数/策略对象）：

```C++
struct Add {
    int operator()(int a, int b) const { return a + b; }
};
Add add;
add(1,2); // 3

```

---

### 3.6 流插入/提取（`<< >>`）

必须是非成员（通常 friend）。

```C++
class Point {
    int x, y;
public:
    Point(int x=0,int y=0):x(x),y(y){}
    friend std::ostream& operator<<(std::ostream& os, const Point& p){
        return os << "(" << p.x << "," << p.y << ")";
    }
};

```

---

## 4. 什么时候该重载？

✅ **语义自然、不会让人意外**时重载  
例如：

- 向量/矩阵的 `+ - *`
    
- 复数 `+ *`
    
- 智能指针 `* ->`
    
- 容器 `[]`
    
- 输出 `<<`
    

❌ **语义不自然或易误导**时别重载  
例如：

- 用 `*` 表示拼字符串
    
- 用 `+` 表示“追加到日志文件”  
    会让读代码的人很痛苦。
    

---

## 5. 高级/容易踩坑点

1. **返回类型要符合直觉**
    
    - `operator+=` 返回 `*this` 的引用
        
    - 前置 `++` 返回引用，后置返回旧值（值类型）
        
2. **保持不变式**  
    例如比较要满足传递性、对称性。
    
3. **效率：参数常用 const 引用**  
    但像 `operator+` 常用“传值 lhs + 复用 +=”模式更高效可读。
    
4. **不要滥用友元**  
    只有确实需要 private 才 friend，否则用 public API。
    
5. **如果要支持 `int + A` 这种交换律**  
    最好写成非成员，否则成员只能支持 `A + int`。
    

---

## 6. 一句话小抄

- **复合赋值做成员，普通算术做非成员复用它。**
    
- `<< >> [] () -> *` 等“语义强绑定对象”的运算符通常做成员（除了 `<< >>`）。
    
- **前置++返回引用，后置++返回旧值。**
    

---