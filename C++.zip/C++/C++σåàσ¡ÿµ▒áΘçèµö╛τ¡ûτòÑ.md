代码：
```C++
static void deallocate_one(pointer p) noexcept {

// 通过 p 算回 Node*：p 指向 Node::storage，减去偏移即可
Node* node = node_from_pointer(p);

// 更新 Chunk 的 live 计数

if (node->owner->live > 0) {

--node->owner->live;

}

// 归还到 free list
node->next_free = s_free_list;
s_free_list = node;

// 这里示例版不做“live == 0 就归还整个 Chunk 给 OS”，
// 而是只做复用，让高水位内存常驻池子。
// 真要做回收，需要从 free_list 中剔除属于该 Chunk 的所有节点，
// 实现会复杂不少。
}
```
###### `通过调用node_from_pointer来释放`

```C++
// -------------------------------------------------------------

// 帮助函数：从 T* 反推出 Node*

// -------------------------------------------------------------

static Node* node_from_pointer(pointer p) {

// p 指向 Node::storage 的起始位置

unsigned char* raw = reinterpret_cast<unsigned char*>(p);

// Node::storage 在 Node 内的偏移量

constexpr std::size_t offset = offsetof(Node, storage);

return reinterpret_cast<Node*>(raw - offset);

}
```
> “p 不应该是要释放的那块内存的起始地址吗？为什么要减 offset？”

### 1. p 是谁的“起始地址”？

关键：`p` 是 **T 对象的起始地址**，不是 `Node` 对象的起始地址。

回忆 `Node` 的定义：

```C++
struct Node {
    Node*  next_free;
    Chunk* owner;
    alignas(T) unsigned char storage[sizeof(T)];
};
```

内存布局大概是这样（示意）：

```lua
        Node 对象的布局
地址低 ─► +---------------------------+  <-- Node* node (Node 的起始地址)
         | Node*  next_free           |
         +---------------------------+
         | Chunk* owner              |
         +---------------------------+
         | unsigned char storage[...]|  <-- T* p 就是指向这里,起始地址
地址高 ─► +---------------------------+

```
        

`allocate_one()` 里是这么返回指针的：

```C++
//把 Node 的 storage 当成 T* 返回 
return reinterpret_cast<pointer>(node->storage);`
```

也就是说：

- `node`：指向整个 `Node` 结构体的起始；
    
- `node->storage`：是 `Node` 里那个 `unsigned char[sizeof(T)]` 成员的起始地址；
    
- `pointer p`（即 `T* p`）：**等于 `node->storage` 的地址**。
    

对用户/容器来说，`p` 就是“这块 T 对象的起始地址”，没错。  
但对于“内存池内部的 Node 头”来说，`p` 是**一个“内部指针”，指向 Node 里的某个成员**，而不是整个 Node 的开始位置。