迭代器的类别

基于范围的for循环

------
## 0. 迭代器到底是什么（底层看法）

迭代器本质上就是一个“**指向容器元素的抽象指针**”，提供：

- **解引用** `*it` 得到元素
    
- **移动** `++it` / `it += n`
    
- **比较** `it == end`
    

它让算法不关心容器内部结构（数组、链表、树、哈希桶……），只要容器给出迭代器，算法就能遍历。

很多容器的迭代器在底层就是指针或包着指针的小对象：

- `vector<T>::iterator` ≈ `T*`（通常）
    
- `list<T>::iterator` = 指向链表节点的指针 + 重载操作
    
- `unordered_map` 的迭代器会带桶信息
    

---

## 1. 迭代器的 6 大类别（能力从弱到强）

标准用“**迭代器范畴（iterator category）**”描述一个迭代器能做什么。能力越强，算法可用的操作越多、复杂度越低。

> 记忆：  
> Input/Output（一次性）→ Forward（可多次）→ Bidirectional（能后退）→ RandomAccess（能跳）→ Contiguous（内存连续）

### 1.1 Input Iterator（输入迭代器）

**能力**：

- 只保证**单趟读取**（single-pass）
    
- `*it` 读值、`++it` 前进、`==/!=` 比较
    
- 不能写（写是 Output）
    

**典型**：

- `istream_iterator`（读输入流）[[C++ istream_iterator]]
    
- 某些生成器/懒序列的迭代器
    

**含义**：你不能保存一个旧 it 再回来读，它可能失效或变化。

---

### 1.2 Output Iterator（输出迭代器）

**能力**：

- 只写不读：
    
    - `*it = value` 写
        
    - `++it` 前进
        

**典型**：

- `ostream_iterator`
	[[C++ostream_iterator]]    
- `back_insert_iterator`（`std::back_inserter(v)`）
    [[C++back_inserter]]

---

### 1.3 Forward Iterator（前向迭代器）

**能力**：

- **多趟遍历**（multi-pass）：拷贝一个 it，两个都能独立走
    
- 可读可写（取决于 const）
    
- `++it` 前进
    

**典型**：

- `forward_list`[[C++forward_list]]
    
- `unordered_*`（遍历意义上是 Forward）
    

**重要区别于 Input**：  
Forward 允许你“回头再从某个位置继续走”（因为你保存的迭代器仍然有效，只要容器没修改导致失效）。

---

### 1.4 Bidirectional Iterator（双向迭代器）

**能力**：

- Forward 全部能力
    
- 还能 `--it` 后退一步
    

**典型**：

- `list`
    
- `map/set`（红黑树）
    
- `deque` 也是 bidirectional 以上
    [[C++双向迭代器]]

---

### 1.5 Random Access Iterator（随机访问迭代器）

**能力**：

- Bidirectional 全部能力
    
- 支持“跳跃”和下标：
    
    - `it + n`, `it - n`, `it += n`
        
    - `it2 - it1`（距离 O(1)）
        
    - `it[n]`
        
    - `< <= > >=` 比较
        

**典型**：

- `vector`
    
- `deque`
    
- `array`
    
- 原生指针 `T*`
    
[[C++随机访问迭代器]]

---

### 1.6 Contiguous Iterator（连续迭代器，C++20）

这是 RandomAccess 的更强版本，额外保证：

- **元素在内存中真正连续**
    
- `&*it` 指向一段连续数组
    
- 允许更激进优化（SIMD / memmove）
    

**典型**：

- `vector`
    
- `array`
    
- `span`
    
- 指针
    

`deque` 不是 contiguous（分段连续）。

---

## 2. 类别用来干嘛？——算法按类别选实现

标准算法会根据迭代器类别选择复杂度不同的实现。

### 2.1 例：`std::distance`

```C++
template<class It>
auto dist(It first, It last) {
  if constexpr (random_access_iterator<It>)
      return last - first;       // O(1)
  else {
      size_t n = 0;
      for (; first != last; ++first) ++n; // O(n)
      return n;
  }
}
```

所以你对 `list` 算 distance 是 O(n)，对 `vector` 是 O(1)。

### 2.2 例：`std::sort`

需要 RandomAccess：

```C++
std::sort(v.begin(), v.end()); // vector OK
std::sort(l.begin(), l.end()); // list ❌ 编译不过
```

因为排序实现依赖 `it + n`、`it2 - it1` 这些能力。  
`list` 自己有 `l.sort()`（链表适合归并排序）。

---

## 3. iterator traits（算法如何在编译期知道类别）

每个迭代器类型通过 `std::iterator_traits<It>` 暴露：

- `value_type`
    
- `reference`
    
- `pointer`
    
- `difference_type`
    
- `iterator_category`（C++17-）
    
- C++20 起用 concepts：`std::input_iterator` 等
    

容器的迭代器一般定义：

`using iterator_category = std::random_access_iterator_tag;`

算法据此 `if constexpr` / tag dispatch 做优化。

---

## 4. 迭代器失效（很重要的底层规则）

迭代器是“指向容器内部元素的句柄”，容器结构变了，句柄可能失效。

### 4.1 vector

- **扩容（reallocate）**：所有迭代器/指针/引用失效
    
- **中间 insert/erase**：插入/删除点及其后的失效
    
- **push_back 不扩容**：旧元素迭代器有效，`end()` 失效
    

### 4.2 deque

- 可能因重新分段导致大范围失效，规则更复杂
    
- 一般认为：中间插删会让很多迭代器失效
    

### 4.3 list / forward_list

- 插入/删除 **只影响被删元素的迭代器**，其它都不失效
    
- 这是链表的优势
    

### 4.4 unordered_map / unordered_set

- rehash 会让所有迭代器失效
    
- erase 只让被删的失效
    

---

## 5. 基于范围的 for（range-based for）怎么工作？

你写：

```C++
for (auto& x : range) {
    body
}
```

等价的标准展开（大意）：

```C++
{
    auto&& __range = range;                 // 1) 绑定 range（注意是万能引用）
    auto __begin = begin(__range);          // 2) 取 begin（有 ADL）
    auto __end   = end(__range);            // 3) 取 end

    for (; __begin != __end; ++__begin) {   // 4) 迭代
        auto& x = *__begin;                 // 5) 绑定元素
        body
    }
}
```

### 5.1 `begin/end` 的查找规则（ADL + std::begin）

编译器按类似顺序找：

1. `__range.begin()` / `__range.end()` 成员函数
    
2. 通过 ADL 找 `begin(__range)` / `end(__range)`
    
3. `std::begin` / `std::end`（数组也在这里支持）
    

所以你自定义容器只要提供成员 `begin/end` 或自由函数都行。

---

## 6. range-for 的细节与坑

### 6.1 `auto` / `auto&` / `const auto&` 的区别

```C++
for (auto x : v)        // 复制一份元素
for (auto& x : v)       // 引用，可修改原元素
for (const auto& x : v) // 只读引用，避免复制大对象
```

### 6.2 遍历临时对象的生命周期

`for (auto x : makeVec()) { ... }`

因为有 `auto&& __range = makeVec();`  
临时对象的生命周期被延长到循环结束，所以是安全的。

### 6.3 但不要返回“悬空迭代器对”

如果 `range` 的 begin/end 来自某个已经销毁的对象，就炸。  
比如你手写了错误的 `begin/end` 返回静态局部引用等。

### 6.4 遍历过程中修改容器（迭代器失效）

```C++
for (auto it = v.begin(); it != v.end(); ++it) {
    if (...) v.erase(it); // ❌ it 失效
}
```

range-for 里更难写安全的 erase。正确方式：

```C++
for (auto it = v.begin(); it != v.end(); ) {
    if (...) it = v.erase(it);
    else ++it;
}
```

或者 C++20：

`std::erase_if(v, pred);`

---

## 7. 你应该怎么“从类别角度”选容器/写算法？

给你一套工程直觉：

- 想要 **随机访问 / sort / 二分 / 下标 O(1)** → 选 `vector/array`（RandomAccess/Contiguous）
    
- 频繁中间插删、迭代器稳定 → `list`（Bidirectional）
    
- 只往前走、极省内存 → `forward_list`（Forward）
    
- 哈希查找快，迭代只要求前向 → `unordered_map/set`（Forward）
    
- 分段连续但两头 push/pop 快 → `deque`（RandomAccess 但非 contiguous）
    

---

## 8. 小练习（你能快速判断类别）

1. `std::advance(it, n)` 在 `list` 上复杂度？  
    **O(n)**，因为 bidirectional 不支持跳跃。
    
2. 下面哪句能编译？
    

```C++
std::list<int> l{3,1,2};
std::sort(l.begin(), l.end()); // ❌
l.sort();                      // ✅
```

3. `vector<int>::iterator` 是什么类别？  
    **RandomAccess + Contiguous**。