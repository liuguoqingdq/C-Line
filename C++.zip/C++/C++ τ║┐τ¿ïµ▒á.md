[[C++线程池的设计思想]]
[[C++线程池演示页面]]
### 代码层面：

下面是一个基于 C++11/14 标准的生产级线程池实现。它具有以下特点：

1. **泛型任务提交**：利用变长模板和 `std::bind`/`std::forward`，支持提交任意函数和参数。
    
2. **异步结果获取**：利用 `std::future` 和 `std::packaged_task`，调用者可以获得任务执行后的返回值。
    
3. **优雅关闭**：析构时自动等待所有任务完成并回收资源，防止内存泄漏。
    
4. **线程安全**：使用互斥锁（Mutex）和条件变量（Condition Variable）确保并发安全。
    

### 1. 核心代码实现 (`ThreadPool.h`)

C++

```C++
#ifndef THREAD_POOL_H
#define THREAD_POOL_H

#include <vector>
#include <queue>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <future>
#include <functional>
#include <stdexcept>
#include <type_traits>

class ThreadPool {
public:
    // 构造函数：启动固定数量的工作线程
    explicit ThreadPool(size_t threads) : stop(false) {
        for(size_t i = 0; i < threads; ++i)
            workers.emplace_back(
                [this] {
                    for(;;) {
                        std::function<void()> task;

                        {
                            // 获取锁
                            std::unique_lock<std::mutex> lock(this->queue_mutex);
                            
                            // 等待直到有任务或线程池停止
                            this->condition.wait(lock,
                                [this]{ return this->stop || !this->tasks.empty(); });
                            
                            // 如果线程池停止且任务队列为空，则退出线程
                            if(this->stop && this->tasks.empty())
                                return;
                            
                            // 取出任务（std::move 优化性能）
                            task = std::move(this->tasks.front());
                            this->tasks.pop();
                        }

                        // 执行任务
                        task();
                    }
                }
            );
    }

    // 析构函数：优雅关闭
    ~ThreadPool() {
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            stop = true;
        }
        condition.notify_all(); // 唤醒所有线程让它们去死（退出循环）
        
        // 等待所有线程结束
        for(std::thread &worker: workers) {
            if(worker.joinable())
                worker.join();
        }
    }

    // 提交任务的核心方法
    // F: 函数类型, Args: 参数包
    template<class F, class... Args>
    auto enqueue(F&& f, Args&&... args) 
        -> std::future<typename std::result_of<F(Args...)>::type> {
        
        using return_type = typename std::result_of<F(Args...)>::type;

        // 将任务包装为 packaged_task，以便获取 future
        // 使用 shared_ptr 是因为 packaged_task 不可拷贝，只能移动，
        // 而 std::function 需要可拷贝的对象（在 C++11 中）
        auto task = std::make_shared<std::packaged_task<return_type()>>(
            std::bind(std::forward<F>(f), std::forward<Args>(args)...)
        );
        
        std::future<return_type> res = task->get_future();

        {
            std::unique_lock<std::mutex> lock(queue_mutex);

            // 禁止在停止后提交任务
            if(stop)
                throw std::runtime_error("enqueue on stopped ThreadPool");

            // 将任务封装进 voqid() lambda 并放入队列
            tasks.emplace([task](){ (*task)(); });
        }
        
        condition.notify_one(); // 唤醒一个线程去执行
        return res;
    }

private:
    // 工作线程组
    std::vector<std::thread> workers;
    // 任务队列
    std::queue<std::function<void()>> tasks;
    
    // 同步原语
    std::mutex queue_mutex;
    std::condition_variable condition;
    bool stop;
};

#endif
```
lambada表达式
```C++
[capture] (参数列表) mutable(optional) noexcept(optional) -> 返回类型(optional) {
    函数体w
}
```
[[C++bind函数]]
[[C++lambada表达式]]
[[C++result_of]]

---

### 2. 使用示例 (`main.cpp`)

下面展示如何使用该线程池，包括普通函数、Lambda 表达式以及获取返回值的场景。

C++

```C++
#include <iostream>
#include <vector>
#include <chrono>
#include "ThreadPool.h"

int square(int x) {
    std::this_thread::sleep_for(std::chrono::milliseconds(100)); // 模拟耗时
    return x * x;
}

int main() {
    // 创建一个包含 4 个线程的池
    ThreadPool pool(4);
    
    // 存储 future 结果
    std::vector<std::future<int>> results;

    std::cout << "Submitting tasks..." << std::endl;

    // 1. 提交普通带返回值的任务
    for(int i = 0; i < 8; ++i) {
        results.emplace_back(
            pool.enqueue(square, i)
        );
    }

    // 2. 提交 Lambda 表达式
    auto future_lambda = pool.enqueue([]{
        std::cout << "Hello from Lambda!" << std::endl;
        return 42;
    });

    // 3. 获取结果
    std::cout << "Waiting for results..." << std::endl;
    
    for(auto && result: results)
        std::cout << result.get() << ' '; // .get() 会阻塞直到任务完成
    std::cout << std::endl;

    std::cout << "Lambda result: " << future_lambda.get() << std::endl;

    return 0;
} // pool 在此处析构，会自动等待所有任务完成并关闭线程
```

---

### 3. 设计亮点与“高可用”解析

为了达到你要求的“高可用”和“鲁棒性”，我在代码中做了以下设计：

1. **RAII (资源获取即初始化)**：
    
    - 在析构函数中设置 `stop` 标志并 `join` 所有线程。这意味着即使程序发生异常或正常退出，线程池也会清理干净，不会导致 `terminate` 或僵尸线程。
        
2. **泛型与完美转发 (`Perfect Forwarding`)**：
    
    - `enqueue` 函数使用了 `F&&` 和 `Args&&...`。这保证了无论你传的是左值、右值、引用还是指针，都能以最高效的方式传递给任务，避免了不必要的拷贝。
        
3. **类型擦除技巧**：
    
    - 任务队列是 `std::queue<std::function<void()>>`。
        
    - 但是用户的任务可能有各种返回值。
        
    - **技巧**：我们用 `std::packaged_task` 包装任务，再用 `std::shared_ptr` 包裹它，最后塞进一个无参数无返回值的 Lambda `[task](){ (*task)(); }` 中。这样既保留了返回值（通过 `future` 获取），又统一了队列接口。
        
4. **异常安全**：
    
    - 如果在 `enqueue` 过程中（比如分配内存失败）抛出异常，锁会被 `std::unique_lock` 自动释放，不会导致死锁。
        
    - 如果 `ThreadPool` 已经停止（stop 为 true），再提交任务会抛出 `std::runtime_error`，而不是默默崩溃或未定义行为。
        

### 4. 还可以如何改进？（生产环境建议）

如果要在**极高负载**或**特定业务**场景下使用，可以考虑以下优化方向：

- **工作窃取 (Work Stealing)**：当前是一个全局锁和全局队列。在极高并发下，锁竞争会影响性能。可以让每个线程有自己的队列，当自己队列空时，去“偷”别人的任务。
    
- **线程数量动态调整**：目前的实现是固定大小。可以增加逻辑，当任务积压过多时动态增加线程，空闲过久时销毁线程。
    
- **优先级队列**：将 `std::queue` 替换为 `std::priority_queue`，允许高优先级任务插队。
    
- **任务组 (Task Group)**：支持等待一组任务全部完成（类似于 `WaitAll`）

------

### 线程池解析：

## 一、核心逻辑与正确性

### 1.1 worker 线程循环

```C++
for(;;) {
    std::function<void()> task;

    {
        std::unique_lock<std::mutex> lock(this->queue_mutex);
        this->condition.wait(lock,
            [this]{ return this->stop || !this->tasks.empty(); });

        if(this->stop && this->tasks.empty())
            return;

        task = std::move(this->tasks.front());
        this->tasks.pop();
    }

    task();
}
```

优点：

- 使用 `condition.wait(lock, predicate)`，**正确处理了虚假唤醒**；
    
- 退出条件设计得很好：
    
    - `stop && tasks.empty()` 时退出；
        
    - 这意味着：**析构时会把当时队列里已经提交的任务全部跑完再退出**；
        
- `task` 在锁外执行，避免长时间持锁，**不会阻塞其它 worker 抢任务**。
    

这是一个完全正确、经典的消费循环。

### 1.2 析构函数的 shutdown 语义

```C++
~ThreadPool() {
    {
        std::unique_lock<std::mutex> lock(queue_mutex);
        stop = true;
    }
    condition.notify_all(); 
        
    for(std::thread &worker: workers) {
        if(worker.joinable())
            worker.join();
    }
}
```
语义：

1. 持锁把 `stop` 设为 `true`；
    
2. `notify_all()` 唤醒所有 worker；
    
3. worker 被唤醒后逻辑是：
    
    - 如果队列非空 → 继续把剩下任务做完；
        
    - 队列为空 & `stop == true` → 返回、结束线程；
        
4. 主线程 `join()` 所有 worker。
    

**结论：**

- 线程池析构时，**所有已经入队的任务一定会被执行完**；
    
- 析构返回后，不会有悬挂线程，不存在“后台线程还在乱跑”的情况。
    

这是一个很好的 RAII 语义：**“池对象存在期间，提交的任务会被跑完；池析构 → 自动收尾”。**

---

## 二、`enqueue` 设计与泛型细节

### 2.1 返回 `std::future<return_type>`

```C++
template<class F, class... Args>
auto enqueue(F&& f, Args&&... args) 
    -> std::future<typename std::result_of<F(Args...)>::type> {
    
    using return_type = typename std::result_of<F(Args...)>::type;
    ...
    auto task = std::make_shared<std::packaged_task<return_type()>>(
        std::bind(std::forward<F>(f), std::forward<Args>(args)...)
    );
    ...
    tasks.emplace([task](){ (*task)(); });
    ...
}
```

这是经典套路：

- 用 `std::packaged_task<return_type()>` 把用户的 callable 包一层；
    
- 放进 `std::function<void()>` 队列里跑；
    
- `packaged_task` 内部帮你把**返回值 / 异常**送进 `future`；
    
- `enqueue` 返回这个 `future`，调用者用 `get()` 拿结果。
    

优点：

- 支持有返回值、无返回值的任务；
    
- 异常自动通过 `future` 传播；
    
- 用 `shared_ptr` 解决 `std::function` 需要可拷贝，而 `packaged_task` 只可移动的问题。
    

这一段是教科书中经常见到的写法，没问题。

### 2.2 停止后禁止提交

```C++
{
    std::unique_lock<std::mutex> lock(queue_mutex);
    if(stop)
        throw std::runtime_error("enqueue on stopped ThreadPool");
    tasks.emplace([task](){ (*task)(); });
}
```

- 在持锁状态下检查 `stop`，**不会有竞态**；
    
- 一旦进入析构，把 `stop` 设真，以后所有 `enqueue` 都会立刻抛异常。
    

语义清晰：**“这个池一旦开始退出，就不能再接新单了。”**  
这也符合 RAII 的期望。

---

## 三、并发安全性检查（data race / 死锁）

### 3.1 `stop` 是否有 data race？

好多同学第一个担心点是：`stop` 是普通 `bool`，不是 `atomic`，会不会有 data race？

看读写点：

- 写：只在析构里，在 `queue_mutex` 上了锁：
    
    ```C++
    {
    std::unique_lock<std::mutex> lock(queue_mutex);
    stop = true;
}
    ```
    
- 读：只在持有同一把锁时访问：
    
    ```C++
    this->condition.wait(lock,
    [this]{ return this->stop || !this->tasks.empty(); });
	if(this->stop && this->tasks.empty())
    return;
    ```
    

**所有对 `stop` 的访问都在 `queue_mutex` 保护下**，  
因此没有 data race，不需要 `std::atomic<bool>`。

### 3.2 死锁风险？

- 唯一的互斥量是 `queue_mutex`；
    
- worker 在持锁区间仅做：
    
    - wait；
        
    - 检查 stop & queue；
        
    - pop 一个任务；
        
- 任务执行在锁外，不会在 `task()` 里触发 `enqueue` 时重入死锁（即便任务里再 `enqueue`，那是另一次独立上锁）。
    

因此，这个实现不会有明显死锁风险，只要任务本身不搞花活（例如任务里无限等待线程池析构之类的自杀行为）。

---

## 四、现代 C++ 视角的改进建议（C++17/20）

你这个版本是典型的 C++11 写法。如果我们站在 C++17/20 角度，可以做一些“**语义不变，但更现代**”的升级。

### 4.1 替换 `std::result_of`（C++17 起废弃）

```C++
// 现在写法：
using return_type = typename std::result_of<F(Args...)>::type;
// 更推荐：
using return_type = std::invoke_result_t<F, Args...>;
```

- `std::result_of` 在 C++17 被标记为 deprecated，C++20 被移除；
    
- 推荐使用 `std::invoke_result_t` 搭配 `std::invoke`，还能更好支持成员函数指针等调用形式。
    

同时，把 `std::bind` 换成 `std::invoke` + lambda 更干净：

```C++
auto task = std::make_shared<std::packaged_task<return_type()>>(
    [fn = std::forward<F>(f), ...capturedArgs = std::forward<Args>(args)...]() mutable {
        return std::invoke(std::move(fn), std::move(capturedArgs)...);
    }
);
```

（当然，这段写法略长，很多人干脆就保留 `bind`，工程上也没大问题）

### 4.2 显式禁用拷贝

当前类没有显式声明拷贝构造/赋值，但因为 `std::thread` 不可拷贝，所以默认拷贝构造会被删掉，用起来没问题，只是错误信息可能不直观。

更现代一点可以加上：

```C++
ThreadPool(const ThreadPool&) = delete;
ThreadPool& operator=(const ThreadPool&) = delete;
```

表示：**线程池不可拷贝**，语义清晰。

### 4.3 C++20 视角的“可停止线程”（`std::jthread` + stop_token）

你这里用的是“硬 stop flag + 析构时 join”，这一套没有问题。  
如果希望支持“**外部发停**”＋**任务响应停止**，可以从：

- 使用 `std::jthread` 替代 `std::thread`；
    
- 为任务提供 `std::stop_token` 之类信息；
    

但这已经是“设计增强”，不属于这个基础实现必须做的。

---

## 五、功能层面可以扩展的地方（但不是 bug）

这些不是“错”，而是**“如果你在论文/工程中玩得再花一点，可以继续做的事”**：

1. **没有任务优先级 / 工作窃取**
    
    - 当前是简单 FIFO 队列 + 多 worker；
        
    - 不适合高复杂度调度场景（如 priority、队列隔离、NUMA 等）。
        
2. **没有任务取消 / 超时**
    
    - 一旦任务入队，线程池坚持把它跑完；
        
    - 想支持取消，需要任务本身定期检查某种 `stop_token`。
        
3. **没有队列上限控制**
    
    - `tasks` 无界增长，提交速度远大于消费速度时，可能撑爆内存；
        
    - 工程版通常会加“最大队列长度”，满时要么阻塞 `enqueue`，要么丢任务。
        
4. **不支持 continuation / `when_all` 风格组合**
    
    - 目前就是“提交 + future.get()”；
        
    - 想玩更高级的异步任务组合，可以在这个池之上封一层自己的 `Future/Task` 抽象。
        

---

## 六、综合评价 & 一句话总结

如果这是一道“实现 C++11 线程池”的考试题，我会打分：

- **正确性：A**（条件变量用法正确、shutdown 语义清晰、无 data race）
    
- **接口设计：A-**（`future` 返回值，使用简单清晰；可以再用 `invoke_result_t` 现代化一下）
    
- **高级特性：B+**（基础功能齐全，但还没涉及优先级、取消、限流等工程增强点）
    

一句压缩总结就是：

> 这是一个典型、稳健的 C++11 风格线程池实现，适合作为你后续“玩更高层抽象（`packaged_task`、自定义 Future、协程调度）”的地基。如果你愿意，我们可以在这个实现之上，给你做一层“`then` + `when_all` 风格的异步任务接口，顺便帮你把它和前面讲的 continuation / 协程世界连起来。

----
### 优化后的线程池
```C++
#ifndef THREAD_POOL_H

#define THREAD_POOL_H

  

#include <vector>

#include <queue>

#include <thread> // 包含 jthread 和 stop_token

#include <mutex>

#include <condition_variable>

#include <future>

#include <functional>

#include <type_traits>

#include <memory>

  

class ThreadPool {

public:

explicit ThreadPool(size_t threads) {

for(size_t i = 0; i < threads; ++i) {

// C++20: jthread 自动传递 stop_token

workers.emplace_back([this](std::stop_token st) {

for(;;) {

std::function<void()> task;

{

std::unique_lock<std::mutex> lock(this->queue_mutex);

// C++20 杀手锏: wait 接受 stop_token

// 如果 st.stop_requested() 为真，wait 会自动返回 false 并退出阻塞

// 这样我们就不需要手动 notify_all 了！

if (!this->condition.wait(lock, st, [this]{ return !this->tasks.empty(); })) {

// wait 返回 false 说明是因为 stop 请求被唤醒的，且条件(任务非空)不满足

return;

}

// 双重检查：如果收到停止信号且队列空了，就退出

// 注意：如果想“做完所有任务再退出”，逻辑需要微调。

// 这里演示的是“响应停止信号，如果队列为空就走”

if(st.stop_requested() && this->tasks.empty()) {

return;

}

  

task = std::move(this->tasks.front());

this->tasks.pop();

}

task();

}

});

}

}

  

// 析构函数变得极其简单！

~ThreadPool() {

// 不需要手动 stop = true

// 不需要 manual notify

// workers 析构时会自动调用 request_stop()，

// 这会触发 condition.wait 中的 stop_token，唤醒所有线程。

}

  

template<class F, class... Args>

auto enqueue(F&& f, Args&&... args)

-> std::future<std::invoke_result_t<std::decay_t<F>, std::decay_t<Args>...>>

{

using return_type = std::invoke_result_t<std::decay_t<F>, std::decay_t<Args>...>;

  

auto task = std::make_shared<std::packaged_task<return_type()>>(

[func = std::forward<F>(f), ...args = std::forward<Args>(args)]() mutable {

return std::invoke(func, args...); // 这里的 args 已经是通过 move 捕获的副本

});

std::future<return_type> res = task->get_future();

{

std::lock_guard<std::mutex> lock(queue_mutex);

// 依然需要 check stop，但在无 bool stop 变量设计中，

// 往往假设析构前用户不会再提交任务，或者需要额外原子变量。

// 为了简化，这里省略显式的 stop 检查，或者由于 workers 尚未析构，继续入队也无妨。

tasks.emplace([task](){ (*task)(); });

}

condition.notify_one();

return res;

}

  

private:

std::queue<std::function<void()>> tasks;

std::mutex queue_mutex;

// C++20: condition_variable_any 支持 stop_token

std::condition_variable_any condition;

std::vector<std::jthread> workers;

};
#endif
```


## . 先标出代码里有哪些“函数对象”

你这段代码里实际上有 **两个 lambda + 一个 `packaged_task`**：

```C++
template<class F, class... Args>
auto enqueue(F&& f, Args&&... args)
-> std::future<std::invoke_result_t<std::decay_t<F>, std::decay_t<Args>...>>
{
    using return_type =
        std::invoke_result_t<std::decay_t<F>, std::decay_t<Args>...>;

    auto task = std::make_shared<std::packaged_task<return_type()>>(
        // 【1】这个 lambda：真实执行用户函数，返回 return_type
        [func = std::forward<F>(f), ...args = std::forward<Args>(args)]() mutable {
            return std::invoke(func, args...); 
        }
    );

    std::future<return_type> res = task->get_future();

    {
        std::lock_guard<std::mutex> lock(queue_mutex);

        // 【2】这个 lambda：只负责“调用 packaged_task”，自己是 void()
        tasks.emplace([task]() {
            (*task)();   // 这里调用的是 packaged_task 的 operator()
        });
    }

    condition.notify_one();
    return res;
}
```

队列定义大概是：

`std::queue<std::function<void()>> tasks;`

**关键问题**：

- 队列里存的是 **【2】号 lambda**，类型相当于 `void()`；
    
- `return std::invoke(func, args...)` 出现在 **【1】号 lambda** 里，它返回 `return_type`，但这个返回值从来没有直接和 `std::function<void()>` 打交道。
    

---