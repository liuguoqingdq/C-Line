## 一、最朴素的理解：什么是内联函数？

形式：

```C++
inline int add(int a, int b) {             return a + b; 
}
```

你可以像普通函数一样用：

`int x = add(1, 2);`

### 1.1 “内联展开”的直觉（但只是建议）

理想中，编译器可能把上面这句：

`int x = add(1, 2);`

在汇编里变成类似：

`int x = 1 + 2;  // 不再有函数调用开销`

所以叫 **内联**（inline）：把函数体“拷贝”到调用点。

> 但关键是：  
> **`inline` 只是一个“建议/资格”，不是强制命令**。  
> 编译器可以选择不内联（比如函数太复杂、递归、或开启了调试）。

现代编译器（-O2/-O3）即使你不写 `inline`，也会对简单函数自动做内联优化。所以 **“让编译器内联”不再是 `inline` 的主要价值**。

---

## 二、现代 C++ 里 `inline` 的真正价值：允许“多处定义”（C++17）

### 2.1 普通函数的 ODR 限制

假设你在头文件里这么写：

```C++
// util.h 
int add(int a, int b) {   // 定义     
return a + b; }
```

然后这个头文件被两个 .cpp 都 `#include`：

```C++
//a.cpp 
#include "util.h"  

// b.cpp 
#include "util.h"
```

链接时会发生什么？

- `a.cpp` 里有一份 `add` 定义；
    
- `b.cpp` 里也有一份 `add` 定义；
    
- 链接器看到同名的**多个外部定义**，直接报 multiple definition 错误。
    

### 2.2 加上 `inline` 后就合法了

```C++
//util.h 
inline int add(int a, int b) {     return a + b; }
```

现在即使被很多 `.cpp` 包含，**每个编译单元里各有一份定义，也没问题**。

语言规则变成：

> 对于 `inline` 函数：  
> 在多个翻译单元中，可以有**多个完全相同的定义**；  
> 链接时会把这些当作“一份逻辑定义”。

这就是为什么：

- 想在 **头文件** 里同时写“声明 + 定义”的小函数/模板函数，必须标 `inline`（或者 `constexpr`，它隐含 inline）。
    

**常见实践：**

```C++
 //math_utils.h 
 #pragma once  
 inline int add(int a, int b) {     return a + b; 
 }
```

之后别人只管 `#include "math_utils.h"`，不会有多重定义的问题。

---

## 三、`inline` 与 `constexpr` / `static` 的关系

### 3.1 `constexpr` 函数自动是 `inline`

```C++
constexpr int square(int x) {     return x * x;
 }
```

- 标准规定：**`constexpr` 函数隐式是 `inline`**；
    
- 所以你可以安全地在头文件中定义 `constexpr` 函数，而不用再额外加 `inline`。
    

### 3.2 `static` 函数 vs `inline` 函数

```C++
// static 函数
static int add(int a, int b) { return a + b; }

// inline 函数
inline int add2(int a, int b) { return a + b; }

```

区别：

- `static`：
    
    - **内部链接（internal linkage）**，
        
    - 每个 `.cpp` 自己有一份私有版本，互不冲突；
        
    - 适合“只在本文件用”的小函数。
        
- `inline`：
    
    - **外部链接（external linkage + 特殊 ODR 规则）**，
        
    - 可以在多个文件中定义，只要定义完全相同；
        
    - 适合放在**头文件**里给整个工程用。
        

---

## 四、`inline` 函数 vs 宏函数

以前很多人用宏来避免函数调用开销，例如：

`#define ADD(a, b) ((a) + (b))`

缺点：

- 不做类型检查；
    
- 参数会被多次求值，可能有副作用问题（例如 `ADD(i++, j++)`）；
    
- 调试、错误定位都很难受。
    

用 `inline` 函数可以替代宏：

```C++
inline int add(int a, int b) {     return a + b; }
```

优点：

- 有类型检查；
    
- 参数只求值一次；
    
- 在需要时依然可能被内联展开。
    

---

## 五、什么时候该用 / 不该用 `inline`

### 5.1 适合用的场景

1. **头文件里的小函数实现**
    

```C++
// vec2.h
struct Vec2 {
    double x, y;

    inline double length2() const { return x*x + y*y; }
};

```

2. **模板函数的定义通常也在头文件**  
    （模板本身就要求定义可见，通常会隐式 inline）
    
3. **特别短、简单、频繁调用的工具函数**
    
    - 比如 get/set、简单数学操作等。
        

> 现代 C++：  
> 很多时候你写一个“很短的小函数 + 打开 -O2”，即使不写 `inline`，编译器也会自己内联。  
> 所以 **`inline` 更像是“头文件里允许多定义”的语义标签**。

### 5.2 不太适合用的场景

1. **大函数、复杂逻辑、带循环/递归、异常处理的函数**
    
    - 即使你写了 `inline`，编译器也大概率不会内联；
        
    - 强行这么写只会混淆含义。
        
2. **想通过 `inline` 强制优化**
    
    - 不靠谱，现在的优化器做得比人靠谱得多；
        
    - 性能问题优先看算法、数据结构、内存访问模式，真的有瓶颈再 profile。
        

---

## 六、一个综合小例子

### 头文件：`math_utils.h`

```C++
#pragma once

inline int add(int a, int b) {
    return a + b;
}

constexpr int square(int x) {   // 隐式也是 inline
    return x * x;
}

```
[[C++ constexpr关键字]]
### 源文件1：`a.cpp`

```C++
#include "math_utils.h"
#include <iostream>

void f() {
    std::cout << add(1, 2) << "\n";      // 可能内联
    std::cout << square(3) << "\n";      // 也可能内联
}

```
### 源文件2：`b.cpp`

```C++
#include "math_utils.h"

int g() {
    return add(10, 20) + square(4);
}

```

- 链接阶段不会报 multiple definition；
    
- 编译器会根据优化等级自行决定哪些调用真的“内联展开”。
-----
### 一句话总结

> **现代 C++ 里，`inline` 的真正价值更多是“允许在多个翻译单元中重复定义（通常在头文件里）”，而不是“强制编译器内联”。**  
> 真正要不要内联展开，主要由编译器和优化等级决定