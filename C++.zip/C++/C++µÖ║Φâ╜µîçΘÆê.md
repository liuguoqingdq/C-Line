## 1. 为什么需要智能指针？

裸指针的问题：

1. **忘记 delete** → 泄漏
    
2. **异常提前跳出** → 没机会 delete
    
3. **多处 delete / 重复释放** → 崩溃
    
4. **对象提前被释放** → 悬空指针（use-after-free）
    
5. **所有权不清晰** → 谁负责释放？
    

智能指针把“释放责任”编码进类型里。

---

## 2. 三大智能指针

### 2.1 `std::unique_ptr<T>` —— 独占所有权

**语义**：一个资源只能有一个拥有者。  
**特点**：

- 不能拷贝（copy deleted）
    
- 可以移动（move）
    
- 几乎零开销（通常就一个指针大小）
    
- 默认 `delete`，也支持自定义 deleter
    

**常用写法**

```C++
#include <memory>
auto p = std::make_unique<int>(42);
std::unique_ptr<Foo> q(new Foo()); // 也行，但推荐 make_unique
```

**移动所有权**

```C++
std::unique_ptr<Foo> a = std::make_unique<Foo>();
std::unique_ptr<Foo> b = std::move(a); // a 变空，b 独占
```

**传参建议**

```C++
void take(std::unique_ptr<Foo> p);   // 接管所有权
void use(const Foo* p);              // 只读使用（不接管）
void use_ref(const Foo& r);          // 不可空更安全
```

__自定义 deleter（管理 FILE_/socket 等）_*

```C++
auto fp = std::unique_ptr<FILE, decltype(&fclose)>(
    fopen("a.txt", "r"), &fclose);
```
[[C++unique_ptr]]

---

### 2.2 `std::shared_ptr<T>` —— 共享所有权（引用计数）

**语义**：多个 `shared_ptr` 共同拥有资源，**最后一个销毁时释放**。  
**特点**：

- 拷贝会增加引用计数
    
- 析构会减少引用计数
    
- 引用计数一般是**原子操作**（线程安全地增减）
    
- 比 unique_ptr 重（额外控制块 + 原子开销）
    

**常用写法**

```C++
auto sp = std::make_shared<Foo>(args...);
```

**计数**

```C++
auto a = std::make_shared<int>(1);
auto b = a;
std::cout << a.use_count(); // 2
```

**自定义 deleter**

```C++
std::shared_ptr<FILE> fp(fopen("a.txt","r"), [](FILE* f){
    if(f) fclose(f);
});
```

---

### 2.3 `std::weak_ptr<T>` —— 观察者（打破环）

**语义**：不拥有资源，只观察 shared_ptr 管理的对象。  
**特点**：

- 不增加引用计数
    
- 用 `.lock()` 临时变成 `shared_ptr`（若对象还活着）
    

**典型场景：解决循环引用**

```C++
struct B;
struct A { std::shared_ptr<B> b; };
struct B { std::weak_ptr<A> a; }; // 用 weak_ptr 打破环
```

**使用**

```C++
std::weak_ptr<Foo> wp = sp;
if (auto p = wp.lock()) {  // p 是 shared_ptr
    p->do_something();
} else {
    // 对象已释放
}
```
[[C++weak_ptr]]

---

## 3. `auto_ptr` 已废弃

`std::auto_ptr`（C++98）是早期智能指针，拷贝会“偷走所有权”，语义很坑。  
C++11 起废弃，C++17 移除。别再用。

---

## 4. `make_unique` / `make_shared` 为什么推荐？

### 4.1 异常安全

```C++
foo(std::shared_ptr<T>(new T), bar()); // 若 bar() 抛异常，new T 泄漏风险
foo(std::make_shared<T>(), bar());     // 安全
```

### 4.2 性能/内存

`make_shared` 会把 **对象 + 控制块** 一次性分配，少一次 `new`，缓存更友好。  
缺点：对象内存与控制块绑定，可能导致“对象被释放但控制块还活着”时内存迟迟不回收（极少数场景需要 `shared_ptr(new T)` 来分离）。

---

## 5. 底层关键点（你应该知道的）

### 5.1 shared_ptr 的控制块

每个 shared_ptr 关联一个控制块，里面有：

- strong count（共享引用数）
    
- weak count（弱引用数）
    
- deleter / allocator 等  
    对象释放时 strong→0；控制块释放要 weak 也→0。
    

### 5.2 线程安全边界

- **引用计数增减是线程安全的**（原子）
    
- 但 **被管理对象本身不是自动线程安全**，要你自己加锁。
    

### 5.3 enable_shared_from_this

对象想在成员函数里拿到“指向自己的 shared_ptr”，必须继承它：

```C++
struct Foo : std::enable_shared_from_this<Foo> {
    std::shared_ptr<Foo> getSelf() {
        return shared_from_this();
    }
};
```

**注意**：对象必须一开始就由 shared_ptr 管理（比如 make_shared），否则 shared_from_this 会抛异常。

### 5.4 aliasing constructor（很有用）

让 shared_ptr 共享同一个控制块，但指向子对象：

```C++
auto sp = std::make_shared<Big>();
std::shared_ptr<Part> part(sp, &sp->part); // 共用计数
```

好处：`part` 活着时，`Big` 不会被释放。

---

## 6. 常见坑

1. **循环引用泄漏**
    
    ```C++
    A has shared_ptr<B>, B has shared_ptr<A>
    ```
    
    strong count 永不归零 → 泄漏。用 weak_ptr。
    
2. **把同一裸指针交给多个 shared_ptr**
    
    ```C++
    Foo* p = new Foo;
	std::shared_ptr<Foo> a(p);
	std::shared_ptr<Foo> b(p); // ❌ 两个控制块 -> double delete
    ```
    
    正确：只生成一次 shared_ptr，再拷贝/传递。
    
3. **unique_ptr 误拷贝**
    
    ```C++
    auto a = std::make_unique<Foo>();
	auto b = a; // ❌ 不能拷贝
    ```
    
    要 move：`auto b = std::move(a);`
    
4. **用 shared_ptr 管理 this**
    
    `std::shared_ptr<Foo> p(this); // ❌ 极易双重释放`
    
    用 enable_shared_from_this。
    

---

## 7. 选型建议（实战最重要）

- 默认首选 **`unique_ptr`**：  
    所有权清晰、性能最好。
    
- 只有当“确实需要多处共享生命周期”时用 **`shared_ptr`**。
    
- 只观察、不管理生命周期 → **`weak_ptr`**。
    
- 不要滥用 shared_ptr：引用计数、控制块、并发原子都更重。