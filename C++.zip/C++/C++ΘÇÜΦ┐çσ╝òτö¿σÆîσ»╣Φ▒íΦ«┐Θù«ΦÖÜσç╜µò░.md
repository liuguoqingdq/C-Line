在 C++ 中，**通过引用（Reference）**和**通过对象（Object/Value）**访问虚函数，行为是截然不同的。这是理解 C++ 多态（Polymorphism）最核心的关键点。

简单结论：

1. **通过引用（或指针）访问：会触发多态**（动态绑定）。调用的是对象**实际类型**（Runtime Type）的函数。
    
2. **通过对象（值拷贝）访问：不会触发多态（静态绑定）。调用的是变量声明类型**（Compile-time Type）的函数，并且会发生**对象切割**。
    

下面通过代码实例和底层原理来详细解释。

### 1. 代码实例对比

C++

```C++
#include <iostream>

class Base {
public:
    virtual void say() {
        std::cout << "我是 Base" << std::endl;
    }
    virtual ~Base() {} // 虚析构函数（好习惯）
};

class Derived : public Base {
public:
    void say() override {
        std::cout << "我是 Derived" << std::endl;
    }
};

void callByReference(Base& b) {
    b.say(); // 引用传递
}

void callByValue(Base b) {
    b.say(); // 值传递（对象拷贝）
}

int main() {
    Derived d;

    std::cout << "1. 直接调用 Derived 对象 d:" << std::endl;
    d.say(); 

    std::cout << "\n2. 通过 Base 引用访问:" << std::endl;
    Base& ref = d; 
    ref.say(); // 【发生多态】

    std::cout << "\n3. 通过 Base 对象（值拷贝）访问:" << std::endl;
    Base obj = d; // 【发生对象切割】
    obj.say(); 

    std::cout << "\n4. 函数参数对比:" << std::endl;
    callByReference(d); // 传引用 -> 多态
    callByValue(d);     // 传值   -> 切割，无多态

    return 0;
}
```

**运行结果：**

Plaintext

```lua
1. 直接调用 Derived 对象 d:
我是 Derived

2. 通过 Base 引用访问:
我是 Derived

3. 通过 Base 对象（值拷贝）访问:
我是 Base

4. 函数参数对比:
我是 Derived
我是 Base
```

---

### 2. 深度解析：为什么会这样？

#### 情况 A：通过引用访问 (`Base& ref = d;`)

- **机制：** 引用本质上是一个别名（底层通常是指针实现）。`ref` 虽然类型是 `Base&`，但它指向的内存地址仍然是 `Derived` 对象 `d` 的原始地址。
    
- **虚函数表 (vptr)：** 编译器看到 `say()` 是虚函数，且通过引用调用，于是会进行**动态绑定 (Dynamic Binding)**。它会去查看该对象内存头部的**虚函数表指针 (vptr)**。
    
- **结果：** 因为对象本身是 `Derived`，它的 vptr 指向的是 `Derived` 的虚函数表，所以调用了 `Derived::say()`。
    

#### 情况 B：通过对象访问 (`Base obj = d;`)

- **机制：** 这一步发生了一个被称为 **“对象切割” (Object Slicing)** 的过程。
    
- **发生了什么：** `Base obj = d;` 实际上调用了 `Base` 的**拷贝构造函数**。编译器只把 `d` 中属于 `Base` 的那部分成员变量拷贝给了 `obj`，而 `Derived` 特有的部分被丢弃（切割）了。
    
- **vptr 的重置：** 最关键的是，新创建的对象 `obj` 是一个纯正的 `Base` 类对象。**它的 vptr 会被设置为指向 `Base` 的虚函数表**，而不是 `Derived` 的。
    
- **结果：** 无论原本的数据来源是什么，`obj` 现在就是一个普通的 `Base` 对象，调用 `obj.say()` 自然执行 `Base::say()`。这是**静态绑定 (Static Binding)**，在编译期就决定了。
    

---

### 3. 图解对象切割 (Object Slicing)

假设内存布局如下：

**原始 Derived 对象 `d`:**

Plaintext

```lua
[ vptr (指向 Derived表) ]  <-- Base& ref 指向这里
[ Base 的成员变量       ]
[ Derived 的成员变量    ]
```

**执行 `Base obj = d` 后的 `obj`:**

Plaintext

```lua
[ vptr (指向 Base表)    ]  <-- 这是一个全新的对象，vptr 重置
[ Base 的成员变量       ]  <-- 从 d 拷贝过来的
(Derived 的部分丢失了)
```

### 4. 总结

|**访问方式**|**代码示例**|**是否多态**|**绑定时机**|**底层行为**|
|---|---|---|---|---|
|**引用/指针**|`Base& r = d;`<br><br>  <br><br>`r.func();`|**是**|**运行时** (Dynamic)|查 vptr -> 查 vtable -> 调用实际类型函数|
|**对象 (值)**|`Base o = d;`<br><br>  <br><br>`o.func();`|**否**|**编译时** (Static)|发生**对象切割**，vptr 指向基类表，直接调用基类函数|

### 建议

在 C++ 中使用多态时，**务必使用指针或引用**来传递对象。如果你在函数参数中写了 `void func(Base b)`，那么多态就会立即失效；正确的写法应该是 `void func(const Base& b)` 或 `void func(Base* b)`。