## 一、C++ 中的 `new`：到底干了几件事？
[[new与delete练习题]]
### 1.1 `new` 不是简单的“malloc”

以这句为例：

`Foo* p = new Foo(42);`

背后其实分两步：

1. **分配原始内存**  
    调用的是 _函数_ `operator new`（注意：是函数，不是关键字）：
    
    ```C++
    void* mem = operator new(sizeof(Foo)); 
     // 可能是全局的，也可能是类重载的
    ```
    
2. **在这块内存上调用构造函数**
    
```C++
   ```C++
    Foo* p = new(mem) Foo(42);  
    // 这就是“placement new”的形式
```
    
语法糖把这两步写成了一句：

`Foo* p = new Foo(42);`

**所以：**

- `new` 不仅仅是“申请内存”，**还会调用构造函数**；
    
- 内部真正分配的动作是 `operator new` 函数（可以重载）。
    

---

### 1.2 `new` 的几种常见形式

#### ① 单对象 `new`

```C++
int* p1 = new int(5);      // 分配 1 个 int，对其值初始化为 5 
Foo* p2 = new Foo();       // 调用 Foo 的无参构造 
Foo* p3 = new Foo(1, 2);   // 调用 Foo(int, int) 构造
```

#### ② 动态数组 `new[]`

```C++
int* arr = new int[10];        // 分配 10 个 int，默认初始化（基本类型是未初始化） 
Foo* objs = new Foo[3];        // 调用 3 次 Foo() 构造
```

> ⚠️ 注意：数组形式一定要用 `delete[]` 释放。

#### ③ `nothrow` 形式

```C++
#include <new>  
int* p = new(std::nothrow) int[100000000000]; 
if (!p) {     
// new 失败返回 nullptr，而不是抛异常 
}
```

默认情况下，`new` 分配失败会 **抛出 `std::bad_alloc` 异常**，而不用你去判空。

---

### 1.3 `new` 与初始化的细节（顺带提一下）

```C++
int* p1 = new int;        // 默认初始化：内存未定义，p1 指向的值是垃圾 
int* p2 = new int();      // 值初始化：变成 0 
int* p3 = new int(5);     // 值初始化为 5
```

类类型对象：

`Foo* p1 = new Foo;   // 调用默认构造 Foo* p2 = new Foo(); // 同上`

---

## 二、C++ 中的 `delete`：干了几件事？

### 2.1 和 `new` 是配对的

```C++
Foo* p = new Foo(42); 
delete p;
```

也分两步：

1. **调用析构函数**
    
    `p->~Foo();`
    
2. **释放内存**
    
    `operator delete(p);`
    

### 2.2 单对象 vs 数组：`delete` vs `delete[]`

```C++
int* p = new int(5); 
delete p;          // ✅  
int* arr = new int[10]; 
delete[] arr;      // ✅ 
delete arr;        // ❌ 未定义行为（UB）
```

对于类类型数组：

```C++
Foo* objs = new Foo[3]; 
delete[] objs;     // 会依次调用 3 次 ~Foo()，再释放整块内存
```

> **一定要保证：**
> 
> - `new` ↔ `delete`
>     
> - `new[]` ↔ `delete[]`  
>     不要混用。
>     

---

### 2.3 几个典型“玩死自己”的错误

1. **重复释放（double delete）**
    
    ```C++
    int* p = new int(5);
     delete p; 
     delete p;   // ❌ 未定义行为
    ```
    
2. **释放非 `new` 得到的指针**
    
    ```C++
    int x = 10; 
    int* p = &x; 
    delete p;   // ❌ 未定义行为
    ```
    
3. **`new` / `malloc` 混用**
    
    ```C++
    int* p = (int*)malloc(sizeof(int)); 
    delete p;   // ❌ 未定义行为  
    int* p2 = new int(5); free(p2);   // ❌ 未定义行为
    ```
    
    > **规则：谁申请谁释放**  
    > `new` → `delete`  
    > `new[]` → `delete[]`  
    > `malloc` → `free`
    

---

## 三、`new` vs `malloc` 的关键区别

### 3.1 语义上的区别

### ✅ `new / delete` vs `malloc / free`（标准对照表）

| 对比项  | `new` / `delete`            | `malloc` / `free`          |
| ---- | --------------------------- | -------------------------- |
| 所属   | **C++ 语言特性**                | **C 标准库函数**                |
| 头文件  | 不需要                         | `<cstdlib>` / `<stdlib.h>` |
| 返回类型 | 返回 **正确类型指针**               | 返回 `void*`（C++ 需强转）        |
| 内存分配 | 是                           | 是                          |
| 构造函数 | `new` **会调用构造函数**           | ❌ 不会                       |
| 析构函数 | `delete` **会调用析构函数**        | ❌ 不会                       |
| 失败行为 | 默认抛 `std::bad_alloc`        | 返回 `nullptr`               |
| 可重载性 | ✅ 可重载 `operator new/delete` | ❌ 不能重载                     |
| 数组支持 | `new[] / delete[]`          | 需手动计算大小                    |
| 面向对象 | ✅ 强                         | ❌ 弱                        |
| 是否配对 | `new` ↔ `delete`            | `malloc` ↔ `free`          |

比如：

```C++
Foo* p1 = new Foo(1, 2);   // 调用了构造  
Foo* p2 = (Foo*)malloc(sizeof(Foo));  // 没构造 
// 必须手动： 
new(p2) Foo(1, 2);         // placement new 上构造对象
```

所以在现代 C++ 里：

> 除了和 C 接口打交道、自己写 allocator 之类的特殊场景，**几乎不推荐在 C++ 代码里直接用 malloc/free**。  
> 普通业务逻辑统一用 `new/delete` 或智能指针就行。

---

## 四、placement new 简单提一下（知道概念即可）

`void* mem = operator new(sizeof(Foo));  // 分配原始内存 Foo* p = new(mem) Foo(42);              // 在这块内存上“原地构造”Foo`

常用于：

- 自己管理内存池；
    
- 在预分配的 buffer 上构造对象；
    
- 容器 / allocator 的内部实现。
    

释放时需要：

`p->~Foo();               // 手动调用析构 
`operator delete(mem);    // 或对应的释放方式`

> 对普通业务代码来说：  
> _placement new_ 是偏底层的技巧，日常写业务基本用不到。

## 五、现代 C++：更推荐智能指针吗？

**非常明确地说：是的。**  
而且进一步：**能不用裸 `new` / `delete` 就尽量不用。**

### 5.1 现代 C++ 的“推荐顺序”（很重要）

1. **首选：自动存储期（“栈上”对象）**
    
    `Foo x(1, 2);          // 函数结束自动析构`
    
    或者放在标准容器里：
    
    `std::vector<Foo> v;   // 容器析构时自动调用每个 Foo 的析构`
    
2. **其次：标准容器管理动态对象**
    
    - 大部分“我要 new 一个数组”的需求，都可以被 `std::vector`、`std::string`、`std::array` 替代；
        
    - 自动管理内存，异常安全，避免手动 `new[] / delete[]`。
        
3. **确实需要动态生命周期 / 多态 / 跨作用域共享时** → 用 **智能指针**：
    
    - 唯一所有权：`std::unique_ptr<T>`
        
    - 共享所有权：`std::shared_ptr<T>` + `std::weak_ptr<T>`
        
    - 搭配 `std::make_unique` / `std::make_shared` 创建对象。
        

> 裸 `new` / `delete`：  
> 只在极特殊的场景（自定义内存池、底层库、性能非常敏感 + 完全控制）才会手写，大部分应用层代码都可以完全不用。

---

### 5.2 智能指针简梳理

#### ① `std::unique_ptr<T>`：独占所有权

```C++
#include <memory>  
std::unique_ptr<Foo> p = std::make_unique<Foo>(1, 2);  // 推荐 
// 或 
std::unique_ptr<Foo> p(new Foo(1, 2));  // 也可以，但不如上面安全  
// 作用域结束自动 delete Foo
```

特点：

- 不能拷贝，只能移动（所有权唯一）；
    
- 非常适合树结构、资源句柄等“谁拿了谁负责”的场景；
    
- 几乎是“现代 C++ 的默认智能指针”。
    

#### ② `std::shared_ptr<T>`：共享所有权

```C++
std::shared_ptr<Foo> p1 = std::make_shared<Foo>(1, 2); std::shared_ptr<Foo> p2 = p1;  // 引用计数 +1 
// 最后一个 shared_ptr 析构时自动 delete Foo
```

特点：

- 使用引用计数管理对象；
    
- 适合确实需要**多方共同拥有**的对象；
    
- 要小心 **循环引用**（会导致内存泄漏），此时配合 `std::weak_ptr`。
    

#### ③ `std::weak_ptr<T>`：不参与所有权，只做“观察者”

配合 `shared_ptr`：

```C++
std::shared_ptr<Foo> sp = std::make_shared<Foo>(); 
std::weak_ptr<Foo> wp = sp;    // 不增加引用计数  
if (auto p = wp.lock()) {      // 尝试拿一个 shared_ptr     // p 非空则对象还活着 
}
```

---

### 5.3 为啥智能指针比裸 `new/delete` 好？

1. **自动 RAII 管理**
    
    - 作用域退出自动释放；
        
    - 异常抛出时也不会泄漏。
        
2. **避免忘记 delete / delete[] / double delete**
    
    - 所有这些人类会犯的错误，智能指针帮你兜住。
        
3. **表达所有权语义**
    
    - 看到 `unique_ptr` 就知道：谁拿谁负责，资源不可共享；
        
    - 看到 `shared_ptr` 就知道：这东西是多方共享的；
        
    - 裸 `T*` 很模糊：
        
        - 它是借用的？
            
        - 还是需要我 delete？
            
        - 不看文档你根本猜不出来。
            
4. **更容易进行重构和维护**
    
    - 当你把“一堆裸指针 + 各种 delete”写乱了之后，再改是噩梦；
        
    - 用智能指针可以显式推断对象生命周期，用工具做静态分析也更容易。
        

---

### 5.4 那还需要学 new/delete 吗？

**必须学。** 原因：

1. 智能指针底层还是 `new/delete`（或者 allocator / operator new）。
    
2. 看别人的老代码、库代码一定会遇到裸 `new`；
    
3. 写自定义 deleter、内存池、容器、框架时离不开这些底层概念。
    

但实务建议是：

> - **自己写业务逻辑：尽量不手写 `new/delete`**；
>     
> - **实在要 new，就马上包进智能指针**，不要裸奔。
>