#### C++ `extern` 关键字系统梳理

##### 1. `extern` 的核心作用

一句话：

> **`extern` = “这里 _只声明_ 一个在别处 _定义_ 的符号”。**
> 
> 典型用途：跨文件共享全局变量 / 与 C 代码链接。

注意：

- **变量**：`extern` 很关键（决定是“声明”还是“定义”）；
    
- **函数**：默认就是 `extern`，通常不写也行；
    
- **`extern "C"`**：控制链接方式（C 风格，无 name mangling）。
    

---

## 2. 跨文件的全局变量：`extern` 的典型用法

### 2.1 正确写法：`.h` 声明，`.cpp` 定义

```C++
// config.h  —— 头文件
#pragma once

extern int g_value;   // 声明：告诉编译器“外面有个 int g_value”

// config.cpp —— 源文件
#include "config.h"

int g_value = 42;     // 定义：真正分配存储（只能有一份）

// main.cpp
#include "config.h"
#include <iostream>

int main() {
    std::cout << g_value << "\n";  // 使用
}

```

要点：

- **头文件里只写 `extern` 声明，不写定义**；
    
- 只在某一个 `.cpp` 中写一次“**无 extern + 有初始化**”的定义；
    
- 所有需要用这个全局变量的文件，都 `#include "config.h"` 即可。
    

##### 2.2 `extern` + 初始化 = 定义（不是纯声明）

很多人容易踩的坑：

`extern int x = 10;  // 这是“定义”，不是单纯声明！`

如果你在多个 `.cpp` 都这样写：

```C++
// a.cpp 
extern int x = 10;  
// b.cpp 
extern int x = 10;
```

链接时仍然会 multiple definition。

**记住：**

> `extern` **不**会因为写上就“自动变成声明”，  
> 只要带初始化，就是定义。

---

#### 3. 函数和 `extern`

##### 3.1 普通函数默认就是“外部链接”（相当于 extern）

```C++
// utils.cpp
void foo() {}   // 默认就是 external linkage，相当于 extern void foo();

// main.cpp
void foo();     // 声明（可以写 extern，也可以不写）
int main() {
    foo();
}

```

所以：

- 一般不会写 `extern void foo();`，写 `void foo();` 就够了；
    
- 对函数来说，`extern` 更多是**显式强调链接方式**，不是必须。
    

### 3.2 `static` 函数 vs 普通（extern）函数

```C++
// a.cpp
static void f1() {}  // internal linkage：只在 a.cpp 内可见

void f2() {}         // external linkage：可被其他 .cpp 调用

```

- 不写 `static` 的普通函数 → 默认 external（类似 `extern`）；
    
- `static` 函数只能在当前编译单元使用，其他 `.cpp` 即使声明也链接不到同一个。
    

---

## 4. 局部变量上的 `extern`

你可以在函数内部写 `extern`，**但它指的是某个全局变量**，不是“函数内部定义的那个”。

```C++
int g;          // 全局变量

void f() {
    extern int g;  // 这里是在声明“外面有个 int g”
    g = 10;        // 操作的其实是上面的全局 g
}

```

但不能这么写：

```C++
void f() {
    extern int x = 10;  // 合法语法，但这定义的是一个“外部变量”，
        
// 如果你在多个函数/文件这样写，还是会 multiple definition
}
```

一般来说：

> **不要在函数内部定义 `extern` 变量（尤其是带初始化的），可读性差又容易出问题。**

---

## 5. `extern "C"`：和 C 代码/库交互

这是 C++ 中 `extern` 的第二大用途：**指定链接方式为 C**。

### 5.1 基本形式

`extern "C" void c_func(int x);`

意味着：

- 不对 `c_func` 做 C++ 的名字改编（name mangling）；
    
- 其符号名按 C 的风格导出，便于跟 C 代码/库链接。
    

### 5.2 常见用法：在头文件中包 C 接口

```C++
// api.h —— 提供给 C 和 C++ 都能包含的头文件

#ifdef __cplusplus
extern "C" {
#endif

void c_func(int x);  // C 风格接口

#ifdef __cplusplus
}
#endif

```

C++ 源文件编译时：

- `extern "C"` 让编译器按 C 方式导出 `c_func`；
    
- C 源文件编译时，`extern "C"` 宏块被忽略（因为没有 `__cplusplus`）。
    

### 5.3 `extern "C"` 区块写法

```C++
extern "C" {
    void c_func1(int);
    int  c_func2(double);
}
```
给区块内所有声明都加上 C 链接方式。

---

## 6. 链接性（linkage）与 `extern` 的关系简表

|写法|说明|
|---|---|
|`int x;`|定义，默认 external linkage|
|`extern int x;`|声明，不定义存储|
|`extern int x = 10;`|定义（带初始化），默认 external linkage|
|`static int x;`|定义，internal linkage（仅本编译单元）|
|`void f();`|声明，默认 external linkage|
|`extern void f();`|同上，显式写出 external linkage|
|`static void f();`|定义，internal linkage|
|`extern "C" void f();`|声明 C 风格 external linkage 的函数|

---

## 7. `extern` 的几个容易搞混的点

### 7.1 “声明 vs 定义” 不要混

- **声明**：告诉编译器“有这个名字 / 类型”，不分配存储；
    
- **定义**：真正分配存储 / 生成函数体。
    

```C++
extern int x;      // 声明 
int x;             // 定义 
extern int x = 1;  // 定义（因为有初始化）
```

### 7.2 不要在多个 `.cpp` 里定义同一个非 `inline` / 非 `static` 符号

比如：

```C++
// a.cpp
int g = 0;

// b.cpp
int g = 0;  // ❌ multiple definition

```

正确做法是：

```C++
// common.h
extern int g;

// common.cpp
#include "common.h"
int g = 0;

```

### 7.3 和“类内静态成员”区分开

类里写的静态数据成员声明本身就类似于 `extern`，但不加关键字：

```C++
struct A {
    static int x;  // 声明：类似“extern int A::x;”
};

// A.cpp
int A::x = 0;      // 定义：分配存储
```

这里类内的 `static int x;` 不分配存储，真正定义要写在类外。

---

## 8. 总结几种典型场景

### 8.1 跨文件共享全局变量

```C++
// global.h
#pragma once
extern int g_count;

// global.cpp
#include "global.h"
int g_count = 0;

// any_other.cpp
#include "global.h"
void inc() {
    ++g_count;
}

```

### 8.2 与 C 库链接（例如调用 C 写的库函数）

```C++
// c_api.h —— C 库提供的头文件
void c_log(const char*);

// cpp_wrapper.cpp
extern "C" {
    void c_log(const char*);   // 声明为 C 链接方式
}

void my_log(const std::string& s) {
    c_log(s.c_str());
}

```
