## 1. 类到底是什么？

从语言角度：

> **类（class）是用户自定义的一种类型，它把“数据（成员变量）”和“操作（成员函数）”打包在一起。**

例子：

```C++
class Point {
public:        // 访问权限：外部可访问
    int x;
    int y;

    void move(int dx, int dy) {
        x += dx;
        y += dy;
    }
};

```

使用：

```C++
Point p;          // 定义一个对象（实例）
p.x = 1;
p.y = 2;
p.move(3, 4);     // p 现在是 (4, 6)

```

**关键点：**

- `Point` 是一个类型；
    
- `p` 是这个类型的一个对象；
    
- 对象里有两块数据（`x`, `y`），还有一个行为 `move()`。
    

---

## 2. 类的基本组成

一个类里通常会出现：

- **成员变量（data members）**：保存对象的状态；
    
- **成员函数（member functions）**：操作这些状态；
    
- **访问控制符**：`public` / `protected` / `private`；
    
- **构造函数 / 析构函数**；
    
- **静态成员**；
    
- （进阶）**友元、继承、多态等**。
    

示意：

```C++
class Person {
public:
    // 构造函数
    Person(const std::string& name, int age);

    // 成员函数
    void say_hello() const;
    void set_age(int age);

private:
    // 成员变量（通常 private）
    std::string name_;
    int age_;
};

```

---

## 3. 访问控制：`public` / `private` / `protected`

### 3.1 `public`：对“外部”可见

```C++
class A {
public:
    int x;          // 外部可以直接访问
    void foo();     // 外部可以调用
};
```

```C++
A a;
a.x = 10;      // OK
a.foo();       // OK
```

### 3.2 `private`：只在类的内部（和友元）可见

```C++
class A {
private:
    int x;          // 外部不能访问

public:
    void set(int v) { x = v; }
};

```

```C++
A a; 
a.x = 10;     // ❌ 编译错误，x 是 private a.set(10);    // ✅ OK，通过 public 接口修改
```

### 3.3 `protected`：类内部 + 子类可访问

```C++
class Base {
protected:
    int value;
};

class Derived : public Base {
public:
    void set(int v) { value = v; }  // ✅ 子类内部可以访问
};

int main() {
    Derived d;
    d.value = 10;   // ❌ 外部仍然不可以
}

```

**默认访问权限：**

- `class` 默认是 `private`（不写时）；
    
- `struct` 默认是 `public`。
    

`class C { int x; };   // x 是 private struct S { int x; };  // x 是 public`

---

## 4. 构造函数与析构函数

### 4.1 构造函数（constructor）

> **构造函数 = “对象出生时，帮你初始化成员”的特殊函数**，名字和类名相同，没有返回值。

```C++
class Point {
public:
    int x;
    int y;

    // 构造函数：初始化 x, y
    Point(int xx, int yy) : x(xx), y(yy) {}
};

```

使用：

`Point p(1, 2);          // 调用构造函数 Point q{3, 4};          // 列表初始化，效果类似`

你可以定义多个构造函数（重载）：

```C++
class Point {
public:
    Point() : x(0), y(0) {}          // 默认构造
    Point(int xx, int yy) : x(xx), y(yy) {}

private:
    int x, y;
};

```

### 4.2 析构函数（destructor）

> **析构函数 = 对象死亡时做清理工作**，名字是 `~类名()`，无参数、无返回值。

```C++
class File {
public:
    File(const std::string& path) {
        // 打开文件...
    }

    ~File() {
        // 关闭文件...
    }
};

```

用法：

`{     File f("data.txt");     // 使用 f }   // 这里作用域结束，自动调用 ~File()，实现 RAII`

> RAII：**资源获取即初始化**，将资源绑定到对象生命周期上，是 C++ 很重要的风格。

[[C++类与对象基础练习题（20题）]]
[[C++ RAII]]

---

## 5. `this` 指针与成员函数

在非静态成员函数里，**编译器会隐式传入一个 `this` 指针**，指向当前对象。

```C++
class Point {
public:
    void move(int dx, int dy) {
        this->x += dx;      // this 是 Point*，等价于 x += dx;
        this->y += dy;
    }

private:
    int x, y;
};

```

你平时写的：

`p.move(3, 4);`

大致等价于：

`Point::move(&p, 3, 4);  // 编译器内部会把 this 当成隐藏参数传进去`

**`const` 成员函数** 会把 `this` 的类型变成 `const Point*`：

```C++
class Point {
public:
    int get_x() const {     // this 的类型是 const Point*，不能改成员
        // x = 10;          // ❌ 不允许改（除非成员是 mutable）
        return x;
    }
};
```

---

## 6. 成员函数的一些重要修饰

### 6.1 `const` 成员函数

```C++
class Person {
public:
    std::string get_name() const;  // 承诺：不会修改对象的逻辑状态
};

```

- 用于“只读接口”；
    
- 可以在 `const Person` 对象上调用：
    
    `const Person p; p.get_name();   // 只能调用 const 成员函数`
    

### 6.2 `static` 成员函数

> **属于类本身，不属于某个具体对象**，没有隐含的 `this` 指针。

```C++
class Util {
public:
    static int add(int a, int b) {
        return a + b;
    }
};

```
调用方式：

`int s = Util::add(1, 2);  // 不需要对象`

**静态成员函数不能访问非静态成员**，因为它没有 `this`。

---

## 7. 成员变量：普通的 vs 静态的

### 7.1 普通成员变量（每个对象一份）

```C++
class A {
public:
    int x;  // 每个对象有自己的 x
};

A a1, a2;
a1.x = 1;
a2.x = 2;  // a1.x 与 a2.x 是两块不同的内存
```

### 7.2 静态成员变量（所有对象共享一份）

```C++
class A {
public:
    static int count;  // 声明
};

int A::count = 0;      // 类外定义 + 初始化（C++17 可以 inline static）

int main() {
    A::count = 10;     // 通过类名访问
    A a1, a2;
    a1.count = 20;     // 语法上也允许，但都指向同一份 A::count
}
```

- `static` 成员变量在整个程序中只有一份；
    
- 常用于计数、全局配置、单例等。
    

---

## 8. 构造 / 拷贝 / 移动：特殊成员函数（简单感知一下）

一个类默认会有这些**特殊成员函数**（可以自己显式写）：

- 默认构造函数：`X()`
    
- 拷贝构造函数：`X(const X&)`
    
- 拷贝赋值运算符：`X& operator=(const X&)`
    
- 移动构造函数：`X(X&&)`
    
- 移动赋值运算符：`X& operator=(X&&)`
    
- 析构函数：`~X()`
    

比如：

```C++
class Buffer {
public:
    Buffer(size_t n) : size_(n), data_(new int[n]) {}
    ~Buffer() { delete[] data_; }

    Buffer(const Buffer& other);            // 拷贝构造
    Buffer& operator=(const Buffer& other); // 拷贝赋值

    Buffer(Buffer&& other) noexcept;        // 移动构造
    Buffer& operator=(Buffer&& other) noexcept; // 移动赋值

private:
    size_t size_;
    int* data_;
};
```
[[C++ new与delete关键字]]、[[C++ noexcept关键字]]、[[C++深拷贝与浅拷贝]]、[[this指针练习题]]
这些东西和资源管理、`std::move`、右值引用等绑定得很紧，属于“类设计”的进阶部分。

---

## 9. 继承：类之间的“is-a”关系（简单感知）
[[继承练习题]]
```C++
class Animal {
public:
    void eat() { std::cout << "eat\n"; }
};

class Dog : public Animal {
public:
    void bark() { std::cout << "wang\n"; }
};

```

- `Dog` 继承自 `Animal`；
    
- `Dog` 对象同时也是一个 `Animal`（is-a）；
    

```C++
Dog d;
d.eat();   // 继承来的函数
d.bark();  // 自己的函数

Animal* p = &d;   // upcast：Dog* → Animal*
p->eat();         // OK
// p->bark();     // ❌ 编译不通过，Animal 不知道 bark

```

后面再配合 `virtual` 与虚函数，就有了多态（polymorphism）。

---

## 10. struct 与 class 的区别

在 C++ 中：

```C++
class A {
    int x;         // 默认 private
};

struct B {
    int x;         // 默认 public
};

```
**本质完全一样**，只是默认访问权限不同：

- `class` 默认成员是 `private`；
    
- `struct` 默认成员是 `public`。
    

工程习惯：

- 用 `struct` 表示“纯数据结构/简单 POD”；
    
- 用 `class` 表示“真正封装了行为 + 数据的类型”。

[[C++友元]]