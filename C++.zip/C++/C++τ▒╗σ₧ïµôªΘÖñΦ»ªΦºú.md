# C++ 类型擦除（Type Erasure）速查笔记

> 面向对象那套“基类 + 虚函数”的动态多态，和模板那套“编译期多态”，中间有一块非常实用但容易被忽视的东西：**类型擦除**。

---

## 1. 什么是“类型擦除”？

**直观理解**：
- 在接口层面“看不见”具体类型，只保留“能做什么”。
- 在实现层面仍然保存真实对象，但通过统一的外壳（wrapper）来操作。

> **口号版**：
> - 编译时：利用模板把各种类型“装进同一个盒子”。
> - 运行时：通过虚函数表等机制，只暴露统一接口，**把原始类型“隐藏/擦除”了**。

典型例子：
- `std::function<R(Args...)>`：可以装 `lambda`、函数指针、`std::bind`、仿函数类……
- `std::any`：可以装任意类型的对象，再在运行时 `any_cast` 出来。

---

## 2. 为什么需要类型擦除？

常见需求：

1. **统一接口，但不想暴露模板参数**
   - 例如对外提供 `class Logger` 接口，内部可能用 `spdlog`、`glog`、自研 logger，但对调用者只暴露非模板 API。

2. **减少模板膨胀 / 编译时间**
   - 如果所有逻辑都写成模板，会产生大量模板实例，编译慢、二进制大。
   - 类型擦除可以把“模板多态”封装起来，对外暴露“非模板的普通类/接口”。

3. **插件、回调等场景**
   - 你只关心“能调这个函数”，不关心内部到底是 lambda 还是某个类。

---

## 3. 经典模式：Concept / Model（概念-模型）

手写类型擦除，一般是经典的 **Concept / Model 模式**：

- `Concept`：抽象接口（纯虚基类）——“能干什么”。
- `Model<T>`：模板派生类，用来包一层具体类型 `T`。
- `Wrapper`：对外暴露的非模板类，持有一个 `unique_ptr<Concept>`。

### 3.1 简化示例：一个可调用对象的 type-erased wrapper

```cpp
#include <memory>
#include <utility>
#include <iostream>

class AnyCallable {
public:
    // 1. 对外暴露的统一调用接口
    void operator()() const {
        self_->call();
    }

    // 2. 构造函数：接受任意可调用对象
    template <class F>
    AnyCallable(F f) : self_(std::make_unique<Model<F>>(std::move(f))) {}

private:
    // 概念接口：能被调用
    struct Concept {
        virtual ~Concept() = default;
        virtual void call() const = 0;
    };

    // 模型：把任意 F 封装起来
    template <class F>
    struct Model : Concept {
        F f_;
        explicit Model(F f) : f_(std::move(f)) {}
        void call() const override { f_(); }
    };

    std::unique_ptr<Concept> self_;
};

int main() {
    AnyCallable c1([]{ std::cout << "lambda\n"; });
    struct Functor { void operator()() const { std::cout << "functor\n"; } };
    AnyCallable c2(Functor{});

    c1();
    c2();
}
```

这里：
- 对调用者来说，只知道 `AnyCallable` 这个**非模板类型**，
- 但它内部可以装任何满足“可调用”条件的类型。
- **所有具体类型在接口层面都被“擦除”了**。

> 这和 `std::function<void()>` 的实现思想几乎一样。

---

## 4. std::function 是如何用类型擦除实现的？（概念性说明）

`std::function<R(Args...)>` 大致做了几件事：

1. 内部有一个抽象基类 `Concept`，定义：
   - `virtual R invoke(Args&&...) = 0;`
   - `virtual Concept* clone(void* buf) = 0;` 等

2. 对每个具体 `F`，有一个 `Model<F>`，持有一个 `F f_`，实现 `invoke` 时内部调用 `f_(std::forward<Args>(args)...)`。

3. `std::function` 本身只持有 `Concept*`（通常是放在一个小缓冲区里做 Small Buffer Optimization），对外只暴露：
   - `R operator()(Args...) const;`

> 关键点：
> - 调用时，只经由 `Concept::invoke` 虚函数，**不需要知道真实类型 F**。
> - 真实类型被擦除在 `Model<F>` 模板的实现细节里。

---

## 5. 手写一个“小号 std::any”示例

`std::any` 是“能装任意类型”的类型擦除容器。我们写个极简版：

```cpp
#include <memory>
#include <typeinfo>
#include <typeindex>
#include <stdexcept>

class Any {
public:
    Any() = default;

    template <class T>
    Any(T value) : self_(std::make_unique<Model<T>>(std::move(value))) {}

    template <class T>
    T& cast() {
        if (!self_ || self_->type() != typeid(T)) {
            throw std::bad_cast{};
        }
        return static_cast<Model<T>*>(self_.get())->value_;
    }

    bool has_value() const { return (bool)self_; }

private:
    struct Concept {
        virtual ~Concept() = default;
        virtual const std::type_info& type() const noexcept = 0;
    };

    template <class T>
    struct Model : Concept {
        T value_;
        explicit Model(T v) : value_(std::move(v)) {}
        const std::type_info& type() const noexcept override { return typeid(T); }
    };

    std::unique_ptr<Concept> self_;
};
```

这里：
- `Any` 本身不再是模板类。
- 但它内部以 `Model<T>` 模板类的形式保存真实类型和值。
- 对外，只暴露 `cast<T>()`，在这里我们再“拿回”原始类型。

---

## 6. 类型擦除 vs. 传统继承 vs. 模板

### 6.1 和虚基类继承的区别

- 传统做法：
  - 定义一个基类 `Base`，所有类型都要显式 `class Derived : public Base`。
- 类型擦除：
  - 不要求被包装的类型继承任何基类，只要提供某些操作就行（结构化约束）。

> 更接近“鸭子类型”：**长得像鸭子（有相应成员函数）就能装进来**，无需修改原类的继承关系。

### 6.2 和模板的区别

- 纯模板：
  - 所有多态都是**编译期决定**，对每个类型实例化一份代码。
- 类型擦除：
  - 对外暴露**统一的非模板接口**。
  - 内部用少量模板 + 虚函数把不同类型统一抽象。

适用场景：
- 如果你需要：
  - API 稳定（非模板）、
  - 支持“运行时选择不同实现”、
  - 又不想用户知道你的具体类型，
  - 那就非常适合用类型擦除。

---

## 7. 实战注意点

1. **分配开销**
   - 大多手写实现会用 `std::unique_ptr` 或堆分配，频繁创建/拷贝会有开销。
   - 可以模仿 `std::function` / `std::any` 的 SBO（Small Buffer Optimization）技巧，
     在栈上预留一个小缓冲区，放得下的小对象直接放栈上。

2. **值语义 / 拷贝语义**
   - 如果 wrapper 需要支持拷贝构造/赋值，就要在 `Concept` 里提供 `clone()` 接口，
     由各个 `Model<T>` 实现深拷贝。

3. **接口设计要简洁**
   - 一旦你希望“通吃所有类型”，接口能力往往很弱；
   - 所以要根据实际需求，抽象出最小的共同行为（最小概念）。

4. **异常安全**
   - 构造、拷贝、赋值、移动时，注意强/基本异常安全保证。

---

## 8. 总结：一句话记住类型擦除

> **类型擦除就是：用模板在内部记住具体类型，用虚函数在外部隐藏具体类型，从而对外只暴露一个非模板、统一接口的“多态盒子”。**

你在标准库中看到的：
- `std::function`
- `std::any`
- 部分 `std::pmr` / allocator 封装

本质上都在不同程度上使用了这种思想。

---

如果之后你有具体代码（比如想给你现有的某个模板类做一层类型擦除封装），可以把接口贴出来，我可以帮你定制一版完整的 type-erased 封装方案。

