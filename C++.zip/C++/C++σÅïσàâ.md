## 1. 友元能是谁？
[[友元练习题]]
在类定义里用 `friend` 声明：

1. **友元函数**
    
2. **友元类**
    
3. **友元成员函数**（某个类的某个成员函数是友元）
    

> 友情是**单向的**：A 把 B 设为友元，不代表 B 自动能访问 A；  
> 友情**不传递**：B 是 A 的友元，不代表 C（B 的友元）也是 A 的友元。

---

## 2. 友元函数（最常用）

让一个**非成员函数**访问类的私有数据。

```C++
#include <iostream>
using namespace std;

class Point {
private:
    int x, y;
public:
    Point(int x, int y): x(x), y(y) {}

    friend void printPoint(const Point& p); // 声明友元函数
};

void printPoint(const Point& p) {           // 定义普通函数
    cout << p.x << ", " << p.y << "\n";     // 访问 private 成员
}

int main() {
    Point p(1,2);
    printPoint(p);
}
```

**典型用途：**

- 重载 `operator<<`、`operator==` 等非成员运算符
    
- 需要访问内部表示、但不想成为成员函数的工具函数
    

### 例：`operator<<` 通常用友元

```C++
class Point {
    int x, y;
public:
    Point(int x,int y):x(x),y(y){}
    friend ostream& operator<<(ostream& os, const Point& p);
};

ostream& operator<<(ostream& os, const Point& p){
    return os << "(" << p.x << "," << p.y << ")";
}

```

---

## 3. 友元类

让整个类访问另一个类的私有成员。

```C++
class B; // 前置声明

class A {
private:
    int secret = 42;
    friend class B; // B 是 A 的友元类
};

class B {
public:
    void show(A& a) {
        cout << a.secret << "\n"; // 可以访问 A 的 private
    }
};

```
**典型用途：**

- 两个类强耦合协作（比如 Iterator 访问容器内部）
    
- Bridge / Proxy / Builder 等设计里共享内部状态
    

---

## 4. 友元成员函数（精准授权）

只让某个类的**某个成员函数**有权限。

```C++
class A;

class B {
public:
    void peek(A& a); // 只有这个函数是友元
};

class A {
private:
    int secret = 7;
    friend void B::peek(A& a); // 精确授予
};

void B::peek(A& a){
    cout << a.secret << "\n";
}

```

**优点**：权限更小、更安全，不像“友元类”那样一把梭。

---

## 5. 友元与继承/多态

- 友元**不继承**：A 的友元不能自动访问 A 的子类的 private；
    
- 子类也不会自动获得父类友元的访问权。
    

```C++
class Base {
    int b = 1;
    friend void f(Base&);
};
class Derived : public Base {
    int d = 2;
};
// f 只能访问 Base 的 private，不能访问 Derived 的 d
```

---

## 6. 模板里的友元（进阶常见）

### 6.1 让所有模板实例都成友元

```C++
template<class T>
class Box {
    T val;
public:
    Box(T v): val(v) {}
    template<class U>
    friend void printBox(const Box<U>& b);
};

template<class U>
void printBox(const Box<U>& b){
    std::cout << b.val << "\n";
}
```

### 6.2 只让同一个 T 的函数成友元（更严格）

```C++
template<class T>
class Box {
    T val;
public:
    Box(T v): val(v) {}
    friend void printBox(const Box<T>& b){ // 只对同T友元
        std::cout << b.val << "\n";
    }
};//这里的意思是，只有T推导出的类型才是友元，主要是函数参数这里
```
## 直观对比总结

|对比项|6.1|6.2|
|---|---|---|
|printBox 是什么|**函数模板**|**每个 T 一份的普通函数**|
|友元范围|**所有 U 版本都成为友元**|**仅当前 T 的版本是友元**|
|权限大小|大（跨类型共享权限）|小（各类型隔离权限）|
|生成的函数数量|一套模板（实例化按需）|每个 Box<T> 生成一个独立函数|

---

## 7. 友元的优缺点

### 优点

- **提高封装下的灵活性**：外部函数仍可高效访问内部数据
    
- **运算符重载更自然**：`operator<<` / `operator==` 常常需要
    
- **能保持接口干净**：不必为了某个外部需求暴露 getter
    

### 缺点

- **破坏封装**：滥用会让类的内部变得“全局可见”
    
- **耦合增强**：友元依赖类内部实现，改内部可能牵一发动全身
    
- **不利于维护/测试**（如果权限给太大）
    

---

## 8. 什么时候该用 / 不该用？

**该用：**

- 重载 I/O 或对称运算符（`<<`, `==`, `+`）
    
- 两个类本来就是紧密协作的抽象（如容器和迭代器）
    
- 性能/表达需要访问内部，但不想暴露到 public
    

**不该用：**

- 只是为了“偷懒访问 private”
    
- 可以通过合理 public 接口解决的情况
    
- 授权范围过大（优先“友元函数/友元成员”而不是友元类）
    

---