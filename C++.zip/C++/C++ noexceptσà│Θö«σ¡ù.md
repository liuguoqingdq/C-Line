> **`noexcept` = 告诉编译器“这个函数不会抛异常（或条件不会抛）”，如果真的抛了，程序直接 `std::terminate()`。同时编译器会因此更大胆地优化、在某些场景优先选择这个函数。**

[[noexcept练习题]]
---

## 一、`noexcept` 有两种用法

### 1. 函数上的异常说明符（最常用）

```C++
void foo() noexcept;                // 承诺：绝不抛异常
void bar() noexcept(false);         // 明确表示：可能抛异常（等价于没写）
void baz() noexcept(noexcept(foo())); // 条件 noexcept（见后面）
```

- 写在函数声明 / 定义后面：
    
    `int f(int x) noexcept {     return x + 1; }`
    

### 2. `noexcept(expr)` 运算符（编译期问一句：这个表达式会不会抛？）

`bool b = noexcept(foo());  // 编译期常量，true / false`

- `noexcept(expr)` 本身**不抛异常**，只是计算一个 `bool` 常量。
    

---

## 二、`noexcept` 对函数语义的真实影响

### 1. “保证不抛” + “违约就毙”

`void f() noexcept {     throw 1;  // 运行到这里：调用 std::terminate() }`

- 一旦 `noexcept` 函数里有异常没被 catch 出函数体，就**不会像普通函数那样再往上抛**，而是：
    
    - 栈展开到这个 `noexcept` 边界 → 发现违反承诺 → `std::terminate()`。
        
- 所以：**`noexcept` 是强承诺，不是“建议”。**
    

### 2. 编译器可以更凶地优化

编译器知道“这里绝不会抛异常”，就可以：

- 省掉异常处理相关的元数据
    
- 对调用点做更多 inline / 冗余消除
    
- 在某些 STL 实现中，容器在异常安全逻辑分支里使用 `noexcept` 来区分“可回滚/不可回滚”的路径
    

典型例子：`std::vector` 扩容时是否用“移动”还是“拷贝”。

---

## 三、STL 和 `noexcept`: 为啥 move 构造经常写成 `noexcept`

```C++
class A {
public:
    A() = default;
    A(const A&) = default;
    A(A&&) noexcept;         // 显式声明移动构造不抛
};

```

**为什么要给移动构造/移动赋值加 `noexcept`？**

因为很多标准容器会用 `noexcept` 来决定要不要走“移动路径”：

```C++
template <class T>
void vector_realloc(std::vector<T>& v) {
    // 伪代码说明思想
    if (std::is_nothrow_move_constructible_v<T>) {
        // 安全地移动元素（不会中途抛异常，整体不会半死不活）
        // 用 T 的移动构造
    } else {
        // 退回到拷贝构造（更安全，但可能更慢）
    }
}

```

`std::is_nothrow_move_constructible_v<T>` 底层就是根据 `noexcept` 判断。

➜ **工程里的规则基本是：**

> 如果你能保证移动构造、移动赋值不抛异常，就给它们加 `noexcept`，这会直接影响容器性能。

---

## 四、条件 `noexcept`：最实用的一种写法

你经常会看到：

```C++
class A {
public:
    A(A&& other) noexcept(std::is_nothrow_move_constructible_v<std::string>) {
        // ...
    }
};

```

或者更常见的：

```C++
template <typename T>
struct Vec {
    void push_back(T&& x) noexcept(std::is_nothrow_move_constructible_v<T>) {
        // ...
    }
};

```

**含义**：  
如果 `T` 的移动构造本身不抛，则这个函数整体也不抛；否则就当作可能抛。

再看一个更直观的例子：

```C++
void f() noexcept(noexcept(g())) { // “f 不抛” 的条件： g() 不抛     
		g(); 
	}
```

背后逻辑：

1. 内层 `noexcept(g())` 是一个编译期 `bool`，判断“调用 `g()` 会不会抛？”。
    
2. 外层 `noexcept(bool)` 就是函数异常说明：
    
    - true → `f()` 被声明为 `noexcept(true)`
        
    - false → `f()` 被声明为 `noexcept(false)`（等价于没写）
        

---

## 五、`noexcept` 的默认值与几个特殊函数

### 1. 不写 `noexcept` 的函数默认是 `noexcept(false)`

`void f();          // 等价于 void f() noexcept(false);`

也就是说：**默认都被认为“可能抛”**。

### 2. 析构函数默认是条件 `noexcept(true)`（C++11+）

编译器会自动给析构函数加 `noexcept`，除非析构函数体里有可能抛异常：

`struct A {     ~A(); // 默认是 noexcept(true)，除非你自己显式写 noexcept(false) };`

因此通常**不要在析构函数里抛异常**，否则会走 `std::terminate()`（尤其是在栈展开过程中再抛异常，是致命错误）。

---

## 六、`noexcept` 运算符：判断表达式是否会抛异常

语法：

`noexcept( expression )`

特点：

- 在**编译期**求值
    
- 返回 `bool`（`true`/`false`）
    
- 本身不会抛异常
    

例子：

```C++
void g() noexcept {}
void h() {}

int main() {
    static_assert(noexcept(g()), "g should be noexcept");
    static_assert(!noexcept(h()), "h is not noexcept");

    int x = 0;
    bool b1 = noexcept(x++);       // true, 内置操作不会抛
    bool b2 = noexcept(std::string("abc")); // 要看 std::string 构造是否声明 noexcept
}

```

配合模板/类型萃取，非常骚：

```C++
template <typename T>
void foo(T&& t) noexcept(noexcept(T(std::forward<T>(t)))) {
    // 如果 T 的拷贝/移动构造不抛，那 foo 也不抛
}

```
[[C++移动语义与完美转发]]

---

## 七、和旧式异常说明对比：`throw()` 已经废了

老代码你会看到这样：

```C++
void f() throw();        // 表示不抛异常（C++11 起被弃用，C++17 移除）
void g() throw(int);     // 表示最多抛 int（基本没人用了）

```

现代 C++ 全换成：

`void f() noexcept;       // 现代写法`

所以现在记一个简单结论：**只用 `noexcept`，别再用 `throw()` 这套东西。**

---

## 八、实际写代码时怎么用？

给你一个**简单实战规则**：

1. **普通函数**
    
    - 确认真的不会抛（内部只做算数、简单逻辑、不调用可能抛异常的库） → 写 `noexcept`
        
    - 不确定 / 未来可能会加抛异常逻辑 → 可以先不标
        
2. **类的移动构造 / 移动赋值**
    
    - 如果你能保证内部只移动不分配 / 不抛 → 尽量：
        
        `A(A&&) noexcept; A& operator=(A&&) noexcept;`
        
    - 或者用条件 `noexcept(...)` 绑定成员的 `noexcept` 性质
        
3. **析构函数**
    
    - 默认就基本是 `noexcept(true)`，**不要在析构里抛异常**。
        
    - 如果你真的想在析构里抛（几乎不推荐）：必须显式 `noexcept(false)`，但一旦在栈展开中抛，还是极危险。
        
4. **模版 & 泛型库**
    
    - 尽量用 `noexcept(expr)` + `noexcept( noexprepr )` 写出条件异常保证，提升泛型代码质量和性能。
        

---

如果你愿意，下一步我可以专门帮你从**编译器/ABI角度**讲一下：

- 带 `noexcept` 和不带 `noexcept` 的函数，在汇编和异常表上的差异
    
- `noexcept` 对 `std::vector` / `std::unique_ptr` / `std::function` 这些容器和工具类实测性能影响
    
- 如何在你的工程里系统地加上 `noexcept`（比如写类模板 / 底层库代码时的套路）
    

你可以直接发一段你自己的类代码，我也可以帮你逐个成员函数判断：**该不该加 `noexcept`，怎么写条件 `noexcept` 比较优雅。**