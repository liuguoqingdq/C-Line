## 一、C++ 的内存布局（Memory Layout）

### 1. 进程的宏观布局（大框架）

典型 64 位进程的大致布局（从低地址到高地址）：

```txt
[  代码区 text    ]   可执行指令、只读常量（字符串字面量等）
[ 全局/静态数据段 ]   全局变量、static 变量
[       堆 heap   ]   new/malloc 分配的动态内存（向高地址增长）
        ...
[       栈 stack  ]   函数调用栈、局部变量、返回地址（向低地址增长）

```

概念对应到 C++：

- **代码区**：函数体的机器码，`"hello"` 这种字符串字面量。
    
- **全局/静态区**：
    
    - 全局变量 `int g;`
        
    - `static int x;`（函数内/命名空间内）
        
    - 它们的生命周期从程序开始到结束。
        
- **堆**（自由存储区 / free store）：
    
    - `new`/`delete`，`std::allocator` 管的区域
        
    - 生命周期由你控制
        
- **栈**（自动存储）：
    
    - 函数里的普通局部变量、函数参数
        
    - 进入作用域分配、离开时自动销毁
        

> 注意：具体“谁在上谁在下”是实现相关的，但这个模型足够你理解概念。

---

### 2. 对象的存储期（Storage Duration）

C++ 更关注的是“对象活多久”，分四种：

1. **静态存储期**：
    
    - 全局变量、`static` 变量、`constexpr` 变量
        
    - 程序整个运行期间都存在
        
2. **线程存储期**（`thread_local`）：
    
    - 每个线程一份，在线程生命周期内存在
        
3. **自动存储期**（栈上的局部变量）：
    
    `void f() {     int x = 0;   // f 返回之后 x 的生命周期结束，内存被回收 }`
    
4. **动态存储期**（堆上的 `new` 出来的对象）：
    
    `int* p = new int(42);  // 直到 delete 前都存在 delete p;`
    

**很多 UB（未定义行为）都和“对象生命周期 + 指针还在乱用”有关：**

- 用已经析构/释放对象的地址 → use-after-free
    
- 返回局部变量地址 → 悬空指针
    

---

### 3. 单个对象的内存布局（类/struct）

#### 3.1 简单 struct 的布局

`struct S {     char  c;     int   i;     double d; };`

一个 `S` 在内存中大致是：

```txt
偏移 0:  c       (1 字节)
偏移 1-3: padding 对齐填充
偏移 4:  i       (4 字节)
偏移 8:  d       (8 字节)
总大小：通常是 16（取决于对齐）

```

**标准保证：**

- 成员按 **声明顺序** 排列，不会乱重排：
    
    `struct A { int x; char c; }; // 内存里一定是 x 在前，c 在后，中间可能有 padding`
    
- `&obj.x <= &obj.c` 这类顺序是确定的。
    
- 中间 padding、对齐细节是实现相关，但规则类似：  
    大类型通常要求更大对齐，编译器会塞 padding。
    

#### 3.2 对齐 & padding 的影响

```C++
struct A {
    char c;
    int  i;
    double d;
};

struct B {
    double d;
    int    i;
    char   c;
};

```

很多平台上两者 `sizeof` 相同，但更复杂时可以通过**调整成员顺序**减少 padding。

#### 3.3 数组的布局

```C++
int a[5];          // 5 个 int 连续存放
S s[3];            // 3 个 S 连续存放
```
标准保证：

- 对任意 `T a[N];`，`a[i]` 在内存里是连续排列的：
    
    `&a[i+1] == &a[i] + 1;`
    

---

### 4. 带虚函数的类：vptr + vtable（典型实现）

`struct Base {     int x;     virtual void foo(); };`

带虚函数的类对象内部 **通常** 会多一个隐藏指针：`vptr`（虚函数表指针），指向一张 vtable：

`[ vptr ]   // 指向虚函数表 [  x  ]`

- `sizeof(Base)` 至少是：一个指针大小 + `int`（再按对齐向上取整）
    
- vtable 里存虚函数地址、RTTI 信息等（具体内容 ABI 决定）
    

> 标准没有规定必须这样实现，但主流编译器都这么做，你可以当心智模型用，但不能在代码里依赖 vptr 的位置。

---

### 5. 继承时的对象布局（简化版）

```C++
struct Base {
    int x;
    virtual void foo();
};

struct Derived : Base {
    int y;
    void foo() override;
};

```

典型布局：

```C++
[ Base 子对象 ]
    [ vptr ]
    [  x   ]
[  y       ]

```

- 一般来说：**Base 子对象放在 Derived 的开头**，所以 `Derived*` → `Base*` 可以只是 reinterpret 成同一地址（单继承）。
    
- 多继承 / 虚继承会复杂得多：多个 Base 子对象、多个 vptr、偏移调整等，属于 ABI 细节。
    

---

## 二、C++ 的内存模型（Memory Model）

上面讲的是“比特怎么摆”；**内存模型讲的是：编译器和 CPU 可以对读写做哪些重排、多线程时什么算数据竞争、什么时候是 UB。**  
C++11 引入正式的内存模型，主要解决多线程语义。

### 1. 抽象机 & as-if 规则

C++ 标准用一个“抽象机器”来描述程序执行：

- 程序由一系列 **操作（evaluation）** 和 **副作用（side effect：写内存、IO）** 组成。
    
- 编译器可以任意重排/优化，只要对单线程程序来说，**可观察行为（observable behavior）不变**，这叫 as-if rule。
    

简单理解：

`int x = 0; int y = 0;  void f() {     x = 1;     y = 2; }`

编译器可以把赋值顺序优化掉、合并寄存器等，但对单线程结果没变化 → 合法。

---

### 2. sequenced-before / happens-before（顺序关系）

内存模型里关键两个关系：

1. **sequenced-before（序列先行）**：
    
    - 在**同一个线程**内，语言规则保证“某个操作必定在另一个操作之前完成”的关系。
        
    - 比如：
        
        `int x = 0; x = 1; int y = x;`
        
        在一个线程内，`x = 1` sequenced-before `y = x`——编译器不能把读 y 提前到写 x 前面去。
        
2. **happens-before（先行发生）**：
    
    - 在**多线程**下，通过 `mutex`、`atomic` 等同步操作建立的一种跨线程“先发生关系”：
        
    - 如果 A happens-before B，那么 B 线程一定能看到 A 的所有效果。
        

这俩概念决定了多线程中**读/写是否“有定义”**，是内存模型的核心。

---

### 3. 数据竞争（data race）与未定义行为

C++11 内存模型对多线程有一个“非常硬”的规则：

> **如果两个线程同时访问同一个普通对象：**
> 
> - 至少有一个是写操作
>     
> - 它们之间没有 happens-before 同步关系  
>     → 就是 **data race**，整个程序行为 **未定义（UB）**。
>     

例子：

```C++
int x = 0;

void t1() { x = 1; }   // 写
void t2() { std::cout << x; } // 读

// t1 和 t2 并发，没有锁/atomic，x 不是 atomic
// → data race → UB

```

在 UB 下，可能出现：

- 打印 0 或 1
    
- 奇怪的值
    
- 崩溃
    
- 或者看起来“正常”，但换个编译器/优化级别就炸
    

所以多线程下，要么：

- 用 `std::mutex` / `std::lock_guard` 保护共享数据
    
- 或者把共享变量声明为 `std::atomic<T>`，用原子操作访问
    

---

### 4. 原子操作（std::atomic）与内存序

`std::atomic<int> x{0};`

原子操作有两层“保证”：

1. **原子性**：不出现中间状态，不会 data race。
    
2. **可见性 & 有序性**：通过 **memory_order** 控制跨线程的先后关系。
    

常用的内存序：

- `memory_order_seq_cst`（默认）：最强、语义最简单，类似“全局总顺序”。
    
- `memory_order_release` / `memory_order_acquire`：
    
    - release：写操作像“放出”一个信号
        
    - acquire：读操作像“接收”一个信号
        
    - 获取/释放之间形成 happens-before，保证发布-订阅模式正确。
        

简单例子（发布/订阅）：

```C++
std::atomic<bool> ready{false};
int data = 0;

void producer() {
    data = 42;                             // 普通写
    ready.store(true, std::memory_order_release);
}

void consumer() {
    while (!ready.load(std::memory_order_acquire)) {
        // 自旋等待
    }
    // 这里一定能看到 data == 42
    std::cout << data << "\n";
}

```

**为什么？**  
`store(..., release)` 和 `load(..., acquire)` 之间建立了 happens-before：  
`producer` 线程中，在 release 前的写入（`data = 42`）对 `consumer` 在 acquire 后可见。

---

### 5. volatile 在 C++ 内存模型里的作用（容易混）

很多人一开始会把 `volatile` 和 “多线程可见性”混在一起。  
但在 C++ 标准语义下：

- `volatile` 的主要用途是：**防止编译器优化掉对某个“特殊内存”（比如 IO 寄存器）的访问**，确保每次都真的读写。
    
- **它不是线程同步原语**，不能替代 `atomic` 或 `mutex`。
    
- 在并发语义上，`volatile` 变量读写之间 **没有 happens-before 关系**，无法避免 data race。
    

所以多线程共享数据时：

- 要么 `std::atomic`
    
- 要么加锁
    
- 不要指望 `volatile` 能保证线程安全。
    

---

## 三、布局 与 模型：怎么同时放在脑子里？

你可以这样区分：

1. **内存布局（layout）回答的是：**
    
    > “这个对象在内存里长什么样？成员怎么排？虚表指针在哪？数组是不是连续？”
    
    主要关注：
    
    - 对象尺寸 `sizeof`
        
    - 对齐 `alignof`
        
    - 成员偏移（class/struct 布局）
        
    - 栈/堆/全局区各自的作用
        
2. **内存模型（model）回答的是：**
    
    > “编译器/CPU 可以怎么重排读写？多个线程同时访问这块内存时，什么时候是未定义行为，什么时候是有定义的？”
    
    主要关注：
    
    - 单线程 as-if rule
        
    - 多线程线程间的 happens-before
        
    - data race = UB
        
    - atomic / mutex 的同步语义
        

两者交集的典型例子：

- 在多线程中，两个线程**同时写一个对象的不同成员**，看上去“布局上不冲突”（不同偏移），但如果没有同步，按 C++ 内存模型仍然是 data race → UB。
    
- 使用 `std::atomic<int>` 时，它的布局也是某种内存块，但访问规则被内存模型特别对待。