# C++ 类型萃取（Type Traits）详解

> 关键词：**type traits / type traits 元编程 / <type_traits> 头文件**

在中文语境里，说“**类型萃取**”一般就是指：
- 利用 `std::type_traits` 这一套模板工具，
- 在**编译期**对类型做“判断、变换、提取信息”，
- 为模板元编程、`if constexpr` 分支、SFINAE 限制等提供基础设施。

它的英文常见叫法是：`type traits`，直译“类型特性”，但很多人会形象地叫“类型萃取”。

---

## 1. 类型萃取在干什么？

核心目标：
- **查询类型的属性**：
  - `std::is_integral_v<T>`：T 是不是整数类型？
  - `std::is_pointer_v<T>`：T 是不是指针？
  - `std::is_const_v<T>`：是不是 const？
- **生成新的类型**（从旧类型“萃取”出核心形态）：
  - `std::remove_reference_t<T>`：去掉引用
  - `std::remove_const_t<T>`：去掉 const
  - `std::decay_t<T>`：做一系列“退化”：去引用、把数组/函数变成指针

一句话：
> **在编译期，用模板对类型做“布尔判断 + 类型变换”，从而驱动其它模板逻辑。**

---

## 2. 标准库里的类型萃取：<type_traits>

头文件：
```cpp
#include <type_traits>
```

### 2.1 判断类（`is_xxx` 家族）

典型成员：
- `std::is_void<T>`
- `std::is_null_pointer<T>`
- `std::is_integral<T>`
- `std::is_floating_point<T>`
- `std::is_enum<T>`
- `std::is_pointer<T>`
- `std::is_reference<T>`
- `std::is_class<T>`
- `std::is_union<T>`
- `std::is_const<T>`
- `std::is_volatile<T>`
- `std::is_trivially_copyable<T>`
- `std::is_constructible<T, Args...>`
- `std::is_convertible<From, To>`

用法示例：
```cpp
static_assert(std::is_integral_v<int>);
static_assert(!std::is_integral_v<double>);
static_assert(std::is_pointer_v<int*>);
static_assert(std::is_const_v<const int>);
```

> C++11 是 `_type::value` 写法，C++17 起有 `_v` 这种别名，更简洁。

### 2.2 变换类（`remove_xxx` / `add_xxx` / `xxx_t` 家族）

典型成员：
- `std::remove_reference<T>::type` / `std::remove_reference_t<T>`
- `std::remove_const_t<T>` / `std::remove_cv_t<T>`（同时去掉 const & volatile）
- `std::add_pointer_t<T>` / `std::add_lvalue_reference_t<T>`
- `std::make_signed_t<T>` / `std::make_unsigned_t<T>`
- `std::decay_t<T>`：综合性的“退化类型”：
  - 去引用
  - 数组 T[N] -> T*
  - 函数类型 f -> f*

用法示例：
```cpp
using T1 = std::remove_reference_t<int&>;    // int
using T2 = std::remove_cv_t<const volatile int>; // int
using T3 = std::decay_t<int&&>;              // int
using T4 = std::decay_t<int[5]>;             // int*
```

---

## 3. 类型萃取 + `if constexpr`：编译期分支

典型写法：

```cpp
#include <type_traits>
#include <iostream>

template <class T>
void print_value(T&& x) {
    using U = std::decay_t<T>;

    if constexpr (std::is_integral_v<U>) {
        std::cout << "int-like: " << x << "\n";
    } else if constexpr (std::is_floating_point_v<U>) {
        std::cout << "float-like: " << x << "\n";
    } else {
        std::cout << "other type\n";
    }
}
```

- `if constexpr` 的条件必须在编译期就能算出来；
- `std::is_integral_v<U>` 就是一个**编译期布尔常量**；
- 不满足的分支代码会在编译期被丢弃，不会参与语义检查。

这就是“类型萃取 + 编译期分支”的典型模式。

---

## 4. 类型萃取 + SFINAE：约束模板重载

经典 SFINAE（Substitution Failure Is Not An Error）写法：

```cpp
// 只对整数类型启用

template <class T,
          std::enable_if_t<std::is_integral_v<T>, int> = 0>
void foo(T x) {
    // 整数版本
}

// 只对浮点类型启用

template <class T,
          std::enable_if_t<std::is_floating_point_v<T>, int> = 0>
void foo(T x) {
    // 浮点版本
}
```

- `std::enable_if_t<cond, int>` 当 `cond` 为 `true` 时是 `int`，否则替换失败，
  该模板候选直接被丢弃。
- 通过 `std::is_integral_v` / `std::is_floating_point_v` 这样的**类型萃取**，
  来决定哪一个模板参与重载解析。

C++20 之后可以用 `concept`/`requires` 表达得更自然，本质上也是靠 type traits 或类似机制。

```cpp
#include <concepts>

template <std::integral T>
void foo(T x) { /* 整数版本 */ }

template <std::floating_point T>
void foo(T x) { /* 浮点版本 */ }
```

`std::integral` / `std::floating_point` 这些 concept 的内部实现也高度依赖 type traits。

---

## 5. 自定义类型萃取：自己写 `is_xxx` / `xxx_t`

你完全可以为自己的类型族写萃取模板：

```cpp
// 判断一个类型是否是 std::vector<...>

#include <vector>

// 默认：不是

template <class T>
struct is_std_vector : std::false_type {};

// 偏特化：对所有 std::vector<U, Alloc> 为 true

template <class T, class Alloc>
struct is_std_vector<std::vector<T, Alloc>> : std::true_type {};

// 帮助别名

template <class T>
inline constexpr bool is_std_vector_v = is_std_vector<T>::value;
```

用法：
```cpp
static_assert(is_std_vector_v<std::vector<int>>);
static_assert(!is_std_vector_v<int>);
```

也可以做“变换型”萃取：

```cpp
// 去掉 std::vector<T> 的 T

template <class T>
struct vector_value_type;  // 未定义，一般只给我们关心的类型定义

// 对 std::vector 特化

template <class T, class Alloc>
struct vector_value_type<std::vector<T, Alloc>> {
    using type = T;
};

template <class T>
using vector_value_type_t = typename vector_value_type<T>::type;
```

---

## 6. 类型萃取与“类型擦除”的关系

两者经常一起出现，但概念不同：

- **类型萃取（type traits）**：
  - 关注 **“在编译期识别 / 变换类型”**；
  - 是模板元编程工具，产生布尔常量或新类型。
- **类型擦除（type erasure）**：
  - 关注 **“对外隐藏具体类型，只暴露统一接口”**；
  - 典型实现是 “模板 + 虚函数” 封装成统一 wrapper，例如 `std::function`。

很多高级封装会同时用到两者：
- 用类型萃取判断某个类型是否满足概念（比如“可调用”、“可移动”）；
- 决定能不能被塞进某个 type-erased 容器里。

---

## 7. 总结

> **C++ 类型萃取（type traits）就是：用模板在编译期提取类型的“布尔特性”和“变换后的新类型”，从而让模板根据不同的 T 走不同的编译期分支，或生成合适的接口。**

它是现代 C++ 元编程 / 泛型编程的一块基石，和：
- `if constexpr`
- SFINAE / `std::enable_if`
- C++20 concepts

密切相关。

如果你有具体代码（比如想写一个 `is_xxx` 检测自己的类、或封装一套萃取工具），可以把接口贴出来，可以进一步按你的项目风格定制。

