## 1. 最常见的形式：拷贝赋值运算符

经典写法：

```C++
class X {
 public:     
	 X& operator=(const X& other);
	  };
```

几点要点：

1. **必须是非静态成员函数**  
    也就是说你不能写成 `friend X& operator=(X&, const X&);` 去重载（内建的有，但用户自定义的赋值运算符必须是成员）。
    
2. **返回类型通常是 `X&`（左值引用）**
    
    - 方便链式赋值：`a = b = c;`
        
    - 返回 `*this`：
```C++
    X& X::operator=(const X& other) {
    if (this != &other) {
        // 拷贝成员
    }
    return *this;
}
```
        
3. **参数一般是 `const X&`**
    
    - 这样可以给“非 const 的对象”赋值，也允许右值、临时对象作为右边：`a = X();`
        

---

## 2. 移动赋值运算符（C++11+）

配合移动语义的重载：

```C++
class X {
public:
    X& operator=(X&& other) noexcept;
};

```

特点：

- 参数是 **右值引用 `X&&`**，用来“吃掉”临时对象或被 `std::move` 过来的对象。
    
- 实现里通常是：
    
    - 先释放自己的资源
        
    - 再接管 `other` 的内部资源指针
        
    - 把 `other` 置为“空壳”
        

例子：

```C++
X& X::operator=(X&& other) noexcept {
    if (this != &other) {
        // 释放自己已有资源
        // 接管 other 的资源
        // 把 other 置为安全的空状态
    }
    return *this;
}

```

---

## 3. 默认生成 / 禁用：`= default` / `= delete`

简单类可以直接让编译器帮你生成：

```C++
class X {
public:
    X& operator=(const X&) = default;  // 默认拷贝赋值
    X& operator=(X&&) = default;       // 默认移动赋值（C++11+）
};
```

如果你想**禁止赋值**（比如 RAII 管理某些独占资源的类）：

```C++
class NonCopyable {
public:
    NonCopyable& operator=(const NonCopyable&) = delete;
    NonCopyable& operator=(NonCopyable&&) = delete;
};

```

---

## 4. 其他重载形式（按需求扩展）

赋值运算符可以**重载多种参数类型**，比如：

### 4.1 从其他类型赋值

```C++
class String {
public:
    String& operator=(const char* s);          // 允许 s = "abc";
    String& operator=(std::string_view sv);    // C++17
};

```

规则：

- **名字必须是 `operator=`**
    
- 参数类型可以不止一个类自己类型，比如 `const char*`、`int` 等
    
- 返回值通常仍然用 `X&`（保持链式赋值习惯）
    

### 4.2 模板赋值运算符

比如做一个模板容器时：

```C++
template <typename T>
class Array {
public:
    template <typename U>
    Array& operator=(const Array<U>& other);   // 允许不同元素类型间赋值
};

```

---

## 5. ref-qualifier 版本（避免对右值赋值）

更进阶一点：你可以限制“只能对左值对象用 `=`”，禁止对右值对象赋值：

```C++
class X {
public:
    X& operator=(const X& other) &;     // 只能对左值 this 调用
};

```

甚至：

```C++
class X {
public:
    X& operator=(const X& other) &;     // 左值可赋值
    X& operator=(const X& other) && = delete;  // 禁止对右值赋值
};

```

不过这个属于进阶语法，你现在只要知道“赋值运算符也可以加 `&` / `&&` 限定 this 是左值还是右值”就行。

---

## 6. 不能写的形式：注意这几点

1. **不能是 `static` 成员函数**：
    
    `static X& operator=(const X&); // ❌ 不允许`
    
2. **不能是 `const` 成员函数**（因为赋值本身要修改对象）：
    
    `X& operator=(const X&) const; // ❌ 没意义：const 成员不能改 this`
    
3. **不能有多个参数**（用户自定义的赋值运算符只能有一个显式参数）：
    
    `X& operator=(const X&, int); // ❌`
    

---