# 一、为什么会有“内存模型”这种东西？

单线程时，你的直觉一般是：

```C++
int x = 0;
x = 1;
int y = x;
```

你会觉得“先写 1，再读 1”，顺序和代码一致。

但在多线程 + 优化编译器 + 多级缓存下，实际情况变成：

- 编译器可以重排指令
    
- CPU 可以乱序执行、缓存、写缓冲
    
- 不同核看到内存更新的时间不一样
    

如果语言**不做统一抽象**，那程序员根本没法推断任何跨线程行为。  
所以 C++11 起引入了一套正式的并发内存模型，里面关键两点：

1. **什么叫 data race（数据竞争）？有就直接 UB。**
    
2. **什么叫 happens-before？有了它，跨线程可见性才有保证。**
    

---

# 二、3.1 Data Race：什么叫数据竞争？

标准给的核心定义可以压成一句话（我们稍微展开一点）：

> **两个或以上线程，同时访问同一个对象，且：**
> 
> - 至少一个访问是写（含读改写，比如 `++`）
>     
> - 这些访问之间没有任何同步关系（happens-before 保证）  
>     → 就是 data race → 整个程序是**未定义行为（UB）**。
>     

### 2.1 “同一个对象”到底指什么？

- 同一个标量变量：`int x;`  
    两个线程同时读写 `x` → 可能 data race。
    
- 同一个数组元素：`int a[10];`
    
    - 线程 A 写 `a[0]`，线程 B 写 `a[1]` → 不算 race（不同对象）
        
    - A 写 `a[0]`，B 读 `a[0]` → race
        
- 结构体里的不同字段：
    
    ```C++
    struct S { int a; int b; };
S s;
// A 写 s.a，B 写 s.b → 标准视为两个不同“子对象”，不算 race
    ```
    

**注意：**

- `char` 型别可以看作“字节级别视图”，有点特殊；一般我们不会用它来做并发同步。
    
- 同一个对象通过不同指针/引用访问，只要底层是同一块内存，也算“同一对象”。
    

---

### 2.2 举个最经典的 data race 例子

```C++
int x = 0;

void t1() {
    x++;
}

void t2() {
    x++;
}

int main() {
    std::thread a(t1);
    std::thread b(t2);
    a.join();
    b.join();
    // x 是多少？（UB）
}
```

直觉：0 → 1 → 2，结果应该是 2，对吧？  
但实际上：

- `x++` 分解成：读 x → 加 1 → 写回
    
- 两个线程可能交错成：
    
    - A: 读 x = 0
        
    - B: 读 x = 0
        
    - A: 写 x = 1
        
    - B: 写 x = 1 // A 的修改被覆盖
        

这只是**行为上的错误**，更严重的是：  
**在 C++ 标准语义下，这个程序直接是 UB**。  
编译器甚至可以用“程序无 data race”的假设做各种激进优化，让你看到更怪异的结果。

---

### 2.3 为什么 UB 这么可怕？

因为标准等价于告诉编译器：

> “你可以假设所有并发程序都没有 data race。  
> 如果有，那我不管，你随便优化。”

所以编译器可以：

- 把 `while(!ready) {}` 优化成无限循环（把 `ready` 缓存在寄存器）
    
- 把 “写 data 再写 flag” 重排成 “先写 flag 再写 data”
    
- 把连续访问合并 / 删除 / 外提到循环外
    

这就是为什么我们总是强调：

> **C++ 并发程序的“底线”：你的程序必须是 data-race-free，否则一切推理都失效。**

---

# 三、3.2 happens-before：跨线程顺序的“金线”

有了 data race 的定义，下一个问题是：  
**“怎么证明两个访问之间是有顺序、有可见性的”？**

C++ 用一个抽象的关系叫 **happens-before**。  
只要你能证明 A happens-before B，就可以说：

> A 中的所有写，对 B 中的读取都是“可见”的。

### 3.1 happens-before 的组成部分

C++ 里 happens-before 是综合出来的，它来源于几种更基础的关系：

1. **sequenced-before（单线程内的程序顺序）**
    
    - 在同一个线程内，语句的执行顺序（在没有重排拆解的抽象视角下）
        
    
    例如：
    
    ```C++
    int x = 0;
	x = 1;       // 1 sequenced-before 2
	int y = x;   // 2
    ```
    
2. **synchronizes-with（跨线程同步事件）**
    
    - 例如：
        
        - 某个线程的 `mutex.unlock()` 与另一个线程的 `mutex.lock()` 之间
            
        - `atomic` 的 `store(release)` 与对应的 `load(acquire)`
            
        - `condition_variable::notify_*` 和 `wait` 之间（配合锁）
            
3. **happens-before 通过“传递闭包”构成**
    
    - 如果 A sequenced-before B，且 B synchronizes-with C，且 C sequenced-before D  
        则可以推导出：A happens-before D
        

你可以把 happens-before 想象成一条穿过所有线程的“偏序时间线”，  
只要 A → B 在这条线上的顺序是确定的，那么：

> 对象的写入在 A，对象的读取在 B，就有确定的可见性。

---

## 四、互斥锁上的 acquire / release 语义

你在提纲里写的这句非常关键：

> - `mutex.unlock()` = **release**
>     
> - `mutex.lock()` = **acquire**
>     

在 C++ 内存模型里，可以这样理解：

### 4.1 假设有共享变量 `data`，由 `m` 保护

`std::mutex m; int data = 0;`

### 线程 A：写入数据

```C++
std::mutex m;
int data = 0;
```

### 线程 B：读取数据

```C++
void reader() {
    std::unique_lock<std::mutex> lk(m); // m.lock() 作为 acquire (3)
    int x = data; // (4)
}
```

内存模型提供的保证是：

1. 在线程 A 内：`data = 42` sequenced-before `m.unlock()`
    
2. 在线程 B 内：`m.lock()` sequenced-before `int x = data`
    
3. `A` 的 `unlock` 与 `B` 的 `lock` 之间存在 **synchronizes-with** 关系  
    → 从而：`data = 42` **happens-before** `int x = data`
    

因此：

> **在不发生 data race 的前提下**，  
> `reader` 里的 `x` 一定能看到写器 `writer` 已经写入的 42（或者更晚的写）。

这就是我们平时说的：

> “**锁不仅保证互斥，还顺便保证了可见性**。”

---

## 五、原子（atomic）的 acquire / release

mutex 是强同步工具，另外一条路线是用 `std::atomic`：

```C++
std::atomic<bool> ready{false};
int data = 0;
```

### 线程 A：生产数据 + 设置标志

```C++
void producer() {
    data = 42;  // (1) 普通写
    ready.store(true, std::memory_order_release); // (2)
}
```

### 线程 B：等待标志 + 读取数据

```C++
void consumer() {
    while (!ready.load(std::memory_order_acquire)) { // (3)
        // busy-wait
    }
    int x = data; // (4)
}
```

这里的语义类似锁：

1. 在 A 中：`data = 42` sequenced-before `ready.store(release)`
    
2. 在 B 中：`ready.load(acquire)` sequenced-before `int x = data`
    
3. `store(release)` 与看到结果的 `load(acquire)` 之间 **synchronizes-with**  
    → `data = 42` happens-before `x = data`
    

所以：

> 只要 B 的 `load(acquire)` 看到了 A 的 `store(release)` 写入的 `true`，  
> 那么 B 后面对 `data` 的读取一定能看到 42。

**注意：**

- `data` 这里甚至可以不是 atomic（但必须没有别的并发访问方式）  
    因为 happens-before 已经建立。
    
- 如果 `ready` 只是普通 `bool`，就会是 data race + 可见性无保证。
    

---

## 六、条件变量与 happens-before

条件变量本身不直接提供内存顺序，而是和 mutex 配合。

典型用法：

```C++
std::mutex m;
std::condition_variable cv;
bool ready = false;
int data = 0;

void producer() {
    {
        std::lock_guard<std::mutex> lk(m);
        data = 42;
        ready = true;
    }           // 解锁 m → release
    cv.notify_one();
}

void consumer() {
    std::unique_lock<std::mutex> lk(m);
    cv.wait(lk, [&]{ return ready; }); // wait 内部：解锁 + 睡眠 + 被唤醒后重新加锁（acquire）
    int x = data;
}
```

逻辑：

1. producer 持锁修改 `data` 和 `ready`，然后解锁 `m`
    
2. consumer 在 `wait` 时内部会：
    
    - 原子地释放锁并睡眠
        
    - 被 notify 唤醒后重新 `lock`（acquire）
        
3. 和之前一样：
    
    - A 线程对 `data`、`ready` 的写 happens-before 它的 `unlock`
        
    - B 线程的 `lock` happens-before 读 `ready` 和 `data`
        
    - unlock/lock 同步 → happens-before 传播
        

因此：

> **只要你的 cv 使用模式是“锁内改状态 + 锁外 notify + 带谓词 wait”**，  
> 就自动建立了正确的 happens-before。

---

## 七、“没有 happens-before 就没有一致性保证”是什么意思？

把前面的话压缩成一条你可以在脑子里用的规则：

> **跨线程的读写，如果你想让它“必然看到最新写入”，必须能在内存模型里画出一条 `happens-before` 链路。**

如果画不出来这条链路：

- 读写间就不具备顺序关系
    
- 在 C++ 语义下，要么 data race（UB），要么是未同步的独立原子行为，结果可能不是你期望的那种“顺序一致”的效果
    

---

## 八、DRF-SC：C++ 对“没有 data race”程序的大奖励

C++ 有一个非常重要但经常被忽略的定理（非标准原文术语，但社区常用）：**DRF-SC**：

> 如果一个程序是 **data-race-free（没有数据竞争）** 的，  
> 那么它的行为就等价于 **某种“顺序一致”（sequentially consistent）执行**：  
> 换句话说，你可以把每个线程看成按源码顺序运行，再把它们交错，  
> 得到的结果就是程序真正可能出现的结果。

这就是标准给你的奖励：  
**只要你保证没有 data race，就可以用“正常人”的心智模型去想并发。**

没有 data race 的方式有三种：

1. 用 mutex/lock_guard/unique_lock 把所有共享可变状态保护起来
    
2. 用 atomic + 正确的 memory_order（通常 acquire/release 就够）
    
3. 设计成不共享可变状态（immutable / thread-local / message passing）
    

---

## 九、你在工程实践中应该怎么用这套模型？

总结成几条“操作性极强”的规则：

1. **先找共享可变状态**：  
    哪些变量/对象会被多个线程读写？  
    → 这些是你必须考虑 happens-before/同步的地方。
    
2. 对每个共享状态，回答两个问题：
    
    - 它是由哪把 mutex 保护？
        
    - 如果不用 mutex，是否使用了 atomic 做同步？内存序是啥？
        
3. 对每个“写 → 读”的跨线程路径，问自己：
    
    - 我能画出一条 unlock/release → lock/acquire 的 happens-before 链路吗？
        
    - 没有的话：这就是潜在 data race 或可见性 bug。
        
4. 切记：**volatile 和并发内存模型几乎无关，不要指望 volatile 解决多线程同步问题。**
    

---

### 一句话压缩这一节

> **data race**：没同步就共享读写 → UB；  
> **happens-before**：由 mutex/atomic/cv 等原语建立的跨线程“时间顺序”，  
> 有它才有可见性保证。  
> 你的任务就是：**用这些原语把所有共享可变状态包在“无 data race”的世界里。**