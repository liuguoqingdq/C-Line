## 一、值类别：先把“左值/右值”说清楚

简单粗暴版记忆：

- **左值（lvalue）**：有名字、能取地址、可以出现在赋值号左边的东西
    
    `int x = 10;     // x 是左值 int& r = x;     // r 也是左值`
    
- **右值（rvalue）**：临时、即将消亡的值
    
    `10          // 纯右值 x + 1       // 表达式结果（纯右值） std::string("abc")  // 临时对象`
    

C++11 又细分出 xvalue / prvalue，这里你先记一条：

> **“快死了、没人再用”的对象 → 可以被“搬家”（move），而不用深拷贝。**

这就是移动语义的切入点。

---

## 二、移动语义（move semantics）

### 1. 核心目标

**以前只有“拷贝”：**

```C++
std::string a = "very long string ...";
std::string b = a;         // 必须重新分配一块内存，把内容拷过去
```

**有了移动之后：**

```C++
std::string a = "very long string ...";
std::string b = std::move(a); // “抢走” a 的内部资源，O(1) 搬指针
                              // a 进入“已移动但有效”的状态
```

移动语义就是：

> **在可以“偷资源”时，就不要做昂贵的深拷贝，而是做“浅搬家”。**

---

### 2. std::move：只是个“类型转换”

`std::move` 干的事特别简单：

```C++
template <class T>
typename std::remove_reference<T>::type&& move(T&& t) {
    return static_cast<typename std::remove_reference<T>::type&&>(t);
}

```

翻译成人话：

> **把任何东西“标记成右值”（cast 成 `T&&`），方便调用方优先走“移动构造/移动赋值”。  
> 它本身不做移动，只是一个强制“把它当右值看”的类型转换。**

所以：

`std::string s = "hello"; std::string t = std::move(s); // 调用 string 的移动构造`

之后：

- `t` 拿走了 `s` 的 buffer
    
- `s` 处于“已移动但有效”的状态（可以析构、可以重新赋值，但不要依赖原内容）

## 二、完美转发std::forwrad
## 1. 完美转发想解决什么问题？

看一个简单的“包装函数”：

```C++
void real_func(int& x);
void real_func(const int& x);
void real_func(int&& x);

template<typename T>
void wrapper(T x) {
    real_func(x); // ？？？
}

```

现在调用：

```C++
int a = 10;
wrapper(a);        // 期望调用 real_func(int& )
wrapper(10);       // 期望调用 real_func(int&&)

```

但 `wrapper` 里无论如何 `x` 本身都是一个**左值变量**（有名字的都是左值），所以 `real_func(x);` 只会走 `int&` 版本，右值信息丢了。

**完美转发的目标：**

> 让 `wrapper` 把“实参是左值还是右值”的信息完整地传给 `real_func`，仿佛没有经过 `wrapper` 这一层。

---

## 2. 核心：转发引用（forwarding reference）

经典写法：

```C++
template <typename T> void wrapper(T&& x) {     // ... 
}
```

这里的 `T&&` 如果你学“右值引用”的时候直接记成“右值引用类型”，在模板里就会容易崩溃。  
**关键点：**

> 当 `T` 是模板参数，形参写成 `T&&`，并且通过类型推导得到 `T` 时，`T&&` 叫 **转发引用（forwarding reference 或 universal reference）**。

它有一条“引用折叠规则”：

- 传**左值**进来：`T` 被推成 `T&`，形参类型变成 `T& &&` → 折叠成 `T&`
    
- 传**右值**进来：`T` 被推成普通类型 `T`，形参就是 `T&&`
    

举个例子：

```C++
int a = 0; 
wrapper(a);   // T 推导成 int&，参数类型是 int& && → 折叠成 int& 
wrapper(0);   // T 推导成 int， 参数类型是 int&&
```

所以 `wrapper` 里面的 `x`：

- 对于 `wrapper(a)`，`x` 是 `int&`（左值引用）
    
- 对于 `wrapper(0)`，`x` 是 `int&&`（右值引用）
    

但是注意：**不管类型是 `int&` 还是 `int&&`，`x` 作为一个变量本身都是左值**。  
这就是为什么直接 `real_func(x)` 不够，需要 `std::forward`。

---

## 3. `std::forward` 究竟干了什么？

典型写法：

```C++
template <typename T> 
void wrapper(T&& x) {     
		real_func(std::forward<T>(x)); }
```

`std::forward<T>(x)` 的设计原则：

> - 如果 `T` 是个左值引用类型（比如 `int&`），就把 `x` 当“左值”转出去；
>     
> - 如果 `T` 是非引用类型（比如 `int`），就把 `x` 当“右值”转出去。
> 
> 主要看T被推导成什么    

可以看看它的典型实现（简化版）：

`template<typename T> T&& forward(std::remove_reference_t<T>& x) {     return static_cast<T&&>(x); }`

关键点：

- 如果 `T = int&`：
    
    - `std::remove_reference_t<T>` 是 `int`
        
    - 函数形参是 `int& x`
        
    - 返回 `static_cast<int& &&>(x)` → 引用折叠 → `int&`（左值）
        
- 如果 `T = int`：
    
    - `remove_reference_t<int>` 还是 `int`
        
    - 参数是 `int& x`
        
    - 返回 `static_cast<int&&>(x)` → 右值
        

所以 `std::forward<T>(x)` 本质就是一个“**带条件的 `static_cast`**”，根据 `T` 是不是引用来决定 cast 成 `T&` 还是 `T&&`。

这样 `real_func(std::forward<T>(x));` 就会：

- 对左值调用时走 `int&` 版本
    
- 对右值调用时走 `int&&` 版本
    

**完美转发达成 ✅**

先看这个模板：

```C++
template<class T>
using Clean = std::remove_cv_t<std::remove_reference_t<T>>;

template<class T>
void g(T&& x) {
    Clean<T> c = std::forward<T>(x);
}
```

### 情况 A：传右值 `unique_ptr`

`std::unique_ptr<int> p = std::make_unique<int>(1); g(std::move(p));`

- 推导：`T = std::unique_ptr<int>`
    
- `x` 的类型：`std::unique_ptr<int>&&`
    
- `std::forward<T>(x)` 仍是右值
    
- `Clean<T>` 是 `std::unique_ptr<int>`
    
- 用右值初始化 → **走移动构造** ✅ OK
    

### 情况 B：传左值 `unique_ptr`

`std::unique_ptr<int> p = std::make_unique<int>(1); g(p);`

- 推导：`T = std::unique_ptr<int>&`
    
- `x` 的类型：`std::unique_ptr<int>&`
    
- `std::forward<T>(x)` 仍是左值
    
- `Clean<T>` 是 `std::unique_ptr<int>`
    
- 用左值初始化 → **需要拷贝构造**（但 unique_ptr 不可拷贝） ❌ 编译报错
    

所以答案是：

> **能完美转发，但完美转发不会改变左值/右值性质；  
> unique_ptr 只有在传入右值时才能成功转发并移动。**

## 关键场景：`int&& a = 6; wrapper(a)` 会怎样？

你关心的是这个：

`int&& a = 6;   // a 的类型是 int&&，但表达式 a 是“有名字的变量” → 左值 wrapper(a);`

这是很多人第一次接触时的坑：**变量 `a` 的类型是右值引用，但“a 这个表达式”本身是左值**。

### 第一步：推导 T

- 传进去的是表达式 `a`，它是**左值**；
    
- 和普通左值一模一样，模板推导仍然按“左值规则”：
    
    - `T = int&`；
        
    - 形参 `T&&` = `int& &&` → `int&`（左值引用）。
        

所以，在 `wrapper` 里面，**`x` 的类型是 `int&`，不是 `int&&`**。

### 第二步：`std::forward<T>(x)` 是什么？

这里 `T = int&`：

```C++
std::forward<T>(x)  ==  std::forward<int&>(x)
                      == static_cast<int&>(x); // 左值
```

所以，`real_func` 看到的是一个 **左值**：

`real_func(std::forward<T>(x));  // 调 real_func(int&)`

也就是说：

> **`wrapper(a)` 把这个“右值引用类型的变量 a”当作左值来转发。**

这其实是对的逻辑：  
因为你确实是把一个“已经绑定好的对象 a”交给 wrapper；  
wrapper 不应该凭空“偷走”它的资源，除非你显式说“我打算把它当右值用”。

---

## 如果你想“无论传左值还是右值，都生成一个 owning 的 Clean<T\>”

那语义上就是“总是移动/接管”，你必须显式 `std::move` 左值：

```C++
template<class T>
void g(T&& x) {
    using C = Clean<T>;
    C c = std::move(x);  // 强行把 x 当右值
}
```

但注意：这会让调用者传左值时也被“掏空”，语义要讲清楚。

---

## 最常见的安全模式：只在能构造时才构造

```C++
template<class T>
auto make_clean(T&& x) {
    using C = Clean<T>;
    return C(std::forward<T>(x)); // 右值->move，左值->copy（若可）
}
```

- 对可拷贝类型：左值 OK
    
- 对不可拷贝但可移动类型（如 unique_ptr）：必须传右值


---

## 4. 和 `std::move` 的区别

一句话对比：

- `std::move(expr)`：**无条件地把表达式当作右值**（本质是 `static_cast<T&&>`）
    
- `std::forward<T>(expr)`：**条件右值**，只有当 `T` 是非引用类型时才转成右值，否则保持左值
    

例如：

```C++
template <typename T> 
void wrapper_move(T&& x) {
     real_func(std::move(x));     // 无论传左值还是右值，统统变右值 
     }  
template <typename T> 
void wrapper_forward(T&& x) {
     real_func(std::forward<T>(x)); // 左值进来 → 左值出去；右值进来 → 右值出去 
     }
```

调用：

`int a = 0; wrapper_move(a);     // a 当成右值用，可能触发 move、甚至把 a 搞残 wrapper_forward(a);  // 仍然按左值转发`

**所以规则：**

> - 对“封装/转发接口”用 `std::forward`
>     
> - 在你“明确希望把某个东西当右值用”时用 `std::move`
>