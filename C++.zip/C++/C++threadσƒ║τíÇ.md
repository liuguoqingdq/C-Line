## 一、2.1 创建线程：`std::thread t(worker, 1);`

### 1.1 构造 `std::thread` 就立即启动线程

这行代码逻辑上等价于：

1. 保存一个“可调用对象 + 参数”的组合
    
2. 创建一个系统线程（pthread / WinThread）
    
3. 在线程里调用 `worker(1)`
    

```C++
void worker(int id) {
    // 在线程里执行的代码
}

int main() {
    std::thread t(worker, 1); // 一构造就启动
    t.join();
}
```

**几点细节：**

- 线程函数可以是：
    
    - 普通函数：`void f(int)`
        
    - lambda：`[](int){…}`
        
    - 仿函数对象：`struct Foo { void operator()(); };`
        
    - 成员函数：`std::thread t(&Obj::method, &obj, args...)`
        
- 线程函数可以有返回值，但**不会被 `std::thread` 接收**。要传结果要用 `std::promise/std::future` 或共享变量。
    

### 1.2 构造函数模板的大致形式

你可以理解为：

```C++
template<class F, class... Args>
explicit thread(F&& f, Args&&... args);
```

内部会做一次 **decay + 复制/移动**，产生一个内部的可调用对象，然后在线程里调用：

```C++
INTERNAL_CALL( std::decay_t<F>(std::forward<F>(f)),
               std::decay_t<Args>(std::forward<Args>(args))... );
```

所以：  
**所有传入的参数，默认都是复制/移动一份到线程内部。**

---

## 二、2.2 参数传递规则（为什么一直强调“值拷贝”）

### 2.2.1 默认：按值（或者按 move）传递副本

```C++
void f(std::vector<int> v); // v 是线程内部的副本

std::vector<int> big(1000000);
std::thread t(f, big);      // 拷贝 big
```

这会发生一次 `big` 的拷贝构造，可能很重。  
更高效写法：

`std::thread t(f, std::move(big)); // 把 big 移动进线程`

线程里 `v` 仍是按值参数，只不过来自 move 构造。

### 2.2.2 真正传引用必须用 `std::ref`

```C++
void g(std::vector<int>& v);

std::vector<int> v;
std::thread t(g, std::ref(v));  // g 里面 v 就是主线程的那一份
```

如果你写：

`std::thread t(g, v); // ❌ 会尝试构造 g(std::vector<int>&) 的参数，编译报错`

所以**记住一条规则**：

> 想让线程操作“同一块对象”，就用 `std::ref`（或传指针），否则默认都是按值复制/移动。

### 2.2.3 小坑：引用 + 生命周期

```C++
std::thread t(g, std::ref(v));
t.detach();
// 或者 main 提前结束
```

只要**线程还在跑，`v` 必须还活着**。  
否则就是典型“悬空引用”：

- 线程访问的是 &v，v 已经出作用域/析构 → 未定义行为。
    

常见安全模式是：

- 线程在 `v` 生命周期内部就 `join()`
    
- 或者 `v` 是更长生命周期的对象（例如全局/堆上托管的）
    

### 2.2.4 lambda 捕获 vs 线程参数

对比下面两种写法：

```C++
std::vector<int> v;

// 写法 1：通过参数传
std::thread t1([&](std::vector<int>& ref){
    // 用 ref
}, std::ref(v));

// 写法 2：lambda 捕获
std::thread t2([&v]{
    // 用 v
});
```

两者本质一样：线程里访问的是同一块 v，只是语法不同。  
**决定是“副本”还是“共享”的关键，不是线程，而是你“是按值捕获还是按引用捕获/传参”。**

---

## 三、2.3 `join()` vs `detach()`：线程生死线

### 3.1 什么是 “joinable”

一个 `std::thread` 有三种状态：

1. **默认构造**：没有线程 `std::thread t;` → `t.joinable() == false`
    
2. **关联了一个线程且尚未 join/detach** → `t.joinable() == true`
    
3. **已经被 join 或 detach** → 再次 `t.joinable() == false`
    

```C++
std::thread t(worker);
if (t.joinable()) {
    t.join();
}
```

**硬规则：**

> `std::thread` 析构时，如果 `joinable()==true` → 直接 `std::terminate()`。

也就是说，你必须在析构前：

- 要么 `join()`（等它结束）
    
- 要么 `detach()`（放飞，不再管理）
    

---

### 3.2 `join()`：等待线程结束（推荐默认）

```C++
std::thread t(worker);
// 做点其它事...
t.join(); // 阻塞到 worker 结束
```

特性：

- 让调用线程阻塞，直到子线程执行完
    
- `join()` 之后该 `std::thread` 不再关联任何线程（`joinable()==false`）
    
- 不能对同一线程调用两次 `join()` → UB
    

这是最安全的模式：**线程生命周期受 main 控制，数据不会乱飞。**

---

### 3.3 `detach()`：后台线程（极易踩坑）

```C++
std::thread t(worker);
t.detach(); // 后台线程跑，t 不再管理
```

**语义：**

- 系统级线程继续运行，和 `std::thread` 对象脱钩
    
- 你再也不能 join 它，也拿不到它的 ID
    
- 线程里如果访问的是栈上对象/局部变量，非常容易变成悬空指针
    

classical bug：

```C++
void f() {
    int x = 0;
    std::thread t([&]{
        // 线程里用 x
        use(x);
    });
    t.detach();   // f 返回后，x 已经销毁
}                // 线程还在访问已经死掉的 x → UB
```

**什么时候“可以” detach？**

- 线程只访问：
    
    - 静态存储期对象（全局单例）
        
    - 寿命肯定长于线程的堆对象（比如 shared_ptr 管理）
        
- 线程逻辑是“完全 fire-and-forget”，不需要结果、不需要错误处理
    

但工程实践里，一般建议：

> 除非你非常清楚生命周期，否则 **能不用 detach 就别用**。  
> 更现代的办法是用 `std::jthread`（C++20），析构时自动 join + 支持 stop_token。

---

### 3.4 RAII 封装：把“忘记 join 导致 terminate”干掉

典型写法：

```C++
class JoiningThread {
    std::thread t;
public:
    template<typename F, typename... Args>
    explicit JoiningThread(F&& f, Args&&... args)
        : t(std::forward<F>(f), std::forward<Args>(args)...) {}

    ~JoiningThread() {
        if (t.joinable()) t.join();
    }

    std::thread& get() { return t; }
};
```

以后你可以写：

`JoiningThread jt(worker); // 不用手动 jt.get().join()，作用域结束自动 join`

`std::thread` 自己的构造函数也是模板 + 完美转发，大致（伪代码）像这样：

```C++
template<class F, class... Args>
thread(F&& f, Args&&... args) {
    using Fdecayed   = std::decay_t<F>;
    using ArgsDecayed... = std::decay_t<Args>...;
    // 把这些东西存在线程内部，作为将来在线程里调用的 callable
    // 内部会构造一个对象，包含 Fdecayed 和 ArgsDecayed...
}
```

**关键点：**

- 即使 `F` 推成了 `SomeFunctor&`，`std::decay_t<F>` 会把引用去掉，得到 `SomeFunctor`
    
- 也就是说，线程内部会存一份 **按值持有的副本**
    
- 你传进去的是左值 → 内部构造这份副本时用 **拷贝构造**
    
- 你传进去的是右值（比如 `std::move(fun)`） → 内部用 **移动构造**

---

## 四、2.4 线程 ID 与硬件并行度

### 4.1 `std::this_thread::get_id()`

获取当前线程的 ID：

```C++
#include <thread>
#include <iostream>

void worker() {
    std::cout << "worker id = " << std::this_thread::get_id() << "\n";
}
```

- `std::thread::id` 是一个可比较/可输出的类型
    
- 默认构造 `std::thread::id{}` 用来表示“没有线程”
    

可以用来：

- 打日志
    
- 标记/调试哪个线程在干嘛
    
- 做简单的线程亲和力管理（配合平台 API）
    

### 4.2 `std::thread::hardware_concurrency()`

```C++
unsigned n = std::thread::hardware_concurrency();
```

- 返回一个**建议值**：系统估计的并发执行线程数（通常是逻辑 CPU 数）
    
- 可能为 0（查询失败）
    

常见用法：**作为线程池大小的上限参考**：

```C++
unsigned n = std::thread::hardware_concurrency();
if (n == 0) n = 4;  // 给个默认值
ThreadPool pool(n);
```

需要强调：

> 这是“hint”，不是“硬约束”。  
> 就算它返回 8，你开 100 个线程系统也不会禁止，只是可能过度切换。

---

## 五、`std::thread` 的“可移动不可复制”

你提到“可移动不可复制”，这点也很重要。

### 5.1 为什么不可复制？

复制一个 `std::thread` 意味着“两个对象共同管理一条线程”：

```C++
std::thread t1(worker);
// std::thread t2 = t1; // 禁止，编译不过
```

如果允许：

- 谁 join？
    
- 谁析构？
    
- 双方都 join 会怎样？
    

太容易出错，所以设计成 **non-copyable**。

### 5.2 为什么允许 move？

移动语义是“转移所有权”：

```C++
std::thread t1(worker);
std::thread t2 = std::move(t1); // t2 管这个线程，t1 变成不 joinable
```

用途：

- 把线程放入容器：
    

```C++
std::vector<std::thread> workers;
workers.emplace_back(worker, 1);
workers.emplace_back(worker, 2);
```

- 从函数返回线程对象：
    

```C++
std::thread make_thread() {
    return std::thread(worker); // 返回的是 move
}
```

> 总之：**一条线程只能有一个 `std::thread` 拥有者。**

---

## 小结（这部分你要“内化”的点）

1. **创建线程时，构造 `std::thread` 就已经启动**。
    
2. **参数默认按值（或按 move）复制到线程内部**，  
    真正想共享就用 `std::ref` 或引用捕获，注意生命周期。
    
3. **每个 `std::thread` 在析构前必须被 join 或 detach**，  
    否则直接 `std::terminate()`。
    
4. `join` 等线程结束，`detach` 放飞；后者极易搞出悬空引用。
    
5. **线程对象可移动不可复制**，这一点确立了“唯一所有权”的语义。
    
6. `get_id` 用于识别线程，`hardware_concurrency` 仅是“建议核心数”。