```C++
#include <iostream>
#include <atomic>
#include <mutex>

class Singleton {
private:
    static std::atomic<Singleton*> instance;//用指针来控制对象，从而手动析构，使用atomic来包裹指针，从而保证原子事物
    static std::mutex mtx; //异步锁

    Singleton() {
        std::cout << "Singleton constructed!" << std::endl;
    }

    ~Singleton() {
        std::cout << "Singleton destructed!" << std::endl;
    }

    Singleton(const Singleton&) = delete;//将拷贝构造函数，删除
    Singleton& operator=(const Singleton&) = delete;//将赋值构造函数，删除

    // 真正干删除事情的实现函数（对内使用）
    static void destroyImpl() {
        Singleton* tmp = instance.load(std::memory_order_acquire);//首次读取，保证顺序，看里面有没有数值，原因在于，如果多线程环境或者编译器优化状况下，可能把修改数值的事物移到读取事务之前。
        if (tmp != nullptr) {
            std::lock_guard<std::mutex> lock(mtx);//加锁
            tmp = instance.load(std::memory_order_relaxed);//再次判定，无需保证事务顺序，因为mtx已经保证，二次加载的原因在于，不同线程，可能同时进入了这个判定，需要继续读取来判定。
            if (tmp != nullptr) {
                delete tmp;
                instance.store(nullptr, std::memory_order_release);
            }
        }
    }

    // 关键：自动析构守护者
    struct AutoDestroy {//如果AutoDestroy的结构体不在private中，则无法调用destroyImpl，并且其对象是静态开辟的，也是为了能自动回收。
        ~AutoDestroy() {
            // 程序结束时会调用这里
            Singleton::destroyImpl();
        }
    };

    static AutoDestroy autoDestroy;  // 这个对象的析构用来“自动收尸”

public:
    static Singleton& getInstance() {
        Singleton* tmp = instance.load(std::memory_order_acquire);
        if (tmp == nullptr) {
            std::lock_guard<std::mutex> lock(mtx);
            tmp = instance.load(std::memory_order_relaxed);
            if (tmp == nullptr) {
                tmp = new Singleton();
                instance.store(tmp, std::memory_order_release);
            }
        }
        return *tmp;
    }

    // 给外部使用的“手动销毁”
    static void destroy() {
        destroyImpl();
    }

    void showMessage() {
        std::cout << "Hello from Singleton!" << std::endl;
    }
};

// 静态成员定义顺序很重要：
// 1. instance
// 2. mtx
// 3. autoDestroy （析构时倒序：先~autoDestroy，再~mtx，最后~instance）
std::atomic<Singleton*> Singleton::instance{nullptr};
std::mutex              Singleton::mtx;
Singleton::AutoDestroy  Singleton::autoDestroy;  // 只为了自动析构

int main() {
    Singleton& s1 = Singleton::getInstance();
    s1.showMessage();

    Singleton& s2 = Singleton::getInstance();
    s2.showMessage();

    // 你可以手动销毁
    Singleton::destroy();

    // 也可以重新获取（如果你愿意，把它当“可重建单例”）
    Singleton& s3 = Singleton::getInstance();
    s3.showMessage();

    // 这里即使你不再 destroy，程序结束时 AutoDestroy 也会再清一次，
    // 但 destroyImpl() 是幂等的，instance == nullptr 时什么也不做
    return 0;
}

```
### ✅ 单例模式

- `getInstance()` 里还是你的 DCL + atomic 写法；
    
- 全程只有一个 `Singleton*` 被 `instance` 持有；
    
- 如果你允许 destroy 后重建，那它是“在任一时刻最多有一个”。
    

### ✅ 线程安全

- 初始化：依旧是原来的 **双重检查 + acquire/release**，线程安全。
    
- 销毁：`destroyImpl()` 里有互斥锁保护，对 `instance` 的读写仍然用原子。
    
- 程序退出阶段：`AutoDestroy::~AutoDestroy()` 在静态对象析构阶段调用，一般只有主线程在跑，其他线程通常已经结束（这点在设计上最好你自己也保证一下）。
    

**注意：**  
依旧有一个逻辑层面的原则——**不要在 `destroy()` 被调用后再在别的线程里用 `getInstance()` 或已拿到的引用**，否则你就会踩到悬空引用的问题。这是所有“支持手动销毁的单例”都绕不开的。

### ✅ 自动析构 + 手动析构

- **手动析构**：你可以在任意时刻 `Singleton::destroy()`，它会删掉当前实例。
    
- **自动析构**：
    
    - 当你没手动 destroy 时：程序结束 → 静态对象 `autoDestroy` 析构 → 调用 `destroyImpl()` → 正常 delete 单例；
        
    - 当你已经手动 destroy 过：
        
        - `instance` 已经是 `nullptr`，
            
        - 退出时 `destroyImpl()` 再跑一次，检测到 `nullptr`，直接返回，不会重复 delete —— 幂等。
## 一、整体设计思路

- **目标**：
    
    1. 懒汉式单例（第一次用到时才创建）；
        
    2. 多线程安全；
        
    3. 既能手动销毁 `Singleton`，又能在程序结束时自动销毁。
        
- **关键手段**：
    
    - 用 `std::atomic<Singleton*>` + `std::mutex` 实现 **双重检查锁 DCL** 的线程安全单例创建；
        
    - 定义一个内部结构体 `AutoDestroy`，再定义一个静态的 `AutoDestroy` 对象，让它的析构函数负责在程序退出时调用 `destroyImpl()` 收尾。
        

---

## 二、类内静态成员

```C++
static std::atomic<Singleton*> instance; 
static std::mutex mtx;
```

- `instance`：保存“当前单例对象”的指针，用 `atomic` 是为了在多线程下无锁读取时不产生 data race。
    
- `mtx`：用来保护创建/删除过程，让同一时刻只有一个线程在构造或销毁单例。
    

```C++
Singleton::instance{nullptr}; 
Singleton::mtx; 
Singleton::AutoDestroy Singleton::autoDestroy;//
```

- 这三行是真正定义静态成员，并指定了初始化顺序。
- 在C++17中，可以加inline关键字来完成唯一类内初始化。
    
- 注意注释里说的：初始化顺序是 `instance -> mtx -> autoDestroy`，  
    析构顺序则相反：**先析构 `autoDestroy`，再析构 `mtx`，最后是 `instance` 对象本身**（但 `atomic`/`mutex` 基本是 trivial 的）。
    

---

## 三、构造 / 析构 & 禁用拷贝

```C++
Singleton()  { std::cout << "constructed\n"; }
~Singleton() { std::cout << "destructed\n"; }

Singleton(const Singleton&)            = delete;
Singleton& operator=(const Singleton&) = delete;

```

- 把构造函数设为 `private`，保证外部不能随便 `new` 或栈上定义；
    
- 删除拷贝构造和赋值运算符，防止复制出第二个 `Singleton` 实例；
    
- 析构函数同样是 `private`，只能在类内部 `delete` 时被调用。
    

---

## 四、核心：`getInstance()`——懒汉式 + DCL

```C++
static Singleton& getInstance() {
    Singleton* tmp = instance.load(std::memory_order_acquire);
    if (tmp == nullptr) {
        std::lock_guard<std::mutex> lock(mtx);
        tmp = instance.load(std::memory_order_relaxed);
        if (tmp == nullptr) {
            tmp = new Singleton();
            instance.store(tmp, std::memory_order_release);
        }
    }
    return *tmp;
}

```

### 步骤拆解

1. **第一次无锁读取（快速路径）**
    
 ```C++
    Singleton* tmp = instance.load(std::memory_order_acquire);
if (tmp != nullptr) return *tmp;

 ```
    - 大多数时候单例已经创建好了，这里直接原子读 + 返回，避免每次都加锁。
        
    - `memory_order_acquire` 和后面的 `release` 配对，保证一旦看到非空指针，能看到对象完整初始化后的状态。
        
2. **第一次判断为 `nullptr` 时，加锁**
    
```C++
std::lock_guard<std::mutex> lock(mtx);
tmp = instance.load(std::memory_order_relaxed);
if (tmp == nullptr) {
    tmp = new Singleton();
    instance.store(tmp, std::memory_order_release);
}

```
    
    - 可能有多个线程并发进来，其中一个先拿到锁。
        
    - 锁内再读一次 `instance`，这是 DCL 的“第二次检查”：
        
        - 如果已经有别的线程抢先构造了单例，这里就能看到非空，直接用；
            
        - 如果还是空，说明当前线程真的需要负责构造。
            
3. **`memory_order_release`**
    
    - `new Singleton()` 里会执行构造函数，对对象成员做各种写入；
        
    - `store(..., memory_order_release)` 保证这些写入在别的线程做 `acquire` 读取 `instance` 时可见，避免“看到非空指针但对象还没完全初始化好”的重排问题。
        

> 总结：这是一个标准的 **DCL 单例 + acquire/release 内存序** 写法。

---

## 五、`destroyImpl()`：统一的销毁逻辑

```C++
static void destroyImpl() {
    Singleton* tmp = instance.load(std::memory_order_acquire);
    if (tmp != nullptr) {
        std::lock_guard<std::mutex> lock(mtx);
        tmp = instance.load(std::memory_order_relaxed);
        if (tmp != nullptr) {
            delete tmp;
            instance.store(nullptr, std::memory_order_release);
        }
    }
}

```

- 结构跟 `getInstance()` 很像，只不过是做 **删除**：
    
    1. 先无锁读一次，如果已经是 `nullptr`，直接返回；
        
    2. 否则加锁再读一次，防止多线程重复删除；
        
    3. 在锁里 `delete` 对象，并把 `instance` 置回 `nullptr`。
        
- 同样用 `acquire/release` 确保内存可见性，`delete` 后把指针发布为 `nullptr`，防止其他线程再看到旧指针。
    

> 注意：从设计上依然需要调用方 **避免在别的线程还在用 Singleton 时调用 `destroy()`**，不然拿着旧引用继续用还是会崩，这是所有“可手动销毁单例”共同的问题。

---

## 六、`AutoDestroy`：实现“程序结束时自动析构”

```C++
struct AutoDestroy {
    ~AutoDestroy() {
        Singleton::destroyImpl();
    }
};

static AutoDestroy autoDestroy;

```

- 这是一个内部小结构体，只定义了析构函数。
    
- 类外有一行：
    
    `Singleton::AutoDestroy Singleton::autoDestroy;`
    
    这意味着在整个程序静态初始化阶段，会构造出一个全局的 `autoDestroy` 对象。
    
- **程序结束时，静态对象会被依次析构**：
    
    - 当轮到 `autoDestroy` 析构时，它会调用 `Singleton::destroyImpl()`；
        
    - 如果此时单例还存在，就会被删除；
        
    - 如果之前已经被 `Singleton::destroy()` 手动删过，`destroyImpl()` 里检查到 `instance == nullptr`，什么也不做——所以是幂等的。
        

这就实现了你要的：

- **平时可以手动 `Singleton::destroy()` 提前收尾；**
    
- **最后没删干净的话，程序退出时自动再收一遍。**
    

---

## 七、`destroy()` 对外接口

`static void destroy() {     destroyImpl(); }`

- 对外暴露一个简单接口，内部直接复用 `destroyImpl()`；
    
- 因为 `destroyImpl()` 做了两次检查 + 加锁，所以多次调用 `destroy()` 是安全的（最多删一次，后面都是空操作）。
    

---

## 八、`main()` 中的执行流程

```C++
int main() {
    Singleton& s1 = Singleton::getInstance();
    s1.showMessage();

    Singleton& s2 = Singleton::getInstance();
    s2.showMessage();

    Singleton::destroy();  // 手动销毁

    Singleton& s3 = Singleton::getInstance();  // 再次创建
    s3.showMessage();

    return 0;  // 程序结束，AutoDestroy 再调用一次 destroyImpl()（这时实例已存在，会被删掉）
}

```

大致输出顺序类似：

```C++
Singleton constructed!
Hello from Singleton!
Hello from Singleton!
Singleton destructed!           // 手动 destroy
Singleton constructed!          // 第三次 getInstance() 重新创建
Hello from Singleton!
Singleton destructed!           // 程序结束时 AutoDestroy 析构

```

说明：

- 这是一个“**可重建的单例**”：同一时刻只有一个实例，但生命周期可以被销毁后再创建；
    
- 真正严格的“一生只构造一次”的 Singleton 一般不会允许这样手动销毁并重建，这里是你特意加的扩展能力。

这里的 `memory` 你其实指的是 **`std::memory_order` 那几个枚举值 + `atomic` 上带这个参数的方法**，也就是：

`instance.load(std::memory_order_acquire); instance.store(ptr, std::memory_order_release); instance.load(std::memory_order_relaxed);`

我分三块给你讲：

1. 先说「为啥要 memory_order」
    
2. 再说 6 种 `memory_order` 各自干嘛
    
3. 最后结合你这段单例代码解释这些参数是怎么配合用的
    

---

## 1. 为啥需要 memory_order？

多核 + 编译器优化的世界里，有两个“会搞事情”的家伙：

1. **编译器优化**：可以把指令重排，只要单线程语义不变就行；
    
2. **CPU & cache**：可能乱序执行、缓存延迟，让别的核心看到的顺序和你写代码的顺序不一致。
    

`std::atomic` 做两件事：

- 保证 **原子性**：这次读 / 写不会被拆成一半一半；
    
- 通过 **memory_order** 参数，让你告诉编译器 & CPU：“这次原子操作在指令重排上要有哪些约束”。
    

> 简单粗暴心智模型：
> 
> - `relaxed`：只要原子性，其他随便排；
>     
> - `acquire` / `release`：保证「前面的写 → 后面的读」的可见性；
>     
> - `seq_cst`：最严格，所有线程看到的顺序都跟你想的一样。
>     

---

## 2. 六种 `std::memory_order` 是什么？

枚举类型：`std::memory_order` 一共 6 种（`<atomic>` 里）：

`memory_order_relaxed memory_order_consume   // 标准里半废弃，一般当成 acquire memory_order_acquire memory_order_release memory_order_acq_rel memory_order_seq_cst`

### 2.1 `memory_order_relaxed` —— 只要“原子”，不要“顺序”

- 只保证这次原子操作本身不会被 tear，别的线程不会读到半个指针这种鬼东西；
    
- **不保证前后的普通读写顺序**，编译器和 CPU 可以随便重排；
    
- 典型用途：**计数器、统计信息**，你不在乎“看到的是最新值”，只要“不会读到乱七八糟的值”。
    

例子：

`std::atomic<int> counter{0}; counter.fetch_add(1, std::memory_order_relaxed);`

---

### 2.2 `memory_order_acquire` —— 读 & “之后的操作不能穿过去”

- 通常用在 **load / 读端**；
    
- 保证：
    
    - 这个 load 之后的普通读写，**不会被重排到 load 之前**；
        
    - 如果它和某个 `release` store 形成同步关系，那么该 release 之前的所有写，对当前线程可见。
        

常见用法：**读一个“已经初始化好的指针 / 标志位”**，只要看到非空，就应该看到对象完整初始化后的状态。

`auto* p = ptr.load(std::memory_order_acquire); if (p) {     // 这里安全地使用 *p }`

---

### 2.3 `memory_order_release` —— 写 & “之前的操作不能穿过去”

- 通常用在 **store / 写端**；
    
- 保证：
    
    - 这个 store 之前的普通读写，**不会被重排到 store 之后**；
        
    - 配合一个 `acquire` load，同步前面的写。
        

常见用法：**初始化完对象之后，把指针发布出去**：

```C++
Data* p = new Data(...);  // 构造里写了一堆成员 
ptr.store(p, std::memory_order_release);  // 发布
```

---

### 2.4 `memory_order_acq_rel` —— 既是 acquire 又是 release

- 用在 **读-改-写（RMW）操作** 上，比如 `fetch_add`、`exchange`、`compare_exchange`；
    
- 一次操作既要：
    
    - 读取旧值时起 **acquire** 作用；
        
    - 写入新值时起 **release** 作用。
        

例子：

`auto old = value.fetch_add(1, std::memory_order_acq_rel);`

---

### 2.5 `memory_order_seq_cst` —— 最强、最简单理解的那种

- **Sequentially Consistent（顺序一致性）**；
    
- 除了有 acquire/release 的效果之外，还保证：
    
    - 所有线程看到所有 `seq_cst` 操作的顺序是一样的；
        
- 心智模型：你可以假装所有原子操作排成一条全局时间线。
    

代价：约束最强，理论上性能也最差；但对大多数逻辑来说，写 `seq_cst` 很好理解。

---

### 2.6 `memory_order_consume` —— 当它不存在

理论上是“依赖性排序（dependency ordering）”，但因为标准的问题，多数实现把它当成 `acquire` 处理，甚至明说“不推荐用”。**实战里基本可以当它不存在**。

---

## 3. `std::atomic` 上那几个带 memory_order 的方法

常见原子操作都有一个可选的 `memory_order` 参数：

- `load(memory_order order = seq_cst)`
    
- `store(T, memory_order order = seq_cst)`
    
- `exchange(T, memory_order order = seq_cst)`
    
- `compare_exchange_weak(...)` / `compare_exchange_strong(...)`
    
- `fetch_add` / `fetch_sub` / `fetch_or` 等 RMW 操作
    

简单记法：

- **load**：可用 `relaxed / acquire / seq_cst`
    
- **store**：可用 `relaxed / release / seq_cst`
    
- **RMW**：可用 `relaxed / acquire / release / acq_rel / seq_cst`
    

---

## 4. 回到你这段 Singleton 代码：为什么这样配？

```C++
// 无锁读取：acquire
Singleton* tmp = instance.load(std::memory_order_acquire);

// 锁内读取：relaxed
tmp = instance.load(std::memory_order_relaxed);

// 发布指针：release
instance.store(tmp, std::memory_order_release);

```

`Singleton* tmp = instance.load(std::memory_order_acquire); if (tmp != nullptr) {     return *tmp; }`

- 这里是无锁快速路径，可能直接把指针返回给别的线程用。
    
- 要求：**只要看到 `tmp != nullptr`，就必须看到构造函数里做的所有写入**。  
    这就需要和构造完成后的 `release` store 配对，形成 `release-acquire` 同步关系。
    

### 4.2 锁内那次 `relaxed`

```C++
Singleton* tmp = instance.load(std::memory_order_acquire);
if (tmp != nullptr) {
    return *tmp;
}

```

- 进入到这里说明我们已经持有互斥锁 `mtx` 了；
    
- `mutex` 本身就提供了很强的内存屏障语义：
    
    - 任何线程在释放锁之前的写，在另一个线程获取同一把锁之后都可见；
        
- 所以这里的 `load` **只需要原子性，不需要额外的排序约束**，用 `relaxed` 就够了。
    

### 4.3 发布实例时的 `release`

```C++
tmp = new Singleton();                         // 构造里写了一堆东西
instance.store(tmp, std::memory_order_release); // 发布指针
```

- 保证：构造函数里的所有写发生在 `store` 之前；
    
- 和别的线程的 `acquire` load 配合，确保只要别人看到非空指针，就一定看到完全初始化完的对象。
```mermaid
graph TD

    subgraph Static["静态区（Static Area）"]
        inst[instance：std::atomic&lt;Singleton*&gt;]
        mtx[mtx：std::mutex]
        autoD[autoDestroy：AutoDestroy 实例]
    end

    subgraph Heap["堆区（Heap Area）"]
        obj1[Singleton 对象 #1]
        obj2[Singleton 对象 #2]
    end

    %% 第一次 getInstance 之后
    inst --> obj1

    %% destroy() 调用后，obj1 被删除（这里只做说明）
    %% 再次 getInstance 之后
    inst -. 指向新的实例 .-> obj2

    %% 程序结束时，autoDestroy 析构，调用 destroyImpl
    autoD --> inst

```
