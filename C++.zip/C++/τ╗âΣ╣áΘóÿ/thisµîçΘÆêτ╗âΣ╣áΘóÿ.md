# 一、`this` 指针与成员函数（1–4）

### 1️⃣ `this` 的本质（理解题）

下面成员函数中，`this` 的类型分别是什么？
```C++
class A {
public:
    void f();
    void g() const;
};
```

请写出：

- `f()` 中 `this` 的类型
    
- `g()` 中 `this` 的类型

**答案：**

- `void f();` 中：`this` 类型是 `A* const`
    
- `void g() const;` 中：`this` 类型是 `const A* const`
    

**易错点：**

- 很多人只写 `A*` / `const A*`，但更准确是“指针本身是 const”（`this` 不能被重新赋值）。

---

### 2️⃣ `this` 等价展开（理解题）

给定代码：

```C++
class Point {
public:
    void move(int dx) {
        x += dx;
    }
private:
    int x;
};

Point p;
p.move(5);
```

请写出**编译器内部等价的函数调用形式**（不要求完全符合语法，只需体现 `this`）。

**答案：**
```C++
Point::move(&p,5);
```
**易错点：**

- 这只是“概念等价”。真实 ABI 可能更复杂，但理解这样就够了。

---

### 3️⃣ `this == &obj` 吗？（判断题）

在下面代码中，`this == &a` 是否恒成立？说明理由。

```C++
class A {
public:
    void check() {
        // this == &a ?
    }
};

A a;
a.check();
```
**答案：**在这段代码里 **成立**（`a.check()` 的当前对象就是 `a`）。

**易错点：**

- 只对“以对象/引用调用”成立；如果你写出 UB 的调用方式（见下一题），就不成立甚至炸。
---

### 4️⃣ `this` 能为 `nullptr` 吗？（思考题）

是否可能在成员函数中出现 `this == nullptr` 的情况？  
在**什么情况下代码能编译但行为是未定义的（UB）**？
**答案：**

- 标准意义上：**不应该**为 `nullptr`
    
- 但你可以写出**能编译**却 **UB** 的代码，比如：
```C++
A *a=nullptr;
a.check();
```
**易错点：**

- “能编译” ≠ “合法”。成员函数调用语法会让你误以为没解引用。
---

# 二、`const` 成员函数（5–7）

### 5️⃣ `const` 成员函数限制（理解题）

下面哪些语句在 `const` 成员函数中是**合法的**？哪些是非法的？为什么？

```C++
class A {
public:
    int x;
    mutable int y;

    void f() const {
        x = 1;
        y = 2;
    }
};
```
**答案：**

- `x = 1;` ❌非法（`x` 是普通成员，`this` 是 `const A*`）
    
- `y = 2;` ✅合法（`mutable` 允许在 `const` 成员函数中修改）
    

**易错点：**

- `mutable` 常用于缓存、延迟计算，不要滥用（会破坏“逻辑 const”）。
---

### 6️⃣ `const` 对象的调用限制（判断题）

判断下列代码是否能通过编译，并说明原因：

```C++
class A {
public:
    void f();
    void g() const;
};

const A a;
a.f();
a.g();
```
**答案：**

- `a.f();` ❌ 编译失败（`f()` 不是 const）
    
- `a.g();` ✅ 可以
    

**易错点：**

- const 对象只能调用 const 成员函数，这是面试必问。
---

### 7️⃣ 接口设计题（简答）

为什么**getter**（如 `get_x()`）通常要声明为 `const` 成员函数？  
请给出 **两个理由**。
**标准答案（给两个理由即可）：**

1. **可在 `const` 对象/引用上调用**（比如 `const A&` 参数）
    
2. **表达接口语义：只读、不修改对象状态**（更安全、更易维护/推理）
    

**易错点：**

- 如果忘了加 `const`，你的类会很难被 STL / 算法正确使用（比如存到 `const` 容器视角里）。
---

# 三、`static` 成员（8–10）

### 8️⃣ 静态成员访问规则（判断题）

下面代码中，哪些访问是合法的？哪些不合法？说明原因。

```C++
class A {
public:
    static int s;
    int x;

    static void f() {
        s = 1;
        x = 2;
    }
};
```
**答案：**

- `s = 1;` ✅合法（静态成员属于类）
    
- `x = 2;` ❌非法（静态函数没有 `this`，无法访问对象成员）
    

**易错点：**

- 静态函数想访问 `x`，必须**通过一个对象/指针/引用参数**传进来。
---

### 9️⃣ 静态成员变量的存储（理解题）

下面代码中，一共存在几份 `count`？为什么？

```C++
class A {
public:
    static int count;
};

A a1, a2;
```
**答案：**只有 **1 份** `A::count`（全局唯一，所有对象共享）

**易错点：**

- `a1.count` 这种写法语法允许，但本质还是 `A::count`。
---

### 🔟 静态成员 vs 全局变量（思考题）

从**封装性、命名空间、可维护性**角度，说明为什么“类内 `static` 成员变量”通常优于全局变量。
**参考答案：**

- **封装性**：放在类里，访问路径清晰（`A::count`），不会污染全局命名空间
    
- **可维护性**：可以配合访问控制（private + getter）、更易定位与管理
    
- **命名冲突更少**：全局变量容易与别的模块撞名
    

**易错点：**

- 全局变量在大型项目里是“维护灾难”，类内 static 是常见替代方案。
---

# 四、普通成员 vs 静态成员（11–12）

### 1️⃣1️⃣ 内存模型理解（理解题）

给定代码：

```C++
class A {
public:
    int x;
    static int y;
};

A a1, a2;
```

请回答：

1. `a1.x` 和 `a2.x` 是否指向同一块内存？
    
2. `a1.y` 和 `a2.y` 是否指向同一块内存？
    
**答案：**

1. `a1.x` 和 `a2.x`：❌不共享（每个对象一份）
    
2. `a1.y` 和 `a2.y`：✅共享（全类一份）
---

### 1️⃣2️⃣ 对象大小判断（思考题）

假设 `int` 占 4 字节，不考虑对齐：

```C++
class A {
public:
    int x;
    static int y;
};
```

`sizeof(A)` 是多少？为什么？
**答案：**`sizeof(A) == sizeof(int)`，一般是 **4**（忽略对齐时也是 4）。

**原因：**

- `static` 成员不在对象内部，不计入对象大小。
    

**易错点：**

- 很多人误以为 static 也占对象大小，这是错误的。
---

# 五、特殊成员函数（13–15，含 5 道编程题）

---

## 🧠 理解题

### 1️⃣3️⃣ 默认生成规则（判断题）

在下面类中，编译器会**自动生成哪些特殊成员函数**？

```C++
class A {
public:
    A(int x);
private:
    int x;
};
```

请判断是否自动生成：

- 默认构造
    
- 拷贝构造
    
- 拷贝赋值
    
- 移动构造
    
- 析构函数
    
**答案：**

- 默认构造 `A()`：❌不会生成（因为你声明了带参构造）
    
- 拷贝构造：✅会生成
    
- 拷贝赋值：✅会生成
    
- 移动构造 / 移动赋值：✅**可能**生成（C++11 起，但受规则影响；只含 int 的情况下通常可以）
    
- 析构：✅会生成
    

**易错点：**

- “写了任意构造函数 ⇒ 默认构造不再自动生成” 这个要记牢。
    
- move 的“是否生成”细节很多，但你当前阶段记住“通常可生成、但有条件”就行。
---

## 💻 编程题（重点）


---

### 1️⃣6️⃣（编程题 3）静态成员计数

实现一个类 `ObjectCounter`：

- 每创建一个对象，计数 +1
    
- 每析构一个对象，计数 -1
    
- 提供 `static int get_count()`
    
```C++
class ObjectCounter{
	ObjectCounter(){count++}
	~ObjectCounter(){count--}
	ObjectCounter(const ObjectCounter&) {count++}
	ObjectCounter& operator=(const ObjectCounter&)=default;
	static int get(){
		return count;
	}

private:
 static int count ;
};
int ObjectCounter::count=0;
```
**static成员函数只能访问static数据成员，非static成员函数能访问static数据成员,想访问需要传this**
```C++
class A {
public:
    int x;

    static void f(A* self) {
        self->x = 10;   // ✅ 完全合法
    }
};

int main() {
    A a;
    A::f(&a);
}
```

---

### 1️⃣8️⃣（编程题 5）`this` 返回自身（链式调用）

实现一个类 `Adder`：

```C++
Adder a;
a.add(1).add(2).add(3);
```

要求：

- 使用 `this`
    
- 返回类型正确
    
```C++
class Adder {
public:
    Adder& add(int x) {
        sum_ += x;
        return *this; // 或 return *this;
    }

    int value() const { return sum_; }

private:
    int sum_ = 0;
};
```
---

## 🎯 建议做题顺序

1 → 2 → 5 → 6 → 8 → 11 → 14 → 15 → 17  
（非常贴合你当前的学习曲线）