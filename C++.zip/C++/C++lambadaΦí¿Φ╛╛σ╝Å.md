
## 第一章：解剖——编译器视角的 Lambda

你以为你写的是函数，其实你写的是 类（Class）。

在 C++ 中，Lambda 表达式严格来说叫做 “闭包类型”（Closure Type） 的实例。

### 1.1 源码到汇编的映射

假设你写了这样一行简单的代码：

C++

```C++
int factor = 10;
auto lambda = [factor](int x) mutable -> int { return x * factor; };
```

**编译器在 AST（抽象语法树）阶段，会将其展开为如下标准 C++ 类：**

C++

```C++
// 1. 编译器生成一个拥有独特名字的类（名字通常包含 hash 值）
class __lambda_5b8e9a {
private:
    int _factor; // 对应捕获列表 [factor]

public:
    // 2. 构造函数：负责初始化捕获的变量
    explicit __lambda_5b8e9a(int factor) : _factor(factor) {}

    // 3. 核心：重载 operator()
    // 注意：因为原代码加了 mutable，所以这里没有 const 修饰
    // 如果没有 mutable，默认是: int operator()(int x) const
    int operator()(int x) { 
        return x * _factor; 
    }
    
    // 4. 类型转换运算符（仅限无捕获 Lambda）
    // 如果捕获列表为空，Lambda 可以隐式转换为函数指针
    // using FuncPtr = int(*)(int);
    // operator FuncPtr() const { ... }
};
```

### 1.2 对象布局（Memory Layout）

Lambda 对象在内存中长什么样？

- **无捕获（Stateless Lambda）：**
    
    - C++17 前：大小为 1 字节（C++ 标准规定空类不能为 0 大小，用于占位）。
        
    - C++20 后：配合 `[[no_unique_address]]`，作为成员变量时大小可能优化为 0。
        
- **有捕获（Stateful Lambda）：**
    
    - 它是“扁平”的。捕获了几个 `int`，它就是几个 `int` 的大小。没有虚函数表指针（vptr），没有 RTTI 信息。**它是极致紧凑的数据结构**。
        

---

## 第二章：捕获机制的深渊（内存安全的核心）

在您的 **线程池（Thread Pool）** 实现中，捕获机制决定了程序是高效运行还是随机崩溃。

### 2.1 捕获模式全解析

|**语法**|**术语**|**底层实现**|**风险等级**|**适用场景**|
|---|---|---|---|---|
|`[]`|无捕获|无成员变量|安全|纯算法逻辑|
|`[=]`|全部值捕获|成员变量拷贝|中（对象拷贝开销）|小对象，异步回调|
|`[&]`|全部引用捕获|指针/引用成员|**高（悬垂引用）**|栈内立即执行（如 `for_each`）|
|`[x, &y]`|混合捕获|混合|高|精细控制|
|`[this]`|指针捕获|`Type* _this`|**高**|访问类私有成员|
|`[*this]`|对象拷贝捕获|`Type _copy`|安全（C++17）|异步执行类成员逻辑|

### 2.2 广义捕获 (Generalized Capture / Init-capture) —— C++14 的革命

这是解决 **“只能移动不能拷贝的对象”**（如 `std::unique_ptr`, `std::thread`, `std::future`）的关键。

C++

```C++
auto ptr = std::make_unique<BigData>();

// 语法： [新变量名 = 表达式]
auto lambda = [data = std::move(ptr)]() {
    // data 在这里是 lambda 的成员变量，类型是 unique_ptr
    process(*data);
};
```

**原理：** 编译器在匿名类中定义了一个数据成员 `data`，并用 `std::move(ptr)` 初始化它。此时外部的 `ptr` 变为空。这在构建任务队列时必不可少。

---

## 第三章：类型的演进（C++11 到 C++23）

Lambda 的进化史，就是 C++ 试图让静态类型系统变得更灵活的历史。

### 3.1 C++11：单态 Lambda

参数类型必须写死。

C++

```C++
auto f = [](int x) { return x + 1; };
```

### 3.2 C++14：泛型 Lambda (Generic Lambda)

引入 `auto` 参数。这是 **编译期多态**。

C++

```C++
auto f = [](auto x) { return x + x; };
```

**底层原理：** `operator()` 变成了模板函数。

C++

```C++
template<typename T>
auto operator()(T x) { return x + x; }
```

### 3.3 C++17：Constexpr Lambda

Lambda 可以在编译期求值。

C++

```C++
constexpr auto square = [](int n) { return n * n; };
static_assert(square(3) == 9); // 编译期断言通过
```

这使得 Lambda 可以用于元编程，比如计算数组大小、模板参数推导等。

### 3.4 C++20：模板 Lambda (Template Lambda)

解决了 C++14 泛型 Lambda 过于“宽泛”的问题。

需求： 我想要一个接受 vector 的 Lambda，但不关心 vector 里的元素类型，但我需要知道那个类型是什么。

**C++14 痛点：**

C++

```C++
auto f = [](auto& vec) { 
    using T = typename std::decay_t<decltype(vec)>::value_type; // 写法极其丑陋
};
```

**C++20 优雅写法：**

C++

```C++
auto f = []<typename T>(const std::vector<T>& vec) {
    T temp = vec[0]; // 直接使用 T
    // ...
};
```

### 3.5 C++23：Deducing `this` (递归 Lambda 的终极解)

在 C++23 之前，Lambda 递归非常痛苦（因为在 Lambda 定义体内，Lambda 变量本身还未构造完成）。

**C++23 允许显式传递闭包对象本身：**

C++

```C++
auto fib = [](this auto&& self, int n) {
    if (n <= 1) return n;
    return self(n - 1) + self(n - 2); // 直接调用 self
};
```

这里 `self` 指代 Lambda 对象本身。

---

## 第四章：性能与汇编层面的考量

### 4.1 为什么 Lambda 比函数指针快？

这是经典的面试题。

- **函数指针：** 编译器看到的是一个指针。调用时必须生成 `call [register]` 指令（间接调用）。CPU 无法进行指令预取，也难以内联（Inline）。
    
- **Lambda：** 编译器看到的是一个具体的类类型。`lambda.operator()` 的代码就在那里。编译器直接将其 **内联展开**。在 `std::sort` 中，比较操作通常被优化为直接的汇编比较指令，没有任何函数调用开销。
    

### 4.2 `std::function` 的代价

在你的线程池中，使用了 `std::function<void()>` 来存储任务。这是必要的（因为任务队列需要存储不同类型的 Lambda），但也是有代价的。

**`std::function` 内部机制：**

1. **类型擦除 (Type Erasure)：** 使用虚函数或函数指针来隐藏具体类型。
    
2. **小对象优化 (SBO - Small Buffer Optimization)：** 如果 Lambda 很小（通常 < 16 或 32 字节），直接存放在 `std::function` 内部。
    
3. **堆分配 (Heap Allocation)：** 如果捕获列表很大（比如捕获了一个大数组），`std::function` 必须在堆上 `new` 内存来存放这个闭包。**这会引起内存碎片和分配延迟。**
    
4. **虚函数调用：** 调用 `std::function` 时，通过虚表跳转，无法内联。
    

**优化建议：** 如果场景极端敏感，且任务类型可预知，可以尝试手写无类型擦除的队列（极其复杂，通常不推荐），或者尽量保持 Lambda 捕获列表短小以命中 SBO。

---

## 第五章：高级设计模式 (Idioms)

### 5.1 IIFE (Immediately Invoked Function Expression)

用于复杂常量的初始化。

C++

```C++
// 你的 config 对象必须是 const，但初始化逻辑很复杂
const Config config = [&]() -> Config {
    Config c;
    if (env == "production") c.enable_log = false;
    else c.enable_log = true;
    // ... 50行初始化逻辑
    return c;
}(); // <--- 注意最后的 ()
```

### 5.2 Overloaded Pattern (访问者模式)

结合 `std::variant` 使用，替代传统的虚函数多态。

C++

```C++
template<class... Ts> struct overloaded : Ts... { using Ts::operator()...; };
template<class... Ts> overloaded(Ts...) -> overloaded<Ts...>;

std::variant<int, std::string, double> data = ...;

std::visit(overloaded {
    [](int) { std::cout << "Integer"; },
    [](const std::string& s) { std::cout << "String"; },
    [](double) { std::cout << "Double"; }
}, data);
```

这种写法比传统的 `switch-case` 或 继承多态 更快且更安全（编译器保证处理了所有类型）。

### 5.3 柯里化 (Currying)

虽然 C++ 不是函数式语言，但 Lambda 支持这种风格。

C++

```C++
auto add = [](int x) {
    return [x](int y) {
        return x + y;
    };
};

int result = add(5)(3); // 结果 8
```

这在配置一系列参数固定的中间件或过滤器时非常有用。

---

## 第六章：避坑指南

### 6.1 默认捕获的陷阱

Google C++ 规范明确禁止使用 [=] 或 [&] 进行全量捕获。

原因：

1. `[&]` 可能意外捕获局部临时变量，导致悬垂引用。
    
2. `[=]` 在类成员函数中，看似捕获了成员变量，实际捕获的是 `this` 指针！
    

C++

```C++
class MyClass {
    int x = 0;
    void bad() {
        auto lam = [=] { std::cout << x; }; 
        // 你以为拷贝了 x？不，它等价于 [this] { cout << this->x; }
        // 如果 MyClass 被销毁，lam 执行就会崩溃。
    }
};
```

### 6.2 滥用 mutable

`mutable` 使得 Lambda 内部有了状态，这破坏了“纯函数”的性质。如果在多线程环境下重用同一个带有 `mutable` 状态的 Lambda，必须加锁，否则会有数据竞争。

---

## 结语

C++ 的 Lambda 表达式通过 **编译器生成匿名类** 的方式，完美地平衡了 **抽象能力** 与 **运行时性能**。

- 对于**线程池**开发者：精通 `std::move` 捕获和 `std::function` 的开销是关键。
    
- 对于**库**开发者：精通泛型 Lambda 和模板 Lambda 是提供通用接口的关键。
    
- 对于**底层**开发者：理解其内存布局和内联机制是性能调优的关键。