#### C++输入和输出概述

多数计算机语言的输入和输出是以语言本身为基础实现的。例如，从诸如BASIC和Pascal等语言的关键字列表中可知，PRINT语句、Writeln语句以及其他类似的语句都是语言词汇表的组成部分，但C和C++都没有将输入和输出建立在语言中。这两种语言的关键字包括for和if，但不包括与I/O有关的内容。C语言最初把I/O留给了编译器实现人员。这样做的一个原因是为了让实现人员能够自由的设计I/O函数，使之最适合于目标计算机的硬件要求。实际上，多数实现人员都把I/O建立在最初为UNIX环境开发的库函数的基础之上。ANSI C正式承认这个I/O软件包时，将其称为标准输入/输出包，并将其作为标准C库不可或缺的组成部分。C++也认可这个软件包，因此如果熟悉stdio.h文件中声明的C函数系列，则可以在C++程序中使用它们（较新的实现使用头文件cstdio来支持这些函数）。

然而，C++依赖于C++的I/O解决方案，而不是C语言的I/O解决方案，前者是在头文件iostream（以前为iostream.h）和fstream（以前为fstream.h）中定义一组类。这个类库不是正式语言定义的组成部分（cin和istream不是关键字）；毕竟计算机语言定义了如何工作（例如如何创建类）的规则，但没有定义应按照这些规则创建哪些东西。然而，正如C实现自带了一个标准函数库一样，C++也自带了一个标准类库。首先，标准类库是一个非正式的标准，只是由头文件iostream和fstream中定义的类组成。ANSI/ISO C++委员会决定把这个类正式作为一个标准类库，并添加其他一些标准类，如第16章讨论的那些类。本章将讨论标准C++ I/O。但首先看一看C++ I/O的概念框架。
### 流和缓冲区

C++程序把输入和输出看作字节流。输入时，程序从输入流中抽取字节；输出时，程序将字节插入到输出流中。对于面向文本的程序，每个字节代表一个字符，更通俗地说，字节可以构成字符或数值数据的二进制表示。输入流中的字节可能来自键盘，也可能来自存储设备（如硬盘）或其他程序。同样，输出流中的字节可以流向屏幕、打印机、存储设备或其他程序。流充当了程序和流源或流目标之间的桥梁。这使得C++程序可以以相同的方式对待来自键盘的输入和来自文件的输入。C++程序只是检查字节流，而不需要知道字节来自何方。同理，通过使用流，C++程序处理输出的方式将独立于其去向。因此管理输入包含两步：

- 将流与输入去向的程序关联起来。
- 将流与文件连接起来。

换句话说，输入流需要两个连接，每端各一个。文件端部连接提供了流的来源，程序端连接将流的流出部分转储到程序中（文件端连接可以是文件，也可以是设备，如键盘）。同样，对输出的管理包括将输出流连接到程序以及将输出目标与流关联起来。这就像将字节（而不是水）引入到水管中（参见图17.1）。

![[Pasted image 20251120165007.png]]
通常，通过使用缓冲区可以更高效地处理输入和输出。缓冲区是用作中介的内存块，它是将信息从设备传输到程序或从程序传输给设备的临时存储工具。通常，像磁盘驱动器这样的设备以512字节（或更多）的块为单位来传输信息，而程序通常每次只能处理一个字节的信息。缓冲区帮助匹配这两种不同的信息传输速率。例如，假设程序要计算记录在硬盘文件中的金额。程序可以从文件中读取一个字符，处理它，再从文件中读取下一个字符，再处理，依此类推。从磁盘文件中每次读取一个字符需要大量的硬件活动，速度非常慢。缓冲方法则从磁盘上读取大量信息，将这些信息存储在缓冲区中，然后每次从缓冲区里读取一个字节。因为从内存中读取单个字节的速度比从硬盘上读取快很多，所以这种方法更快，也更方便。当然，到达缓冲区尾部后，程序将从磁盘上读取另一块数据。这种原理与水库在暴风雨中收集几兆加仑流量的水，然后以比较文明的速度给您家里供水是一样的（见图17.2）。输出时，程序首先填满缓冲区，然后把整块数据传输给硬盘，并清空缓冲区，以备下一批输出使用。这被称为刷新缓冲区（flushing the buffer）。
![[Pasted image 20251120165053.png]]
键盘输入每次提供一个字符，因此在这种情况下，程序无需缓冲区来帮助匹配不同的数据传输速率。然而，对键盘输入进行缓冲可以让用户在将输入传输给程序之前返回并更正。C++程序通常在用户按下回车键时刷新输入缓冲区。这是为什么本书的例子没有一开始就处理输入，而是等到用户按下回车键后再处理的原因。对于屏幕输出，C++程序通常在用户发送换行符时刷新输出缓冲区。程序也可能会在其他情况下刷新输入，例如输入即将到来时，这取决于实现。也就是说，当程序到达输入语句时，它将刷新输出缓冲区中当前所有的输出。与ANSI C一致的C++实现是这样工作的。
### 流、缓冲区和iostream文件

管理流和缓冲区的工作有点复杂，但iostream（以前为iostream.h）文件中包含一些专门设计用来实现、管理流和缓冲区的类。C++98版本C++ I/O定义了一些类模板，以支持char和wchar_t数据；C++11添加了char16_t和char32_t具体化。通过使用typedef工具，C++使得这些模板char具体化能够模仿传统的非模板I/O实现。下面是其中的一些类（见图17.3）：
![[Pasted image 20251120165625.png]]

- streambuf类为缓冲区提供了内存，并提供了用于填充缓冲区、访问缓冲区内容、刷新缓冲区和管理缓冲区内存的类方法；
- ios_base类表示流的一般特征，如是否可读取、是二进制流还是文本流等；
- ios类基于ios_base，其中包括了一个指向streambuf对象的指针成员；
- ostream类是从ios类派生而来的，提供了输出方法；
- istream类也是从ios类派生而来的，提供了输入方法；
- iostream类是基于istream和ostream类的，因此继承了输入方法和输出方法。
## 1. 类层次结构：成员里到底放了什么？

先看你平时用的 `std::cout`，它其实是：

```C++
extern std::ostream cout;
```

而 `std::ostream` 又是一个 typedef：

`using ostream = std::basic_ostream<char>;`

再往下传：

```C++
template <class CharT, class Traits = std::char_traits<CharT>>
class basic_ostream : virtual public basic_ios<CharT, Traits> {
    // 提供 operator<<、put、write、flush 等
};
```

`basic_ios` 又继承自 `ios_base`：
 ios_base类表示流的一般特征，如是否可读取、是二进制流还是文本流等；
```C++
class ios_base {
public:
    // ---- 状态 & 格式相关 ----
    using fmtflags = /* 位掩码类型 */;
    using iostate  = /* 位掩码类型 */;

    fmtflags flags_;     // 当前格式标志（进制、对齐等）
    iostate  state_;     // goodbit / failbit / badbit / eofbit
    iostate  except_;    // 哪些状态发生时抛异常

    std::locale loc_;    // 本地化信息（小数点、千分位、日期等）
    // 回调、存储空间（xalloc/pword/iword）等等
};

```

`basic_ios` 在此基础上加了两类关键东西：

1. **字符相关类型 & Traits**
    
2. **指向缓冲区的指针**
    

典型实现里大致是：

```C++
template <class CharT, class Traits>
class basic_ios : public ios_base {
public:
    using char_type   = CharT;
    using traits_type = Traits;
    using int_type    = typename traits_type::int_type;

protected:
    basic_streambuf<CharT, Traits>* rdbuf_;   // 真正干活的缓冲区
    iostate rdstate_;                         // 实际保存的状态
    basic_ostream<CharT, Traits>* tied_;      // tie() 绑定的输出流
};
```

#### `CharT` 是什么？

`CharT` = **character type（字符类型）**，决定这个流读写的基本单位是啥。

常见实例：

- `CharT = char`  
    对应 `std::basic_ios<char>`，typedef 成我们常用的 `std::ios / std::istream / std::ostream`  
    也就是窄字符流：`cin/cout`。
    
- `CharT = wchar_t`  
    对应宽字符流：`std::wios / std::wistream / std::wostream`  
    也就是 `wcin/wcout`，用于宽字符（UTF-16/UTF-32 取决平台）。
    
- 还有（C++20 起更正规地支持）：  
    `char8_t, char16_t, char32_t` 作为 `CharT`  
    但标准库对它们的完整流支持在不同实现中差异较大。
    

**一句话：** `CharT` 决定流里“一个字符”的物理类型。
你看到的状态查询、错误清除，最终都是对这些成员变量的读取/写入：
#### 2. `Traits` 是什么？

`Traits` = **character traits（字符特征/策略类）**。  
它告诉流：**怎么理解 CharT 这种字符**。

默认值是：

`Traits = std::char_traits<CharT>`

`std::char_traits` 里定义了一堆“字符相关的基础操作”，例如：

- `eq(a,b)`：两个字符是否相等
    
- `lt(a,b)`：字符大小比较
    
- `compare(s1,s2,n)`：比较两个字符序列
    
- `length(s)`：长度
    
- `find(s,n,ch)`：在序列里找字符
    
- **最重要的：EOF 相关处理**
    
    - `eof()`：返回一个特殊值表示 EOF
        
    - `not_eof(x)`：如果是 EOF 变成非 EOF
        
    - `to_int_type(ch)`：把 CharT 转成 int_type
        
    - `to_char_type(x)`：把 int_type 转回 CharT
        
    - `eq_int_type(x,y)`：比较两个 int_type 是否相等
        

你平时几乎不需要自定义 Traits，但标准留了这个口子让你能：

- 改变字符比较规则（比如大小写不敏感）
    
- 改变 EOF 表示/转换规则
    
- 对接某些特殊字符类型
#### 3. `int_type` 是什么？为什么不直接用 `int`？

`using int_type = typename traits_type::int_type;`

`int_type` 是 Traits 里定义的一种“扩展整数类型”，用来：

1. **能够容纳所有 CharT 的值**
    
2. **还能额外表示一个 EOF（结束/错误）状态**
    

原因：  
如果用 `CharT` 本身作为返回值，那就没法区分：

- “读到了一个合法字符”
    
- “读到了 EOF”
    

比如 `CharT=char` 时，char 可能是 `0~255`（unsigned）或 `-128~127`（signed），不一定有多余的空位来表示 EOF。

所以标准用一个更大的类型（通常是 int），并**保证 Traits::eof() 返回的值不与任何合法字符冲突**。

典型情形（实现相关但普遍如此）：

- 对 `char_traits<char>`：
    
    - `int_type` 通常= `int`
        
    - `eof()` 通常= `EOF`（也就是 `-1`）
        
    - `to_int_type(char c)` → 把 `unsigned char(c)` 提升到 int
        
- 对 `char_traits<wchar_t>`：
    
    - `int_type` 通常= `wint_t`
        
    - `wint_t` 也能表示 `WEOF`
        

**直接感受一下：**

```C++
int c = std::cin.get();  // get() 返回 int_type
if (c == std::char_traits<char>::eof()) {
    // 到 EOF 了
} else {
    char ch = std::char_traits<char>::to_char_type(c);
    // 正常字符
}
```
你会发现输入函数经常返回 `int_type`，正是为了让它既能返回字符，又能返回 EOF。
**一句话：** `int_type` 是“字符 + EOF” 的安全载体。
#### 1. `rdbuf_`：指向**真正干活的缓冲区对象**

`basic_streambuf<CharT, Traits>* rdbuf_;`

### 它是什么？

- 一个指针，指向某个 `basic_streambuf`（或其派生类）对象。
    
- **流本身不直接和设备交互**，所有字节的读写都通过 `rdbuf_` 完成。
    

### 为什么重要？

`istream/ostream` 的高层接口（`<<`, `>>`, `get`, `put`, `read`, `write`…）最终都会变成对

- `rdbuf_->sgetc()` / `sbumpc()` / `xsgetn()`（读）
    
- `rdbuf_->sputc()` / `xsputn()` / `pubsync()`（写）
    

这些函数的调用。

### 典型指向哪些东西？

- `std::cin` 的 `rdbuf_` → 绑定到 **stdin 对应的 streambuf**
    
- `std::cout` 的 `rdbuf_` → 绑定到 **stdout 对应的 streambuf**
    
- `std::ifstream` / `std::ofstream` 的 `rdbuf_` → 指向内部的 `std::filebuf`
    
- `std::stringstream` 的 `rdbuf_` → 指向内部的 `std::stringbuf`
    

### 你可以换它（重定向）

```C++
std::ofstream f("out.txt");
auto* old = std::cout.rdbuf(f.rdbuf());  // cout 改写到文件
std::cout << "goes to file\n";
std::cout.rdbuf(old);                   // 恢复
```

**直观理解：**

- `rdbuf_` 就是“流的插座”，换插座就换了设备。
    

---

## 2. `rdstate_`：流的**状态位集合（good/eof/fail/bad）**

`iostate rdstate_;`

### 它是什么？

- 一个位掩码（bitmask），记录当前流状态。
    
- 来自 `ios_base::iostate`，常见位是：
    

```C++
goodbit = 0
eofbit  = 1<<0   // 读到 EOF
failbit = 1<<1   // 格式/逻辑失败，比如 "abc" 读 int
badbit  = 1<<2   // 底层设备错误，比如 read/write 失败
```

`rdstate_` 可能同时包含多个位，比如 `eofbit | failbit`。

### 它什么时候被设置？

高层操作过程中一旦发生问题，就会调用 `setstate()`：

- **读到 EOF**：
    
    - `rdbuf_->underflow()` 返回 EOF  
        → `rdstate_ |= eofbit`
        
- **格式解析失败**（比如 `cin >> int` 遇到字母）：  
    → `rdstate_ |= failbit`
    
- **底层设备失败**（filebuf 的 read/write 出错）：  
    → `rdstate_ |= badbit`
    

### 它怎么影响程序？

你平时写的：

`if (!cin) { ... }`

就是在检查 `rdstate_`：

- `operator bool()` ≈ `!fail()`
    
- `fail()` ≈ `(rdstate_ & (failbit|badbit)) != 0`
    

并且可恢复：

`cin.clear();          // rdstate_ = goodbit cin.ignore(1024,'\n');`

### 和异常的关系

`ios_base` 里还有一个 `except_`（异常掩码）。  
如果你设置：

`cin.exceptions(std::ios::failbit | std::ios::badbit);`

那每次 `setstate()` 把这些位加进去时，会立刻抛 `ios_base::failure`。

**直观理解：**

- `rdstate_` 是“仪表盘告警灯”，告诉你流现在是否还健康。
    

---

## 3. `tied_`：`tie()` 绑定的**输出流指针**

`basic_ostream<CharT, Traits>* tied_;`

### 它是什么？

- 用来实现 **“输入前自动刷新某个输出流”** 的机制。
    
- 典型目的：保证提示信息先显示出来，再等用户输入。
    

### 默认是什么？

标准初始化时：

`std::cin.tie(&std::cout);`

所以默认：

- `std::cin.tied_ == &std::cout`
    

### 它什么时候起作用？

每次对一个输入流进行输入操作（`>>`, `get`, `getline`, `read`…）时，  
`istream::sentry` 构造器会做：

`if (is.tie() != nullptr)     is.tie()->flush();`

也就是：  
**读 `cin` 之前先 flush `cout`**。

### 你可以取消它（提升性能）

竞赛常见写法：

```C++
std::ios::sync_with_stdio(false);
std::cin.tie(nullptr);   // tied_ = nullptr
```

这样 `cin` 读之前就不会自动 flush `cout` 了，少很多无谓刷新。

举例感受区别：

```C++
cout << "input x: ";   // 可能还在缓冲里
cin >> x;              // 如果 tie 还在，会先 flush cout
```

若 `tie(nullptr)` 了，可能出现提示没显示就等输入（尤其输出没换行时）。

**直观理解：**

- `tied_` 就是“输入流的自动刷新伙伴”。
-----
```C++
bool good() const { return rdstate_ == goodbit; }
bool fail() const { return (rdstate_ & (failbit | badbit)) != 0; }
void clear(iostate state = goodbit) { rdstate_ = state; }
```

**要点**：

- `ios_base`：保存**所有流共有的“控制位”**（格式、状态、本地化）。
    
- `basic_ios`：加上**字符类型 + 缓冲区指针 + tie逻辑**。
    
- `basic_istream/ostream`：在 `rdbuf_` 基础上提供高层的 `<<` / `>>` / `get` / `put` 等操作。
    

---

## 2. `streambuf` 的内存布局和虚函数调用链

`basic_streambuf<CharT, Traits>` 是 I/O 的核心，是一个抽象基类。  
它大致有这些成员（简化示意）：

```C++
template <class CharT, class Traits>
class basic_streambuf {
public:
    using char_type = CharT;
    using int_type  = typename Traits::int_type;

protected:
    // 输入区域（get area）
    char_type* eback_;  // 缓冲区起始
    char_type* gptr_;   // 当前读指针
    char_type* egptr_;  // 缓冲区末尾

    // 输出区域（put area）
    char_type* pbase_;  // 缓冲区起始
    char_type* pptr_;   // 当前写指针
    char_type* epptr_;  // 缓冲区末尾
};
```

可以想成两块独立的 buffer：

```txt
输入 get area:         输出 put area:

eback_          egptr_ pbase_           epptr_
  |--------------|       |---------------|
        ^
       gptr_             ^
                         pptr_

```

### 2.1 从 `istream::operator>>` 调用链看读流程

以 `int x; std::cin >> x;` 为例：

1. `operator>>(int&)` 调用 `num_get` facet（locale 里的一个“数字解析器”）。
    
2. `num_get` 需要读一个字符，就调用 `istream::sentry` 和底层的 `rdbuf()->sbumpc()` / `sgetc()`。
    
3. `sbumpc()` 的逻辑大致是：
    
```C++
    int_type sbumpc() {
    if (gptr_ < egptr_)          // 缓冲区里还有数据
        return Traits::to_int_type(*gptr_++);  // 直接返回并前移指针
    else
        return uflow();          // 调用虚函数，从设备读新数据
}
```
    
4. `uflow()` 通常默认实现为：
    
```C++
    int_type uflow() {
    int_type ch = underflow();   // 向缓冲区里读新数据
    if (!Traits::eq_int_type(ch, Traits::eof())) {
        ++gptr_;
    }
    return ch;
}
```
    
5. `underflow()` 是**真正与设备交互**的虚函数：
    
    - 对 `filebuf`：会调用 `read(fd, buffer, bufsize)` 把数据从文件读进缓冲区，然后设置 `eback_ / gptr_ / egptr_`。
        
    - 对 `stringbuf`：直接从内部 `std::string` 里拷数据。
        

**一旦 `underflow()` 返回 EOF**，上面这整条调用链会发现 EOF，并触发 `eofbit` / `failbit`。

### 2.2 写流程：`ostream::operator<<` → `overflow`

类似地，`std::cout << "hello";` 最终会变成对 `rdbuf()->sputn("hello", 5);` 的调用。

`sputn` 简化逻辑：

```C++
std::streamsize sputn(const char_type* s, std::streamsize n) {
    // 尝试先写到当前缓冲区（put area）
    std::streamsize written = 0;
    while (written < n) {
        if (pptr_ == epptr_) {          // 写满了，触发 overflow
            if (Traits::eq_int_type(overflow(Traits::eof()), Traits::eof()))
                break;                  // 设备出错
        }
        *pptr_++ = s[written++];
    }
    return written;
}
```

`overflow` 由具体设备的 `streambuf` 重写，例如：

- `filebuf::overflow`：调用 `write(fd, pbase_, pptr_ - pbase_)` 把当前缓冲区写到文件，然后清空缓冲区；若 `ch != EOF`，再把新字符写入缓冲区。
    
- `stringbuf::overflow`：直接把字符 append 到内部 `std::string`。
    

**flush 的本质**：强制调用 `rdbuf()->pubsync()` → `streambuf::sync()` → 触发 `overflow`/`fflush`/`fsync` 等。

---

## 3. 格式化是如何被拆分到“facet”里的？

C++ 为了支持本地化，把“数值 ↔ 文本”的转换拆给了一些“facet”（局部功能组件）：

- `std::num_put`：负责把 `int/double` 按当前 locale 和 `fmtflags` 转成字符序列；
    
- `std::num_get`：负责从字符序列解析数值，写入变量。
    

`operator<<(int)` 大致干的事是：

```C++
std::ostream& operator<<(std::ostream& os, int val) {
    // 1. 创建 sentry 对象，做一些准备（如 flush tie() 的流）
    std::ostream::sentry s(os);
    if (s) {
        // 2. 调用 locale 的 num_put facet，进行格式化
        std::use_facet<std::num_put<char>>(os.getloc()).put(
            std::ostreambuf_iterator<char>(os),   // 迭代器包装 rdbuf
            os, os.fill(), val
        );
    }
    return os;
}
```

重点：

- 真正做数字转字符串的是 `num_put`；
    
- `num_put` 会根据 `os.flags()` 的内容判断是 `dec/hex/oct`、是否带符号、对齐宽度等；
    
- 它通过一个 `ostreambuf_iterator<char>` 一次一个字符写进 `rdbuf()`，间接触发 `overflow()`。
    

类似地，`operator>>(int)` 会用 `num_get`，逻辑对称。

---

## 4. 状态位 & 异常：到底什么时候设置什么位？

### 4.1 常见状态

```C++
std::ios_base::iostate rdstate_;
enum iostate {
    goodbit = 0,
    eofbit  = 1 << 0,
    failbit = 1 << 1,
    badbit  = 1 << 2
};

```

- `goodbit`：`rdstate_ == 0`，一切 OK。
    
- `eofbit`：读操作遇到 EOF（例如 `underflow()` 返回 EOF）。
    
- `failbit`：**逻辑错误**，如想读 `int` 却遇到 `"abc"`，或没读到任何数字就结束。
    
- `badbit`：**物理错误**，如硬盘错误、系统调用失败、缓冲区内部状态损坏。
    

### 4.2 典型读取流程中的状态更新（伪代码）

```C++
std::istream& operator>>(std::istream& is, int& x) {
    std::istream::sentry s(is);
    if (!s) { is.setstate(std::ios::failbit); return is; }

    bool ok = parse_int_from_streambuf(is.rdbuf(), x);
    if (!ok) {
        is.setstate(std::ios::failbit);
    }
    return is;
}
```

再比如读取到 EOF：

```C++
int ch = is.rdbuf()->sbumpc();
if (Traits::eq_int_type(ch, Traits::eof())) {
    is.setstate(std::ios::eofbit | std::ios::failbit);
}

```

**异常掩码**：决定遇到这些状态时是否抛异常：

`is.exceptions(std::ios::failbit | std::ios::badbit);`

之后如果 `setstate()` 时，这些位发生了，`basic_ios` 内部会 `throw std::ios_base::failure`。

---

## 5. 标准流 `cout/cin/cerr` 是怎么初始化的？

标准里规定：

- 存在一个 `std::ios_base::Init` 类；
    
- 定义了一个静态的 `Init` 对象，构造函数里会初始化 `cin/cout/cerr/clog`。
    

大致这么个模式（简化）：

```C++
namespace std {
    ios_base::Init __io_init;  // 全局静态对象

    ios_base::Init::Init() {
        // 构造时：
        // 1. 构造 cout/cin/cerr/clog 的 streambuf（通常包装 stdin/stdout/stderr 的 FILE*）
        // 2. 把这些 streambuf 绑定到对应的 istream/ostream 对象上
        // 3. 设置 tie：cin.tie(&cout);
    }

    ios_base::Init::~Init() {
        // 程序结束前，析构时确保 flush 所有缓冲区
    }
}

```

这就是为什么：**你甚至可以在 `main` 之前使用 `std::cout`，也能工作**——因为全局初始化先于 `main`。

---

## 6. `sync_with_stdio` 背后发生了什么？

多数实现会在同步状态下，让 C++ 的 `streambuf` 直接用 C 的 `FILE*` 进行读写。

典型模式是：

```C++
// 初始时
std::ios_base::sync_with_stdio(true);

// libstdc++ 中，会创建一种叫 __gnu_cxx::stdio_sync_filebuf 的东西
// 它是 basic_streambuf 的子类，内部持有一个 FILE*
```

当你调用：

`std::ios::sync_with_stdio(false);`

做的事情是类似：

- 把 `std::cout` 的 `rdbuf()` 换成一个“纯 C++ 的 filebuf”，直接基于文件描述符工作，不再通过 `FILE* stdout`；
    
- 取消掉一些为了与 `printf` 排序正确而做的同步逻辑。
    

这样做的后果：

- 性能提升（少了一层 `FILE*` 的锁和缓冲）；
    
- 但**不再保证** `printf` 和 `cout` 的输出顺序按你写代码的顺序出现。
    

---

## 7. 文件流 `filebuf` / `fstream` 的底层

`std::ifstream` 实际上是：

```C++
class ifstream : public std::basic_istream<char> {
    std::filebuf buf_;  // 真正工作的 filebuf
};
```

构造时：

```C++
ifstream::ifstream(const char* filename, ios_base::openmode mode) {
    // 1. buf_.open(filename, mode);   // 打开文件、创建 fd
    // 2. this->init(&buf_);           // basic_ios::init(rdbuf指针)
}
```

`filebuf` 内部一般包含：

- 一个 `int fd;` 或者 `FILE* fp;`
    
- 一个自管的缓冲区 `char buffer[BUFSIZE]`；
    
- 重写了 `underflow`/`overflow`/`seekoff`/`seekpos` 等虚函数：
    

```C++
int_type filebuf::underflow() {
    if (gptr_ < egptr_) return Traits::to_int_type(*gptr_);

    // 缓冲区空了，从 fd 读
    ssize_t n = ::read(fd, buffer, BUFSIZE);
    if (n <= 0) return Traits::eof();

    eback_ = buffer;
    gptr_  = buffer;
    egptr_ = buffer + n;

    return Traits::to_int_type(*gptr_);
}
```

二进制 vs 文本模式：

- `std::ios::binary` 决定 `open` 时是否带 `O_BINARY` 标志（Windows 下区别明显）。
    
- 文本模式下可能会对 `\n` 做转换（`\r\n` ↔ `\n`）。
    

---

## 8. 字符串流：`stringbuf` 的内部结构

`std::stringstream` 是：

```C++
class stringstream : public std::basic_iostream<char> {
    std::stringbuf buf_;
};
```

`stringbuf` 比较简单：

- 内部持有一个 `std::string str_;`
    
- `underflow` 时：如果 `gptr_ == egptr_`，就看 `str_` 里还有没有数据可以拷到缓冲区（很多实现甚至直接把 get area 指向 `str_.data()`）；
    
- `overflow` 时：直接在 `str_` 上 append 新字符。
    

`stringstream` 的 `str()` 接口：

```C++
std::stringstream ss;
ss << 123 << " abc";
std::string s = ss.str();  // 把当前内部字符串拿出来
```

本质上是把“文件”换成了“内存字符串”，其他层几乎完全一致。

---

## 9. 线程安全、`cout` 混用等细节

### 9.1 标准对 thread-safety 的基本保证

C++11 起标准大致要求：

- **对同一个流对象同时从多个线程读写是存在数据竞争的**（行为未定义），因为内部状态（缓冲区指针、状态位）会被并发修改；
    
- 库通常会对单次 I/O 函数调用内部加锁，保证不把它自己的内部结构搞坏，但**不同线程的输出可能交织**（如字符顺序交错）。
    

所以你会看到：

```C++
std::cout << "thread1" << std::endl;
// 和
std::cout << "thread2" << std::endl;
```

在两个线程中交替输出时可能变成：`thtreaadr e1d2` 这种乱序。  
要么你自己加锁，要么使用 `std::ostringstream` 在线程内组好一整行，再一次性 `cout << oss.str();`。

### 9.2 为什么说 “`cout` 线程不安全”？

从严格意义讲：

- 没锁保护+共享同一个 `ostream`，就有数据竞争风险；
    
- 就算一些实现加了内部锁，也只保证不会崩溃，不保证输出语义（不保证“每次输出是一整段原子文本”）。
    

工程实践：  
**多线程下，推荐：**

- 每个线程写自己的 `ostringstream`；
    
- 最后在某个“日志线程”里统一拼接输出，或统一写文件。
    

---

## 10. 一个小例子：自定义 `streambuf` 实现“计数 logger”

做一个玩具：所有写到这个流的字符，既写到 `std::cout`，又统计总字节数。

```C++
#include <iostream>
#include <streambuf>

class counting_buf : public std::streambuf {
public:
    counting_buf(std::streambuf* dest)
        : dest_(dest), count_(0) {}

    std::size_t count() const { return count_; }

protected:
    // 重写 overflow，用于单字符写入
    int_type overflow(int_type ch) override {
        if (traits_type::eq_int_type(ch, traits_type::eof()))
            return dest_->sputc(ch);  // 把 EOF 传下去

        ++count_;                     // 统计字符数
        return dest_->sputc(ch);      // 真正写到目标 streambuf（比如 cout 的 rdbuf）
    }

    // 重写 xsputn，用于批量写入
    std::streamsize xsputn(const char_type* s, std::streamsize n) override {
        count_ += n;
        return dest_->sputn(s, n);
    }

private:
    std::streambuf* dest_;
    std::size_t count_;
};

int main() {
    counting_buf cbuf(std::cout.rdbuf()); // 包装 cout 的缓冲区
    std::ostream out(&cbuf);

    out << "Hello, world!\n";
    out << 123 << '\n';

    std::cout << "Total chars written: " << cbuf.count() << '\n';
}
```

这里你可以明显看到三层关系：

1. `out` 是一个 `ostream`，负责格式化（`"Hello, world!"`、`123`）；
    
2. `out` 的 `rdbuf()` 是我们自定义的 `counting_buf`，负责统计和转发；
    
3. `counting_buf` 内部再把数据转发给 `std::cout` 的 `rdbuf()`，后者再写到终端。
    

---

## 11. 小结：从上到下再串一次

- **接口层**：  
    `istream/ostream` 提供 `<<` / `>>`，内部通过 `sentry` + `facet`（`num_get/num_put`）完成“对象 ↔ 文本”的转换，状态用 `iostate` 管，格式用 `fmtflags` 管。
    
- **缓冲层**：  
    `basic_streambuf` 用 get/put 两块缓冲区管理数据，`underflow/overflow/sync` 是与设备交互的核心虚函数，`filebuf/stringbuf` 等具体派生类分别对接文件、内存等。
    
- **系统层**：  
    `filebuf` 的 `underflow/overflow` 里最终会调用系统调用 `read/write` 或 C 的 `fread/fwrite`，系统再通过内核缓冲、页缓存把数据写入磁盘或终端。
    

---
- unsigned char；
- signed char；
- char；
- short；
- unsigned short；
- int；
- unsiged int；
- long；
- unsigned long；
- long long（C++11）；
- unsigned long long（C++11）；
- float；
- double；
- long double。

对于上述每种数据类型，ostream类都提供了operator<<( )函数的定义

可以使用width成员函数将长度不同的数字放到宽度相同的字段中，该方法的原型为：

int width()
int width(int i)

第一种格式返回字段宽度的当前设置；第二种格式将字段宽度设置为i个空格，并返回以前的字段宽度值。这使得能够保存以前的值，以便以后恢复宽度值时使用。

width( )方法只影响将显示的下一个项目，然后字段宽度将恢复为默认值。例如，请看下面的语句：
#### 填充字符

在默认情况下，cout用空格填充字段中未被使用的部分，可以用fill( )成员函数来改变填充字符。例如，下面的函数调用将填充字符改为星号：

cout.fill('*')

这对于检查打印结果，防止接收方添加数字很有用。程序清单17.5演示了该成员函数的用法。
例子：
![[Pasted image 20251120191930.png]]
注意，与字段宽度不同的是，新的填充字符将一直有效，直到更改它为止。
#### 设置浮点数的显示精度

浮点数精度的含义取决于输出模式。在默认模式下，它指的是显示的总位数。在定点模式和科学模式下（稍后将讨论），精度指的是小数点后面的位数。已经知道，C++的默认精度为6位（但末尾的0将不显示）。precision( )成员函数使得能够选择其他值。例如，下面语句将cout的精度设置为2：

cout.precision(2)；

和width( )的情况不同，但与fill( )类似，新的精度设置将一直有效，直到被重新设置。程序清单17.6准确地说明了这一点。
#### 打印末尾的0和小数点

对于有些输出（如价格或栏中的数字），保留末尾的0将更为美观。例如，对于程序清单17.6的输出，$20.40将比$20.4更美观。iostream系列类没有提供专门用于完成这项任务的函数，但ios_base类提供了一个setf( )函数（用于set标记），能够控制多种格式化特性。这个类还定义了多个常量，可用作该函数的参数。例如，下面的函数调用使cout显示末尾小数点：

cout.self(ios_base::showpoint);

使用默认的浮点格式时，上述语句还将导致末尾的0被显示出来。也就是说，如果使用默认精度（6位）时，cout不会将2.00显示为2，而是将它显示为2.000000。
![[Pasted image 20251120194435.png]]
![[Pasted image 20251120195928.png]]
#### 头文件iomanip

使用iostream工具来设置一些格式值（如字段宽度）不太方便。为简化工作，C++在头文件iomanip中提供了其他一些控制符，它们能够提供前面讨论过的服务，但表示起来更方便。3个最常用的控制符分别是setprecision( )、setfill( )和setw( )，它们分别用来设置精度、填充字符和字段宽度。与前面讨论的控制符不同的是，这3个控制符带参数。setprecision( )控制符接受一个指定精度的整数参数；setfill( ) 控制符接受一个指定填充字符的char参数；setw( )控制符接受一个指定字段宽度的整数参数。由于它们都是控制符，因此可以用cout语句连接起来。这样，setw( )控制符在显示多列值时尤其方便。
![[Pasted image 20251120200749.png]]
![[Pasted image 20251120200807.png]]
## 使用cin进行输入

现在来介绍输入，即如何给程序提供数据。cin对象将标准输入表示为字节流。通常情况下，通过键盘来生成这种字符流。如果键入字符序列2011，cin对象将从输入流中抽取这几个字符。输入可以是字符串的一部分、int值、float值，也可以是其他类型。因此，抽取还涉及了类型转换。cin对象根据接收值的变量的类型，使用其方法将字符序列转换为所需的类型。

通常，可以这样使用cin：

	cin>>value_holder

其中，value_holder为存储输入的内存单元，它可以是变量、引用、被解除引用的指针，也可以是类或结构的成员。cin解释输入的方式取决于value_holder的数据类型。istream类（在iostream头文件中定义）重载了抽取运算符>>，使之能够识别下面这些基本类型：

- signed char &；
- unsigned char &；
- char &；
- short &；
- unsigned short &；
- int &；
- unsigned int &；
- long &；
- unsigned long &；
- long long &（C++11）；
- unsigned long long &（C++11）；
- float &；
- double &；
- long double &。

这些运算符函数被称为格式化输入函数（formatted input functions），因为它们可以将输入数据转换为目标指定的格式。
###  cin>>如何检查输入

不同版本的抽取运算符查看输入流的方法是相同的。它们跳过空白（空格、换行符和制表符），直到遇到非空白字符。即使对于单字符模式（参数类型为char、unsigned char或signed char），情况也是如此，但对于C语言的字符输入函数，情况并非如此（参见图17.5）。在单字符模式下，>>运算符将读取该字符，将它放置到指定的位置。在其他模式下，>>运算符将读取一个指定类型的数据。也就是说，它读取从非空白字符开始，到与目标类型不匹配的第一个字符之间的全部内容。
![[Pasted image 20251120203311.png]]
![[Pasted image 20251120204436.png]]
#### 设置状态

表17.4中的两种方法——clear( )和setstate( )很相似。它们都重置状态，但采取的方式不同。clear( )方法将状态设置为它的参数。因此，下面的调用将使用默认参数0，这将清除全部3个状态位（eofbit、badbit和failbit）：

clearI()

同样，下面的调用将状态设置为eofbit；也就是说，eofbit将被设置，另外两个状态位被清除：

clear(eofbit)

而setstate( )方法只影响其参数中已设置的位。因此，下面的调用将设置eofbit，而不会影响其他位：
setstate(eofbit)

因此，如果failbit被设置，则仍将被设置。

为什么需要重新设置流状态呢？对于程序员来说，最常见的理由是，在输入不匹配或到达文件尾时，需要使用不带参数的clear( )重新打开输入。这样做是否有意义，取决于程序要执行的任务。稍后将介绍一些例子。setstate( )的主要用途是为输入和输出函数提供一种修改状态的途径。例如，如果num是一个int，则下面的调用将可能导致operator >> (int &)使用setstate( )设置failbit或eofbit：

cin>>num      //read an int



#### cin.ignore函数
## 最经典用法：清掉 `>>` 后的换行

`cin >> x` 读完数字后，**换行符 `'\n'` 还留在缓冲里**，  
直接 `getline` 会读到一个空行。

```C++
int x;
cin >> x;
cin.ignore();  // 丢掉一个字符，通常就是 '\n'

string line;
getline(cin, line);

```

---

## 3. 更稳妥：清掉整行剩余内容

如果你不确定后面还有多少垃圾（比如输入 `123 abc`），用下面这个“万能清行”：

```C++
cin.ignore(numeric_limits<streamsize>::max(), '\n');
```

意思是：  
丢弃**最多非常多**个字符，直到遇到换行 `'\n'` 为止（并把它也丢掉）。

常见场景：

```C++
int x;
cin >> x;
cin.ignore(numeric_limits<streamsize>::max(), '\n'); // 清到行末

string line;
getline(cin, line);  // 现在能正常读下一整行

```

---

## 4. 处理非法输入后的恢复（搭配 clear）

当输入类型不匹配时，流会 fail，需要先 `clear()` 再 `ignore()`：

```C++
int x;
while (true) {
    if (cin >> x) break;

    cin.clear();  // 清除 failbit
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); // 扔掉本行垃圾
    cout << "请输入整数：";
}

```

---

## 5. `ignore(n, delim)` 的小例子

```C++
// 输入：abc,123
cin.ignore(3, ',');  // 最多丢 3 个，或遇到 ',' 停
// 会丢掉 "abc"（没遇到 ',' 也会在 n=3 停）

```

```C++
// 输入：abc,123
cin.ignore(100, ',');  
// 丢到 ',' 为止，并把 ',' 也丢了
// 下一次读取从 '1' 开始
```

---

## 6. 注意点 / 坑

1. **只 ignore 1 个字符不一定够**  
    如果缓冲里不是只有 `'\n'`，比如 `123 abc\n`，  
    `cin.ignore()` 只丢一个空格，`getline` 仍会读到 `abc`。  
    → 用“清行版”更稳。
    
2. `ignore` 是**非格式化输入**，不会跳空白  
    它就是按字节往前扔。
    
3. 如果流已经 `eof()` 或 `bad()`，`ignore` 不会神奇修复  
    需要先看状态。

## 1) `cin >> x`（格式化输入）

特点：

- 默认跳过空白（`skipws`），读一个“类型值”
    
- 适合按空格分隔的数字/单词
    
- 容易和 `getline` 混用出坑（因为残留 `'\n'`）
    

用法：

`int x; string s; cin >> x >> s;   // 读整数和一个单词`

---

## 2) `cin.get()`（逐字符，**不跳过空白**）

特点：

- 每次读一个原始字符（包括空格、换行）
    
- 适合你要自己做词法/状态机解析时
    

```C++
char c; 
while (cin.get(c)) {     // c 是原样字符
 }
```

注意：`get()` 是非格式化输入，**不会自动跳过空白**。

---

## 3) `std::getline(cin, line)`（读一整行）

特点：

- 读到换行符为止（换行符被丢弃）
    
- 适合“按行处理”的文本
    

```C++
string line; 
getline(cin, line);
```

和 `>>` 混用时，记得先吃掉残留换行：

```C++
int x;
cin >> x;
cin.ignore(numeric_limits<streamsize>::max(), '\n');
string line;
getline(cin, line);
```

---

## 4) **想要“快”**：先给 iostream 提速

如果你用 `cin/cout`，先写这两行，速度可提升一个量级：

```C++
ios::sync_with_stdio(false); 
cin.tie(nullptr);
```

解释：

- 关闭 C/Cpp 流同步，减少锁和 flush
    
- 解除 `cin` 对 `cout` 的自动刷新绑定
    

这对大量输入特别明显。

---

## 5) 更高效的读法（大数据 / 竞赛）

### 5.1 一口气读完：`istreambuf_iterator`

优点：简单、够快，适合读整个文件/标准输入。

```C++
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string data((istreambuf_iterator<char>(cin)),
                 istreambuf_iterator<char>());
    // data 里是全部内容
}

```

底层等价于直接从 `streambuf` 读，少了逐次解析开销。

### 5.2 读一块原始字节：`cin.read`

适合二进制或“你自己解析格式”的情况：

```C++
char buf[1<<16];
cin.read(buf, sizeof(buf));
streamsize n = cin.gcount();  // 实际读到多少字节
```

### 5.3 直接走 C I/O：`scanf/fread`

在极限性能场景仍然最快/最稳定之一：

```C++
int x;
scanf("%d", &x);
```

或：

```C++
static char buf[1<<20];
size_t n = fread(buf, 1, sizeof(buf), stdin);
```

---

## 6) 怎么选（给你口袋里的决策）

- **读整数/单词，按空格分隔**：`cin >>` + 提速两行
    
- **按行读**：`getline`（混用前先 `ignore`）
    
- **逐字符、空白也有意义**：`get` 或 `noskipws`
    
- **输入特别大、要自己解析**：`istreambuf_iterator` / `read` / `fread`
    

---

## 7) 小提示：性能瓶颈在哪

- `operator>>` 慢，主要慢在：跳空白 + locale/格式解析 + 类型转换
    
- `getline/get/read` 更接近“裸读”，快在：少解析、直接走 `streambuf`
    
- 终极提速要点：**减少解析次数 + 批量读 + 自己解析**


-----
## 1) `ios::sync_with_stdio(false);` 的副作用

它做的事是：**关闭 C++ iostream 与 C stdio（printf/scanf/fread…）的同步**。  
同步一关，两个体系各自缓冲、各自推进文件指针，所以：

### ① 不能再“安全混用” `printf/scanf` 和 `cin/cout`

典型表现：

- 输出顺序错乱（因为缓冲分离）
    
- 读入行为怪异（因为文件指针/缓冲不同步）
    

例子：

```C++
ios::sync_with_stdio(false);

cout << "A";
printf("B");
cout << "C\n";
```

你可能以为一定是 `ABC`，但实际可能变成 `BAC`、`ACB` 等（取决于缓冲何时刷新）。

更危险的是输入混用：

```C++
ios::sync_with_stdio(false);

int x;
scanf("%d", &x);
string s;
cin >> s;   // 这里可能读不到你以为的内容
```

因为 `scanf` 和 `cin` 在不同缓冲区上推进，同步关闭后它们互相“看不见对方吃掉了什么”。

**结论：关了 sync 后，尽量别再用 printf/scanf/fgets/fread 和 cin/cout混着来。  
要么全用 iostream，要么全用 stdio。**

### ② 和 `stderr`/`cerr` 交错输出也不再有顺序保证

尤其是你用 `fprintf(stderr, ...)` + `cout` 混着打印调试时，顺序可能变得更随机。

---

## 2) `cin.tie(nullptr);` 的副作用

默认情况下 `cin` 是 **tie 到 `cout` 的**：  
每次你 `cin >> ...` 之前，`cout` 会自动 flush 一次，保证提示信息先出现。

解开 tie 之后：

### ① 交互式/命令行程序里提示可能不显示

比如：

```C++
cin.tie(nullptr);

int x;
cout << "Enter x: ";  // 可能还在缓冲里没刷出
cin >> x;            // 程序已经在等输入，但你看不到提示
```
**解决：手动 flush**

`cout << "Enter x: " << flush; cin >> x;`

或用 `endl`（但 `endl` 会强制 flush，慢一些）。

### ② 依赖“自动刷新顺序”的代码输出时序会变

一般批处理/离线评测无影响；**交互题、REPL、在线服务的 prompt** 会受到影响。

---

## 3) 会不会影响正确性/线程安全？

- 对**纯 iostream 的离线程序**：几乎没负面影响，通常是推荐提速手段。
    
- 对**多线程**：不会让 iostream 变得“不线程安全”，但**printf/cout 跨线程混用的输出顺序更不可控**（本来就不该依赖顺序）。
    

---

## 一句话总结

- `sync_with_stdio(false)`：**别再混用 C stdio 和 C++ iostream**，否则读写顺序可能乱、输入可能诡异。
    
- `cin.tie(nullptr)`：**交互式场景要手动 flush 提示**，否则用户看不到 prompt。

------
#### 手动flush
## 1) 用操纵符 `std::flush`

最推荐、最直白：

```C++
#include <iostream>
using namespace std;

cout << "Enter x: " << flush;  // 立刻刷新 cout
int x;
cin >> x;

```

`std::flush` **不输出任何字符**，只做刷新。

---

## 2) 用 `std::endl`

`endl` = 输出一个换行 + flush：

```C++
cout << "Processing..." << endl;  // 换行并刷新
```

注意：`endl` 会频繁 flush，**循环里大量用会变慢**，如果只想换行用 `'\n'`：

```C++
cout << "Processing...\n";  // 仅换行，不强制 flush
```

---

## 3) 调成员函数 `.flush()`

对任意输出流都能用：

```C++
cout << "Enter x: "; 
cout.flush();               // 手动刷新 cin >> x;
```

文件流也一样：

```C++
cout << "Enter x: ";
cout.flush();               // 手动刷新
cin >> x;
```

---

## 额外小技巧

### A) 让流每次输出都自动 flush：`std::unitbuf`

适合交互式调试（别在性能敏感代码里常开）：

```C++
cout << unitbuf;   // 开启自动刷新 
cout << "A";       // 每次输出都刷 
cout << nounitbuf; // 关闭自动刷新
```

### B) `std::cerr` 默认不缓冲

所以输出调试信息往往不用 flush：

`cerr << "error!" ; // 通常立即显示`

---

## 如果你还在用 C 的 stdio

手动 flush 是：

`printf("Enter x: "); fflush(stdout);`

⚠️ 但如果你已经 `ios::sync_with_stdio(false);` 了，就别混用 `printf` 和 `cout`，否则顺序可能乱。

---

### 最常用的交互式模板

（你前面提到 `cin.tie(nullptr)` 后提示可能不显示）

```C++
ios::sync_with_stdio(false); 
cin.tie(nullptr);  
cout << "Enter x: " << flush;  // 关键！ 
int x; 
cin >> x;
```
