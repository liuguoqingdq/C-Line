## 1. 阻塞式 `future.get()` 有什么问题？

标准库的 `std::future` 只有这几招：

- `f.get()`：阻塞直到 ready；
    
- `f.wait()` / `wait_for()` / `wait_until()`：阻塞等待 ready；
    
- 没有 continuation，没有组合运算。
    

典型写法：

```C++
auto f1 = pool.submit(task1); // 返回 std::future<int>
auto f2 = pool.submit(task2); // 返回 std::future<int>

// 阻塞等待
int x = f1.get();
int y = f2.get();

int z = x + y;
```

问题：

1. **调用方线程被阻塞**：
    
    - 当前线程啥也干不了，只能等；
        
    - 如果你在一个线程池里这样写，很容易把 worker 都堵死。
        
2. **组合性不好**：
    
    - 想表达“f1 完成后再继续算 f2”只能写成：
        
        ```C++
        auto f1 = pool.submit(...);
		int x = f1.get();          // 阻塞
		auto f2 = pool.submit(...);
		int y = f2.get();
        ```
        
    - 调度逻辑分散、难以重用。
        
3. **不适合事件驱动 / 单线程事件循环**：
    
    - 例如你在某个 event loop 线程里，不能随便 `get()`，否则整个 loop 死锁。
        

continuation 风格就是要把这句话：

> “等 f1 完成以后，再做 X”

从**“阻塞等待 + 手写 get”**，变成 **“声明式地挂一个后继任务”**。

---

## 2. 什么是 continuation？和回调有什么关系？

抽象一点说：

> **一个“continuation”就是“当某个异步操作完成后要执行的那段逻辑”。**

在普通回调模型里，这叫 callback：

```C++
doAsync([&](Result r){
    // 这段代码就是 continuation
});
```

在 future 模型里，continuation 通常写成：

```C++
auto fut2 = fut1.then([](Result r) {
    // 这段 lambda 就是 fut1 完成后的 continuation
    return process(r);
});
```

和“裸回调”的区别：

- **回调**：你直接把 lambda/函数指针丢给 API，API 内部决定什么时候调用。
    
- **continuation + future**：
    
    - 你拿到一个表示“未来结果”的 `future`；
        
    - 在它上面挂 `.then()`；
        
    - `.then()` 返回另一个 `future`，表示“continuation 执行完成的结果”。
        

也就是说，**continuation 的结果本身也是 future**，可以继续链下去：

```C++
auto f3 =
    f1.then([](int x) { return x * 2; })
      .then([](int y) { return std::to_string(y); })
      .then([](std::string s) { log(s); });
```

这就是你看到的“任务链”。

---

## 3. continuation 风格 `then()` 的基本语义

一个典型库（比如 folly / Boost 自己的 future 实现）里的 `then` 大概是这样的：

```C++
template <class F>
Future<U> Future<T>::then(F&& func);
```

行为可以拆成两点：

1. **注册 continuation**  
    把 `func` 挂在当前 `Future<T>` 的 shared state 上；
    
2. **当这个 future ready 时**
    
    - 从 shared state 取出结果（或异常）；
        
    - 在某个线程/执行器上调用 `func(result)`；
        
    - 得到一个返回值/异常；
        
    - 用它来 fulfill 一个新的 `Future<U>`，并把这个新 future 返回给调用者。
        

伪代码逻辑大概是：

```C++
auto Future<T>::then(F&& func) -> Future<U> {
    Promise<U> p;
    Future<U> fu = p.getFuture();

    // 把这个 continuation 注册到当前 future 的 shared state 上
    this->shared_state->add_continuation(
        [p = std::move(p), func = std::forward<F>(func)](Try<T> t) mutable {
            try {
                if (t.hasException()) {
                    // 把异常传下去，或者交给 func 自己处理也行
                    p.setException(t.exception());
                } else {
                    U u = func(t.value());
                    p.setValue(std::move(u));
                }
            } catch (...) {
                p.setException(std::current_exception());
            }
        }
    );

    return fu;
}
```

> 注意：这里只是**概念实现**，真实库会更复杂（涉及线程安全、取消、执行器等）。

### 3.1 异常传播

一个设计良好的 future/continuation 框架会把异常也当成“结果”来传递。通常做法：

- shared state 里存的是 `std::variant<T, exception_ptr>`，或者一个 `Try<T>`；
    
- `.then()` 接收到的是 `Try<T>`；
    
- 你可以写两类 continuation：
    
    - 正常值的处理，比如 `thenValue`；
        
    - 异常的处理，比如 `thenError`；
        

比如 folly 里：

```C++
f1.thenValue([](int x) {
    return x * 2;
}).thenError<std::exception>([](const std::exception& e){
    LOG(ERROR) << e.what();
    return -1;
});
```

**对比标准库**：

- 标准库的 `std::future` 没有 continuation：
    
    - 异常只能在 `f.get()` 时一次性 rethrow；
        
    - 一旦 `get()` 被调用，shared state 就消耗掉了，链也就结束了。
        

---

## 4. 执行器（Executor） + `.via()`：continuation 跑在哪儿？

一个关键问题：

> continuation 这段代码到底在哪个线程上执行？

几种常见策略：

1. **inline 执行**：
    
    - “谁让 future ready 的，谁顺手执行 continuation”；
        
    - 优点：少线程切换，快；
        
    - 缺点：某个 continuation 写得很重，就会拖慢生产者线程。
        
2. **线程池执行**：
    
    - 每个 continuation 扔到某个线程池里执行；
        
    - 优点：公平一些，不阻塞 producer；
        
    - 缺点：调度成本略高。
        

现代库通常会引入一个概念：**Executor**/Scheduler：

- 表示“在哪里运行 continuation”；
    
- 未来你会看到类似 API：
    

```C++
auto f2 = f1.via(cpuExecutor)
              .then([](int x) { return heavy_compute(x); });
```

含义：

- `f1` 的结果 ready 后，不是直接在 producer 线程执行 continuation；
    
- 而是把 continuation 提交给 `cpuExecutor`（可能是一个线程池）；
    
- `cpuExecutor` 再安排某个 worker 线程去跑这段 lambda。
    

结合前面的例子，你会看到这样一种使用模式：

```C++
auto f = startAsyncIO()                 // 在 IO 线程完成
    .via(cpuPool)                       // 后续计算在 CPU 线程池跑
    .then([](Data d) { return parse(d); })
    .then([](Parsed p) { return analyze(p); });
```

也就是说：

> continuation 不仅描述**顺序关系**，还描述**“在哪一类资源上跑”**。

---

## 5. 几种常见的 continuation 组合模式

有了 `then` 之后，典型还会有一些辅助函数：

- `when_all`：多个 future 全部完成；
    
- `when_any`：任意一个完成；
    
- `collectAll` / `collectAny`：同上，返回结果集合或第一个结果。
    

### 5.1 顺序链（单条 pipeline）

最基本的就是：

```C++
auto f = getUser()
    .then([](User u){ return queryProfile(u); })
    .then([](Profile p){ return renderPage(p); });
```

没有任何阻塞，整个链条由内部的 continuation + promise/future 机制驱动，  
调用者只拿最外层的 `f`，在需要时 `f.get()` 或注册最终回调。

### 5.2 并行 + 聚合

例如，你要同时发起两个异步任务，然后等两个都完成后再处理：

阻塞式写法：

```C++
auto f1 = async(...);
auto f2 = async(...);

auto r1 = f1.get();  // 阻塞
auto r2 = f2.get();  // 阻塞
auto r  = combine(r1, r2);
```

continuation 风格一般会提供类似：
//伪代码
```C++
auto all = when_all(f1, f2); // 返回 Future<std::tuple<T1, T2>>

auto f = all.then([](auto tup) {
    auto& [r1, r2] = tup;
    return combine(r1, r2);
});
```

更高层一点的库会连 `when_all` 都包装好，比如：
//folly库
```C++
auto f = collectAll(
    asyncTask1(),
    asyncTask2(),
    asyncTask3()
).then([](auto results) {
    // results 是一个 vector 或 tuple
});
```

你能看到，**上层逻辑完全不写 `get()`，全部是算子式组合**。

---

## 6. 自己实现一个极简的 `Future::then()`（思想版）

现在把这些落地到你能写的代码上，用我们前面讨论过的：

- `std::promise` / `std::future`
    
- `std::packaged_task`
    
- 一个简单线程池/执行器
    

### 6.1 一个简易 Future 包装

写一个自己的 `MyFuture<T>`，内部包一层 `std::shared_ptr<SharedState<T>>`，  
其中 `SharedState` 包含：

- `std::mutex`；
    
- `std::condition_variable`；
    
- `std::optional<T>` 或 `std::variant<T, exception_ptr>`；
    
- 一个 `std::vector<Continuation>`。
    

当这个 shared state 被 fulfill（`set_value` 或 `set_exception`）时：

- 通知所有等待 `get()` 的线程；
    
- 依次执行所有 continuation。
    

简化起见，这里我们只写概念：

```C++
template<typename T>
class MyFuture {
public:
    using Continuation = std::function<void(const T&)>;

    void then(Continuation cont) {
        std::unique_lock lk(m_);
        if (ready_) {
            // 已经 ready，直接调用或丢到线程池
            lk.unlock();
            cont(value_);
        } else {
            continuations_.push_back(std::move(cont));
        }
    }

    T get() {
        std::unique_lock lk(m_);
        cv_.wait(lk, [&]{ return ready_; });
        return value_;
    }

    void set_value(T v) {
        {
            std::lock_guard lk(m_);
            value_ = std::move(v);
            ready_ = true;
        }
        cv_.notify_all();
        for (auto& c : continuations_) {
            // 或者扔给线程池执行
            c(value_);
        }
    }

private:
    std::mutex m_;
    std::condition_variable cv_;
    bool ready_ = false;
    T value_;
    std::vector<Continuation> continuations_;
};
```

这当然不包括异常处理、执行器选择、多个消费者等复杂逻辑，但**核心思想就是：**

1. future has **shared state**；
    
2. continuation = “挂在 shared state 上的一段函数”；
    
3. ready 时调用所有 continuation，并将结果通过新的 future 传下去。
    

### 6.2 再往前一步：`then` 返回一个新的 future

把 `then` 改造成返回 `MyFuture<U>`：

```C++
template<typename T>
class MyFuture {
public:
    template<typename F>
    auto then(F&& func) -> MyFuture<std::invoke_result_t<F, T>> {
        using U = std::invoke_result_t<F, T>;

        MyPromise<U> p;             // 你自定义的 promise
        MyFuture<U> next = p.getFuture();

        auto cont = [p = std::move(p), func = std::forward<F>(func)]
                    (const T& val) mutable {
            try {
                U u = func(val);
                p.set_value(std::move(u));
            } catch (...) {
                p.set_exception(std::current_exception());
            }
        };

        std::unique_lock lk(m_);
        if (ready_) {
            lk.unlock();
            cont(value_);
        } else {
            continuations_.push_back(std::move(cont));
        }
        return next;
    }
};
```

这样你就得到了“`then` 返回新 future，可以链式调用”的完整模式。  
这就是 folly 等库在做的事情，只不过他们把异常、`Try<T>`、Executor、取消、超时等都做得非常完善。

---

## 7. continuation vs 协程：两种抽象层次

最后简单对比一下你现在的“任务链”和 C++20 协程：

- continuation（future + then）：
    
    - 完全是 **库级别** 的；
        
    - “任务链”是一堆 future + continuation 的组合；
        
    - 代码还是看起来比较“嵌套的 lambda 风格”；
        
    - 但组合性、可控性很强。
        
- 协程（`co_await`）：
    
    - 是 **语言级** 的 continuation 抽象；
        
    - 编译器帮你把函数本身拆成一个状态机；
        
    - 每个 `co_await` 点本质上就是“挂一个 continuation”，只是你不需要手写；
        
    - 写法更接近同步：
        
        `task<void> pipeline() {     int x = co_await async1();     int y = co_await async2(x);     co_return; }`
        
    - 底层还是会生成 continuation，只不过由编译器产生。
        

可以这么理解：

> 你现在学的“future + continuation + then”是**手写 continuation 的时代**；  
> C++20 协程则是让编译器帮你生成 continuation 的时代。  
> 但两者的根本思想——“异步任务完成后继续执行什么”——是一致的。

---

### 压一句给你记忆：

> **阻塞式 `future.get()` 把控制权卡在当前线程；  
> continuation 风格的 `.then()` 把“接下来要干什么”封装成一个 continuation，交给 future 框架在“任务完成时”自动调度执行，并把结果变成新的 future，串成任务链。**

如果你愿意，我们可以选一个具体场景，比如“**并发请求多个节点获取以太坊网络统计 → 聚合结果 → 再做下一步处理**”，我可以分别用：

- 阻塞式 future.get 写一版；
    
- continuation 风格（假设有 then/when_all）写一版；
    
- 协程风格（`co_await`）写一版，
    

让你直观感受这三种风格的对比。

##### You said:

是不是说.then就是在future得到结果之后，再执行.then()里面的函数，再得到一个future？

###### ChatGPT said:

对，你这句话抓住了 **大方向**，但有两个细节需要纠正一下，我给你捋顺成一个“时间线版本”：

> **正确理解是：**
> 
> 1. 调用 `.then(...)` 的时候，**先**在当前 future 上“挂上一个回调”（continuation），
>     
> 2. `.then(...)` **立刻返回一个新的 future**（这个时候还没结果），
>     
> 3. 当“前一个 future 真正变成 ready”时，才会调用你 `.then(...)` 里的函数，
>     
> 4. 这个函数的返回值（或异常）会被塞进那个“新 future”里面。
>     

所以顺序应该是这样：

```txt
f1 是一个 Future<int>

auto f2 = f1.then( lambda );   // 第一步：注册 lambda 为 f1 的 continuation
                               // 第二步：马上得到一个新的 Future<U> = f2

// 将来某个时刻：f1 完成（有结果/异常）
// runtime 做：
调用 lambda( f1 的结果 )
   ↳ 得到一个 U 或抛异常
   ↳ 把它写入 f2 的 shared state

此时 f2 才真正 ready
```

你原话里有一个容易误解的小地方是：

> “在 future 得到结果之后，再执行 `.then()` 里面的函数，再得到一个 future”

更精确说法应该是：

- `.then()` **调用那一刻**就“得到一个新 future”了（只是还没 ready）；
    
- “在前一个 future 得到结果之后”，**运行的是你之前挂进去的函数**，  
    运行完了之后，**这个新 future 才变成 ready**。
    

类比一下：

```C++
auto f1 = ... // 一个正在路上的快递

auto f2 = f1.then([](int x) { return x * 2; });
```

- `f1` = “快递 A 的单号”
    
- `.then(…)` = “在快递 A 送达时，让仓库自动做一个操作：把包裹 A 再加工一下，生成包裹 B”
    
- `f2` = “快递 B 的单号”
    

你在 `.then()` 那一刻，就拿到了“快递 B 的单号”（就是新 future），  
只是包裹 B 还没生成，要等包裹 A 到了、加工完，单号 `f2` 才真正对应一个 ready 的结果。

再压一句完全可以背的版本：

> **`.then` 的本质：在旧 future 上挂一个“完成后要干什么”的函数，并立刻返回一个代表“干完之后结果”的新 future；等旧 future 真完事儿了，才会真正去调用这个函数并把结果塞进新 future。**