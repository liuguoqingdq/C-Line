函数模板
类模板
变量模板
别名模板
类模板参数推到
decltype
后置返回类型声明和返回类型自动推导
声明变量和初始化的不同方式
结构化绑定

----
# 1. 函数模板（Function Templates）

## 1.1 基本形式

```C++
template <typename T>
T add(T a, T b) {
    return a + b;
}
```

使用时：

```C++
add<int>(1, 2);   // 显式指定 
T add(1, 2);        // 编译器推导 T = int
```

# (1) 值传递 `f(T x)`：抹掉引用和顶层 const

## 规则（正式版）

当形参是**非引用**（`T x`）时：

1. 先把实参类型中的**引用去掉**
    
2. 再把**顶层 cv（const/volatile）去掉**
    
3. 得到的就是 T
    

也就是：

> `T` 推导 = `decay(实参类型)` 的一部分（但注意数组/函数退化另说，下面讲）

## 直观理由

你传值进来，相当于**拷贝一份**新对象到形参 `x` 里。  
既然是新对象，它不会“继承”你原对象的顶层 const，也不会是引用。

---

## 例子细化

```C++
template<class T>
void f(T x);

int a = 1;
const int ca = 2;
int& ra = a;
const int& rca = ca;

f(a);    // 实参 int        -> T = int
f(ca);   // 实参 const int  -> 去顶层const -> T = int
f(ra);   // 实参 int&       -> 去引用 -> T = int
f(rca);  // 实参 const int& -> 去引用，再去顶层const -> T = int
```

所以你看到的现象就是：**值传递永远推成“裸类型”**。

---

## 重要边界 1：指针的底层 const 不会被抹掉

```C++
template<class T>
void f(T x);

const int ci = 3;
const int* p = &ci;

f(p);   // 实参类型 const int*
        // 顶层const？没有（const 在 *p 上，是底层）
        // 所以 T = const int*
```

> 值传递只抹掉“顶层 const”，不会碰“底层 const”。

---

## 重要边界 2：数组/函数会退化为指针（decay）

```C++
template<class T>
void f(T x);

int arr[3] = {1,2,3};
f(arr);   // 实参 int[3] -> 退化成 int* -> T = int*

void foo(int);
f(foo);   // 实参 void(int) -> 退化成 void(*)(int) -> T = void(*)(int)
```

> 因为按值传递时，数组/函数本来就不能“拷贝”，标准规定退化成指针。

# (2) 引用参数 `g(T& x)`：保留 const / 不退化

## 规则（正式版）

当形参是**左值引用** `T&` 时：

1. 实参必须是**左值**（不能传纯右值）
    
2. `T` 推导为**实参的类型（去掉引用，但保留 const/volatile）**
    
3. **不会发生数组/函数退化**（因为是引用）
    

---

## 直观理由

`T& x` 不是拷贝，而是把形参 `x` **绑到原对象**上。  
既然绑的是原对象，它的 const 属性必须被保留。

---

## 例子细化

```C++
template<class T>
void g(T& x);

int a = 1;
const int ca = 2;

g(a);    // 实参 int      -> T = int
g(ca);   // 实参 const int -> T = const int
```

于是 `g(ca)` 的形参类型是：  
`T&` = `const int&`  
所以你不能在 `g` 里改它。

---

## 边界 1：右值不能绑定到 `T&`

```C++
g(3);  // ❌ 3 是右值，不能给 T& 绑定
```

---

## 边界 2：数组/函数不退化

```C++
template<class T>
void g(T& x);

int arr[3] = {};
g(arr);  // T = int[3]   (没有退化)
          // 参数类型是 int (&)[3]
```

这招常用于**拿到数组长度**：

```C++
template<class T, size_t N>
constexpr size_t len(T (&)[N]) { return N; }//长度为N的引用类型
```
# (3) 转发引用/万能引用 `h(T&& x)`：最容易懵的，但规则很机械

> 注意：**只有当 T 是模板参数、并且形参写成 `T&&` 时**，它才是“转发引用”。  
> 如果你写成 `void h(std::vector<T>&& x)`，那就只是普通右值引用。

---

## 规则（正式版）

当形参是 `T&&` 且 T 参与推导时：

1. **如果实参是左值**
    
    - `T` 推导为 **左值引用类型** `U&`
        
    - 形参类型变成 `U& &&`，按引用折叠变为 `U&`
        
2. **如果实参是右值**
    
    - `T` 推导为 **非引用类型** `U`
        
    - 形参类型就是 `U&&`

这背后是**引用折叠规则**：  
## 引用折叠（记住这张表）

| 组合       | 折叠结果  |
| -------- | ----- |
| `U& &`   | `U&`  |
| `U& &&`  | `U&`  |
| `U&& &`  | `U&`  |
| `U&& &&` | `U&&` |
**只要出现 &，最后基本就是 &。**

---

# 1) 重载（overload）到底在做什么？

代码：

```C++
template<class T>
void print(T x) { std::cout << x << "\n"; }
void print(const char* s) { std::cout << s << "\n"; }
```

这里有两个同名函数：

1. **函数模板**：`print(T)`
    
2. **普通函数（非模板）**：`print(const char*)`
    

当你调用 `print(...)` 时，编译器会做**重载决议**：

### 1.1 编译器怎么选？

步骤大致是：

**(A) 先收集所有同名 print 的候选函数**

- 包括普通函数
    
- 也包括模板实例化后可能匹配的版本
    

**(B) 看哪些能匹配实参**（能转换就算）

**(C) 选“最优匹配”的那一个**  
而其中有一个重要规则：

> **如果普通函数和模板都同样匹配，那么普通函数优先**。

所以：

`print("hi");`

- `"hi"` 的类型是 `const char[3]`  
    先退化为 `const char*`
    

候选：

- 普通函数 `print(const char*)`：完美匹配 ✅
    
- 模板 `print(T)`：也能匹配，`T = const char*` ✅
    

两者一样好 → **普通函数胜出**。

所以会走 `const char*` 的重载版本。

### 1.2 重载的特点

- 你写的是**两个完全独立的函数**
    
- 模板那个对“泛型情况”负责
    
- 普通版本对“特殊情况”负责
    
- **所有选择规则都走重载决议**，比较直观、稳定
    

---

# 2) 显式特化（explicit specialization）在做什么？

代码：

```C++
template<class T> void foo(T);
template<> void foo<int>(int) { /*...*/ }
```

意思是：

1. 先声明一个通用模板 `foo(T)`
    
2. 再说：
    
    > 当 `T = int` 时，`foo<int>` 这个模板实例用我这个特化版本
    

也就是：

- 模板版是“总方案”
    
- 特化版是“针对某个模板实例改写实现”
    

### 2.1 调用时怎么选？

`foo(3);`

编译器会先推导：

- `T = int`  
    然后找到：
    
- 主模板 `foo<int>(int)`
    
- 显式特化 `foo<int>(int)`
    

**如果有精确匹配的显式特化，就用特化。**

所以会调用特化版本。

---

# 3) 为什么工程上更推荐“重载”？

### 3.1 函数模板**没有偏特化**

你不能写：

```C++
template<class T>
void foo(T*);          // 想对指针偏特化

template<>
void foo<int*>(int*); // 这不是偏特化，这是对一个具体实例的特化
```

你想“对一类类型特殊处理”（比如所有指针/所有 vector）时，**显式特化做不到**，只能靠重载：

```C++
template<class T>
void foo(T x);         // 泛型

template<class T>
void foo(T* p);        // 指针情况（重载）
```

**重载能表达“一个类型族的特殊逻辑”，特化只能表达“某一个具体类型”。**

---

### 3.2 重载的匹配规则更统一、更可控

重载靠“重载决议”这套成熟规则（最优匹配、优先普通函数、优先更特化的模板等），结果常常更符合直觉。

特化则是“模板系统的另一层规则”，和重载叠在一起时容易让人读不懂。

---

### 3.3 特化的可见性/作用域坑很多

显式特化必须在**同一命名空间**里声明，而且需要在使用前可见，否则可能出现：

- 你以为调用的是特化
    
- 结果编译器在某个翻译单元里只看到了主模板
    
- **不同 cpp 里行为不一致**
    

重载几乎不会有这种“跨 TU 的惊喜”。

---

# 4) 显式特化最常见的坑（一定要知道）

### 坑 1：和重载混用时，优先级不是你想的那样

比如：

```C++
template<class T>
void foo(T) { std::cout << "template\n"; }

template<>
void foo<int>(int) { std::cout << "specialized int\n"; }

void foo(long) { std::cout << "overload long\n"; }
```

调用：

`foo(3);   // int`

会选谁？

- `foo(long)` 需要 int→long 转换（一般转换）
    
- `foo(T)` 推导出 `T=int` 是完美匹配  
    然后才发现有 `foo<int>` 的特化
    

**最终结果：走 int 特化。**

但如果是：

`foo(3L);  // long`

此时：

- `foo(long)` 是普通函数完美匹配
    
- 模板也能匹配但普通函数优先  
    → **走 overload long，不走模板，更不会走 int 特化**
    

这种优先级链条不熟的话很容易误判。

---

### 坑 2：特化不是重载，它不参与“候选集扩展”

很多人以为写了特化，就等于多了个候选函数。  
其实特化只是“替换某个模板实例的实现”，**不是一个新的重载函数**。

所以：

- 先选模板实例
    
- 再用特化替换  
    逻辑顺序不同。
    

---

# 5) 一句话总结

- **重载**：写一个新的同名函数，让它在重载决议阶段就赢 → 直观、可表达一类类型、工程首选
    
- **显式特化**：只是在“模板实例化”后替换某个特定类型的实现 → 能用但规则更绕、易踩坑
    

所以你常看到的最佳实践是：

> **函数模板用重载处理特殊情况；类模板才常用偏特化/特化。**
**注意**：函数模板的“部分特化”不存在，只能重载来替代。

---

## 1.4 非类型模板参数（NTTP）

```C++
template<int N>
int pow2() { return 1 << N; }

auto x = pow2<5>(); // 32
```

C++20 起 NTTP 可以是更复杂的字面量类型（如 `std::array<int, N>` 的 N）。
## 1. C++11/14/17 时代：NTTP 允许哪些类型？

在 C++20 之前，NTTP 允许的类型比较“窄”。可以归成两大类：

### 1.1 整数/枚举类（最常用）

- `int, long, size_t, char, bool...`
    
- 以及 `enum`
    

`template<std::size_t N> struct Buf { char data[N]; };  Buf<1024> b;`

### 1.2 指针/引用/成员指针/`nullptr`

要求是 **指向的对象/函数必须有外部链接（external linkage）**。

```C++
extern int g;
void foo();

template<int* P>
struct UsePtr {};

template<void(*F)()>
struct UseFunc {};

UsePtr<&g> up;
UseFunc<&foo> uf;

template<const int& R>
struct UseRef {};

UseRef<g> ur;

template<std::nullptr_t NP>
struct UseNull {};

UseNull<nullptr> un;

```

> 为什么要 external linkage？  
> 因为模板参数要在不同翻译单元里“同一性可判定”（ODR），内部链接/临时对象会导致歧义。

---

## 2. 从 C++17 开始：`auto` NTTP（更灵活）

C++17 允许你写：

```C++
template<auto V>
struct C {};
```

编译器从实参推导 NTTP 的类型。

```C++
C<42>      c1;   // V 是 int
C<true>    c2;   // V 是 bool
C<'x'>     c3;   // V 是 char
C<&foo>    c4;   // V 是 函数指针
```

用途：写“按常量值分派”的通用模板不必手动写类型。

---

# 2. 类模板（Class Templates）

## 2.1 基本形式

```C++
template<class T>
class Box {
    T val;
public:
    Box(T v) : val(v) {}
    T get() const { return val; }
};

```

使用：

`Box<int> b(3);`

## 2.2 类模板的偏特化（partial specialization）

```C++
template<class T>
struct Trait { static constexpr bool is_ptr = false; };

template<class T>
struct Trait<T*> { static constexpr bool is_ptr = true; };

```

函数模板没有偏特化，但类模板有，这是二者重要差异。

---

# 3. 变量模板（Variable Templates, C++14）

## 3.1 作用

模板化“变量/常量”，按类型生成不同实例。

```C++
template<class T>
constexpr T pi = T(3.141592653589793);

double x = pi<double>;
float  y = pi<float>;

```

## 3.2 也支持特化

```C++
template<> constexpr const char* pi<const char*> = "3.14";
```

---

# 4. 别名模板（Alias Templates）

# 1. 别名模板到底是什么？

一句话：

> **“可以带模板参数的类型别名”**，用 `using` 定义。

普通别名（不带模板）你很熟：

```C++
using ll = long long;
```

别名模板就是让这个别名也能“泛型化”：

`template<class T> using Vec = std::vector<T>;`

然后：

```C++
Vec<int> v;   // 等价 std::vector<int>
Vec<std::string> vs; // 等价 std::vector<std::string>
```

所以 alias template 本质上是**“类型函数（type function）”**：输入参数 → 输出一个类型。

---

# 2. 语法拆解

`template<...> using AliasName = 复杂类型表达式;`

- `template<...>`：可有 1 个或多个模板参数
    
- `AliasName`：这是你要起的新名字
    
- `=`右边：任何合法的类型表达式（可依赖模板参数）
    

比如多参数：

```C++
template<class K, class V>
using HashMap = std::unordered_map<K, V>;
```

带默认模板参数：

```C++
template<class T, class Alloc = std::allocator<T>>
using MyVec = std::vector<T, Alloc>;
```

## `std::allocator<T>` 在干啥？

它提供最基本的 2 件事：

1. **分配原始内存（allocate）**
    
2. **释放原始内存（deallocate）**
    

容器再在这块内存上**构造/析构对象**。

简单理解：

- `allocate(n)`：给你一块能放 `n` 个 T 的“裸内存”
    
- 容器用 placement new 在上面构造元素
    
- 最后 `deallocate` 还回去

---

# 3. 别名模板 vs typedef（为什么要用 using）

### 3.1 `typedef` 不能模板化

你做不到：

```C++
template<class T>
typedef std::vector<T> Vec;   // ❌ 不允许
```

而 `using` 可以。

### 3.2 `using` 更直观，能写复杂类型

`typedef` 遇到函数指针/多层嵌套会很反人类；`using` 更像“等号赋值”，好读：

```C++
using FnPtr = int(*)(double, char);
```
读法是：

- `FnPtr` 是一个**函数指针类型**
    
- 指向的函数：  
    **返回 `int`**  
    **参数列表是 `(double, char)`**
    

也就是说它能指向任何形如下面签名的函数：

```C++
int foo(double x, char c) { ... }

FnPtr p = &foo;
int r = p(3.14, 'a');
```

---

# 4. 元编程里为什么特别爱别名模板？

#### 一、什么是 C++ 元编程（Metaprogramming）？

**元编程**直译就是“写用来生成/操纵程序的程序”。在 C++ 里通常指 **模板元编程（Template Metaprogramming, TMP）**：

> 利用模板在**编译期**做计算、做类型变换、做条件分支，从而生成不同的代码。

你可以把它理解成：  
**模板 = 编译期的“函数/语言”**

- 输入：类型、编译期常量
    
- 输出：新类型、常量、不同的函数/类实现
    
- 运行时不再做这些判断和组合，编译器已经替你“算完并生成代码”。
    

### 元编程在 C++ 里能做什么？

1. **类型变换**  
    例如把 `T&` 变成 `T`、把 `const T` 去掉 const、判断 T 是否指针等。
    
2. **编译期条件分支（SFINAE / Concepts）**  
    根据类型特性选择不同函数重载，做到“只对某些类型可用”。
    
3. **编译期计算**  
    比如 `std::array<T, N>` 的 N、`pow2<5>()` 这种。
    
4. **零运行时开销的多态/策略选择**  
    把选择放在编译期，让运行时更快。
    

### 为什么要用元编程？

- **性能**：条件和计算提前到编译期，运行时更轻
    
- **泛型能力**：写一份代码，适配很多类型
    
- **安全/可检查**：错误尽量在编译期暴露（例如不支持的类型直接编译不过）

### 1）“早期 type trait 的返回类型都要写 `::type`…”

在 C++11 时代，标准库的类型萃取（type traits）一般长这样：

`std::remove_reference<T>::type`

`remove_reference` 是一个**类模板**（trait），里面有个成员类型 `type` 表示“变换后的结果类型”。

但在模板里要用它，还得写 `typename`：

`typename std::remove_reference<T>::type`

#### 为什么必须写 `typename`？

因为在模板里：

- `std::remove_reference<T>::type` **依赖于模板参数 T**
    
- 编译器不知道 `type` 是类型还是静态成员
    
- 你要用 `typename` 明确告诉它“这是个类型”。
    

这就导致 TMP 的代码经常像这样又长又吵：

```C++
typename std::remove_const<
    typename std::remove_reference<T>::type
>::type
```

可读性确实很差。

#### `std::remove_const<T>`

作用：**去掉类型的顶层 const**。

- 只去“顶层 const”（修饰对象本身的 const）
    
- 不会去掉指针所指向内容的 const（底层 const）

## 它们通常怎么一起用？

在模板里你经常想拿到“真实的基础类型”，就会组合：

`template<class T> using Clean = std::remove_const_t<std::remove_reference_t<T>>;`

比如：

`Clean<const int&>  // -> int Clean<int&&>       // -> int`

---

### 2）“别名模板把它缩成 type 函数：`std::remove_reference_t<T>`”

从 C++14 起，标准库为绝大多数 traits 提供了 `_t` 版本：

`std::remove_reference_t<T>`

它本质就是一个**别名模板**，等价于：

`template<class T> using remove_reference_t = typename remove_reference<T>::type;`

所以 `_t` 做的事是：

- 把 `::type` 这一坨藏起来
    
- 把 `typename` 也藏起来
    
- 让 trait 看起来像“接收 T → 返回新类型”的**类型函数**
    

于是 TMP 代码瞬间清爽：

`std::remove_const_t<std::remove_reference_t<T>>`

---

### 3）“你可以再封装一个自己的别名模板：`RemoveRef<T>`”

你写的：

`template<class T> using RemoveRef = std::remove_reference_t<T>;`

意味着你自己定义了一个“类型函数别名”：

- 输入：类型 T
    
- 输出：去掉引用后的类型
    

现在你写：

`RemoveRef<T>`

就等价于老写法：

`typename std::remove_reference<T>::type`

---

### 4）“核心价值 1：可读性提升”

看对比就懂了：

**旧：**

`typename std::remove_reference<T>::type`

**新：**

`RemoveRef<T>`

尤其在长链组合时差别更大。

---

### 5）“核心价值 2：减少 `typename` 噪音”

因为 `_t`/别名模板已经**内置了 typename**：

旧代码里经常要反复写：

```C++
typename A<T>::type
typename B<typename A<T>::type>::type
```

新写法里你就不用关心 `typename` 了：

`B_t<A_t<T>>`

这对模板元编程非常关键：  
**把语法噪音降到最低，让你专注“类型变换逻辑”。**

---

### 6）“核心价值 3：让类型变换更像函数式组合”

别名模板把 trait 变成“类型函数”后，你可以像拼函数一样拼类型：

```C++
template<class T>
using Clean = std::remove_cv_t<std::remove_reference_t<T>>;
```

此时 `Clean<T>` 就是：

1. 先 RemoveRef
    
2. 再 RemoveCV
    

这和函数式管道非常像：  
`Clean(T) = remove_cv(remove_reference(T))`

甚至可以层层封装：

```C++
template<class T>
using Decay = std::decay_t<T>;

template<class T>
using Elem = std::remove_pointer_t<Decay<T>>;
```

读起来就像一串“类型处理流水线”。

---

## 三、给你一个完整的“小元编程”例子串起来

```C++
template<class T>
using RemoveRef = std::remove_reference_t<T>;

template<class T>
using RemoveCV  = std::remove_cv_t<T>;

template<class T>
using Clean = RemoveCV<RemoveRef<T>>;  // 组合

template<class T>
void foo(T&& x) {
    using U = Clean<T>;
    // U 现在是“真实裸类型”
}
```

你会发现：

- TMP 仍在做编译期类型计算
    
- 但表达方式已经很接近“普通函数调用”
    
- 这就是 alias templates 带来的质变。
    


---

# 5. `RemoveRef` 例子详解

先看 `std::remove_reference` 的作用：

- `remove_reference<int&> -> int`
    
- `remove_reference<int&&> -> int`
    
- `remove_reference<int> -> int`
    

等价 alias：

`template<class T> using RemoveRef = std::remove_reference_t<T>;`

验证：

`static_assert(std::is_same_v<RemoveRef<int&>,  int>); static_assert(std::is_same_v<RemoveRef<int&&>, int>); static_assert(std::is_same_v<RemoveRef<int>,   int>);`

**使用场景：**  
你写模板时常要先“剥掉引用”，再做判断/转换：

`template<class T> void foo(T&& x) {     using U = RemoveRef<T>;  // 把 T 变成“纯类型”     // 现在 U 就是你要分析的真实类型 }`

---

# 6. 别名模板的常见实战用法

## 6.1 给复杂 STL 类型起简短名字（工程可读性）

### 6.1.1 为什么需要？

真实项目里 STL 类型往往很长、嵌套很深：

`std::unordered_map<std::string, std::vector<std::pair<int,double>>>`

一长就会带来三个问题：

1. **可读性差**（你一眼很难看出它的语义）
    
2. **重复成本高**（到处复制这坨类型）
    
3. **难改策略**（想换容器/比较器/allocator 时要全局搜改）
    

### 6.1.2 用别名模板怎么做？

```C++
template<class K, class V>
using UMap = std::unordered_map<K, V>;

UMap<std::string, int> cnt;
```

读代码时，`UMap<K,V>` 一眼就知道“unordered map”。  
以后你要换成 `std::map`，只改这里：

`template<class K, class V> using UMap = std::map<K, V>;  // 业务代码完全不动`

### 6.1.3 工程里更常见的写法

把语义也塞进别名名字里：

```C++
template<class K, class V>
using IdIndex = std::unordered_map<K, V>;

template<class T>
using ObjList = std::vector<T>;

```

这样别名不只是短，更是“**领域语义的载体**”。

---

## 6.2 固定策略/模板参数（“一处定义，全局换策略”）

STL 容器通常有很多可选策略参数：allocator、hash、compare、policy……  
你不想在业务里到处写这些参数，但又想**全项目统一策略**。

### 6.2.1 例子：固定 allocator（内存池）

```C++
template<class T>
using FastVec = std::vector<T, MyPoolAlloc<T>>;
```

以后业务就写：

`FastVec<Node> nodes; FastVec<int> ids;`

#### 这带来什么好处？

- 业务代码干净，不关心内存策略；
    
- 你要换 allocator（比如从 pool 换到 pmr 或 debug allocator），只改别名模板。
    

### 6.2.2 例子：固定 hash/比较器

```C++
template<class K, class V>
using MyMap = std::unordered_map<K, V, MyHash<K>>;
```

业务层：

`MyMap<std::string, int> cnt;`

#### 为什么特别适合工程？

- 如果你做安全/区块链/网络测量，可能希望统一用一个 **抗碰撞 hash / 自定义 key 规范**；
    
- alias template 让你“**约束策略**”变得像强制编码规范一样自然。
    

---

## 6.3 作为“类型函数”组合类型变换（现代元编程的语法糖）

你列的这些 `_t` 都是 alias template（标准库提供的“类型函数”）。  
它们的共同点：

> 输入类型（或编译期条件） → 输出一个新类型

### 6.3.1 `std::enable_if_t<cond, T>`

**按条件得到一个类型；条件不成立则“没有这个类型”。**

- cond = true → 返回 T
    
- cond = false → 不存在（SFINAE 会用到）
    

```C++
template<class T>
using IfInt = std::enable_if_t<std::is_integral_v<T>, int>;
```
`static_assert` 用来在**编译期做断言检查**：条件不满足就**直接编译报错**，程序根本不会生成可执行文件。
```C++
static_assert(条件, "错误提示");
```

### 6.3.2 `std::conditional_t<cond, A, B>`

**编译期三目运算符（类型版）**：

```C++
template<class T>
using SignedOrUnsigned =
    std::conditional_t<std::is_signed_v<T>, long long, unsigned long long>;
```

### 6.3.3 `std::void_t<...>`

**把一堆类型表达式“压扁为 void”**。  
它的价值不是“void”，而是：

> 如果里面任意一个类型表达式非法，就 SFINAE 掉。

经典检测 idiom：

```C++
template<class, class = void>
struct has_value_type : std::false_type {};

template<class T>
struct has_value_type<T, std::void_t<typename T::value_type>>
    : std::true_type {};
```

### 6.3.4 `std::remove_cv_t<T>`

去掉**顶层 const/volatile**：

`std::remove_cv_t<const int>  // int`

### 6.3.5 `std::decay_t<T>`

**“把 T 变成函数参数按值传递后的类型”**，规则包括：

- 去引用
    
- 去顶层 cv
    
- 数组/函数退化为指针
    

```C++
std::decay_t<int&>       // int
std::decay_t<const int>  // int
std::decay_t<int[3]>     // int*
```

与std::remove_const<std::remove_reference_t<>>相比
1. `remove_reference_t<T>`：把 `T& / T&&` 变成 `T`
    
2. `remove_const<>`：去掉 **顶层 const**（不去 volatile，不去底层 const）
    

所以它的效果是：

- 去引用 ✅
    
- 去顶层 const ✅
    
- **不去 volatile** ❌
    
- **数组不会退化为指针** ❌
    
- **函数不会退化为函数指针** ❌
    

你可以把它理解成一个“轻量 clean”。



-----
### 6.3.6 `std::common_type_t<A,B,...>`

**求一组类型共同能转到的“最自然的结果类型”**：

```C++
std::common_type_t<int, double>  // double
std::common_type_t<int, long>    // long
```

用于泛型数值运算。

### 6.3.7 `std::remove_cvref_t<T>`（C++20）

一步完成：

> 去 const/volatile + 去引用

`std::remove_cvref_t<const int&> // int`

你封装的：

```C++
template<class T>
using Clean = std::remove_cvref_t<T>;
```

这就是典型“类型函数组合”的现代写法。

---

## 6.4 SFINAE / Concepts 的简化（最“值钱”的工程用途）

### 6.4.1 先回顾：SFINAE 是啥？

SFINAE：**Substitution Failure Is Not An Error**  
意思是：模板参数替换失败时，不报错，只是该候选被丢弃。

用途：在编译期“按类型条件启用/禁用函数”。

---

### 6.4.2 早期写法（你说的“typename 噪音”）

```C++
template<class T,
         class = typename std::enable_if<std::is_integral<T>::value>::type>
void f(T);
```

难点：

- 有 `typename`
    
- 有 `::type`
    
- 有 `::value`
    
- 嵌套一多就像噪音
    

---

### 6.4.3 用 alias template 后的写法

```C++
template<class T,
         class = std::enable_if_t<std::is_integral_v<T>>>
void f(T);

```

缩短了三处：

- `enable_if_t` 省掉 `typename ...::type`
    
- `is_integral_v` 省掉 `::value`
    
- 整体读起来像“类型条件函数”
    

---

### 6.4.4 常见工程模式：返回类型 SFINAE

更自然的风格：

```C++
template<class T>
std::enable_if_t<std::is_integral_v<T>, void>
f(T x) {
    // 只对整数类型开放
}
```

或者给返回类型起别名：

```C++
template<class T>
using EnableInt = std::enable_if_t<std::is_integral_v<T>, int>;

template<class T>
EnableInt<T> g(T x) { return x + 1; }
```

---

### 6.4.5 C++20 Concepts：别名模板仍然是底层工具

Concepts 更语义化，但 concept 本身就是“编译期谓词”，常由 trait/alias 组合而成：

```C++
template<class T>
concept Integral = std::is_integral_v<std::remove_cvref_t<T>>;

template<Integral T>
void f(T x) { }
```

这里 `remove_cvref_t` 仍是 alias template。  
所以 alias templates 是 **SFINAE/Concepts 的“积木”**。

---

## 一段“把 6.1–6.4 串起来”的示例

```C++
// 6.1 简短语义别名
template<class K, class V>
using UMap = std::unordered_map<K, V>;

// 6.2 固定策略
template<class T>
using FastVec = std::vector<T, MyPoolAlloc<T>>;

// 6.3 类型函数组合
template<class T>
using Clean = std::remove_cvref_t<T>;

// 6.4 SFINAE/Concepts
template<class T>
concept IntLike = std::is_integral_v<Clean<T>>;

template<IntLike T>
void count_freq(const FastVec<T>& v) {
    UMap<T, int> cnt;
    for (auto x : v) cnt[x]++;
}

```

你会看到：

- 别名模板让类型表达短、语义清晰
    
- 把策略统一抽出去
    
- 类型变换像函数组合
    
- 编译期约束表达自然
    

---

## 总结（你需要记住的“工程价值”）

1. **短 + 有语义**：减少“类型噪音”
    
2. **统一策略入口**：allocator/hash/compare 全局可换
    
3. **类型函数化**：trait 链组合更清晰
    
4. **SFINAE/Concepts 的第一生产力**：不然模板会写到崩溃
---

# 7. 一个很重要的限制（常见坑）

> **别名模板不能被特化/偏特化。**

你不能写：

```C++
template<class T> using Vec = std::vector<T>;
template<>              // ❌ 不允许 
using Vec<int> = std::list<int>;
```

如果你需要“按类型分支”这种能力，就用 `struct`/`class` 包一层再特化：

```C++
template<class T> 
struct VecImpl { using type = std::vector<T>; };  
template<> 
struct VecImpl<int> { using type = std::list<int>; };  
template<class T> 
using Vec = typename VecImpl<T>::type;  // 现在 Vec 可以“特化效果”
```

---

# 8. 总结一句话

- **别名模板 = 带模板参数的类型别名 / 类型函数**
    
- 让复杂类型更好读，也让 trait 元编程从 `typename ...::type` 进化到 `_t` 风格
    
- **不能特化**是唯一大限制，需要特化就套一层 struct


---

# 5. 类模板参数推导（CTAD, C++17）

## 5.1 现象

可以省略 `<T>`，让编译器从构造参数推导。

```C++
std::pair p(1, 2.5);   // 推导为 pair<int, double>
std::vector v{1,2,3};  // 推导为 vector<int>
```

## 5.2 推导依据

- 默认由构造函数生成“隐式推导指南”
    
- 也可以自定义 deduction guide
    

```C++
template<class T>
struct Box {
    Box(T) {}
};
// 自定义推导指南：输入 T* 推导成 Box<std::shared_ptr<T>>
template<class T>
Box(T*) -> Box<std::shared_ptr<T>>;
```

## 5.3 常见坑：花括号优先匹配 `initializer_list`

```C++
std::vector v{10, 3}; // vector<int>，含两个元素 10 和 3
std::vector v(10, 3); // vector<int>，含10个元素，每个3
```

括号 `()` 和花括号 `{}` 意义可能完全不同。

---

# 6. `decltype`

## 6.1 `decltype(e)` 的三条规则

1. 若 `e` 是**未加括号的变量名/成员访问**：得到它的**声明类型**
    
2. 否则若 `e` 是 **lvalue**：得到 `T&`
    
3. 否则若 `e` 是 **xvalue**：得到 `T&&`
    
4. 否则（prvalue）：得到 `T`
    
## `decltype(e)` 的三条核心规则（必须背）

设 `e` 是一个表达式：

### 规则 A：如果 `e` 是**未加括号的变量名/成员访问（id-expression）**

返回它的**声明类型**（原汁原味）

```C++
int x = 0;
const int cx = 0;
int& rx = x;

decltype(x)  a = x;   // int
decltype(cx) b = cx;  // const int
decltype(rx) c = x;   // int&   （因为 rx 声明就是引用）
```

### 规则 B：否则，如果 `e` 是 **左值 (lvalue)**

返回 `T&`

```C++
int x = 0;
decltype((x)) d = x;  // int&   注意多了一层括号！
```

### 规则 C：否则，如果 `e` 是 **将亡值 (xvalue)**

返回 `T&&`

### 规则 D：否则（纯右值 prvalue）

返回 `T`
例子：

```C++
int x = 0;
const int cx = 1;

decltype(x)        A; // int
decltype((x))      B = x; // int&
decltype(cx)       C = cx; // const int
decltype((cx))     D = cx; // const int&

decltype(x + cx)   E; // int（prvalue）
decltype(std::move(x)) F = 1; // int&&

```

## 6.2 常用用途

- 获取表达式真实类型
    
- 与 trailing return type/`decltype(auto)` 搭配（后面讲）
    

---

# 7. 后置返回类型 & `auto` 返回推导

## 7.1 后置返回类型（Trailing return type）

当返回类型依赖参数类型时很有用。

```C++
template<class A, class B>
auto add(A a, B b) -> decltype(a + b) {
    return a + b;
}
```


写成后置的原因：  
参数 `a,b` 只有在参数列表出现后才能用于 `decltype(a+b)`。
**错误写法（参数名还没声明）**：

```C++
template<class A, class B> 
decltype(a + b) add(A a, B b) {  // ❌ a,b 在这里还不存在     
return a + b;}
```
### 7.13`decltype(a+b)` 的好处

它能得到**最精确的表达式类型**（包括引用/const 等）。

举个例子（假设 `operator+` 返回引用）：

```C++
struct X {
    int v;
    X& operator+(const X&) { return *this; } // 很怪但合法
};

template<class A, class B>
auto add(A a, B b) -> decltype(a + b) {  // 返回 X&
    return a + b;
}
```

> 如果不用 decltype，而是随便写 `A` 或 `auto`，就可能丢掉引用语义。

### 7.14什么时候必须用它？

当返回类型**依赖参数的类型或表达式**，且你需要**精确类型**时：

- 泛型运算：`a+b`, `a*b`, `a[i]`
    
- 返回某个成员：`obj.field`
    
- 返回迭代器表达式：`begin(c)`

## 7.2 `auto` 返回类型推导（C++14）

```C++
template<class A, class B>
auto add(A a, B b) {   // 返回类型由 return 推导
    return a + b;
}
```

### 注意：多个 return 必须推导出同一类型

```C++
auto f(bool ok){
    if(ok) return 1;   // int
    else   return 2.0; // double -> ❌ 推导冲突
}
```

## 7.3 `decltype(auto)`（C++14）

按 `decltype` 规则推导返回类型，能保留引用。

```C++
decltype(auto) get_ref(int& x) { return (x); } // 返回 int&
auto          get_val(int& x) { return (x); }  // 返回 int
```

---

# 8. `auto` 自动类型推导（和函数模板推导同源）

把下面类比记住就行：  
`auto` 推导 ≈ 模板参数推导 `T` in `void f(T)`。

## 8.1 典型规则

### (1) `auto`（值推导）

抹掉顶层 const/引用：

```C++
int x=1; 
const int cx=2; 
int& rx=x;

auto a = x;   // int
auto b = cx;  // int
auto c = rx;  // int
```

### (2) `auto&`（引用推导）

保留 const：

```C++
auto& r1 = x;   // int&
auto& r2 = cx;  // const int&
```

### (3) `auto&&`（转发引用推导）

```C++
auto&& u1 = x;  // int&   (x 是左值)
auto&& u2 = 3;  // int&&  (3 是右值)
```

### (4) 花括号推导特殊：`std::initializer_list`

```C++
auto v = {1,2,3}; // std::initializer_list<int>
auto x{1};        // int （C++17 起）
auto y = {1};     // initializer_list<int>
```

---

# 9. 声明变量与初始化的不同方式

## 9.1 主要形式

```C++
T a;        // 默认初始化（内置类型可能未定义）
T a{};      // 值初始化（内置类型清零）
T a(b);     // 直接初始化
T a = b;    // 拷贝初始化
T a{b};     // 直接列表初始化
T a = {b};  // 拷贝列表初始化
```

## 9.2 关键差异

- `{}` **禁止窄化**（narrowing）
    

```C++
int a = 3.14; // ok -> 3
int b{3.14};  // ❌ 窄化报错
```

- 避免“最烦人的解析”（Most vexing parse）
    

```C++
std::vector<int> v(); // 这是函数声明，不是对象！
std::vector<int> v{}; // 对象
```

总体建议：  
**优先用 `{}`**，除非你明确要匹配某个构造（如 `vector(n, val)`）。

---

# 10. 结构化绑定（Structured Bindings, C++17）

## 10.1 支持对象

- `std::pair`
    
- `std::tuple`
    
- 数组
    
- 公开成员的聚合体 struct/class
    

```C++
std::pair<int,double> p{1,2.0};
auto [i, d] = p;   // i=1, d=2.0
```

## 10.2 绑定是“拷贝”还是“引用”

默认是拷贝：

`auto [a,b] = p;  // a,b 是 p 成员的副本`

要引用：

```C++
auto& [a,b] = p;         // a,b 引用 p 的成员，可修改 p
const auto& [a,b] = p;   // 只读引用
```

## 10.3 聚合体例子

```C++
struct S { int x; double y; };
S s{1, 2.5};

auto [x, y] = s;  // 拷贝
auto& [rx, ry] = s; // 引用
```

## 10.4 小坑

- 结构化绑定的变量是**编译器生成的隐藏对象的别名**
    
- 不能绑定到私有成员（除非友元）
    
- 绑定引用时要注意**被绑定对象的生命周期**（别绑到临时对象上）

## 5. 生命周期与临时对象（最大的坑）

### 5.1 默认拷贝绑定：**临时对象安全**

`auto [a,b] = make_pair(1,2);  // ✅ 安全`

因为 `__tmp` 是一个新对象，生命周期就是当前作用域。

### 5.2 引用绑定到临时对象：**危险**

`auto& [a,b] = make_pair(1,2); // ❌ 绑定到临时 => 悬垂引用`

原因：`__tmp` 要绑定 `expr` 本身，而 expr 是临时，语句结束就销毁。

同理：

`const auto& [a,b] = make_pair(1,2); // ❌ 仍然危险`

**const 引用只能延长临时到“引用对象本身”的生命周期**，  
但这里引用的是“临时的子对象”，不延长。

> 经验法则：  
> **只有默认（非引用）结构化绑定可以安全解构临时对象；`auto&/const auto&` 只能用于左值对象。**


## 9. 最常用的三种写法（你以后基本就用这三种）

1. **拆临时 / 拆返回值**（默认拷贝）
    
    `auto [x,y] = foo();   // ✅ 安全`
    
2. **遍历 map 并修改 value**

    `for (auto& [k,v] : mp) { v++; }`
    
3. **只读访问，避免拷贝**
    
    `const auto& [x,y] = s;  // s 必须是左值`
    

---
## 用 friend 提供“可分解视图”，再结构化绑定（✅）

思路：  
你不能直接解构 private 成员，但你可以**让一个 friend 函数返回一个 tuple/pair 的“成员引用”**，然后对这个返回值做结构化绑定。

```C++
#include <tuple>
#include <iostream>

class Secret {
private:
    int x;
    double y;

    // friend 函数：可以访问 private
    friend auto expose(Secret& s) {
        return std::tie(s.x, s.y); // 返回 (int&, double&)
    }

public:
    Secret(int a, double b) : x(a), y(b) {}
};

int main() {
    Secret s{1, 2.5};

    auto& [a, b] = expose(s); // ✅ 现在可以结构化绑定
    a = 10;                   // 改的是 s.x
    b = 3.14;                 // 改的是 s.y

    auto [c, d] = expose(s);  // 也可以拷贝绑定，只是 c/d 是副本
}
```

这里 `expose` 是 `Secret` 的 friend，所以能访问 `x,y`。  
`std::tie` 生成一个 tuple-like 对象，结构化绑定就能拆它。

###### `auto expose(...) { return std::tie(...); }` 会不会把引用剥离？

不会。

- `std::tie(s.x, s.y)` 的返回类型是一个**按值返回的 tuple 对象**，但这个 tuple 的**元素类型是引用**：  
    `std::tuple<int&, double&>`
    
- `auto` 返回类型推导只会去掉**最外层**的引用/const（top-level cv/ref）。  
    这里最外层类型是 `std::tuple<...>`（**不是引用类型**），所以 `auto` 推导得到的仍然是：
    

`std::tuple<int&, double&>`

也就是说：**tuple 里那两个引用还在，指向 `s.x / s.y`，不会被“剥成值”。**

---
### std::tie()是干嘛用的
## 1. 它干嘛用的？

### 1.1 用来“多返回值解包”

函数返回一个 tuple/pair，你想一次性拆到多个变量里：

```C++
#include <tuple>
#include <iostream>
using namespace std;

tuple<int, double, string> foo() {
    return {1, 2.5, "hi"};
}

int main() {
    int a; double b; string c;
    tie(a, b, c) = foo();  // 把返回值拆到 a,b,c
    cout << a << " " << b << " " << c << "\n";
}
```

这里 `tie(a,b,c)` 创建的是“引用 tuple”，所以赋值时会把每个字段写回到 a/b/c。

---

### 1.2 可以配 `std::ignore` 忽略某些字段

```C++
#include <tuple>
using namespace std;

tuple<int, double, string> foo();

int main(){
    int a; string c;
    tie(a, ignore, c) = foo(); // 忽略中间的 double
}
```

---

### 1.3 用来做字典序比较（tuple 比较）

tuple 支持自动的字典序比较：

```C++
#include <tuple>
using namespace std;

struct S { int x; int y; };

bool operator<(const S& a, const S& b){
    return tie(a.x, a.y) < tie(b.x, b.y);
}
```

这比手写  
`if (a.x != b.x) return a.x < b.x; return a.y < b.y;`  
更短也更不容易错。

---

## 2. 关键点：`tie` 只接受**左值**

因为它要返回引用 tuple，你必须传变量，而不能传临时值：

```C++
int a;
std::tie(a) = std::make_tuple(1);  // ✅

std::tie(1) = std::make_tuple(1);  // ❌ 1 不是左值
```

---

## 3. 和结构化绑定的关系

结构化绑定是 C++17 的“语法糖”，更常用：

`auto [a, b, c] = foo(); // 拷贝/移动解包`

但 `std::tie` 仍有它自己的优势：

- 你**已经有变量了**，想把返回值写进去 → `tie` 更合适
    
- 你想**忽略部分字段** → `tie + ignore` 很方便
    
- 你想**用引用的方式解包并修改原变量** → `tie` 是引用 tuple
    

---

## 4. 小总结

- `std::tie(...)`：把多个变量打包成 **tuple 的引用**
    
- 常用于：
    
    1. 多返回值解包
        
    2. 忽略某些返回字段（`ignore`）
        
    3. 字典序比较简化
        
- 只能绑左值变量（不能绑临时）