### 10.1 锁粒度 (Lock Granularity)

锁粒度指的是一个锁所保护的数据范围的大小。

- **粗粒度锁 (Coarse-Grained Lock)**：用一个锁保护一大块数据或多个独立资源。
    
    - **比喻**：进入图书馆前，必须先获取整个图书馆的唯一一把钥匙。任何时候只允许一个人进入。
    - **优点**：
        1. **简单**：逻辑简单，只需要在操作开始时加锁，结束时解锁。
        2. **不易出错**：由于所有东西都被一个锁保护，很难发生死锁或竞争条件。
    - **缺点**：
        1. **吞吐量低 (Low Throughput)**：并发性极差。即使两个线程想访问完全不相关的资源（比如一个想去A区看书，一个想去B区看报纸），它们也必须排队等待。
    
    C++
    
    ```C++
    std::mutex big_lock;
    std::vector<int> user_scores;
    std::string admin_name;
    
    void updateUserScore(int userId, int score) {
        std::lock_guard<std::mutex> lock(big_lock); // 锁住了所有东西
        user_scores[userId] = score;
    }
    
    void getAdminName() {
        std::lock_guard<std::mutex> lock(big_lock); // 只是读个名字，也要等上面写分数的完成
        return admin_name;
    }
    ```
    
- **细粒度锁 (Fine-Grained Lock)**：为每个独立的资源或小的数据块分别设置一个锁。
    
    - **比喻**：图书馆的每个书架、每个房间都有自己的钥匙。你可以拿A书架的钥匙，同时另一个人可以拿B书架的钥匙。
    - **优点**：
        1. **高并发**：只要线程访问的是不同资源，它们就可以并行执行，大大提高吞吐量。
    - **缺点**：
        1. **复杂**：需要管理多个锁，代码逻辑更复杂。
        2. **死锁风险**：当一个线程需要同时获取多个锁时，如果加锁顺序不当，极易引发死锁。
    
    C++
    
    ```C++
    std::mutex scores_lock;
    std::mutex name_lock;
    std::vector<int> user_scores;
    std::string admin_name;
    
    void updateUserScore(int userId, int score) {
        std::lock_guard<std::mutex> lock(scores_lock); // 只锁分数
        user_scores[userId] = score;
    }
    
    void getAdminName() {
        std::lock_guard<std::mutex> lock(name_lock); // 只锁名字，不会和 updateUserScore 冲突
        return admin_name;
    }
    ```
    

**“先粗后细”是正确路线**： 这是一个非常重要的工程实践原则。在项目初期，优先使用粗粒度锁保证程序的**正确性**。当性能分析（profiling）显示这个锁成为了瓶颈时，再有针对性地将其拆分为细粒度锁，以提高**性能**。不要过早优化。

### 10.2 临界区要短 (Keep Critical Sections Short)

临界区（Critical Section）是指被锁保护的代码块。持有锁的时间越长，其他需要这把锁的线程等待的时间就越长，并发性能就越差。

**核心原则**：锁内只做**必要**的、对共享状态的原子性修改。

**反面教材：**

C++

```C++
std::mutex mtx;
std::queue<Data> data_queue;

void processAndLogData() {
    std::lock_guard<std::mutex> lock(mtx); // 坏：过早加锁

    // 1. 从磁盘读取数据（非常慢的 I/O 操作）
    Data data = readDataFromDisk();

    // 2. 进行复杂的计算（非常慢的计算）
    data.process();

    // 3. 将数据放入队列（唯一需要保护的操作）
    data_queue.push(data);

    // 4. 将日志写入文件（非常慢的 I/O 操作）
    logToFile("Pushed data to queue");

} // 坏：锁在这里才释放，持锁时间极长
```

**正确做法：**

C++

```C++
void processAndLogData_Optimized() {
    // 1. 准备数据（在锁外完成）
    Data data = readDataFromDisk();
    data.process();

    { // 使用代码块明确界定临界区
        std::lock_guard<std::mutex> lock(mtx);
        // 2. 只在更新共享状态时加锁
        data_queue.push(data);
    } // 锁在这里立即释放

    // 3. 其他操作（在锁外完成）
    logToFile("Pushed data to queue");
}
```

**禁止在锁内做**：

- **文件 I/O、网络 I/O**：这些操作的延迟非常高且不可预测。
- **`sleep` 或等待其他同步事件**：这会让所有等待该锁的线程一起休眠。
- **大规模、耗时的计算**：可以在锁外预先计算好结果。
- **调用可能再次请求同一个锁的函数**：这会导致死锁。

### 10.3 惊群效应 (Thundering Herd)

当多个线程等待同一个条件变量（`condition_variable`）时，如果使用 `notify_all()` 唤醒它们，会发生什么？

1. 所有等待的线程被同时唤醒。
2. 它们像一群受惊的野牛一样，冲向同一个互斥锁。
3. 只有一个线程能抢到锁。
4. 它检查条件（比如队列是否为空），处理任务，然后释放锁。
5. 其他所有被唤醒的线程，在抢锁失败后，或者抢到锁后发现条件又不满足了（比如队列又空了），只能再次进入睡眠状态。

这个过程造成了大量的**上下文切换**和**CPU 资源浪费**，就像一场无意义的“虚假繁荣”，这就是惊群效应。

**能 `one` 就 `one`**：

- **`notify_one()`**：只唤醒**一个**正在等待的线程。适用于任何一个线程都能处理任务的场景（“消费者”之间没有区别）。这是最常见、最高效的情况。
- **`notify_all()`**：唤醒**所有**等待的线程。适用于以下场景：
    1. 共享状态的改变可能让**多个**线程的等待条件同时满足（例如，设置一个“任务完成”的标志，所有等待任务完成的线程都应该继续执行）。
    2. 等待的线程之间存在差异，不是任何一个都能处理（例如，不同线程等待不同的条件）。

在经典的“生产者-消费者”模型中，每次只生产一个任务，使用 `notify_one()` 是最佳选择。

### 10.4 伪共享 (False Sharing)

这是一个更底层的硬件相关性能问题。

- **背景**：CPU 不直接从内存读写数据，而是通过高速缓存（Cache）。Cache 的最小管理单位是**缓存行 (Cache Line)**，通常是 64 字节。当你读取一个变量时，它所在的整个缓存行都会被加载到 CPU 核心的私有 Cache 中。
- **问题**：假设有两个变量 `A` 和 `B`，它们碰巧位于同一个缓存行上。
    - 线程 1 在核心 1 上频繁写入 `A`。
    - 线程 2 在核心 2 上频繁写入 `B`。
    - 当线程 1 写入 `A` 时，核心 1 的 Cache Line 变为“已修改”。根据缓存一致性协议（如 MESI），这会导致核心 2 中相同的 Cache Line 失效。
    - 当线程 2 想要写入 `B` 时，它发现自己的 Cache Line 失效了，必须重新从内存或核心 1 的 Cache 中加载，这带来了巨大的延迟。
    - 这个过程反向亦然，两个核心会不断地争抢同一个缓存行的所有权，导致性能急剧下降。

**伪共享**的“伪”在于：`A` 和 `B` 在逻辑上是完全独立的，但因为物理上靠得太近，导致了不必要的硬件级别竞争。

**解决方法**： 通过**内存对齐 (Padding)**，确保不同线程高频访问的数据位于不同的缓存行。

C++

```C++
// C++11 alignas
struct AlignedData {
    alignas(64) long counterA; // counterA 独占一个缓存行
    alignas(64) long counterB; // counterB 独占一个缓存行
};

// 手动 padding
struct PaddedData {
    long counterA;
    char paddingA[56]; // 64 - sizeof(long)
    long counterB;
    char paddingB[56];
};
```

### 10.5 死锁排查四原则 (Deadlock Prevention)

死锁产生的四个必要条件：互斥、持有并等待、不可剥夺、循环等待。破坏其中任何一个即可避免死锁。以下原则是实践中的最佳策略：

1. **固定锁顺序 (Fixed Lock Ordering)**
    
    - **核心思想**：破坏“循环等待”条件。规定系统中所有锁的获取顺序，所有线程都必须严格遵守。
    - **示例**：假设有锁 `m1` 和 `m2`。规定必须先锁 `m1`，再锁 `m2`。
        - 线程 A：`lock(m1); lock(m2);`
        - 线程 B：`lock(m1); lock(m2);` (而不是 `lock(m2); lock(m1);`)
    - **实现**：可以根据锁的内存地址大小来排序，这是一种简单通用的方法。
2. **多锁用 `std::lock` / `std::scoped_lock`**
    
    - **核心思想**：这是“固定锁顺序”原则的自动化、标准化实现。
    - `std::lock(m1, m2, ...)`：这是一个函数，它能以一种**避免死锁**的方式一次性锁住多个互斥体。它内部实现了一套复杂的算法来避免循环等待。
    - `std::scoped_lock<Mutex1, Mutex2> lock(m1, m2);` (C++17)：这是 RAII 版本的 `std::lock`，是现代 C++ 的首选。它在构造时调用 `std::lock`，在析构时自动解锁所有互斥体。
    
    C++
    
    ```C++
    std::mutex m1, m2;
    void transfer_money() {
        // 自动处理加锁顺序，绝不会死锁
        std::scoped_lock lock(m1, m2);
        // ... 执行转账操作 ...
    }
    ```
    
3. **少持锁等待外部事件**
    
    - **核心思想**：破坏“持有并等待”条件。
    - 这与“临界区要短”原则紧密相关。如果你持有一个锁，然后去等待一个不确定的外部事件（如用户输入、网络响应），那么你持有锁的时间会变得不可控，极大地增加了死锁和其他线程饥饿的风险。
    - **正确做法**：先释放锁，等待事件，事件发生后再重新尝试获取锁。
4. **尽量减少嵌套锁**
    
    - **核心思想**：简化是避免错误的最好方法。
    - 每增加一层嵌套锁，死锁的风险和分析代码的复杂度都呈指数级增长。
    - **最佳实践**：一个函数内最好只获取一个锁。如果必须获取多个，优先使用 `std::scoped_lock`。如果业务逻辑复杂到需要精细控制多层嵌套锁，那么很可能需要重新审视和设计你的并发模型。

[[C++多线程性能与正确性调优日志]]
