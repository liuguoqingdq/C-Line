## 1. condition_variable 是什么？解决什么问题？

> `std::condition_variable` 用来让线程 **等待某个条件成立**，并在条件成立时被别的线程唤醒。

它解决的是“**线程协作**”问题，而不是“单纯互斥”。

典型场景：

- 生产者/消费者：队列空/满时等待
    
- 任务线程池：没有任务就睡，有任务就醒
    
- 状态机：等待某个状态切换
    

如果你不用 cv，只能：

- 一直轮询（busy-wait）→ 浪费 CPU
    
- sleep/poll → 延迟大、难控制
    

cv 是 **“睡眠等待 + 精确唤醒”** 的标准机制。

---

## 2. cv 的核心语义：必须与 mutex 搭配

### 2.1 为什么必须有 mutex？

因为“条件”通常依赖共享状态（比如队列是否为空）。  
你要保证：

- 检查条件
    
- 入睡等待  
    这两个动作之间是**原子的**，否则会“错过唤醒”。
    

**cv 的 wait 做了一件非常关键的原子操作：**

> **原子地：解锁 mutex → 进入睡眠**  
> 被唤醒后再 **重新加锁**，返回到你手上。

因此 wait 的参数必须是能解锁/再加锁的锁类型 —— `std::unique_lock`。

---

## 3. 基本 API

```C++
class condition_variable {
public:
    void notify_one() noexcept;
    void notify_all() noexcept;

    void wait(std::unique_lock<std::mutex>& lock);
    template<class Pred>
    void wait(std::unique_lock<std::mutex>& lock, Pred pred);

    template<class Rep, class Period>
    cv_status wait_for(std::unique_lock<std::mutex>& lock,
                       const std::chrono::duration<Rep,Period>& rel_time);

    template<class Rep, class Period, class Pred>
    bool wait_for(std::unique_lock<std::mutex>& lock,
                  const std::chrono::duration<Rep,Period>& rel_time,
                  Pred pred);

    template<class Clock, class Duration>
    cv_status wait_until(std::unique_lock<std::mutex>& lock,
                         const std::chrono::time_point<Clock,Duration>& abs_time);

    template<class Clock, class Duration, class Pred>
    bool wait_until(std::unique_lock<std::mutex>& lock,
                    const std::chrono::time_point<Clock,Duration>& abs_time,
                    Pred pred);
};
```

---

## 4. 正确使用的“金科玉律”—— wait 必须配谓词

你几乎永远都应该写：

```C++
cv.wait(lk, [&]{ return condition_is_true(); });
```

而不是：

`cv.wait(lk);`

原因有两个（都非常致命）：

### 4.1 虚假唤醒（spurious wakeup）

标准允许：线程可能在**没有 notify** 的情况下醒来。  
所以醒来后必须再次检查条件。

谓词版 wait 等价于：

```C++
while (!pred()) {
    cv.wait(lk);
}
```

### 4.2 防止“丢失唤醒”

如果你不把检查条件放进循环里，就可能出现：

- 线程 A：检查条件 false → 准备 wait
    
- 线程 B：迅速把条件变 true 并 notify
    
- 线程 A：此时刚进入 wait → **永远睡**（错过 notify）
    

循环＋谓词就能避免这一类竞态。

---

## 5. 经典例子：生产者/消费者队列

这是你写 cv 时的“标准模板”。

```C++
std::mutex m;
std::condition_variable cv;
std::queue<int> q;

void producer(int v) {
    {
        std::lock_guard lk(m);
        q.push(v);
    } // 先释放锁
    cv.notify_one();  // 再唤醒
}

int consumer() {
    std::unique_lock lk(m);
    cv.wait(lk, [&]{ return !q.empty(); }); // 等到队列非空
    int v = q.front();
    q.pop();
    return v;
}
```

### 注意顺序：

- **修改共享状态要在锁内**
    
- **notify 一般放锁外**（不是必须，但更高效）
    

为什么 notify 放锁外更好？

- 锁内 notify 会让被唤醒线程立刻抢锁，但锁还在你手上 → 白唤醒、造成抖动
    
- 锁外 notify：你已放锁，被唤醒线程拿到锁就能立刻干活
    

---

## 6. notify_one vs notify_all

- `notify_one()`：唤醒一个等待线程  
    用于“单个任务/单个资源”到来
    
- `notify_all()`：唤醒所有等待线程  
    用于“状态发生广播式变化”，或你不知道谁该醒
    

**经验法则：**

- 能 `notify_one` 就别 `notify_all`  
    后者会造成“惊群效应”（thundering herd）：  
    大量线程醒来争同一把锁，然后又睡回去。
    

---

## 7. timed wait（带超时）

### 7.1 相对超时 `wait_for`

```C++
std::unique_lock lk(m);
if (!cv.wait_for(lk, 100ms, [&]{ return ready; })) {
    // 超时还没 ready
    return fallback();
}
// ready == true
```

谓词版返回 `bool`：

- true：谓词满足
    
- false：超时
    

### 7.2 绝对时间点 `wait_until`

```C++
auto deadline = std::chrono::steady_clock::now() + 100ms;
cv.wait_until(lk, deadline, [&]{ return ready; });
```

推荐用 `steady_clock` 作为 deadline（不受系统时间调整影响）。

---

## 8. condition_variable_any

`std::condition_variable` 只能配 **std::mutex + unique_lockstd::mutex**。

如果你想配别的锁（如 `shared_mutex` / 自旋锁 / 自定义锁），用：

```C++
std::condition_variable_any cva;
std::unique_lock<MyMutex> lk(mm);
cva.wait(lk, pred);
```

代价：更慢一点（类型擦除）。

---

## 9. 常见坑（你必须会避）

### 9.1 用 lock_guard 等待（编译不过）

```C++
std::lock_guard lk(m);
cv.wait(lk);  // ❌ wait 要求 unique_lock
```

因为 wait 需要“临时解锁/再加锁”。

---

### 9.2 只 wait 不检查谓词

`cv.wait(lk); // ❌ 虚假唤醒/丢失唤醒 use(q.front());`

必须谓词/while 重试。

---

### 9.3 notify 意味着条件成立？不一定

notify 只是“叫醒你去检查”，**不是保证条件一定 true**。

尤其是 `notify_all` 场景：  
醒来后只有一个线程真正满足条件，其余要继续睡。

---

### 9.4 两个条件共用一个 cv，但谓词不清晰

比如等待“队列非空”和“队列非满”共用一个 cv，必须保证谓词分别正确，否则会唤错对象。

常见做法：两个 cv 或一个 cv + 两个谓词。

---

### 9.5 用 atomic + cv 的正确姿势

可以用 atomic 存状态，但 wait 必须仍配 mutex，否则无法原子地“检查+睡”。

模板：

```C++
std::atomic<bool> ready{false};
std::mutex m;
std::condition_variable cv;

void wait_ready(){
    std::unique_lock lk(m);
    cv.wait(lk, [&]{ return ready.load(std::memory_order_acquire); });
}

void set_ready(){
    ready.store(true, std::memory_order_release);
    cv.notify_all();
}
```

atomic 只负责状态本身的原子性；  
mutex/cv 负责睡眠等待与同步。

---

## 10. 设计层面的最佳实践（教授总结）

1. **先锁内改状态，再锁外 notify**
    
2. **wait 必须有谓词（或 while 循环）**
    
3. **谓词只访问被同一 mutex 保护的状态**
    
4. **读写锁（shared_mutex）不直接配 cv**  
    需要时用普通 mutex 或 condition_variable_any
    
5. **临界区要短**：锁内只读/写共享状态
    
6. **notify_one 优先**，除非确实需要广播
    

---

## 11. 一句话总结

> `condition_variable` 是“睡眠等待共享条件”的协作机制：  
> **锁内改状态，锁外唤醒；wait 必须带谓词循环。**  
> 否则你迟早遇到虚假唤醒或丢失唤醒导致的诡异死锁。