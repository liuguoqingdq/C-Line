## 1. “引用是别名”——语言层面到底什么意思？

先看最简单的例子：

```C++
int x = 10;
int& r = x;  
r = 20; 
std::cout << x << std::endl;  // 20
```

从 **C++ 语言标准**的语义角度：

- `r` 在定义那一行就**永久绑定到 `x` 这一个对象**；
    
- 之后对 `r` 的所有读写，都被视为对 `x` 的读写；
    
- `&r` 和 `&x` 的值是一样的（取地址运算符对引用其实是“取它所指对象的地址”）。
    

也就是说：

> **在 C++ 的抽象语义中，“引用自己不是一个独立的对象”，而是现有对象的一个“另一个名字”。**

所以才有这些语义约束：

1. **必须初始化**：
    
    `int& r;  // 不允许：因为你没指定它是“谁的别名”`
    
2. **不能改变绑定对象**：
    
    ```C++
    int a = 1, b = 2; 
    int& r = a; 
    r = b;    // 这是“把 b 的值赋给 a”，不是“让 r 改为引用 b”
    ```
    
3. **理论上不存在“空引用”**：  
    按标准，引用总要绑定到一个实际存在的对象（指向无效内存是 UB）。
    

但这些都是**语言层面的抽象**。编译器要把它翻译成机器码，就得有个实现策略——这就引到下一部分。

---

## 2. 编译器怎么“实现”引用？——大多数情况下就是隐藏指针

标准并不规定“引用在内存里长什么样”，但绝大多数 ABI 的实现都类似：

> **引用 = 编译器自动解引用的指针**  
> （或者甚至被完全优化掉，不占内存）

我们可以用两种角度来理解：

### 2.1 作为函数参数：基本就是传指针

假设有：

```C++
void inc(int& x) {
     ++x; 
}  
int main() {
     int a = 10;
     inc(a); 
}
```

编译器常见的“心里默念的等价代码”是：

```C++
// 逻辑等价（粗略理解） 
void inc(int* x) {   
// 内部当作一个指针
     ++(*x); 
}
int main() {
     int a = 10;     
     inc(&a); 
    }
```

当然，实际函数签名还是 `void inc(int&)`，只是**在调用约定层面，传的是一个地址**：

- 汇编里，一般就是把 `a` 的地址放到一个寄存器/栈上；
    
- `inc` 里面用这个地址去读写内存。
    

所以：

- **引用参数传递 = 本质上传一个指针**；
    
- 但 **语言语义**把它包装成“别名”：你不用写 `*x`，直接写 `x`。
    

这就是为什么你会感觉：

- 引用像“按引用传参”；
    
- 指针是“传地址再手动解引用”。
    

底层都差不多，只是语法糖不同。

---

### 2.2 作为成员 / 局部变量：通常就是一个指针槽位

```C++
struct S {
     int a;     
     int& r; 
};  
int x; 
S s{42, x};
```

在大部分实现里：

- `S` 的大小 = `sizeof(int) + sizeof(int*)`（对 64 位就是 4 + 8）；
    
- `r` 这个成员**实际上存的就是一个地址**（指向某个 `int`）。
    

也就是说，你可以粗暴地当成：

`struct S_model {     int a;     int* r;   // 模型里的“实现”，实际语义是 int& };`

访问时：

`s.r = 100;      // 实际相当于：*(s.r_hidden_ptr) = 100;`

当然，编译器在优化时可能进一步把它“抹平”，直接用 `x` 的地址，甚至常量折叠掉，但从 ABI 的角度，**引用几乎就是一个隐藏的指针字段**。

---

### 2.3 `&r == &x` 是怎么实现的？

`int& r = x;` 时：

- 编译器在内部把 `r` 关联到“`x` 的地址”，
    
- 当你写 `&r` 时，语言规定“取引用的地址等同于取被引用对象的地址”，
    
- 所以它直接生成“拿出 `x` 的地址”。
    

抽象上相当于：

```C++
int x;
int* const r_impl = &x;  // 实现层的“引用”（不能改指向）

&x    // -> &x
&r    // 语义等价 -> r_impl (也就是 &x)

```

---

## 3. 为什么引用不能“重新绑定”，而指针可以？

从语言设计的角度其实很简单：

- 指针被设计成“可变的地址容器”；
    
- 引用被设计成“编译期确定的别名”。
    

如果你允许引用像指针那样改指向：

`int& r = a; r = &b;     // 如果这么写是改绑定，那所有语义都要乱套`

那么：

- 你就很难保证“引用一定有含义清晰的对象”；
    
- 很难在编译期做优化（因为谁都可能随时把引用改到别的对象）；
    
- 函数接口的语义也糊掉：
    
    - `void foo(int& x);` 到底表示“我要改这个对象”还是“你可以传进一个引用然后把它改指向别的对象”？
        

因此 C++ 的语义直接定死：

> **引用一旦绑定，就不能再重绑定。**

底层实现通常就是：

`int* const p = &x;  // 注意：const 放在 * 右边 → 指针自身不可改`

`int&` 的行为和“`int* const` + 语法糖”非常像。

---

## 4. const 引用绑定临时对象 & 延长生命周期：底层上做了什么？

这块是很多人觉得“很魔法”的地方。

`const std::string& s = std::string("hello") + " world";`

语言语义：

1. `std::string("hello") + " world"` 产生一个**临时对象**；
    
2. 因为我们用 **`const T&`** 来绑定这个临时，  
    标准规定：**临时对象的生命周期被延长到 `s` 的作用域结束**。
    

大致的“编译器心里模型”是：

```C++
{    
std::string __temp = std::string("hello")+"world";     const std::string& s = __temp;  // 绑定到这个隐藏临时     // ... 可以使用 s ... 
} // 这里 __temp 和 s 一起销毁
```

也就是说：

- 编译器会在栈上**实际生成一个临时对象 `__temp`**；
    
- 用它做 `s` 的底层 referent；
    
- 然后 `s` 就像普通引用一样，底层就是拿 `__temp` 的地址当成内部指针。
    

**为什么要这么设计？**

- 为了支持“高效传参”又不产生多余拷贝；
    
- 可以方便地写：
    
    `void foo(const std::string& s);  foo("hello");  // "hello" -> 临时 std::string -> 绑定到 const ref`
    
#### 具体一点
## 1. 先说“临时对象”是什么

看看这几种写法：

```C++
std::string s1 = "hello";          // 有名字的变量 s1 —— 左值 
std::string s2("world");          // 也是有名字的变量 —— 左值  
std::string temp = s1 + s2;       // s1 + s2 的结果是一个“临时对象” 
foo(std::string("hi"));           // std::string("hi") 也是临时对象 
foo(s1 + s2);                     // 这里 (s1 + s2) 的结果也是临时对象

```

这些 **没有名字、表达式算出来的一次性结果**，就是我们说的“临时对象”（prvalue）。

**正常情况下：**

> 临时对象的生命周期只活到这条“完整语句”的末尾（分号那里）就会被销毁。

比如：

`std::string("hello");   // 这条语句结束后，临时 string 就销毁了`

---

## 2. const 引用绑定临时对象 & 延长生命周期：到底干了啥？

看这句：

`const std::string& ref = std::string("hello");`

按“原始规则”，`std::string("hello")` 这个临时 string，语句结束就应该被销毁。但 C++ 有一条**特殊规则**：

> **如果用 `const T&`（const 左值引用）直接绑定一个临时对象，那么这个临时对象的生命周期会被延长到这个引用本身的生命周期结束。**

你可以想象编译器“脑补的一段代码”：

`{     std::string __temp("hello");        // 隐藏的临时变量     const std::string& ref = __temp;    // ref 是它的别名     // ... 在这个作用域里 ref 一直可用 ... } // 这里作用域结束，__temp 和 ref 一起销毁`

**这就叫“延长生命周期”**：  
原本 “只活到分号”，现在改成 “活到 ref 这个引用结束”。

---

## 3. 函数参数的例子：`string& a` vs `const string& a`

这也是你最关心的部分，我们用具体代码看差异。

### 3.1 函数签名：`void foo(std::string& s)`

`void foo(std::string& s) {     s += " world"; }`

这表示：

- 参数是一个**非常量左值引用**；
    
- 只能绑定到**一个已有的、非 const 的 std::string 变量**。
    

能怎么调用？

```C++
std::string x = "hello"; 
foo(x);              // ✅ OK，x 是一个 std::string 左值  
foo("hello");        // ❌ 不行，"hello" 是 const char[ ] 字面量，不是 std::string 左值 
foo(std::string("hello"));  // ❌ 不行，这是一个临时对象（右值），不能绑到非 const 左值引用
```

**关键点：**

> `std::string&` 参数 **只能接“真·变量”**，不能接临时对象 / 字面量 / const 对象。

---

### 3.2 函数签名：`void foo(const std::string& s)`

`void foo(const std::string& s) {     std::cout << s << "\n"; }`

现在参数是 **const 左值引用**，规则变了：

```C++
std::string x = "hello"; const std::string cx = "hi";  foo(x);                    // ✅ OK，可以绑定到普通变量 
foo(cx);                   // ✅ OK，可以绑定到 const 变量 
foo("hello");              // ✅ OK：隐式构造一个临时 std::string("hello") 绑定到 const 引用 foo(std::string("hello")); // ✅ OK：临时对象绑定到 const 引用 foo(x + cx);               // ✅ OK：表达式结果是临时 
std::string
```

这里就用到了刚才那条规则：

- 当你写 `foo("hello");` 时，实际过程是：
    
    1. 先构造一个临时 `std::string temp("hello");`
        
    2. 用 `const std::string& s` 绑定这个临时；
        
    3. 临时对象的生命周期被**延长到函数体结束**；
        
    4. `foo` 里正常读这个 `s` 完全没问题。
        

---

### 3.3 所以：两个函数签名本质上的区别是

1. **能接什么东西：**
    
    ```C++
    void f1(std::string& s);           // 只能接“可修改的变量” 
    void f2(const std::string& s);     // 可以接 变量 / const 变量 / 临时对象 / 字面量
    ```
1. **能不能改实参：**
    
    ```C++
    void f1(std::string& s) {     
    s += " world";       // ✅ 可以改原来的 string }  
    void f2(const std::string& s) {     
    s += " world";       // ❌ 不行，s 是 const 引用，只能读 
    }
    ```
    
    
2. **临时对象的生命周期差异：**
    
    - `std::string&` **不能**绑定临时对象 → 谈不上延长生命周期；
        
    - `const std::string&` 可以绑定临时 → 临时对象的生命周期自动延长到函数结束：
        
    
    `foo("hello");   // 参数是 const std::string& 时，这个临时 string 活到 foo 结束`
    

---

## 4. 再举一个“延长生命周期”的局部变量例子

```C++
const std::string& r = std::string("abc") + "def";  // 如果没有这条“延长生命周期”的规则： 
//   (std::string("abc") + "def") 这个临时在分号处就销毁了 
// 但因为被 const 引用 r 绑定： 
//   这个临时会活到 r 的作用域（大括号）结束
```

对比一下：

```C++
const std::string& r = std::string("abc") + "def"; 
std::cout << r << "\n";   // ✅ 合法，r 绑定的临时仍然存活  
// 如果你这么写： 
const std::string& r = std::string("abc") + "def"; //（然后不再使用 r） 
// 临时会跟 r 一起在作用域结束时析构
```

而如果没有绑定：

`std::string("abc") + "def"; std::cout << "done\n"; // 临时在上一行分号处就销毁了，你也没法再用它`

---

## 5. API 设计时的实际建议

### 5.1 什么时候用 `string&` 参数？

- 当函数的语义就是“**要修改这个 string 本身**”；
    
- 且你只打算接受**真·变量**（非 const、非临时）。
    

比如：

```C++
void to_lower(std::string& s) {     
for (auto& ch : s) {         
	ch = std::tolower(static_cast<unsigned char>(ch));     } 
}
```

调用时：

`std::string name = "Hello"; to_lower(name);         // ✅ name 被原地修改 to_lower("Hello");      // ❌ 不允许，对字面量没意义`

---

### 5.2 什么时候用 `const string&` 参数？

- 当函数只是**读取这个 string**，不需要修改；
    
- 并且你希望调用方式要足够灵活：
    
    - 变量可以传、字面量可以传、表达式结果可以传；
        

例如：

`void print(const std::string& s) {     std::cout << s << "\n"; }  print(name);               // ✅ print("hello");            // ✅ print(name + " world");    // ✅`

**这也是现代 C++ 的一个常用模式：**

> 对于“大对象（如 std::string、std::vector、你自己的类）”，  
> **只读参数优先用 `const T&`**，  
> 既避免拷贝，又方便接临时值、字面量。
---

## 5. 引用能不能“为空”？从语言 vs 底层看

标准上说：引用必须绑定到一个有效对象 → **不应该有“空引用”**。

但你可以这么干（典型作死写法）：

`int* p = nullptr; int& r = *p;   // 行为未定义（UB）`

底层实际就是：

- `p` = 0；
    
- `r` 内部指向地址 0；
    
- 之后任何对 `r` 的访问都会变成对地址 0 的访问——UB。
    

所以：

- **语言层面的声明**：“引用总是合法别名”；
    
- **底层实际上可以绕过这个保证**（只要你写 UB）。
    

这也是为什么标准一直强调：

> 不要通过未定义行为去推任何“实现细节”。

---

## 6. 引用 + 强制转换：底层其实就是改“解释方式”

你前面问到“引用与强制转换”，我们从底层视角再看几种典型情况。

### 6.1 `static_cast` 引用：不产生额外对象

```C++
struct Base { ... }; 
struct Derived : Base { ... };  
Derived d; 
Base& b = d;                        // 隐式 
upcast Base& b2 = static_cast<Base&>(d);   // 显式 upcast
```

这两种在底层几乎完全一样：

- 都是拿 `d` 的地址，
    
- 当成 `Base` 子对象的地址（有时需要加上一个 offset），
    
- 不会生成新对象。
    
##### 二、`static_cast` 是什么？

`static_cast` 是 C++ 四大显式强转之一，用来做各种 **“编译期可检查的、相对安全的”** 类型转换，比如：

- 基本类型之间：`double → int`；
    
- 指针/引用在继承层次里的转换（upcast / 某种 downcast）；
    
- `void* ↔ T*`；
    
- 调用显式构造函数 / 转换函数等。
    

语法：

`T target = static_cast<T>(expr);`

全部在编译期检查：

- 编译器会检查你要 cast 的类型之间有没有“合理的关系”（继承、可转换构造函数等）；
    
- **没有运行时检查**，运行时不会多做什么（除了可能指针加个偏移）。
- 偏移是什么：
## 1. 先看一个多重继承的例子

`struct Base1 {     int b1; };  struct Base2 {     int b2; };  struct Derived : Base1, Base2 {     int d; };`

在大多数 64 位实现里，一个 `Derived` 对象在内存中**大致**长这样（示意）：

`地址假设从 0x1000 开始： 
0x1000  
	┌────────────────────┐       
	│ Base1::b1          │  ← Base1 子对象（offset = 0） 
	└────────────────────┘
0x1004  
0x1004  ┌────────────────────┐       
	    │ Base2::b2        │  ← Base2 子对象（offset = 4）└────────────────────┘
0x1008
0x1008  ┌────────────────────┐        
		│ Derived::d         │  ← Derived 自己的成员（offset = 8）└────────────────────┘
0x100C  

（实际上还要考虑对齐、padding、vptr 等，但我们先忽略）

---

## 2. “原来它在哪？”——先看 `Derived*` 的位置

`Derived obj; Derived* pd = &obj;`

通常：

- `pd` 的值 = `&obj` = **对象起始地址**，也就是上图中的 **0x1000**。
    

你可以理解成：

`pd  = 0x1000  （指向整个 Derived 对象的开头 / 也就是第一个基类 Base1 子对象）`

---

## 3. `Base1*` 上行转换（upcast）：**不需要偏移**

`Base1* p1 = &obj;                  // 隐式 upcast Base1* p1b = static_cast<Base1*>(&obj);  // 显式 upcast，效果一样`

因为 `Base1` 是 **第一个基类**，它的子对象从 offset 0 开始，所以：

- `p1` 的值 = `0x1000`；
    
- 即：**`Base1*` 和 `Derived*` 指向同一地址**。
    

也就是：

`pd  = 0x1000 p1  = 0x1000   // 不偏移`

这时候你用 `p1->b1`，就是读写 0x1000 那个 int。

---

## 4. `Base2*` 上行转换：**这里才会“偏倚”**

关键来了：

`Base2* p2 = static_cast<Base2*>(&obj);`

C++ 语义上叫：把 `Derived*` **upcast** 到 `Base2*`。  
但在内存层面，**Base2 子对象不是从 0 开始的**，而是从 offset = `sizeof(Base1)` 开始（这里假设 `Base1` 只有一个 `int`，4 字节）。

所以 Base2 子对象在：

`Base2 子对象起始地址 = 0x1000 + sizeof(Base1) = 0x1000 + 4 = 0x1004`

因此 `static_cast<Base2*>(&obj)` 的效果是：

`pd  = 0x1000  (Derived* 指向对象开头) p2  = 0x1004  (Base2* 指向 Base2 子对象开头)`

这就是我说的“**指针会偏倚（有一个固定偏移）**”。

**回答你的问题：**

> 偏倚之前：它（`Derived*`）在对象的起始位置（0x1000）。
> 
> 偏倚之后：它（`Base2*`）被挪到了对象内部的某个位置（这里是 0x1004），  
> **恰好对齐到 Base2 子对象的开头**。

---

## 5. 为什么必须这么挪？不挪会怎样？

假设你用 **错误的方式**：

`Base2* bad = reinterpret_cast<Base2*>(&obj);  // ❌ 别这么干`

如果编译器没做任何偏移，`bad` 仍然是 `0x1000`。  
那么当你访问：

`bad->b2;`

编译器会认为 `b2` 在 `Base2` 子对象的 offset = 0 上，也就是读写 0x1000：

`0x1000  
┌────────────────────┐
	│ 这里实际上是 Base1::b1 │       
└────────────────────┘`

结果：

- 你以为在操作 `Base2::b2`；
    
- 实际上却在操作 `Base1::b1`；
    
- 严重违反类型系统，属于未定义行为（UB）。
    

而 `static_cast<Base2*>(&obj)` 会帮你做对的事情：

- 它知道 Derived 布局里，`Base2` 子对象的 offset 是 `sizeof(Base1)`；
    
- 所以把指针加上这个偏移，保证 `p2` 正好对齐到 Base2 子对象起始地址。
Downcast：

```C++
Base* pb = &d; 
Derived& dr = static_cast<Derived&>(*pb);  // 编译过，逻辑由你承担
```

底层其实就是 reinterpret `pb` 的值为 `Derived*`，**没有 runtime type check**，  
如果 `pb` 其实不是指向 `Derived`，就是 UB。

### 6.2 `const_cast` 引用：只改“类型上的 const 属性”

```C++
const int x = 10; 
const int& cr = x; 
int& r = const_cast<int&>(cr);
```

- 底层指针值没变，还是指向同一块内存；
    
- 只是告诉编译器：“我现在要把它视为非 const”；（也可以改变volatile视角[[C++ Volatile关键字]]）
    
- 如果原始对象真的是一个 `const int`，你通过 `r` 修改就是 UB。
    
如果底层不是const，就可以改：
典型安全场景：**对象本来不是 const，只是你现在手里拿的是一个 `const` 视图**。

例如：

```C++
void foo(int* p) {
     *p = 10;   // 正常改 
     }  
void bar(const int* p) {
     int* q = const_cast<int*>(p);     
     *q = 20;   // 是否安全取决于 p 指向的是否是“本来非 const”的对象 
}
```

如果这样用：

`int x = 0; bar(&x);  // 本体是一个非 const 的 int`

那么：

- `p` 指向的其实是一个“非 const 的 int”；
    
- 只是形参类型是 `const int*`；
    
- 这时候 `const_cast` 去掉 const 再改，是 **行为上安全的**（虽然风格上可能不太优雅）。
    

但如果：

`const int y = 0; bar(&y);     // 传进来的就是一个真实 const 对象`

那 `*q = 20;` 就又变成 UB 了。

> 所以你可以记一个原则：  
> **`const_cast` 只能“修饰视角”，不能违背“对象真实的 const 性质”。**
编译器大致处理成：

`int* p = const_cast<int*>(&x);  // 改掉类型里的 const 限定符`

### 6.3 `reinterpret_cast` 引用：纯类型视角的 reinterpret

`double d = 3.14; int& ri = reinterpret_cast<int&>(d);`

底层行为：

- 把 `&d` 当成 `int*` 来解读，只做比特级解释。
    
- `ri` 操作的内存就是 `d` 所在那几字节，只是用 `int` 的方式解释 / 读写。
- `reinterpret_cast` 允许的是：

- 指针 ↔ 指针
    
- 指针 ↔ 整数
    
- 引用 ↔ 引用（`reinterpret_cast<float&>(i)` 这种）
    
- 某些 enum/int 互转
    

像 `reinterpret_cast<float>(i)` 这种“把一个普通 int 直接变成 float 值”的，是不允许的。
    

**严格来说这是踩了 aliasing/UB 的大坑**，除非你非常清楚平台的布局和标准里的别名规则。
##### 例子
## 1. `reinterpret_cast` 只能用于指针吗？

**不是。** 它还能用于：

### (1) 引用之间的硬转

`int i = 42; double& dr = reinterpret_cast<double&>(i); // 编译可能过，但几乎必 UB`

> 注意：这种用法非常危险，解引用/使用通常 UB。

### (2) 指针 ↔ 整数

```C++
int* p = &i;
std::uintptr_t addr = reinterpret_cast<std::uintptr_t>(p); // 指针->整数
int* p2 = reinterpret_cast<int*>(addr);                  // 整数->指针
```

### (3) 不同对象指针之间

```C++
struct A{};
struct B{};
A* pa = nullptr;
B* pb = reinterpret_cast<B*>(pa);  // 只换“类型标签”
```

### (4) 函数指针之间（也很危险）

```C++
using F1 = void(*)(int);
using F2 = void(*)(double);
F1 f1 = nullptr;
F2 f2 = reinterpret_cast<F2>(f1);
```

所以它不“只限指针”，但**几乎都和“地址/比特级表示”相关**。

---

## 2. 转换时会考虑指针指向的内容吗？

**完全不会。**

`reinterpret_cast` 的本质是：

> **把同一段比特 / 同一个地址，用另一种类型“贴标签”。**

它不会：

- 检查内存里是不是那个类型
    
- 读取/转换内容
    
- 做边界/对齐/多态判断
    
- 做任何运行时验证
    

举个直观例子：

```C++
int i = 0x3f800000;              // 这串比特刚好是 float 1.0 的 IEEE754 表示
float* pf = reinterpret_cast<float*>(&i); // 只是把 &i 当 float* 看
```

这里 `reinterpret_cast` **不管 i 里到底是什么**。  
你如果解引用 `*pf`，结果取决于那串比特“恰好”能否被当 float 解释；  
而且这还可能触发 **严格别名/对齐** 的 UB。

-----
### 6. 4 `dynamic_cast<T>(expr)` — **运行时安全转型**

### ✅ 用于：

- 有虚函数的多态类之间的 **安全向下转型**
    
- 返回 nullptr 表示失败（指针版）
    
- 抛出 `bad_cast` 异常（引用版）
    

### 条件：

- 类型必须有虚函数（才能有 RTTI 支持）
    

### ✅ 示例：

```C++
class Base { public: virtual ~Base() {} };
class Derived : public Base {};

Base* b = new Derived();
Derived* d = dynamic_cast<Derived*>(b);  // 成功

```

### 引用形式（失败抛异常）：
```C++
try {
    Base& b = ...;
    Derived& d = dynamic_cast<Derived&>(b);
} catch (const std::bad_cast& e) {
    std::cerr << e.what() << "\n";
}

```
现代 C++ 强烈推荐使用：  
👉 明确写出用的是 `static_cast`、`const_cast` 等，读者/编译器一眼明了。

---

## 7. 一个“模型化理解”小总结（帮助你脑补编译器视角）

你可以把常见 C++ 代码，心里翻译成“伪 C”来理解引用的底层行为。比如：

`void foo(int& x) { x += 1; }  int main() {     int a = 10;     foo(a); }`

编译器视角（简化版模型）：

`void foo_impl(int* x) { *x += 1; }  int main() {     int a = 10;     foo_impl(&a); }`

再比如：

`struct S {     int a;     int& r; };  int x; S s{42, x};  s.r = 100;`

编译器视角模型：

`struct S_impl {     int a;     int* r;  // 实际存的是地址 };  int x; S_impl s = {42, &x};  // s.r = 100; 在语义上展开： *(s.r) = 100;`

而：

`const int& cr = 10; // 视角： int __temp = 10; const int& cr = __temp;`

> **语言层面：**  
> 引用 = 某个对象的“别名”，不会单独当对象看。  
> **实现层面（常见 ABI）：**  
> 引用 = 隐藏的“不能重指向的指针”，访问时自动解引用；再加上编译器某些情况下会把它完全优化掉。

理解了这两层，你再看各种“引用 + 强制转换”的组合、`std::move`/`std::forward` 这些基于引用玩的花活，底层就不会神秘了：  
本质上都在**改“这个地址的类型视角”和“这个地址的生命周期语义”**。