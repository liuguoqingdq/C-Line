### 一、CowString
### 1. 核心原理：它是如何工作的？

在 COW 机制下，当你复制一个字符串时（例如 `std::string s2 = s1;`），系统**不会**立即开辟新的内存并复制字符数据。相反，两个字符串对象会**共享**同一块内存缓冲区。

- **共享内存：** `s1` 和 `s2` 指向堆上的同一个字符数组。
    
- **引用计数：** 这块内存区域通常会维护一个“引用计数器”（Reference Count）。此时计数为 2。
    
- **延迟拷贝：** 只有当其中一个字符串试图**修改**内容（即“写”）时，系统才会检测到引用计数大于 1，此时才会真正分配新内存、复制数据，并将旧内存的引用计数减 1。
    

**优点：**

- **读取极快：** 如果只是传递字符串进行读取操作，几乎没有内存分配成本。
    
- **节省内存：** 多个相同的字符串只占用一份数据空间。
### 2. C++11 的转折点：COW 的终结

在 C++98/03 时代，GCC 的 libstdc++ 等主流标准库实现都广泛使用了 COW。但是，**C++11 标准实际上禁止了 COW 字符串的实现。**

虽然标准没有明文写着“禁止 COW”，但它对 `std::string` 的某些操作提出了新的要求，导致 COW 无法满足：

1. **迭代器失效规则：** C++11 规定，非 const 的 `operator[]` 不应导致迭代器失效。但在 COW 实现中，调用 `s[0]` 可能会触发“写时复制”（因为编译器无法区分你是要读还是写），从而分配新内存，导致旧的迭代器失效。
    
2. **并发性要求：** C++11 引入了多线程内存模型。为了在多线程环境下维护 COW 的引用计数，必须使用**原子操作**（Atomic Operations）。原子操作虽然比锁快，但在高并发场景下（多核 CPU）仍然有显著的性能开销，这抵消了 COW 带来的内存分配优势。
    

---

### 3. 为什么现代 C++ 放弃了它？

除了上述的标准限制，COW 在现代硬件架构下也显露出了一些严重的缺陷：

- **多线程性能杀手：** 即使是单纯的拷贝（增加引用计数），在多核环境下也需要原子操作，导致缓存同步和总线锁，性能反而下降。
    
- **不可预测的延迟：** 一个简单的“写”操作（如修改一个字符）可能偶尔会触发昂贵的内存分配和全量拷贝，导致程序性能抖动。
    
- **内存分配器的进步：** 现代内存分配器（如 jemalloc, tcmalloc）分配内存的速度已经非常快，COW 避免分配带来的收益变小了。

CowString使用代理设计模式解决二义性问题的完整代码实例：
```C++
#include <iostream>
#include <cstring>
#include <atomic> // 为了模拟真实场景，引用计数使用原子类型

class CowString {
private:
    // 内部结构体：真正存放数据和引用计数的地方
    struct SharedBlock {
        std::atomic<int> refCount; // 引用计数
        char* buffer;              // 字符数据
        size_t size;

        SharedBlock(const char* s) {
            size = std::strlen(s);
            buffer = new char[size + 1];
            std::strcpy(buffer, s);
            refCount = 1; // 初始计数为 1
        }

        ~SharedBlock() {
            delete[] buffer;
        }
    };

    SharedBlock* m_block; // 字符串对象只持有一个指针

    // 辅助函数：释放当前持有的引用
    void release() {
        // 计数减 1。如果减完后变为 0，则物理删除内存
        if (--m_block->refCount == 0) {
            delete m_block;
            std::cout << "    [内存释放] 销毁 SharedBlock\n";
        }
    }

public:
    // ==========================================
    // 核心：代理类 (Proxy Pattern)
    // ==========================================
    class CharProxy {
    private:
        CowString& m_str; // 归属的字符串对象
        size_t m_index;   // 访问的下标

    public:
        CharProxy(CowString& str, size_t index) : m_str(str), m_index(index) {}

        // 1. 【写操作】拦截：当发生赋值时 (s[0] = 'c')
        CharProxy& operator=(char c) {
            std::cout << "  [Proxy] 检测到写操作(赋值) -> ";
            // 关键：在这里触发写时复制
            m_str.fork_if_shared(); 
            // 执行真正的修改
            m_str.m_block->buffer[m_index] = c;
            return *this;
        }

        // 支持从另一个代理赋值 (s[0] = s[1])
        CharProxy& operator=(const CharProxy& other) {
            return this->operator=(static_cast<char>(other));
        }

        // 2. 【读操作】拦截：当需要转换为 char 时 (char c = s[0])
        operator char() const {
            std::cout << "  [Proxy] 检测到读操作(取值) -> 保持共享\n";
            return m_str.m_block->buffer[m_index];
        }
    };

    // ==========================================
    // CowString 的公共方法
    // ==========================================

    // 构造函数
    CowString(const char* s = "") {
        m_block = new SharedBlock(s);
    }

    // 拷贝构造 (浅拷贝 + 增加引用计数)
    CowString(const CowString& other) {
        m_block = other.m_block;
        m_block->refCount++;
        std::cout << "  [拷贝构造] 仅增加引用计数 (Count: " << m_block->refCount << ")\n";
    }

    // 赋值运算符 (浅拷贝)
    CowString& operator=(const CowString& other) {
        if (this != &other) {
            release(); // 释放旧的
            m_block = other.m_block;
            m_block->refCount++; // 增加新的
        }
        return *this;
    }

    // 析构函数
    ~CowString() {
        release();
    }

    // 核心逻辑：分离（Fork）
    // 如果引用计数 > 1，说明有人在共享，我需要把自己分离出去
    void fork_if_shared() {
        if (m_block->refCount > 1) {
            std::cout << "触发写时复制 (COW)!\n";
            
            // 1. 记录旧数据
            SharedBlock* oldBlock = m_block;
            
            // 2. 创建新块 (深拷贝数据)
            m_block = new SharedBlock(oldBlock->buffer);
            
            // 3. 旧块计数减 1
            oldBlock->refCount--;
        } else {
            std::cout << "独占状态，直接修改，无需复制。\n";
        }
    }

    // 重载 operator[] - 返回代理对象！
    CharProxy operator[](size_t index) {
        return CharProxy(*this, index);
    }

    // 对于 const 对象，不需要代理，直接返回 char (只读)
    char operator[](size_t index) const {
        return m_block->buffer[index];
    }

    const char* c_str() const { return m_block->buffer; }
    
    // 调试用：查看内部指针地址
    const void* raw_ptr() const { return m_block->buffer; }
};

// ==========================================
// 测试主程序
// ==========================================
int main() {
    std::cout << "=== 1. 初始化 s1 ===" << std::endl;
    CowString s1("Hello World");
    std::cout << "s1 地址: " << s1.raw_ptr() << "\n\n";

    std::cout << "=== 2. s2 = s1 (浅拷贝) ===" << std::endl;
    CowString s2 = s1;
    std::cout << "s1 地址: " << s1.raw_ptr() << "\n";
    std::cout << "s2 地址: " << s2.raw_ptr() << " (地址应相同)\n\n";

    std::cout << "=== 3. 读操作测试: char c = s1[0] ===" << std::endl;
    // 这里调用 operator[] 返回 CharProxy，然后隐式转换为 char
    char c = s1[0]; 
    std::cout << "读取到的字符: " << c << "\n";
    std::cout << "s1 地址: " << s1.raw_ptr() << " (地址应不变)\n\n";

    std::cout << "=== 4. 写操作测试: s2[0] = 'X' ===" << std::endl;
    // 这里调用 operator[] 返回 CharProxy，然后调用 CharProxy::operator=
    s2[0] = 'X'; 
    
    std::cout << "修改后 s2 内容: " << s2.c_str() << "\n";
    std::cout << "s1 地址: " << s1.raw_ptr() << "\n";
    std::cout << "s2 地址: " << s2.raw_ptr() << " (地址应已改变!)\n";

    return 0;
}
```


### SSO实现字符串
与简单的“指针指向内部或外部”不同，**真正的 SSO 为了节省内存，会使用 `union`（联合体）**，让“栈缓冲区”和“堆指针”共用同一块内存空间。

### 核心设计：内存重叠 (Memory Overlay)

在 64 位系统下，我们希望 `String` 对象本身的大小固定且尽可能小（通常是 24 或 32 字节）。

1. **Short 模式**：直接利用这 24 字节存字符。
    
2. **Long 模式**：利用这 24 字节存 `ptr`, `size`, `capacity`。
    

---

### C++ SSO 完整代码实例

C++

```C++
#include <iostream>
#include <cstring>
#include <algorithm>
#include <new> // for placement new if needed

class SSOString {
private:
    // 64位系统下，指针通常8字节。
    // 我们设定一个阈值，比如 15 字符。
    // 之所以是 15，因为我们需要 1 字节存 '\0'，且保持结构体内存对齐。
    static const size_t SSO_CAPACITY = 15;

    // 判别当前是长还是短，通常依赖 m_size。
    size_t m_size; 

    // 使用匿名 union 让 栈内存 和 堆元数据 共享空间
    union {
        // [短字符串模式]：直接存储字符
        // 大小：16字节 (15字符 + 1个结束符)
        char m_local[SSO_CAPACITY + 1];

        // [长字符串模式]：存储堆信息
        // 大小：16字节 (8字节指针 + 8字节容量)
        // 注意：m_size 放在外面公用，所以这里不需要再存 size
        struct {
            char* ptr;
            size_t capacity;
        } m_heap;
    };

public:
    // ==========================================
    // 构造与析构
    // ==========================================
    
    // 默认构造
    SSOString() : m_size(0) {
        m_local[0] = '\0'; // 默认短模式
    }

    // C风格字符串构造
    SSOString(const char* str) {
        size_t len = std::strlen(str);
        m_size = len;

        if (len <= SSO_CAPACITY) {
            // 【短模式】直接拷贝到成员变量 m_local
            std::memcpy(m_local, str, len + 1);
        } else {
            // 【长模式】分配堆内存
            m_heap.capacity = len;
            m_heap.ptr = new char[len + 1];
            std::memcpy(m_heap.ptr, str, len + 1);
        }
    }

    // 拷贝构造 (深拷贝)
    SSOString(const SSOString& other) {
        m_size = other.m_size;
        if (other.is_short()) {
            std::memcpy(m_local, other.m_local, m_size + 1);
        } else {
            m_heap.capacity = other.m_heap.capacity;
            m_heap.ptr = new char[m_heap.capacity + 1];
            std::memcpy(m_heap.ptr, other.m_heap.ptr, m_size + 1);
        }
    }

    // 移动构造 (Move Constructor) - 性能关键点！
    SSOString(SSOString&& other) noexcept {
        m_size = other.m_size;
        
        if (other.is_short()) {
            // 【短模式移动】：无法偷指针，只能拷贝数据（memcpy很快）
            // 因为数据在 other 的栈内存里，偷不走
            std::memcpy(m_local, other.m_local, m_size + 1);
        } else {
            // 【长模式移动】：直接偷走堆指针
            m_heap.ptr = other.m_heap.ptr;
            m_heap.capacity = other.m_heap.capacity;
            
            // 将源对象置空，防止 double free
            other.m_heap.ptr = nullptr;
            other.m_size = 0;
            other.m_local[0] = '\0'; // 让 other 变回安全的空短字符串
        }
    }

    // 析构
    ~SSOString() {
        if (!is_short()) {
            delete[] m_heap.ptr;
            std::cout << "  [析构] 释放堆内存\n";
        }
    }

    // ==========================================
    // 赋值操作
    // ==========================================
    SSOString& operator=(const SSOString& other) {
        if (this == &other) return *this;
        
        // 简单粗暴写法：先清理自己，再拷贝
        if (!is_short()) delete[] m_heap.ptr;

        m_size = other.m_size;
        if (other.is_short()) {
            std::memcpy(m_local, other.m_local, m_size + 1);
        } else {
            m_heap.capacity = other.m_heap.capacity;
            m_heap.ptr = new char[m_heap.capacity + 1];
            std::memcpy(m_heap.ptr, other.m_heap.ptr, m_size + 1);
        }
        return *this;
    }

    // ==========================================
    // 辅助方法
    // ==========================================
    
    bool is_short() const {
        return m_size <= SSO_CAPACITY;
    }

    const char* c_str() const {
        return is_short() ? m_local : m_heap.ptr;
    }

    size_t size() const { return m_size; }
    
    // 调试：打印内部信息
    void debug_info() const {
        std::cout << "String: \"" << c_str() << "\"\n";
        std::cout << "  Size: " << m_size << "\n";
        std::cout << "  Mode: " << (is_short() ? "Short (Stack/Local)" : "Long (Heap)") << "\n";
        // 打印数据存放的地址，证明是在对象内还是对象外
        printf("  Data Addr: %p\n", (void*)c_str());
        printf("  Obj  Addr: %p\n", (void*)this);
        std::cout << "-----------------------\n";
    }
};

int main() {
    std::cout << "=== 1. 短字符串测试 (SSO) ===\n";
    // "Hello" 长度为5，小于15，存在 local buffer
    SSOString s1("Hello");
    s1.debug_info();

    std::cout << "\n=== 2. 长字符串测试 (Heap) ===\n";
    // 长度超过15，触发 new allocation
    SSOString s2("This is a very long string that triggers heap allocation");
    s2.debug_info();

    std::cout << "\n=== 3. 移动语义测试 ===\n";
    std::cout << ">> 移动长字符串 (偷指针):\n";
    SSOString s3 = std::move(s2); // 调用移动构造
    s3.debug_info();
    // 此时 s2 应该是空的或者安全的
    
    std::cout << ">> 移动短字符串 (拷贝内存):\n";
    SSOString s4 = std::move(s1);
    s4.debug_info();

    std::cout << "\n=== 4. 内存大小 ===\n";
    // 验证对象本身的大小（不包含堆内存）
    // size_t(8) + union(16) = 24 字节 (可能会因为对齐变成 24 或 32)
    std::cout << "sizeof(SSOString): " << sizeof(SSOString) << " bytes\n";

    return 0;
}
```

### 关键技术点解析

#### 1. `union` 的妙用（内存压缩）

请注意这段代码：

C++

```
union {
    char m_local[SSO_CAPACITY + 1]; // 16 bytes
    struct {
        char* ptr;        // 8 bytes
        size_t capacity;  // 8 bytes
    } m_heap;             // Total 16 bytes
};
```

在 C++ 对象布局中，`m_local` 和 `m_heap` 占用的是**同一块内存地址**。

- 如果字符串短，这块内存里存的是 `'H', 'e', 'l', 'l', 'o', '\0' ...`
    
- 如果字符串长，这块内存里存的是 `0x000060000... (堆地址)` 和 `100 (容量)`。
    
- 这种设计使得 `SSOString` 对象的大小固定且紧凑（通常是 `sizeof(size_t) + 16` = 24 字节）。
    

#### 2. 移动语义 (Move Semantics) 的差异

这是面试中的高频考点：

- **Move 长字符串**：非常快。只需要拷贝两个整数（指针和容量），并将源对象的指针置空。这是 $O(1)$ 操作。
    
- **Move 短字符串**：**必须拷贝字符**。因为数据存储在源对象本身的栈内存里，你不能“偷走”栈内存，只能把数据复制到新对象的栈内存里。虽然是复制，但因为有 CPU 缓存（L1 Cache）且长度短（<16字节），速度依然极快。
    

#### 3. 为什么不需要 COW 的代理模式？

在这个实现中，`operator[]`（虽然我没写，但逻辑很简单）直接返回 `char&`：

C++

```
char& operator[](size_t idx) {
    return is_short() ? m_local[idx] : m_heap.ptr[idx];
}
```

因为内存是独立的（不共享），所以无论你是读 `s[0]` 还是写 `s[0] = 'x'`，都不需要检查引用计数，也不需要分离内存。**读写歧义问题在 SSO 模型下根本不存在。**