## 1. C++ 里拷贝是怎么触发的？
[[深拷贝与浅拷贝联系题]]
拷贝操作主要有两种形式：

1. **拷贝构造函数**：用一个已存在对象构造新对象
    
```C++
class A {
		public:
	    A(const A& other);  // 拷贝构造
				};

A a;
A b = a;    // 调用拷贝构造
A c(a);     // 调用拷贝构造

```
    
2. **拷贝赋值运算符**：一个已经存在的对象被另一个对象赋值
    
```C++
class A {
public:
    A& operator=(const A& other);  // 拷贝赋值
};

A a, b;
b = a;    // 调用拷贝赋值

```
    

如果你不自己写，编译器会给你**默认版本**（默认成员赋值/拷贝）。

---

## 2. 编译器默认的拷贝：成员“逐个拷贝”（通常是浅拷贝）

看一个简单的类：

`class Foo { public:     int x;     double y; };`

对这种类，默认拷贝是这样的：

`Foo a{1, 3.14}; Foo b = a;     // b.x = a.x, b.y = a.y`

因为都是内置类型，**成员逐个拷贝本身就是合理的“深拷贝”**。

但如果类里有 **指针成员**，情况就变味了：

```C++
class Buffer {
 public:
      int* data;     
      std::size_t size;
       };
```

默认拷贝等价于：

```C++
Buffer::Buffer(const Buffer& other)
    : data(other.data), size(other.size) {}

Buffer& Buffer::operator=(const Buffer& other) {
    data = other.data;
    size = other.size;
    return *this;
}

```

**注意：这里只是把指针值复制了一份，两个对象指向同一块内存。**  
这就是典型的“浅拷贝”。
[[C++ this指针]]

---

## 3. 浅拷贝（shallow copy）具体会出什么问题？

假设：

```C++
class Buffer {
public:
    int* data;
    std::size_t size;

    Buffer(std::size_t n)
        : data(new int[n]), size(n) {}

    ~Buffer() {
        delete[] data;
    }
    // 拷贝构造/赋值 都用默认的（浅拷贝）
};
```

使用：

```C++
int main() {
    Buffer a(10);   // a.data 指向一块堆内存
    Buffer b = a;   // 浅拷贝：b.data == a.data

    // 程序结束时：
    // 先析构 b：delete[] b.data
    // 再析构 a：delete[] a.data  （同一块内存再 delete 一次） → 未定义行为（double free）
}
```
典型问题：

- **double free / 野指针**：两个对象共享同一块内存，但各自析构时都 `delete[]` 一次。
    
- 对一个对象修改 `data[i]`，另一个对象看到的内容也变了，本来你可能不想共享。
    

所以：

> 一旦类里有“自己负责释放”的资源（裸指针、文件句柄、socket 等），**默认浅拷贝往往是有毒的**，你要么：
> 
> - 禁止拷贝（`= delete`），要么
>     
> - 自己实现“深拷贝”。
>     

---

## 4. 深拷贝（deep copy）该怎么写？

目标：**每个对象有自己独立的一份资源**。

延续上面的 `Buffer` 类，写一个深拷贝：

```C++
class Buffer {
public:
    int* data;
    std::size_t size;

    Buffer(std::size_t n)
        : data(new int[n]), size(n) {}

    ~Buffer() {
        delete[] data;
    }

    // 深拷贝构造
    Buffer(const Buffer& other)
        : data(new int[other.size]), size(other.size) {
        std::copy(other.data, other.data + size, data);
    }

    // 深拷贝赋值
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            // 1. 先释放自己原来的资源
            delete[] data;

            // 2. 分配新资源并复制
            size = other.size;
            data = new int[size];
            std::copy(other.data, other.data + size, data);
        }
        return *this;
    }
};

```

现在：

`Buffer a(10); Buffer b = a;   // b 拷贝一份自己的 data b.data[0] = 42; // 修改 b，不会影响 a`

**关键点：**

- 拷贝构造：分配新资源并复制内容；
    
- 拷贝赋值：注意**先释放旧资源，再分配新资源**（或者用“拷贝-交换”习惯用法避免异常问题）。
    

---

## 5. STL 容器的拷贝：对你来说是“深拷贝”

很多人会问：那 `std::vector<int>` 拷贝呢，是深的还是浅的？

```C++
std::vector<int> v1 = {1,2,3};
std::vector<int> v2 = v1;  // v2 拥有自己的堆内存
v2[0] = 100;
```

对 `vector` 自己内部来说，它也有指针指向堆内存，但：

- 它自己实现了拷贝构造/拷贝赋值，**会为每个 `vector` 分配独立的堆空间并拷贝元素**。
    
- 所以从用户角度看：**`vector` 拷贝是“深拷贝”**。
    

同理 `std::string`, `std::map` 等标准容器。

---

## 6. 跟移动语义的关系（顺带帮你串一下）

有了深拷贝之后，通常你还会顺便写“移动构造/移动赋值”，避免没必要的深拷贝消耗：

```C++
class Buffer {
public:
    // ... 深拷贝那一套

    // 移动构造
    Buffer(Buffer&& other) noexcept
        : data(other.data), size(other.size) {
        other.data = nullptr;
        other.size = 0;
    }

    // 移动赋值
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] data;       // 先释放自己
            data = other.data;
            size = other.size;
            other.data = nullptr;
            other.size = 0;
        }
        return *this;
    }
};//可以用std::move来夺取控制权，或者Buffer(...)

```

**深拷贝**：复制一份资源（耗时但安全）。  
**移动**：直接“抢走”对方的资源指针，置空对方（快）。
[[C++ 运算符函数形式]]
所以一整套就是 “Rule of 5”：  
拷贝构造 + 拷贝赋值 + 移动构造 + 移动赋值 + 析构。

---

## 7. 总结一下差异（给你一个对照表）

|项目|浅拷贝（默认）|深拷贝（你自己写）|
|---|---|---|
|行为|成员值逐个拷贝；指针只拷贝地址|为每个对象分配独立资源，并复制内容|
|适用场景|成员全是值类型 / 已经自己管理好的对象（`string` 等）|类自己直接管理原始资源（`new` / 文件句柄等）|
|风险|双重释放、悬空指针、共享状态|拷贝成本较高|
|实现者|编译器自动生成|需要你写拷贝构造和拷贝赋值|
|与移动关系|不写移动则大对象频繁拷贝很慢|深拷贝+移动一起写体验最佳（复制少，用时移动）|

---