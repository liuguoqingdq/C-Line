## 0. 一句话定义

**字符串 IO 流**就是：在内存里用一个 `std::string` 当缓冲区，把它当成 `cin/cout/fstream` 那样用 `>> / << / getline / seek / tell` 来**解析、格式化、构造字符串**。

对应头文件：`#include <sstream>`  
底层缓冲：`std::stringbuf`（属于 `streambuf` 家族）

---

## 1. 类族与定位（要记牢这 3 个）

|类|作用|类比|
|---|---|---|
|`std::istringstream`|从字符串读（解析）|`ifstream/cin`|
|`std::ostringstream`|向字符串写（拼接/格式化）|`ofstream/cout`|
|`std::stringstream`|同时读写|`fstream`|

它们都继承自 iostream 系列，所以接口和语义与文件/控制台流一致。

---

## 2. 用法体系（按“读”和“写”两大类）

### 2.1 从字符串读：`istringstream`

**典型用途：把一行文本解析成结构化数据。**

```C++
#include <sstream>
#include <string>
#include <iostream>
using namespace std;

int main() {
    string line = "42 3.14 Alice";
    istringstream iss(line);

    int id; double score; string name;
    iss >> id >> score >> name;  // 跳空白、按类型读

    cout << id << " " << score << " " << name << "\n";
}

```
只不过输入源变成了 `line`。

---

### 2.2 按分隔符拆字段：`getline(iss, ..., delim)`

这其实是**非格式化读取**，常用于 CSV/日志拆字段：

```C++
string csv = "tom,18,student";
istringstream iss(csv);

string name, age, role;
getline(iss, name, ',');
getline(iss, age, ',');
getline(iss, role, ',');

cout << name << " " << age << " " << role << "\n";

```

**对比：**

- `>>`：按空白分隔、会跳过前导空白
    
- `getline`：按指定分隔符分隔、不跳空白
    

---

### 2.3 向字符串写：`ostringstream`

**典型用途：复杂格式拼接（比 `+` 好维护）**

```C++
ostringstream oss;
oss << "id=" << 7 << ", score=" << 9.5;
string out = oss.str();  // 取结果
```

你可以用所有 `iomanip` 控制输出格式：

```C++
#include <iomanip>
ostringstream oss;
oss << fixed << setprecision(2) << 3.14159; // "3.14"
```

---

### 2.4 读写同一个缓冲：`stringstream`

```C++
stringstream ss;
ss << 10 << " " << 20;

int a, b;
ss >> a >> b;    // 从内部字符串再解析出来
```

常用于：写一段格式化内容后又要再解析、或临时做“中间缓冲”。

---

## 3. 状态位与检查（和 `cin` 一模一样）

字符串流也有 `good/eof/fail/bad`：

```C++
istringstream iss("12 abc");

int x;
iss >> x;            // 成功
if (iss.fail()) { }  // false

iss >> x;            // 再读 int 会失败（遇到 abc）
if (iss.fail()) {    // true
    iss.clear();     // 清状态
}
````

> 状态位会记录在 `basic_ios::rdstate_` 里  
> 你之前学的那套流状态在这里完全适用。

---

## 4. 读写指针（seekg/seekp/tellg/tellp）

`stringstream` 也有两套指针：

- **get 指针（读）**：`seekg / tellg`
    
- **put 指针（写）**：`seekp / tellp`
    

```C++
stringstream ss("abc def");

ss.seekg(0, ios::beg);   // 读指针回到开头
string a;
ss >> a;                 // a="abc"
```

写指针例子：

```C++
stringstream ss;
ss << "hello";
auto p = ss.tellp();     // p=5
ss.seekp(0, ios::beg);
ss << "H";               // 变成 "Hello"
```

---

## 5. 底层机制（把它和你学的文件流一样串起来）

### 5.1 结构图

```C++
istringstream / ostringstream / stringstream
          |
   basic_istream / basic_ostream / basic_iostream
          |
       basic_ios  (width、fmtflags、rdstate、tie...)
          |
   rdbuf_  --->  std::stringbuf  --->  std::string 内存

```

- **`rdbuf_` 指向 `stringbuf`**
    
- `stringbuf` 维护一段 `std::string` 作为缓冲
    
- `>> / << / getline / seek` 都是在操作这块内存
    

### 5.2 为什么 `>>` 会跳空白？

原因与你之前理解的 `cin >>` 一样：  
格式化输入会创建 `sentry`，看 `skipws` flag 并跳过空白，然后用 locale facet 解析。

所以字符串流的“格式化语义”完全继承 iostream 的设计。

---

## 6. 什么时候用它？什么时候不要用它？

### 6.1 适合用 stringstream 的场景

1. **解析一行结构化文本**（日志/配置/命令输出）
    
2. **快速把多类型格式化成字符串**
    
3. **需要复用 iostream 的解析规则**
    
4. **需要 `iomanip` 做复杂格式控制**
    

### 6.2 不太适合的场景

1. **极限性能的数值转换**  
    `stringstream` 走 locale/facet 会慢。
    
2. **超大规模拼接**  
    更快的是 `string.reserve + append`。
    
3. **明确的简单转换**  
    用 `std::stoi / stod / to_string / from_chars / fmt` 更直接。
    

---

## 7. 性能与替代手段（你做工程要知道）

### 7.1 数字 <-> 字符串

- **最快（C++17）**：`std::from_chars / to_chars`
    
- **简单易用**：`std::stoi / stod / to_string`
    
- **格式化强、现代**：`std::format`（C++20）或 `{fmt}`
    

`stringstream` 更像是“通用瑞士军刀”，但不是最快。

### 7.2 大量字符串拼接

- `ostringstream`：好写、可读性高
    
- `string reserve + append`：性能更极致
    

---

## 8. 常见坑（高频）

1. **复用同一个 stringstream 前要清两样：内容+状态**
    

```C++
stringstream ss;
ss << "1 2";
int x; 
ss >> x;   // ok

ss.str("");       // 清内容
ss.clear();       // 清 fail/eof 状态
```

2. **`>>` 不会读取空格后的内容**  
    读整段带空格文本要用 `getline`。
    
3. **CSV 不要指望 `>>`**  
    CSV 需要分隔符解析，用 `getline(iss, field, ',')`。
    
4. **不要把它当高速通道**  
    它是语义正确的解析器，不是极限性能工具。
    

---

## 9. 一个“解析+校验”典型模板

```C++
bool parse_line(const string& line, int& a, double& b, string& c) {
    istringstream iss(line);
    if (!(iss >> a >> b >> c)) return false; // 至少三字段
    if (!iss.eof()) return false;            // 还有多余垃圾
    return true;
}
```

这就是用“流状态+EOF”做严格格式校验的标准手法。